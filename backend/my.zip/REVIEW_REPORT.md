# STARX24 Project Review

**Review date:** 2026-10-02  
**Archive:** `my.zip`  
**Scope:** Android source, Firebase Realtime Database rules, Node.js payment backend, build/dependency setup, secrets exposure and documentation consistency.

## Executive summary

The archive contains a substantial Android tournament application with user, admin and messenger product flavors, Firebase Auth/Realtime Database/Storage/Messaging integration, and a Node.js payment backend. The general architecture is understandable and the backend does verify Firebase ID tokens for money-moving endpoints.

However, I would **not deploy this package as-is for real-money production use**. There are multiple high-severity issues in Firebase rules and backend money flows that can cause wallet corruption, duplicate refunds/withdrawals, and privacy exposure. The Android build could not be compiled in this sandbox because no Android SDK is installed; the project itself does not currently provide a reproducible CI/build check.

## Findings

### CRITICAL-1 — User can directly modify their own wallet balance

**File:** `database.rules.json` (`/users/$uid/wallet/balance`)

The child rule allows the authenticated user to write their own balance, with validation that the new value is numeric, non-negative, and lower than the old value. This means a player can directly set their balance to any smaller value, bypassing the backend ledger and transaction history.

Even if this cannot increase the balance, it breaks the server's accounting invariant: the database balance and the immutable server-side ledger can diverge. It can also interfere with simultaneous backend debit/refund transactions.

**Fix:** remove the user write permission for `wallet/balance` entirely. Wallet balance, locked amount, pending debit and wallet transaction records should be writable only through trusted backend/Admin SDK paths. If a client needs to submit an intent, create a separate request node with strict user ownership and no balance fields.

### CRITICAL-2 — `leaveMatch` can refund the same paid join more than once

**File:** `backend/index.js` (`/leaveMatch`, around line 2309 onward)

The endpoint reads the participant record, then later removes it and credits the refund. Two concurrent requests can both read the same participant before either removal is visible. Both can then refund the same entry fee. The endpoint has no atomic claim/state transition such as `REGISTERED -> LEAVING` before refunding.

**Fix:** atomically claim the participant using a transaction, or use a single server-side settlement record with an idempotency key. Only the request that successfully changes the record from `REGISTERED` to `LEAVING/LEFT` may release slots and issue a refund. Refund ledger IDs must be deterministic and written/claimed atomically.

### CRITICAL-3 — Multiple withdrawal requests can pass the “one pending request” check

**File:** `backend/index.js` (`/requestWithdrawal`, around line 1238 onward)

The code first queries all withdrawals and checks for a pending record, then separately debits the wallet and creates a new request. Two concurrent requests can both observe “no pending request” and both proceed. The wallet debit is transactional, but the one-pending invariant is not atomically represented in Firebase.

**Fix:** maintain an atomic per-user withdrawal lock/current-pending record and claim it with a transaction before debit, or create a deterministic per-user request key that can be claimed only once. Ensure every failed path releases the claim exactly once.

### HIGH-4 — Any authenticated user can read tournament participant and slot data

**File:** `database.rules.json`

The following paths are broadly readable by any signed-in user:

- `/tournaments/$matchId/participants`
- `/tournaments/$matchId/participants/$uid`
- `/tournaments/$matchId/slotIndex`
- `/matches/$matchId/participants/$uid`

Participant records contain game UID/name and slot information. Depending on the product's privacy expectation, this lets one player enumerate other players' gaming identifiers and registration data.

**Fix:** restrict participant reads to the participant themselves, authorized match/admin roles, or a sanitized public projection containing only the fields needed for the UI. Keep private game credentials and identifiers in a separate restricted subtree.

### HIGH-5 — Client can forge wallet transaction history and notifications

**File:** `database.rules.json`

`/users/$uid/wallet/transactions/$txId` allows the user to write their own record and validates only a few basic fields. A user can create arbitrary fake `type`, `title`, `amount`, and `status` records. Similarly, `/users/$uid/notifications/$id` allows the user to write their own notification record with only a title requirement.

This is dangerous for auditability and can mislead the wallet UI/support team even when the actual balance is not increased.

**Fix:** make wallet transaction records and server-generated notifications backend-only. If users need to acknowledge/read a notification, allow only a narrow `read`/`readAt` child update, not arbitrary record creation.

### HIGH-6 — Dependency lockfile is not reproducible

**Files:** `backend/package.json`, `backend/package-lock.json`

`npm ci --omit=dev` fails because the lockfile is out of sync with `package.json`:

```text
Missing: undici@6.29.0 from lock file
```

This will break clean Render/CI deployments that use `npm ci`.

**Fix:** from `backend/`, run `npm install --package-lock-only` (or update the lockfile using the intended Node/npm version), review the diff, then run `npm ci --omit=dev` and `npm audit` in CI.

### HIGH-7 — No Android build verification in the supplied environment

The Gradle wrapper downloaded successfully, but `./gradlew assembleUserDebug --no-daemon` stopped before compilation because the environment has no Android SDK and the archive has no CI configuration to supply one:

```text
SDK location not found. Define a valid SDK location with ANDROID_HOME ...
```

This does not prove the Java/resources fail, but it means the package is currently unverified here.

**Fix:** add CI (for example GitHub Actions) with JDK 17, Android SDK platform 34/build tools, and tasks for `assembleUserDebug`, `assembleAdminDebug`, and backend `npm ci`/tests.

### MEDIUM-8 — Admin key records are too broadly readable

**File:** `database.rules.json`

`/admin_keys/$key` has `.read: auth != null`. Any authenticated user who knows or obtains a key identifier can read its role/active/perms record. The admin session/key design also duplicates authorization logic across Firebase rules, the Android app and the backend.

**Fix:** make admin key records readable only to the owner/master admin or the specific authenticated admin session that needs its own record. Prefer Firebase custom claims or a backend-issued short-lived admin authorization model for sensitive actions.

### MEDIUM-9 — Sensitive data appears in normal user-readable match trees

Room IDs/passwords and participant details are stored in broad tournament/match objects and are also loaded by admin/message screens. The rules need a clear “room released and this user is a participant” condition before exposing room credentials. A scheduled/scrub job is not a substitute for restrictive read rules.

**Fix:** store room credentials in a restricted subtree and expose them only after release to the registered participant UID. Avoid relying on client-side hiding.

### MEDIUM-10 — Documentation and package contents contradict each other

`README.md` describes APKs under `apk/` as included, while `SOURCE_PACKAGE_NOTE.md` says APKs are intentionally excluded. The README also describes a white/professional theme while the build instructions describe a “Type 5 Luxury White Theme”; the reference redesign notes describe a different blue-grey/electric-blue direction.

**Fix:** publish one canonical README with the actual archive contents, exact flavor names, deployment prerequisites, current backend URL, Firebase project setup, and a clear release/debug signing status.

### LOW-11 — No automated tests were found

There are no unit, instrumentation, backend integration, or Firebase Emulator tests in the archive. `RULES_EMULATOR_PROOF.txt` is useful evidence, but it is not an executable regression suite.

**Fix:** add tests for:

- paid/free join authorization and slot races;
- duplicate join, duplicate leave and duplicate withdrawal requests;
- wallet debit/refund idempotency;
- Firebase rules for normal user/admin/other-user access;
- webhook replay and `verifyOrder` idempotency.

### LOW-12 — Release hardening is incomplete

The documentation states the APKs are debug-signed. `minifyEnabled false` is also configured for release. That is acceptable for testing but not Play Store production distribution.

**Fix:** use a protected release keystore outside the repository, enable release shrinking/obfuscation after mapping validation, configure Play App Signing, and remove debug-only URLs/logging from release builds.

## Positive observations

- Backend money endpoints generally require and verify Firebase ID tokens.
- Admin endpoints use a shared `requireAdmin` middleware and role/permission checks.
- Paid join has server-side fee calculation and transaction-based slot/wallet operations.
- ZapUPI secret and Firebase service-account configuration are intended to remain server-side.
- The root Firebase rules default to deny (`/.read: false`, `/.write: false`), which is a good baseline.
- The archive includes deployment/build notes and a rules-proof document, which will help turn the review into regression tests.

## Recommended order of work

1. **Immediately lock wallet balance, wallet transactions and notifications against client writes.**
2. **Make leave/refund and withdrawal request flows idempotent and atomically claimable.**
3. **Restrict participant, slot and room-secret reads.**
4. Regenerate/update `backend/package-lock.json`; verify clean install.
5. Add Firebase Emulator + backend concurrency tests.
6. Add CI with Android SDK and Node checks.
7. Reconcile README/package contents and then produce a release-signed build.

## Validation performed

- ZIP extracted successfully: 752 entries.
- JSON parse checks: `database.rules.json` parses successfully; `google-services.json` is present.
- Static scan: no Firebase service-account private key file or obvious OpenAI/Stripe private key was found; the Firebase web API key in `google-services.json` is normally a client identifier, not a service-account secret.
- Backend clean install: failed due to package-lock/package.json mismatch (`undici@6.29.0`).
- Android build attempt: reached Gradle but failed before compilation because Android SDK was not available in the sandbox.
- Source inventory: 96 Java files, 558 Android resource files, 0 actual automated test files found.
