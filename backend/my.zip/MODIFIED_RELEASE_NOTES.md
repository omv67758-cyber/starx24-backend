# STARX24 / STARX24 Modified Release Notes

This package contains the targeted admin and user-flow fixes applied in this pass.

## Implemented

- Duo and other team matches now allow a player to claim **one slot or up to the configured team size**. Solo matches retain their single-slot behavior; the backend and Android client enforce the same limit.
- Global admin device notifications now write both the in-app notification history and the backend `broadcast_notifications` queue. The backend worker can therefore deliver FCM pushes instead of only showing an admin success toast.
- Admin room-release pushes now use the authenticated backend relay. The Android app no longer tries to load or ship a Firebase service-account private key.
- FCM relay requests now include the currently signed-in Firebase ID token, so `/admin/sendPush` can authenticate the admin correctly.
- Withdrawal approval/rejection already routes through the backend and sends the user an in-app notice plus a device push when the user has a valid FCM token.
- The existing admin workspaces remain available for categories, banners, matches, room control, payments, users/moderation, reports, notifications, roles, and app settings.

## Required before production

1. Configure `backend.base.url` with the final deployed HTTPS backend URL when building the APK.
2. Configure the backend environment variables: `FIREBASE_SERVICE_ACCOUNT` (or base64 form), `FIREBASE_DATABASE_URL`, `ZAPUPI_KEY`, `ZAPUPI_MODE`, and `PUBLIC_BASE_URL`.
3. Deploy `database.rules.json` and verify the Firebase project matches `google-services.json`.
4. Build with JDK 17 and Android SDK/Build Tools installed.
5. On Android 13+, grant notification permission on each test device.
6. Verify an admin Firebase account has an active role/session before testing push, withdrawal approval, or moderation actions.

No payment secret, Firebase Admin private key, or release-signed APK is included in this source package.
