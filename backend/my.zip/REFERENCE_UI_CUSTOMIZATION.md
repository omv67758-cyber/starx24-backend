# STARX24 Reference UI Customization

This source is customized against the supplied STARX24 reference screens. It preserves the existing authentication, Firebase, tournament, wallet, payment, notification, and bottom-navigation flows while updating the visual system.

The UI uses a warm-white canvas, charcoal typography, metallic-gold accent colors, rounded white cards, gold ribbon details, manual drawable symbols, high-contrast headings, and gold active navigation states. The home header now uses the STARX24 brand label; the wallet header follows the STARX24 / WALLET / EARN structure; and the wallet balance card uses a dark charcoal surface with a gold border and coin icon.

The leaderboard uses the reference structure: gold segmented period control, three silver/gold/bronze podium columns, a centered winner logo, score pills, visible rank numbers, manual profile/trophy symbols, and highlighted ranked rows.

The source ZIP is intended to be reviewed and customized before APK generation. No APK is included in this delivery.

## Build later

```bash
./gradlew assembleUserDebug
```

The Android project is a flat root module. Use JDK 17 and compile SDK 34. If the SDK is not detected, add a root `local.properties` file with a machine-specific `sdk.dir` value; this file is intentionally excluded from the ZIP.
