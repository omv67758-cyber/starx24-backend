from pathlib import Path

p = Path('/home/ubuntu/work/backend/index.js')
s = p.read_text()

# Deposit credits must never increase the withdrawable winnings ledger.
s = s.replace('    wallet.balance = currentBalance + Number(order.amount);\n', '    wallet.balance = currentBalance + Number(order.amount);\n    // Deposits are playable only; they are never withdrawable.\n    wallet.withdrawableBalance = Math.max(0, Number(wallet.withdrawableBalance || 0));\n', 1)

# Join match: spend deposit balance first, then winnings; remember the winnings portion for rollback/refund.
s = s.replace('  let debitedAmount = 0;\n  let reserved = false;\n', '  let debitedAmount = 0;\n  let debitedWithdrawable = 0;\n  let reserved = false;\n', 1)
old = '''        const wallet = current && typeof current === "object" ? { ...current } : {};
        const balance = Number(wallet.balance || 0);
        sawDuringTransaction = { rawCurrent: current, parsedBalance: balance };
        if (!Number.isFinite(balance) || balance < entryFee) return;
        wallet.balance = balance - entryFee;
        return wallet;'''
new = '''        const wallet = current && typeof current === "object" ? { ...current } : {};
        const balance = Number(wallet.balance || 0);
        const withdrawable = Math.max(0, Math.min(balance, Number(wallet.withdrawableBalance || 0)));
        sawDuringTransaction = { rawCurrent: current, parsedBalance: balance, parsedWithdrawable: withdrawable };
        if (!Number.isFinite(balance) || balance < entryFee) return;
        // Deposited coins are consumed first, preserving winnings for payout.
        const fromWinnings = Math.max(0, entryFee - Math.max(0, balance - withdrawable));
        if (fromWinnings > withdrawable) return;
        wallet.balance = balance - entryFee;
        wallet.withdrawableBalance = withdrawable - fromWinnings;
        debitedWithdrawable = fromWinnings;
        return wallet;'''
assert old in s
s = s.replace(old, new, 1)
s = s.replace('      entryFeeCoins: entryFee, entryStatus: entryFee > 0 ? "PAID" : "FREE",\n', '      entryFeeCoins: entryFee, withdrawableDebited: debitedWithdrawable, entryStatus: entryFee > 0 ? "PAID" : "FREE",\n', 1)
s = s.replace('        wallet.balance = Number(wallet.balance || 0) + debitedAmount;\n        return wallet;', '        wallet.balance = Number(wallet.balance || 0) + debitedAmount;\n        wallet.withdrawableBalance = Number(wallet.withdrawableBalance || 0) + debitedWithdrawable;\n        return wallet;', 1)

# Withdrawal is strictly against winnings ledger, not total wallet balance.
old = '''      const wallet = current && typeof current === "object" ? { ...current } : {};
      const balance = Number(wallet.balance || 0);
      if (!Number.isFinite(balance) || balance < amount) return;
      wallet.balance = balance - amount;
      wallet.locked = Number(wallet.locked || 0) + amount;
      return wallet;'''
new = '''      const wallet = current && typeof current === "object" ? { ...current } : {};
      const balance = Number(wallet.balance || 0);
      const withdrawable = Math.max(0, Math.min(balance, Number(wallet.withdrawableBalance || 0)));
      if (!Number.isFinite(withdrawable) || withdrawable < amount) return;
      wallet.balance = balance - amount;
      wallet.withdrawableBalance = withdrawable - amount;
      wallet.locked = Number(wallet.locked || 0) + amount;
      return wallet;'''
assert old in s
s = s.replace(old, new, 1)
s = s.replace('    return res.status(409).json({ error: `You need ${amount} coins available to request this withdrawal` });', '    return res.status(409).json({ error: `You need ${amount} winnings coins available to request this withdrawal` });', 1)
s = s.replace('        wallet.balance = Number(wallet.balance || 0) + amount;\n        wallet.locked = Math.max(0, Number(wallet.locked || 0) - amount);', '        wallet.balance = Number(wallet.balance || 0) + amount;\n        wallet.withdrawableBalance = Number(wallet.withdrawableBalance || 0) + amount;\n        wallet.locked = Math.max(0, Number(wallet.locked || 0) - amount);', 1)
# Rejected withdrawal restores winnings balance.
s = s.replace('      if (action === "REJECTED") wallet.balance = Number(wallet.balance || 0) + Number(amount);', '      if (action === "REJECTED") {\n        wallet.balance = Number(wallet.balance || 0) + Number(amount);\n        wallet.withdrawableBalance = Number(wallet.withdrawableBalance || 0) + Number(amount);\n      }', 1)

# Match reward credits/adjustments update the winnings ledger.
old = '        wallet.balance = after;\n        return wallet;\n      });\n      if (!walletRes.committed) {'
new = '        wallet.balance = after;\n        wallet.withdrawableBalance = Math.max(0, Number(wallet.withdrawableBalance || 0) + (after - before));\n        return wallet;\n      });\n      if (!walletRes.committed) {'
assert old in s
s = s.replace(old, new, 1)
old = '        wallet.balance = before + delta;\n        applied = true;\n        return wallet;'
new = '        wallet.balance = before + delta;\n        wallet.withdrawableBalance = Math.max(0, Number(wallet.withdrawableBalance || 0) + delta);\n        applied = true;\n        return wallet;'
assert old in s
s = s.replace(old, new, 1)

# Leave-match refunds restore the same winnings portion that was consumed.
s = s.replace('        wallet.balance = Number(wallet.balance || 0) + refund;\n        return wallet;', '        wallet.balance = Number(wallet.balance || 0) + refund;\n        wallet.withdrawableBalance = Number(wallet.withdrawableBalance || 0) + Math.max(0, Number(participant.withdrawableDebited || 0));\n        return wallet;', 1)

p.write_text(s)

p = Path('/home/ubuntu/work/src/main/java/com/arenax/tournament/WalletActivity.java')
s = p.read_text()
s = s.replace('    private long balance;\n', '    private long balance;\n    private long withdrawableBalance;\n', 1)
s = s.replace('findViewById(R.id.wallet_withdraw).setOnClickListener(v -> WithdrawDialog.show(this, balance));', 'findViewById(R.id.wallet_withdraw).setOnClickListener(v -> WithdrawDialog.show(this, withdrawableBalance));', 1)
s = s.replace('                balance = value == null ? 0L : value;\n                render();', '                balance = value == null ? 0L : value;\n                render();', 1)
s = s.replace('        FirebaseRepository.users().child(user.getUid()).child("wallet").child("balance")\n                .addValueEventListener(balanceListener);', '        FirebaseRepository.users().child(user.getUid()).child("wallet").child("balance")\n                .addValueEventListener(balanceListener);\n        FirebaseRepository.users().child(user.getUid()).child("wallet").child("withdrawableBalance")\n                .addValueEventListener(new ValueEventListener() {\n                    @Override public void onDataChange(DataSnapshot snapshot) {\n                        Long value = snapshot.getValue(Long.class);\n                        withdrawableBalance = value == null ? 0L : Math.max(0L, value);\n                        render();\n                    }\n                    @Override public void onCancelled(DatabaseError error) { }\n                });', 1)
s = s.replace('        withdrawBalance.setText("₹" + balance);', '        withdrawBalance.setText("₹" + withdrawableBalance);', 1)
p.write_text(s)

p = Path('/home/ubuntu/work/src/main/java/com/arenax/tournament/WithdrawDialog.java')
s = p.read_text()
s = s.replace('withdrawal bottom sheet shared by the\n * Wallet screen and the Add Money screen.', 'withdrawal bottom sheet shared by the\n * Wallet screen. It receives winnings-only balance; deposited coins are never passed here.')
s = s.replace('Available: \\u20b9" + balance', 'Winning balance: \\u20b9" + balance')
p.write_text(s)
