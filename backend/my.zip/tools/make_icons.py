#!/usr/bin/env python3
"""Generate StarX24 launcher icons (all densities) from the uploaded logo."""
from PIL import Image, ImageDraw, ImageOps
import os

SRC = "/workspace/IMG-20260913-WA0003.jpg"
MAIN_RES = "/workspace/sun-tournament-app/app/src/main/res"
ADMIN_RES = "/workspace/sun-tournament-app/app/src/admin/res"

DENSITIES = {"mdpi": 48, "hdpi": 72, "xhdpi": 96, "xxhdpi": 144, "xxxhdpi": 192}

logo = Image.open(SRC).convert("RGBA")
print("Source:", logo.size)

def make_square(img, size):
    """Center-crop to square + resize."""
    w, h = img.size
    side = min(w, h)
    left = (w - side) // 2
    top = (h - side) // 2
    sq = img.crop((left, top, left + side, top + side))
    return sq.resize((size, size), Image.LANCZOS)

def make_round(img, size):
    """Circular crop with transparent bg."""
    sq = make_square(img, size)
    mask = Image.new("L", (size, size), 0)
    d = ImageDraw.Draw(mask)
    d.ellipse((0, 0, size, size), fill=255)
    out = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    out.paste(sq, (0, 0), mask)
    return out

# Adaptive foreground (bigger inner content, 432 canvas, ~66% inner)
def make_foreground(img, size=432, inner_ratio=0.72):
    sq = make_square(img, int(size * inner_ratio))
    canvas = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    off = (size - sq.size[0]) // 2
    canvas.paste(sq, (off, off), sq if sq.mode == "RGBA" else None)
    return canvas

# Main app icons
for dpi, size in DENSITIES.items():
    d = os.path.join(MAIN_RES, f"mipmap-{dpi}")
    os.makedirs(d, exist_ok=True)
    make_square(logo, size).convert("RGBA").save(os.path.join(d, "ic_launcher.png"))
    make_round(logo, size).save(os.path.join(d, "ic_launcher_round.png"))
    print(f"main mipmap-{dpi}: {size}px OK")

# Foreground for adaptive icons (main)
fd = os.path.join(MAIN_RES, "mipmap-anydpi-v26")
os.makedirs(fd, exist_ok=True)
make_foreground(logo).save(os.path.join(fd, "ic_launcher_foreground.png"))
print("adaptive foreground OK (432px)")

# Admin icons (slightly darker badge tone = same logo, fine)
for dpi, size in DENSITIES.items():
    d = os.path.join(ADMIN_RES, f"mipmap-{dpi}")
    os.makedirs(d, exist_ok=True)
    make_square(logo, size).convert("RGBA").save(os.path.join(d, "ic_admin_launcher.png"))
    print(f"admin mipmap-{dpi}: {size}px OK")

print("ALL ICONS GENERATED")
