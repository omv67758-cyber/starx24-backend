#!/usr/bin/env python3
"""Bulk remap hardcoded dark hex in drawables → light/white professional palette.
Rules:
- Very dark reds (9E1019, 1A080C, 140709...) → white or light grey surfaces
- Blood red family (E22E3C*, FF4757*) → keep (brand accent / error) BUT dark variants → lighter
- Near-black translucent overlays (0F0507, 0C0406, 05E22E3C etc.) → subtle light greys
- Dark navy (1D2B4D, 2E3F63, 31456F, 16233F...) → keep (accent blue cards look good on white)
- Pure white/transparent/keep as is
Only BACKGROUND-ish darks change; text-stay-dark philosophy.
"""
import os, re, collections

RES = "/workspace/sun-tournament-app/app/src/main/res/drawable"

# hex (uppercase, no alpha handling first) → replacement
MAP = {
    # near-black red backgrounds → white surfaces
    "1A080C": "FFFFFF", "140709": "FFFFFF", "17070A": "FFFFFF", "0F0507": "FFFFFF",
    "0E0508": "FFFFFF", "0C0406": "FFFFFF", "140803": "FFFFFF", "120D03": "FFFFFF",
    "120709": "FFFFFF", "140A0C": "FFFFFF", "150709": "FFFFFF", "0E0406": "FFFFFF",
    "0D0407": "FFFFFF", "0D0406": "FFFFFF", "0C0508": "FFFFFF", "0B0507": "FFFFFF",
    "0B040A": "FFFFFF", "0D050F": "FFFFFF", "08090D": "FFFFFF", "080D15": "FFFFFF",
    "050203": "FFFFFF", "050203A": "FFFFFF", "0E0406": "FFFFFF", "1D090D": "FFFFFF",
    "1D070C": "FFFFFF", "17090D": "FFFFFF", "16000000": "FFFFFF", "20080B": "FFFFFF",
    # dark red panels → very light red-grey (chip backgrounds on white)
    "33151B": "F7F9FC", "9E1019": "E22E3C", "B51E2A": "E22E3C", "B0101C": "E22E3C",
    "4D8B1624": "33E22E3C", "8B1624": "E22E3C",
    # dark navy backgrounds (subtle) → light blue-grey cards (KEEP the richer navys for accents)
    "101828": "F7F9FC", "0E1830": "EEF2F7", "10233C": "EEF2F7", "0E2E22": "F7F9FC",
    "06120D": "F7F9FC", "190820": "F7F9FC", "24081C": "F7F9FC", "1A2440": "EEF2F7",
    "16233A": "EEF2F7", "16233F": "EEF2F7", "1F1D2224": "EEF2F7", "22000000": "EEF2F7",
    "140F05": "F7F9FC", "101820": "F7F9FC", "0A0E14": "FFFFFF", "141B26": "F7F9FC",
    "1B2532": "EEF2F7", "14141414": "F7F9FC", "10000000": "EEF2F7",
    # black scrims → keep (overlays for dialogs are fine) but lighten slightly
    "99000000": "66000000",
    # yellow/amber keep (prize)
    # greens keep (success)
    # cyan keep
}

def hex_to_replacement(h6):
    if h6 in MAP:
        return MAP[h6]
    return None

changed_files = 0
changed_count = collections.Counter()
for fname in os.listdir(RES):
    if not fname.endswith(".xml"):
        continue
    path = os.path.join(RES, fname)
    s = open(path).read()
    orig = s
    # match #RRGGBB or #AARRGGBB (8-digit: alpha + rgb)
    def repl8(m):
        alpha, rgb = m.group(1), m.group(2).upper()
        rep = hex_to_replacement(rgb)
        if rep is None:
            return m.group(0)
        changed_count[rgb] += 1
        # preserve alpha but cap it so whites don't blind: keep alpha
        return "#" + alpha + rep
    def repl6(m):
        rgb = m.group(1).upper()
        rep = hex_to_replacement(rgb)
        if rep is None:
            return m.group(0)
        changed_count[rgb] += 1
        return "#" + rep
    s = re.sub(r'#([0-9A-Fa-f]{2})([0-9A-Fa-f]{6})\b', repl8, s)
    s = re.sub(r'#([0-9A-Fa-f]{6})\b', repl6, s)
    if s != orig:
        open(path, "w").write(s)
        changed_files += 1

print(f"Files changed: {changed_files}")
print("Hex replacements:", sum(changed_count.values()))
for k, v in sorted(changed_count.items(), key=lambda x: -x[1])[:20]:
    print(f"  #{k} -> #{MAP[k]}  x{v}")
