from pathlib import Path

ROOT = Path('/home/ubuntu/work_starx24/starx24-final')
RES = ROOT / 'src/main/res'

# Brand palette: reference-inspired light canvas, navy typography, electric blue CTAs.
colors = RES / 'values/colors.xml'
s = colors.read_text()
repls = {
    '#E22E3C':'#1976D2', '#B31024':'#1257B7', '#FF4757':'#2D8CFF', '#33E22E3C':'#331976D2',
    '#FDECEC':'#EAF3FF', '#2D6CDF':'#1976D2', '#EAF1FE':'#EAF3FF', '#D8E6FD':'#D6E8FF',
    '#F4F6FB':'#F4F7FC', '#0E1420':'#1F3B68', '#5A6472':'#68778D', '#9AA3B2':'#9AA8BA',
    '#1FAE6E':'#22A06B', '#178E5A':'#187A52', '#C7DBFB':'#BFD8FA', '#E2E6F0':'#E3EAF4',
    '#EEF0F6':'#EEF3F8', '#C8CFDE':'#C8D5E5', '#F7F8FC':'#F7F9FD', '#EFF1F7':'#EFF4FA',
    '#FAFBFD':'#F8FAFE', '#F0F2F7':'#F1F5FB', '#EAEDF3':'#E8F0FA', '#DFE3EB':'#DCE7F5',
    '#CBD2DE':'#C7D8EE', '#14161D':'#1F3B68', '#3E4552':'#536985', '#F5F6FA':'#F4F8FD',
    '#E4E8EF':'#DCE7F2', '#000000':'#F4F7FC', '#0A000000':'#0A1F3B68', '#14000000':'#140D2B4D',
}
for a,b in repls.items(): s=s.replace(a,b)
colors.write_text(s)

# Make legacy dark-texture references render as a clean light app canvas.
(RES/'drawable/bg_black_texture.xml').write_text('''<?xml version="1.0" encoding="utf-8"?>\n<shape xmlns:android="http://schemas.android.com/apk/res/android" android:shape="rectangle">\n    <solid android:color="@color/home_bg"/>\n</shape>\n''')
(RES/'drawable/bg_bottom_nav_red_card.xml').write_text('''<?xml version="1.0" encoding="utf-8"?>\n<shape xmlns:android="http://schemas.android.com/apk/res/android" android:shape="rectangle">\n    <solid android:color="#FFFFFFFF"/>\n    <stroke android:width="1dp" android:color="@color/stroke"/>\n</shape>\n''')
(RES/'values/nav_colors.xml').write_text('''<resources xmlns:android="http://schemas.android.com/apk/res/android">\n    <color name="nav_item_active">#1976D2</color>\n    <color name="nav_item_inactive">#8090A5BA</color>\n    <style name="STARX24ActiveIndicator" parent="Widget.Material3.BottomNavigationView.ActiveIndicator">\n        <item name="android:color">#221976D2</item>\n    </style>\n</resources>\n''')

# Consistent screen canvas and reference-like spacing.
for name in ['fragment_home.xml','fragment_leaderboard.xml','fragment_tournaments.xml','fragment_rewards.xml']:
    p=RES/'layout'/name; t=p.read_text()
    t=t.replace('android:background="@color/ink"','android:background="@color/home_bg"')
    t=t.replace('android:background="@drawable/bg_black_texture"','android:background="@color/home_bg"')
    p.write_text(t)
p=RES/'layout/fragment_profile.xml'; t=p.read_text().replace('android:background="@drawable/bg_black_texture"','android:background="@color/home_bg"'); p.write_text(t)

# Reference navigation has Home, Leaderboard, Tournaments, Wallet, Profile.
menu=RES/'menu/main_bottom_nav.xml'
menu.write_text('''<menu xmlns:android="http://schemas.android.com/apk/res/android">\n    <item android:id="@+id/nav_home" android:icon="@drawable/ic_home" android:title="Home"/>\n    <item android:id="@+id/nav_leaderboard" android:icon="@drawable/ic_trophy" android:title="Leaderboard"/>\n    <item android:id="@+id/nav_tournaments" android:icon="@drawable/ic_matches" android:title="Tournaments"/>\n    <item android:id="@+id/nav_wallet" android:icon="@drawable/ic_wallet_outline" android:title="Wallet"/>\n    <item android:id="@+id/nav_profile" android:icon="@drawable/ic_profile" android:title="Profile"/>\n</menu>\n''')

# Bottom bar is a compact white floating-like strip with readable five-tab labels.
p=RES/'layout/activity_main.xml'; t=p.read_text()
t=t.replace('android:layout_height="82dp"','android:layout_height="76dp"')
t=t.replace('android:background="@drawable/bg_bottom_nav_red_card"','android:background="@drawable/bg_bottom_nav_red_card"\n        android:elevation="8dp"\n        app:itemHorizontalTranslationEnabled="false"\n        app:labelVisibilityMode="labeled"')
p.write_text(t)

# Ensure reference-style light canvas on app entry/login containers where present.
for name in ['activity_login.xml','activity_admin.xml','activity_message_login.xml']:
    p=RES/'layout'/name
    if p.exists():
        t=p.read_text().replace('android:background="@drawable/bg_black_texture"','android:background="@color/home_bg"')
        p.write_text(t)

# MainActivity routes the new tab without disturbing wallet's existing payment activity.
main=ROOT/'src/main/java/com/arenax/tournament/MainActivity.java'; t=main.read_text()
t=t.replace('else if (item.getItemId() == R.id.nav_wallet) {', 'else if (item.getItemId() == R.id.nav_tournaments) fragment = new com.arenax.tournament.fragment.TournamentsFragment();\n            else if (item.getItemId() == R.id.nav_wallet) {')
main.write_text(t)

# Update README with the concrete design change.
readme=ROOT/'README.md'; t=readme.read_text()
t += '\n\n## 🎨 Reference UI redesign applied\nThe user app now follows the supplied reference direction: light blue-grey canvas, navy typography, electric-blue actions, rounded white cards, and five-tab navigation (Home, Leaderboard, Tournaments, Wallet, Profile). Existing Firebase, payment, notification, and join flows are preserved.\n'
readme.write_text(t)
print('Applied reference-inspired visual redesign')
