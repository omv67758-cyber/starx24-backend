# Fancy text design (app-wide)

All visible text now renders in the stylised Unicode alphabet (e.g. Hello -> 𝖧𝖾𝗅𝗅𝗈), using a lighter (non-bold) weight.

- `util/FancyText.java` - the whole feature. Change `STYLE` (SANS / ITALIC / MONO / BOLD) to change the look.
- Works at display time, so text an admin types in a normal field is saved as plain text and shown in this design to players.
- EditText fields are never converted. Digits, Hindi/other scripts, emoji untouched.
- Room IDs, UPI IDs, e-mails, links, usernames and amounts (tokens with digits, @, /, _) stay plain so copy/paste keeps working.
- Hooked in: `STARX24App` (every screen), `FullScreenDialog`, bottom sheet, alert dialogs (FancyText.*Builder), and all Toasts (`FancyText.toast`).
- Code that reads text back from a label should use `FancyText.plain(...)` (already done in TournamentsFragment and WithdrawalDetailActivity).
- Opt a single view out with `view.setTag("nofancy")`.

## Home header logo text (STARX24)
Uses `res/font/pierknife_regular.otf` (Pierknife) at 56sp with 0.05 letter spacing; "X" stays blue. Tag `nofancy` keeps FancyText from converting it.

## Login card (glass + soft shadow)
- Removed the blue-tinted elevation shadow that showed as a blue square behind the card.
- Card is now a glass card (translucent white, white edge, top sheen) with a layered neutral shadow (`bg_login_card_shadow.xml`).
- Tabs and LOGIN button have rounded baked-in shadows (elevation 0) so no square shadow appears behind them.

## Wallet balance card
Gradient made deeper (sky blue to green-teal), card radius now matches the gradient (22dp) and a 1.5dp blue outline hugs the card edge with no gap.

## Profile info card + bio
- Profile page: logo/avatar (with outline ring) on the left, username / email / phone (read-only) on the right, inside an outlined card.
- Tap the card to show/hide the Bio card; the pencil icon on it edits the bio (only editable field, max 150 chars, saved to `users/{uid}/bio`).
- `database.rules.json`: added `users/$uid/bio` rule. **Redeploy rules** (`deploy_rules.sh`) or bio saving will be denied.

## Notifications header
Removed the red INBOX / WALLET eyebrow text above the "Notifications" title.

## STARX24 AI chat page (white theme redesign)
- White page with soft blue glow (reference style), white status bar with dark icons (clock/battery visible now).
- Header: back + menu on the left, centered card with STARX symbol + "STARX24 AI", settings (gear) on the right.
- Menu: "App guide" bottom sheet with 9 ready-written how-to answers (join match, add coins, withdraw, room ID, results, history, bio, language, support). Shown instantly, no AI call.
- Settings: Language (opens the app language picker) and Clear chat.
- Bot messages have the small STARX logo avatar; user bubble is a blue gradient; input is a white pill with shorter hint.
