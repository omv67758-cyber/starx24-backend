# Admin Permission Fixes

Applied fixes for admin-key/work-role Firebase permission failures:

- A work-role key with `match_detail` can create a new `/matches/{id}` record; existing edits AND deletes are allowed (delete fix: completed matches could not be deleted by match_detail admins).
- A work-role key with `match_detail` can use the Add Match UI (`canCreateMatch()`), including the match-management entry points.
- `RESULTS_COINS_ADMIN` and work-role keys with `results` can publish the public leaderboard copy at `/tournaments/{id}/results`.
- Work-role keys with `coin_requests` or `coin_support` can see the Give Coins controls; the backend already accepts those permissions and Firebase wallet rules now match the same capability.
- Updated stale UI text that incorrectly said only the owner could create matches.

## Deployment

Publish `database.rules.json` to the Firebase Realtime Database before testing production admin keys:

```bash
./deploy_rules.sh
```

The Android build could not be completed in this sandbox because no Android SDK is installed/configured (`ANDROID_HOME`/`sdk.dir` is missing). JSON validation, Java brace/sanity checks, and permission-gate assertions passed.


## Completed match delete fix
- database.rules.json: removed `(!data.exists() || newData.exists())` from `/tournaments/$matchId` and `/matches/$matchId` write rules (it blocked delete for work-key admins).
- FirebaseRepository.deleteTournament: also removes the `/matches/{id}` mirror after delete.
- backend slot reconciler: transaction, no longer re-creates a deleted match as a stub.
- Deploy: `./deploy_rules.sh` + backend redeploy + rebuild admin app.
