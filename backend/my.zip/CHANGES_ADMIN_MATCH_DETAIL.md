# Admin match detail — compact 3-tab redesign

Files changed (all under src/main/java/com/arenax/tournament):
- TournamentControlCenterActivity.java — 3 tabs: Overview | Participants | Rank & Leaderboard
  (Rank Manage / Leaderboard / Edit Logs inside one tab). Radius max 4dp everywhere on this screen.
- data/FirebaseRepository.java — saveRankDraft, markResultPublished, editLogs, addEditLog
- MatchResultActivity.java — VIEW RESULT now shows the published placement/kills/total leaderboard
- fragment/TournamentsFragment.java — Resulted card -> MatchResultActivity
- MyMatchesStatusActivity.java — published match -> Completed list, tap -> result
- adapter/TournamentAdapter.java, TournamentDetailActivity.java, MatchJoinedActivity.java — "Joining Full" state

Firebase paths added under tournaments/{id}: rankDraft, rankDraftAt, editLogs, resultPublishedAt
(covered by the existing tournaments/$matchId admin write rule — no rules change needed).

## Match start = joining closed (30 Sep 2026)
Agar 48 me se sirf 40 join hue aur start time aa gaya -> match ONGOING, join/waitlist band, leaderboard unlock.
- model/Tournament.java: hasStarted(), isJoiningOpen()
- adapter/TournamentAdapter.java: button "MATCH STARTED", spots text "Joining Closed"
- TournamentDetailActivity.java: join lock (live, countdown end pe bhi), waitlist block
- JoinMatchActivity.java: started match pe join screen open nahi hoti
- MatchJoinedActivity.java: "Match Started" label
- backend/index.js /joinMatch: startAt guard (server side)
- database.rules.json: participants + waitlist write start ke baad blocked (non-admin)
- Admin leaderboard (TournamentControlCenterActivity.rankUnlocked) pehle se ONGOING pe unlock hota hai.

## Full-screen fix for high-DPI / large display-size phones (30 Sep 2026)
Problem: high DPI wale users ko admin/user pages half/zoomed dikhte the (dp-width 300-330 reh jati thi).
- util/ScreenFit.java (new): shortest side < 360dp ho to density kam karke 360dp width guarantee; fontScale max 1.15
- BaseActivity.java (new): attachBaseContext + applyOverrideConfiguration me ScreenFit
- Saari 33 AppCompatActivity screens ab BaseActivity extend karti hain (user + admin + message)
- AdminLoginActivity, CrashActivity (plain Activity): attachBaseContext me ScreenFit
- AndroidManifest.xml: supports-screens (all sizes, anyDensity), resizeableActivity=true, android.max_aspect=3.0
Normal phones (>=360dp) pe kuch change nahi hota.

## Match roadmap audit fixes (30 Sep 2026)
- TournamentControlCenterActivity: Publish Leaderboard ab match start hone se pehle blocked (Draft allowed)
- TournamentControlCenterActivity.saveSchedule: past start time reject (warna match turant ONGOING + joining band)
- FirebaseRepository.publishMatchResults: weekly/monthly leaderboard bucket ab MATCH ke startAt se, edit ke din se nahi

## Security + data-loss fixes (30 Sep 2026)
- Room ID/password ab release se pehle tournaments/{id} (sab players padh sakte) me nahi rehta; admin-only matches/{id}/roomRelease me rehta hai.
- rankDraft ab admin-only root node rank_drafts/{id} me (database.rules.json me rule add).
- backend/index.js scrubPublicSecrets(): purane leaked room creds + drafts ko startup pe aur har 5 min me admin-only nodes me move karta hai.
- FirebaseRepository.saveTournament: existing match pe setValue() (poora node overwrite -> participants/slotIndex/waitlist mit jate the) ki jagah updateChildren(); joinedSlots overwrite nahi hota.
- AdminActivity match edit: date/time badalne par startAt bhi update hota hai (pehle edit ka koi asar nahi padta tha).
Deploy: backend redeploy + database.rules.json Firebase Console me publish (rank_drafts rule zaroori, warna draft save fail hoga).
