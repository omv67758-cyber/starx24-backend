# (Removed) Auto delete completed matches

Auto-delete after 24h feature hata diya gaya hai: backend worker `processCompletedCleanup` aur Admin Settings ka "Auto delete (completed)" option dono nahi hain.
Completed matches ab sirf admin manually delete karta hai.

---
# Slot rule + Solo/Duo/Squad auto type + Rules scroll

- User app, match detail: RULES box ab apne andar scroll hota hai (page scroll ab usse nahi churata). Box ke top/bottom par pahunchne par page scroll wapas chalta hai.
- Slot limit = match ka team size: SOLO 1 slot, DUO 1-2 slot, SQUAD 1-4 slot (JoinMatchActivity). Backend `/joinMatch` pehle se yehi check karta hai (1..teamSize).
- Add Match (MatchScheduleActivity aur AdminActivity dialog): admin sirf Team size number likhta hai (1 / 2 / 4), Match type (SOLO / DUO / SQUAD) apne aap set ho jata hai. Dusra number (jaise 3) KILL / SURVIVAL match me allowed nahi.
- 1VS1 aur TEAM result system pehle jaise hi chalte hain.

---
# Daily match: har din naya #number

- Naye din ki daily copy me sirf public #number badalta hai, baaki sab (time, slots, fee, rules, banner...) same copy hota hai.
- #number match ki key se banta hai (MatchNumber), aur har daily copy ki key alag hoti hai (`series_startAt`), isliye number roz naya.
- Agar admin ne title me khud "#123456" likha tha, to copy ke title me wo purana number ki jagah copy ka naya number lag jata hai
  (app `FirebaseRepository.ensureDailyNext` aur backend `processDailyMatches` dono me).
- Match list me title ke end ka purana "#123456" ab hata kar hamesha key wala number dikhaya jata hai, taaki list, detail aur Search Match ka number ek hi rahe.
- Backend ka number-formula Java ke `hashCode` jaisa hi hai (test: "abc" -> 096354).

Deploy: backend redeploy + admin/user app dubara build.

---
# Category-wise saved Description & Rules

- Add Match (MatchScheduleActivity) aur category ke andar wale purane Add dialog (AdminActivity) me Description aur Rules ke neeche
  **SAVE DESCRIPTION FOR <CATEGORY>** / **SAVE RULES FOR <CATEGORY>** buttons.
- Har category ka apna saved text: Firebase `categoryPresets/{categoryId}/description` aur `/rules` (max 8000 characters).
- Us category me agli baar Add Match kholne par saved description aur rules apne aap bhar jate hain. Fields edit hote hain;
  badalkar dobara SAVE dabao to naya text save ho jata hai.
- Field khali karke SAVE dabane se saved text hat jata hai (rules phir app ke default rules par wapas).
- Auto-fill sirf tab hota hai jab field abhi untouched ho (khali / default rules), taaki admin ka likha hua kabhi overwrite na ho.
- Jin matches ko pehle hi banaya ja chuka hai unka description/rules nahi badalte; daily copy apne match ka text hi copy karti hai.

Deploy: `./deploy_rules.sh` (database.rules.json me naya `categoryPresets` node) + admin app dobara build.

---
# Auto delete completed matches (back, now with a setting)

- Admin app: More > "Auto delete completed matches" -> hours (OFF / 6 / 12 / 24 / 48 / 72 or any number). Saved in Firebase `appConfig/autoDeleteCompletedHours` (0 = OFF).
- Backend `processCompletedCleanup` (backend/index.js, runs every 5 min) deletes COMPLETED / RESULT_PUBLISHED / RESULTED matches that many hours after `resultPublishedAt`. Upcoming/ongoing matches are never touched; a daily match whose next copy is missing is kept.
- Manual buttons: "AUTO DELETE ALL COMPLETED" on the Complete tab and in Search Match.
- More page also has shortcuts: Search Match, Bulk match actions, Match showing time, Revenue Dashboard, Activity Log, Reports, Admin PIN, Backup now.

Deploy: backend redeploy on Render + admin app rebuild.
