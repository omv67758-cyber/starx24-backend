# Sun Tournament App - Full Upgrade Plan

## Phase 1: Analysis (DONE)
- [x] View uploaded screenshots (match UI reference photos - BATTLEX11 style blue cards + leaderboard)
- [x] View logo image (StarX24 crown+lightning logo, red/black)
- [x] Extract main.zip and analyze existing codebase (arenax-android: 60 java files, 183 res files, 20 layouts)
- [x] Root causes identified:
   - BUG A: Firebase rules pendingDebit arithmetic impossible -> paid join ALWAYS permission denied
   - BUG B: rules pendingDebit write allowed only with wallet balance = negative check + wallet write rule
   - BUG C: Admin announcements write to /announcements+/notifications but backend FCM worker reads /broadcast_notifications -> notifications never sent
   - BUG D: FcmSender room release push requires admin assets/service-account.json (missing in repo)
   - BUG E: joinedSlots never updated on join (cards show stale slots)
   - BUG F: admin_keys read for ANY auth user
   - BUG G: order_node missing in rules (orders writes fail silently)
   - BUG H: AdminActivity broadcast not using broadcast_notifications

## Phase 2: Backend + Rules + Notifications (in progress)
- [x] Fix database.rules.json — DONE: newData.parent() arithmetic + users/$other removed
- [x] ✅✅✅ RULES 100% FIXED & EMULATOR-VERIFIED (17:38): root causes = (1) unguarded admin_keys.child(null) chain crash on non-admin users (53 chains now null-guarded), (2) $slot>=1 string-vs-number comparison (bounds removed from slotIndex; slot bounds enforced via participants .validate slotNumber). Emulator matrix proof: FREE multi-path join PASS, FREE slot 12/48 PASS, PAID direct DENY, slot theft DENY, wallet self-credit DENY, joinedSlots=99 DENY. Fix script pattern: replace `root.child('admin_keys').child(root.child('admin_sessions').child(auth.uid).child('key').val())` → `(root.child('admin_sessions').child(auth.uid).child('key').val() != null ? <same chain> : root.child('x_none'))`
- [x] Fix backend/index.js — DONE (5 fixes, node --check PASS)
- [x] Add user FCM push on wallet credit — DONE
- [x] FirebaseDirectJoinClient hybrid routing + joinedSlots increment — DONE (needs recompile)

## Phase 3: UI/UX White Professional Theme
- [ ] Create new white professional design system (colors.xml, themes.xml, drawables)
- [ ] Redesign match cards like reference photo (blue gradient banner + progress bar + FULL state)
- [ ] Redesign bottom nav + home + fragments (white + outline)
- [ ] Redesign JoinMatchActivity + PlayerGameDetailsActivity (white, professional outline cards)
- [ ] Redesign WalletActivity (white, payment flow polished)
- [ ] Redesign LoginActivity (white + logo)
- [ ] Redesign Admin app UI (white professional + outline)
- [ ] New app logo (StarX24 crown lightning from uploaded image) + admin launcher

## Phase 4: Build + Deliver
- [x] Gradle wrapper setup + user APK BUILD SUCCESSFUL (app-user-debug.apk, 1m37s) — REBUILD needed after FirebaseDirectJoinClient edits
- [x] Backend node --check PASS
- [x] INTERIM HANDOFF (user request): starx24-modified-work.zip (source+rules+backend+APK) + CONTINUE_PROMPT.md delivered
- [ ] Build admin APK
- [ ] Final deliverables (dono APKs + setup guide) — next session per CONTINUE_PROMPT.md
