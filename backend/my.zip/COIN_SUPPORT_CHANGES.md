# Coin Support + Leaderboard Coins — changes

## Leaderboard coins (leaderboard_coins_update-1.zip injected)
- backend/index.js: POST /admin/creditMatchCoins
- WithdrawalApiClient.java: creditMatchCoins()
- TournamentControlCenterActivity.java: publish -> creditLeaderboardCoins()

## Coin Support (payment hua, coins nahi mile)
User: Wallet page -> "Payment kiya, coins nahi mile?" card -> CoinSupportActivity
  (QR image (app me compress hoke seedha Firebase coin_support_images me) + UPI ID + description -> backend /requestCoinSupport; apni requests + admin reply bhi dikhti hain)
Admin: Users page (aur Notifications page) -> "COIN REQUESTS (n pending)"
  (user detail, UPI ID + COPY, QR, description; ADD COINS / PAID VIA UPI / REJECT -> backend /admin/resolveCoinRequest)

New/changed files
- src/main/java/.../CoinSupportActivity.java (new), wallet_card_coin_support.xml (new)
- activity_wallet.xml, WalletActivity.java, AndroidManifest.xml
- WithdrawalApiClient.java (requestCoinSupport, resolveCoinRequest), FirebaseRepository.java (coinRequests)
- AdminActivity.java (coin requests page)
- backend/index.js (/requestCoinSupport, /admin/resolveCoinRequest)
- database.rules.json (coin_support + coin_support_images: admin read, write false)  [coin_requests purana match-coins node hai, use touch nahi kiya]

Deploy: firebase deploy --only database, phir backend index.js Render par push, phir APK build.

## Coin Support function (role admin key function, FIRST in list)
- AdminRoles.FUNCTIONS: new first function `coin_support` ("Coin Support") — tick it when generating a key in Admin Panel.
- Flow: user request -> admin sees it (bell / landing page "COIN REQUESTS") -> APPROVE USER (status APPROVED, user ko notification)
  -> ADD COINS / REMOVE COINS (wallet +/-; remove kabhi balance ko 0 se neeche nahi le jaata) / PAID VIA UPI / REJECT.
- backend/index.js /admin/resolveCoinRequest: new actions APPROVED and DEBIT; coin_support perm allowed in isMasterOrResultsCoins.
- Deploy: backend index.js Render par push karo, phir APK build. (database.rules.json me change nahi.)

## Match Detail Handle + Admin key history
- Match create/delete is OWNER-ONLY now: "Add / Manage Matches" removed from assignable functions (AdminRoles), Add Match / New battle / delete buttons hidden for work keys (AdminActivity.canCreateMatch()).
- New function `match_detail` ("Match Detail Handle"): room / key release, edit existing match, leaderboard (pages matches, tournaments, results).
- database.rules.json: tournaments/$matchId, tournaments/$matchId/$other, matches/$matchId, matches/$matchId/roomRelease now accept perms.match_detail (edit only: data.exists() && newData.exists(); roomRelease always) instead of perms.matches. Old keys that only had `matches` perm lose match access - re-issue them with Match Detail Handle.
- History: tap any key card (Admin Panel "Key History" or Roles page) -> full activity list for that key with date + time. Logs now carry adminKey + adminUid (client) / adminKey (backend); new util/AdminKeyHistory.java. activity_logs got .indexOn adminKey/adminUid/actorUid.
- Deploy: firebase deploy --only database, backend index.js -> Render, then build APK. Older log entries (before this update) are matched via the key's session uid only.
