# Admin Work Roles (owner assigns functions per key)

Owner flow: Admin Panel (More > Roles & Permissions) -> pick a work card (or "Generate Admin Key")
-> type admin name -> tick functions -> Generate Key -> give key to admin.
Admin flow: Admin Login > ADMIN KEY tab > Admin Panel shows ONLY the works the owner assigned.

Works: 1 Withdrawal Manager (payments, coin_requests) | 2 Match & Banner Manager (categories, matches, banners)
       3 Profile & System Manager (profile_text, notice, platform_links) | 4 Custom / Extra Manager (owner picks anything).

Add a new assignable function: one line in AdminRoles.FUNCTIONS (+ its pages), then a perms clause in
database.rules.json for the node it writes. Key record: admin_keys/{key} = {label, role, active, perms:{fn:true}}.

Deploy after install: `./deploy_rules.sh` (database.rules.json) and redeploy backend/ (index.js now reads perms).
Old keys (no perms map) keep working exactly as before.
