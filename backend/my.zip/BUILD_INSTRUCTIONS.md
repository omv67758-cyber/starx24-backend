# STARX24 Type 5 Luxury White Theme

This source contains the updated STARX24 Android app with the Type 5 luxury white theme: warm white surfaces, charcoal text/actions, and metallic-gold prize and coin accents.

## Build with Android Studio

1. Extract this ZIP.
2. Open the extracted folder in Android Studio.
3. Allow Gradle sync to finish.
4. Select the `userDebug` variant.
5. Run **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. The APK will be generated at `build/outputs/apk/user/debug/STARX24-user-debug.apk`.

## Build from command line

Requirements: JDK 17, Android SDK with Android API 34 and Build Tools installed.

```bash
# Linux/macOS
export JAVA_HOME=/path/to/jdk-17
./gradlew assembleUserDebug
```

On Windows:

```bat
gradlew.bat assembleUserDebug
```

The project is a flat Android module, so run the command from the project root. Do not add an `app/` module.

## Other flavors

```bash
./gradlew assembleAdminDebug
./gradlew assembleMessengerDebug
```

## Notes

- The APKs produced by these commands are debug-signed and intended for testing.
- The source uses the public backend URL configured in `build.gradle`; do not put payment secrets in the Android project.
- If Gradle cannot find the SDK, create `local.properties` in the project root with:

```properties
sdk.dir=/absolute/path/to/Android/sdk
```
