# Notification click -> direct content redirect

## Admin
Send Device Notification, New Announcement and Broadcast forms now have a
"REDIRECT CONTENT" row with a SELECT button. It opens a full-screen picker:
- phone previews of the whole user panel (Home, Leaderboard, Wallet, Add Money, Profile,
  Notifications, My Upcoming/Ongoing/Completed, Match History, Esports Games, Support,
  Support Chat, FAQ, About)
- live game categories and live matches (searchable) from Firebase
- a big "PLAYER WILL SEE" preview, NO REDIRECT, and SELECT THIS.

## User
Tap on the push notification (app open, background or closed) or on an inbox row opens
the chosen screen / category / match directly. Completed matches open the result page.

## Files
New: util/NotificationRedirect.java, util/ScreenPreviewView.java, util/RedirectPickerDialog.java
Edited: AdminActivity, RoleAdminActivity, FirebaseRepository, StarxFirebaseMessagingService,
LoginActivity, MainActivity, NotificationsActivity, backend/index.js

## Data
notifications / broadcast_notifications / announcements records get
redirectType, redirectId, redirectTitle. FCM data payload carries the same 3 keys.
Redeploy backend/index.js (Render) for pushes to carry the redirect.
