# Maintenance mode + Update notice

Admin app: Dashboard -> Platform controls -> "Maintenance and update mode".
Data lives at Firebase `appConfig/status` (read: public, write: owner or `platform_links` permission).

## Maintenance mode
- ON: user app shows a full-screen maintenance page (title, message, expected-back time, Check again, Contact support). It closes by itself when you switch it OFF.
- Admin app shows the same page once per launch with "Continue to admin panel", so you can never lock yourself out.

## Update notice
- Fields: version name, version code, title, description, player link, optional admin link, Force update toggle.
- Any installed app whose versionCode is LOWER than the code you enter gets the update dialog. Force = cannot be dismissed.
- versionCode is auto-generated per build. Build both apps in ONE command so they share the same code:
  `./gradlew assembleUserRelease assembleAdminRelease`, then press "Use this build's code".

## Deploy
1. Publish `database.rules.json` (`./deploy_rules.sh`) - adds the `appConfig/status` rule.
2. Build + install the new APKs.
Apps installed BEFORE this build do not contain this code, so they cannot show these screens.

## Launch order (update notice before login)
`LoginActivity` (the launcher) now calls `AppStatus.launchGate()` first, before auto-login, ban check or admin/messenger routing.
- Optional update: dialog shows, "Maybe later" continues to login / app.
- Force update: dialog cannot be closed, login never opens until the app is updated.
- Offline / slow (> 3.5 s) / no update: continues normally (fail-open).
