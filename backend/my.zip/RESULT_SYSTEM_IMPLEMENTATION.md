# Leaderboard & Reward Systems

This implementation adds three independent result systems to tournaments while sharing one result-notice delivery pipeline.

## Admin setup and results

Choose **KILL → COIN**, **SURVIVAL → COIN**, or **1VS1 BATTLE** when creating a tournament. The same choice is editable later in the tournament quick-edit form. A 1VS1 tournament is restricted to two player slots and one player per side.

Open the tournament in **Results & Coins → tournament** (or **Match Operations → category → tournament**) and use **Rank & Leaderboard**:

- **KILL → COIN:** Enter kills as before. Highest kills rank first; tied highest scores are all marked as winners. Coins are the saved per-kill rate multiplied by kills.
- **SURVIVAL → COIN:** Select 1–10 surviving players. Selection order becomes placement (#1, #2, …). The configured coin prize pool is divided equally; any remainder coin(s) go to the earlier selected places. If no explicit prize pool is set, the pool defaults to entry fee × registered participant count.
- **1VS1 BATTLE:** The two sides are assigned by slot number, then player name. Admin chooses one outcome: Left/Right wins at **100/0**, or Left/Right joined at **80/20**. The 80/20 choice credits 80% of the pool to the joined player and 20% to the no-show as a refund. The pool is the configured prize pool, or 2 × entry fee if the prize pool is zero.

The server computes final rewards, writes both players to the 1VS1 leaderboard, and uses transaction-based wallet settlement so retrying a result does not duplicate a payout. A wallet update failure is reported to the admin; retry settlement to finish that player’s reward.

## Shared notices

All three systems create targeted **WIN**, **LOSS**, and (for 1VS1 80/20) **REFUND** notices. Admins can customize the LOSS and REFUND text per result. Notices are queued in `result_notice_jobs`, added to the player’s in-app inbox, and sent through FCM when the player has a registered token. The backend worker checks every 15 seconds and retries stale in-flight deliveries.

## Files and deployment

- Android app source: `src/main/java/com/arenax/tournament/…`, `src/main/res/layout/fragment_leaderboard.xml`
- Backend settlement endpoint and notice worker: `backend/index.js` (`POST /admin/settleTournament`)
- No Firebase rules change is required for settlement writes; the backend uses its Firebase Admin SDK. Admin authorization uses the existing Results & Coins permission predicate.
- Deploy the updated backend to the configured Render service and build/install the updated Android app so the endpoint and client are both active. The feature has not been deployed from this workspace.

## Validation performed

- `node --check backend/index.js` — passed.
- `database.rules.json` parsed successfully.
- Edited Java files parsed successfully with a Java syntax parser; the leaderboard XML parsed successfully.
- `./gradlew assembleUserDebug --no-daemon` could not run to completion because this workspace has no Android SDK (`ANDROID_HOME`/`ANDROID_SDK_ROOT` unset and no SDK at common locations). Run the documented Gradle build from Android Studio or a host with Android API 34 and Build Tools installed.

## Add Match type chooser + TEAM system (update)

Category -> **+ Add Match** now first asks for the match type: **1 vs 1**, **Full Map**, **Team Match**, **Survival Match**. The form adapts to the choice and saves `resultSystem` (`BATTLE_1V1`, `KILL`, `TEAM`, `SURVIVAL`).

- **1v1:** admin picks "A WIN / B LOSS" (100/0) or "A aaya, B nahi aaya" (80/20 - joined player 80%, no-show 20%).
- **Full map:** every player listed, admin types kills, coins = kills x per-kill.
- **Team match (new):** admin types a rank number per team (teams = same `teamName` when team size > 1). Leaderboard is auto-built; coins follow the rank and are split equally inside the team.
- **Survival:** admin selects up to 10 surviving teams/players in order. Coins are tiered, not equal.
- **Rank payouts (TEAM + SURVIVAL):** optional "Prize per rank" (e.g. `500,300,200,100`) is used as exact coins; if empty the prize pool is split 30/20/15/10/7/5/4/3/3/3 % over ranks 1-10 (normalised if fewer ranks are awarded).

Backend: `POST /admin/settleTournament` now accepts `teamRanks` and the `TEAM` system - **redeploy `backend/index.js`** for these to work.
