# Source package note

This project archive includes the complete Android project source for both the user/player app and the admin app, including the admin source set, shared app source, resources, Firebase rules, backend source, build scripts, and documentation.

The admin dashboard home has been updated to match the supplied reference style. The update passed Android resource processing and Java compilation checks.

No APK or Android App Bundle is included, per the request to hold the APK until further work is provided. Generated Gradle caches and build output directories are excluded from this source package.

## Language option (player app)

Profile -> Language lets the player pick from 19 Indian languages, English and 40 world languages.
Screen text is translated at runtime (LanguageManager + AppTranslator) and cached per language.

- ML Kit on-device translation (free, ~30 MB pack downloaded once) covers Hindi, Bengali, Gujarati,
  Kannada, Marathi, Tamil, Telugu, Urdu and the world languages.
- Odia, Punjabi, Assamese, Malayalam, Nepali, Sindhi, Sanskrit, Maithili, Dogri, Konkani and Meiteilon
  need a Google Cloud Translation key: add `translate.api.key=YOUR_KEY` to local.properties
  (restrict the key to the Translation API and this app's package/SHA-1 in Google Cloud Console).
  Without a key those rows show "setup needed".
- Bodo, Kashmiri and Santali are not offered by ML Kit or Google Cloud Translation.
