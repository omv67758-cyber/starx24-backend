#!/data/data/com.termux/files/usr/bin/bash
# build_apk.sh — Termux se STARX24/STARX24 app ka APK build karne ke liye.
#
# Usage:
#   bash /storage/emulated/0/tournament_app_msking/build_apk.sh              (debug build, default)
#   bash /storage/emulated/0/tournament_app_msking/build_apk.sh release      (release build)
#   bash /storage/emulated/0/tournament_app_msking/build_apk.sh admin        (admin flavor, debug)
#   bash /storage/emulated/0/tournament_app_msking/build_apk.sh admin release
#
# Ye script khud ke folder me hi rehna chahiye, project root me
# (ussi jagah jaha build.gradle, gradlew, src/ hain).

set -e

# ---- 0. Script jahan hai, wahi project root maan lo ----
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$SCRIPT_DIR"

if [ ! -f "./gradlew" ]; then
  echo "❌ gradlew nahi mila. Ye script project root me hona chahiye (jaha build.gradle hai)."
  echo "   Abhi ye yahan chal raha hai: $SCRIPT_DIR"
  exit 1
fi

# ---- 1. Arguments parse karo (flavor + build type) ----
FLAVOR="user"
BUILD_TYPE="Debug"

for arg in "$@"; do
  case "$arg" in
    admin) FLAVOR="admin" ;;
    messenger) FLAVOR="messenger" ;;
    user) FLAVOR="user" ;;
    release) BUILD_TYPE="Release" ;;
    debug) BUILD_TYPE="Debug" ;;
    *) echo "⚠️  Pehchana nahi gaya argument: $arg (ignore kar raha hoon)" ;;
  esac
done

FLAVOR_CAP="$(echo "${FLAVOR:0:1}" | tr '[:lower:]' '[:upper:]')${FLAVOR:1}"
TASK="assemble${FLAVOR_CAP}${BUILD_TYPE}"

echo "================================================"
echo " STARX24 / STARX24 APK Builder (Termux)"
echo "------------------------------------------------"
echo " Flavor      : $FLAVOR"
echo " Build type  : $BUILD_TYPE"
echo " Gradle task : $TASK"
echo " Project dir : $SCRIPT_DIR"
echo "================================================"

# ---- 2. Termux packages check (Java + Gradle deps) ----
if ! command -v javac >/dev/null 2>&1; then
  echo "→ JDK nahi mila, install kar raha hoon (openjdk-17)..."
  pkg install -y openjdk-17
fi

# Termux me Android SDK khud install karna padta hai (Google isko Termux
# repo me nahi deta). Agar local.properties nahi hai ya sdk.dir set nahi
# hai, to yahi rukiye aur pehle SDK set up kariye.
if [ ! -f "local.properties" ]; then
  if [ -n "$ANDROID_SDK_ROOT" ]; then
    echo "sdk.dir=$ANDROID_SDK_ROOT" > local.properties
    echo "→ local.properties bana diya, sdk.dir=$ANDROID_SDK_ROOT"
  elif [ -n "$ANDROID_HOME" ]; then
    echo "sdk.dir=$ANDROID_HOME" > local.properties
    echo "→ local.properties bana diya, sdk.dir=$ANDROID_HOME"
  else
    echo "❌ local.properties nahi mila aur ANDROID_SDK_ROOT / ANDROID_HOME env var bhi set nahi hai."
    echo "   Android SDK ka path pata karke ye file khud banao:"
    echo "     echo \"sdk.dir=/path/to/Android/sdk\" > local.properties"
    exit 1
  fi
fi

chmod +x ./gradlew

# ---- 3. Build ----
echo "→ Gradle build shuru ho raha hai (pehli baar dependencies download hone me time lagega)..."
./gradlew "$TASK" --console=plain

# ---- 4. APK dhundo aur Downloads folder me copy karo ----
BUILD_TYPE_LOWER="$(echo "$BUILD_TYPE" | tr '[:upper:]' '[:lower:]')"
APK_DIR="build/outputs/apk/${FLAVOR}/${BUILD_TYPE_LOWER}"
APK_PATH="$(find "$APK_DIR" -iname "*.apk" 2>/dev/null | head -n 1)"

if [ -z "$APK_PATH" ]; then
  echo "❌ Build to complete ho gaya lekin APK $APK_DIR me nahi mila. Upar ka gradle output check karo."
  exit 1
fi

DEST_DIR="/storage/emulated/0/Download"
mkdir -p "$DEST_DIR"
DEST_NAME="STARX24-${FLAVOR}-${BUILD_TYPE_LOWER}.apk"
cp "$APK_PATH" "$DEST_DIR/$DEST_NAME"

echo "================================================"
echo "✅ Build safal! APK yahan hai:"
echo "   $APK_PATH"
echo "   (copy: $DEST_DIR/$DEST_NAME)"
echo "================================================"
echo "Install karne ke liye phone ke Files app me Downloads kholo aur"
echo "$DEST_NAME par tap karo (purana app pehle uninstall kar lena)."
