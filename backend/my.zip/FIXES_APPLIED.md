# Fixes applied (review pass)

## database.rules.json  -> redeploy with ./deploy_rules.sh
- users/$uid/wallet/balance: client write REMOVED (backend/Admin SDK only). Users could set their own balance.
- users/$uid/wallet/pendingDebit: client write REMOVED.
- users/$uid/wallet/transactions/$txId: only active admins can write (users could forge history).
- users/$uid/notifications/$id: users can only change `read` / `readAt`, not create records.
The user app only READS wallet balance; all money moves via backend endpoints, so the app keeps working.

## backend/index.js  -> redeploy backend
- /leaveMatch: participant record is now claimed atomically (transaction) before refund,
  so double-tap / parallel requests can no longer refund the same entry fee twice.
  If refund fails after the claim, the participant record is restored.
- /requestWithdrawal: per-user atomic lock (withdrawal_locks/{uid}, stale after 2 min) so two
  parallel requests can't both pass the "one pending withdrawal" check. Lock released in `finally`.

## Second pass
- orders/$orderId: client write REMOVED. Wallet top-up credits `order.amount` read from the DB, and users could edit their own
  order amount (e.g. 10 -> 10000) before paying. Orders are created/updated only by the backend now (app never writes them).
- wallet/balance create-check restored: a brand-new self-created user record must start with balance 0 (no wallet extras, no coins).
- AndroidManifest: allowBackup=false.
- backend/nixpacks.toml: install uses `npm install` so an out-of-sync lockfile can't break Railway deploys.

## Third pass (room credentials)
- Room ID/password no longer copied into /notifications (readable by every signed-in user): backend room-release notice,
  RoomReleaseAlarmReceiver inbox row and MessageActivity no longer store them. The FCM push to joined players still carries them.
- STILL OPEN: after release, roomId/roomPassword sit in /tournaments/{id} (all signed-in users can read), and /notifications as a whole
  is readable by all signed-in users (NotificationsActivity filters client-side). Closing both needs per-user notification paths and
  a restricted room subtree = rewrite of NotificationsActivity + ~12 files, only safe with an Android Studio build.

## Fourth pass
- FirebaseRepository.deleteTournament: a PAID match with joined players (not COMPLETED/CANCELLED) can no longer be deleted
  (Match #hash search, Admin and Category screens all use it). Delete wiped participants without refunding entry fees.
  Not compiled here; build in Android Studio.

## Fifth pass (Admin home search icon)
- activity_admin.xml + AdminActivity.setupHeaderSearch(): search icon in the Admin home top bar (left of the bell) opens the
  full-screen MatchSearchActivity. Shown to owner / match roles / keys with match_detail or categories permission.
- MatchSearchActivity: with nothing typed it now lists ALL matches (every category/status, newest first); typing filters by
  #hash code, match name, category or exact id. Not compiled here; build the admin flavor in Android Studio.

## NOT changed (needs your decision / environment)
- backend/package-lock.json out of sync: sandbox has no network, run `cd backend && npm install` once and commit the lockfile.
- admin_keys/$key readable by signed-in users: the key name itself is the credential (list is not readable), so only someone who already knows a key can see its role. Left as is.
- participants / slotIndex readable by every signed-in user (game UID/name visible): the joined-players UI depends on it.
- Room ID/password: before release it is already kept in admin-only matches/$id/roomRelease. After release it is copied to /tournaments (readable by all signed-in users). Hiding it needs a restricted subtree plus changes in ~15 Android files; not done without a compile check.
- Android build not compiled here (no SDK). Release build: minifyEnabled false (enabling without keep rules + a test build can crash Firebase/Glide).

## Notification delay fix
- backend/index.js: every FCM send now uses android.priority=high, ttl=10min, channelId=starx24_announcements (+ apns priority 10). Normal priority was deferred by Doze -> late pushes.
- Room-release / match-reminder: FCM tokens fetched in parallel, push sent together with the inbox write (was sequential per player).
- App: STARX24App.onCreate creates the heads-up channel at start; manifest default_notification_channel_id set.
- Redeploy backend (Render) + rebuild APK. On Render FREE plan the service can sleep -> keep KEEP_ALIVE on or use a paid plan.
