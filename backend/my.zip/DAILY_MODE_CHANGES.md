# Daily Mode (roz repeat match)

- Add Match form (PUBLISH MATCH) me "DAILY MODE" switch.
- Control Center (Overview) me "DAILY MODE" switch - purane/kisi bhi category ke match par ON/OFF.
- ON karne par agle din ka match (same time, slots 0, room blank) apne aap ban jata hai, phir har din naya.
- OFF karne par poori series band.
- Server worker: backend/index.js `processDailyMatches` (30s). Backup: admin app category list kholne par.
- Copy key `{seriesId}_{startAtMillis}` => duplicate nahi banta.
- Messenger app: daily copy ka /matches mirror bhi apne aap banta hai (key = copy id).

Deploy: `database.rules.json` (indexOn dailyMode, dailySeriesId) + backend redeploy (Render). Optional env: DAILY_TIMEZONE (default Asia/Kolkata).

# Search Match (#hash code)
- Admin home -> "Search Match" tile -> MatchSearchActivity: #482913 type karo, sabhi categories ke matches me se wahi code wale aate hain (naam se bhi search).
- Result par tap = Control Center. Delete bhi wahin se.
- MatchNumber: daily copies (key `series_startAt`) ke liye full-key hash, taaki #code unique rahe.

# Developer Profile (user app)
- Profile tab -> "Developer Profile" row -> DeveloperProfileActivity (logo, contact number, about, skills, services, Telegram button).
- Edit constants at top of DeveloperProfileActivity.java: DEV_NAME, DEV_TAGLINE, DEV_PHONE (TODO: real number), DEV_TELEGRAM.
- Logo: res/drawable/developer_logo.jpg laga hua hai (circle me crop hota hai).
