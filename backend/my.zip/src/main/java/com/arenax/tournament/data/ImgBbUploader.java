package com.arenax.tournament.data;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.media.ExifInterface;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.util.Base64;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

/**
 * Image upload via the ImgBB API (https://api.imgbb.com). Simplest option of
 * the three tried for this app: one free API key, one HTTP call, and imgbb
 * hands back a permanent public image URL -- no Firebase Storage bucket, no
 * Telegram bot/channel to set up.
 *
 * SETUP (one-time):
 * 1. Go to https://api.imgbb.com/ and sign in (free, Google login works).
 * 2. Copy the API key shown on that page.
 * 3. Paste it into API_KEY below.
 *
 * SECURITY NOTE: like any key embedded in a client app, this can be extracted
 * by decompiling the APK. The imgbb API key only allows *uploading* images to
 * your imgbb account (it can't read/delete other users' data or cost you
 * money beyond imgbb's free-tier limits), so the blast radius if it leaks is
 * small -- worst case someone else uploads images under your imgbb account.
 * If that ever matters, regenerate the key from the imgbb dashboard.
 */
public final class ImgBbUploader {
    // TODO: paste your key from https://api.imgbb.com/
    private static final String API_KEY = "43145dc502aae7d628eff91e01d82fde";

    private static final Handler MAIN = new Handler(Looper.getMainLooper());

    private ImgBbUploader() {}

    public static void uploadImage(Context context, Uri imageUri, StorageUploader.Callback callback) {
        if (imageUri == null) {
            callback.onFailure("Select an image first");
            return;
        }
        if (API_KEY.startsWith("REPLACE_")) {
            callback.onFailure("Image uploader is not configured yet (ImgBB API_KEY missing).");
            return;
        }

        Context appContext = context.getApplicationContext();
        new Thread(() -> {
            try {
                // Resize + compress before upload: raw camera photos (3000x4000px, several MB)
                // made both the admin's upload and every user's later download slow. Capping the
                // longest side at 1280px and re-encoding as ~82% quality JPEG cuts most images
                // down to a few hundred KB with no visible quality loss on a phone screen, so
                // banners/category art/match images load fast for every player.
                byte[] imageBytes = readCompressedBytes(appContext, imageUri);
                String base64Image = Base64.encodeToString(imageBytes, Base64.NO_WRAP);
                String body = "image=" + URLEncoder.encode(base64Image, "UTF-8");

                HttpURLConnection conn = (HttpURLConnection) new URL(
                        "https://api.imgbb.com/1/upload?key=" + API_KEY).openConnection();
                conn.setRequestMethod("POST");
                conn.setDoOutput(true);
                conn.setConnectTimeout(15_000);
                conn.setReadTimeout(30_000);
                conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8");
                try (OutputStream os = conn.getOutputStream()) {
                    os.write(body.getBytes(StandardCharsets.UTF_8));
                }

                int code = conn.getResponseCode();
                InputStream stream = (code >= 200 && code < 300) ? conn.getInputStream() : conn.getErrorStream();
                String response = readStream(stream);
                android.util.Log.d("ImgBbUpload", "HTTP " + code + " response: " + response);

                JSONObject json = new JSONObject(response);
                if (code < 200 || code >= 300 || !json.optBoolean("success", false)) {
                    String description = json.optJSONObject("error") != null
                            ? json.optJSONObject("error").optString("message", "unknown error")
                            : ("HTTP " + code);
                    throw new IllegalStateException("ImgBB upload failed: " + description);
                }
                String url = json.getJSONObject("data").getString("url");
                postSuccess(callback, url);
            } catch (Exception error) {
                postFailure(callback, error.getMessage() == null ? "Image upload failed" : error.getMessage());
            }
        }).start();
    }

    private static final int MAX_DIMENSION = 1280;
    private static final int JPEG_QUALITY = 82;

    /** Downscales to at most {@link #MAX_DIMENSION}px on the longest side, fixes camera
     *  rotation using EXIF, and re-encodes as JPEG. Falls back to the raw file bytes if
     *  the image can't be decoded (e.g. an already-tiny image or unusual format). */
    private static byte[] readCompressedBytes(Context context, Uri uri) throws Exception {
        byte[] original = readBytes(context, uri);

        BitmapFactory.Options bounds = new BitmapFactory.Options();
        bounds.inJustDecodeBounds = true;
        BitmapFactory.decodeByteArray(original, 0, original.length, bounds);
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return original;

        int sample = 1;
        while ((bounds.outWidth / sample) > MAX_DIMENSION * 2 || (bounds.outHeight / sample) > MAX_DIMENSION * 2) {
            sample *= 2;
        }
        BitmapFactory.Options opts = new BitmapFactory.Options();
        opts.inSampleSize = sample;
        Bitmap bitmap = BitmapFactory.decodeByteArray(original, 0, original.length, opts);
        if (bitmap == null) return original;

        int rotation = readExifRotationDegrees(context, uri);
        if (rotation != 0) {
            Matrix matrix = new Matrix();
            matrix.postRotate(rotation);
            Bitmap rotated = Bitmap.createBitmap(bitmap, 0, 0, bitmap.getWidth(), bitmap.getHeight(), matrix, true);
            if (rotated != bitmap) bitmap.recycle();
            bitmap = rotated;
        }

        int width = bitmap.getWidth();
        int height = bitmap.getHeight();
        if (Math.max(width, height) > MAX_DIMENSION) {
            float scale = MAX_DIMENSION / (float) Math.max(width, height);
            int newWidth = Math.max(1, Math.round(width * scale));
            int newHeight = Math.max(1, Math.round(height * scale));
            Bitmap scaled = Bitmap.createScaledBitmap(bitmap, newWidth, newHeight, true);
            if (scaled != bitmap) bitmap.recycle();
            bitmap = scaled;
        }

        ByteArrayOutputStream out = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.JPEG, JPEG_QUALITY, out);
        bitmap.recycle();
        return out.toByteArray();
    }

    private static int readExifRotationDegrees(Context context, Uri uri) {
        try (InputStream in = context.getContentResolver().openInputStream(uri)) {
            if (in == null) return 0;
            ExifInterface exif = new ExifInterface(in);
            int orientation = exif.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL);
            switch (orientation) {
                case ExifInterface.ORIENTATION_ROTATE_90: return 90;
                case ExifInterface.ORIENTATION_ROTATE_180: return 180;
                case ExifInterface.ORIENTATION_ROTATE_270: return 270;
                default: return 0;
            }
        } catch (Exception ignored) {
            return 0;
        }
    }

    private static byte[] readBytes(Context context, Uri uri) throws Exception {
        try (InputStream in = context.getContentResolver().openInputStream(uri)) {
            if (in == null) throw new IllegalStateException("Could not read selected image");
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buffer = new byte[8192];
            int read;
            while ((read = in.read(buffer)) != -1) out.write(buffer, 0, read);
            return out.toByteArray();
        }
    }

    private static String readStream(InputStream in) throws Exception {
        if (in == null) return "";
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buffer = new byte[4096];
        int read;
        while ((read = in.read(buffer)) != -1) out.write(buffer, 0, read);
        return out.toString("UTF-8");
    }

    private static void postSuccess(StorageUploader.Callback callback, String url) {
        MAIN.post(() -> callback.onSuccess(url));
    }

    private static void postFailure(StorageUploader.Callback callback, String message) {
        MAIN.post(() -> callback.onFailure(message));
    }
}
