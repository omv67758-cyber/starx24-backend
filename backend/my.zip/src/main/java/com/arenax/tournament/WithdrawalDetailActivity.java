package com.arenax.tournament;


import com.arenax.tournament.util.FancyText;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.arenax.tournament.data.FirebaseRepository;
import com.bumptech.glide.Glide;
import com.google.android.material.button.MaterialButton;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.ValueEventListener;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.QRCodeWriter;

import java.text.SimpleDateFormat;
import java.util.Locale;
import java.util.Map;

/**
 * Full-screen withdrawal detail page — replaces the old cramped MaterialAlertDialog
 * ("Withdrawal TXN-xxxx" / MARK PAID / REJECT / CANCEL) with a proper page: user card,
 * UPI details + scan-to-pay QR, request summary, user information, an admin notification
 * composer, and the approve/reject actions pinned to the bottom.
 */
public class WithdrawalDetailActivity extends BaseActivity {

    public static final String EXTRA_TXN_ID = "txn_id";
    public static final String EXTRA_USER_ID = "user_id";
    public static final String EXTRA_AMOUNT_LABEL = "amount_label";
    public static final String EXTRA_CREATED_AT = "created_at";
    public static final String EXTRA_STATUS = "status"; // PENDING / PAID / REJECTED
    public static final String EXTRA_PENDING_COUNT = "pending_count";
    public static final String EXTRA_PENDING_TOTAL = "pending_total";

    private String txnId;
    private String userId;
    private String amountLabel;
    private long createdAt;
    private String status;

    private TextView notifyMessage;
    private EditText amountInput;
    private EditText reasonInput;
    private LinearLayout amountFieldRow;
    private LinearLayout reasonFieldRow;
    private TextView modeSuccessTab;
    private TextView modeRejectTab;
    private String notifyMode = "SUCCESS"; // SUCCESS or REJECT — which template is being composed
    private LinearLayout actionBar;
    private MaterialButton rejectActionBtn;
    private MaterialButton paidActionBtn;
    private boolean resolving = false;
    private TextView sendBtnRef;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        txnId = getIntent().getStringExtra(EXTRA_TXN_ID);
        userId = getIntent().getStringExtra(EXTRA_USER_ID);
        amountLabel = getIntent().getStringExtra(EXTRA_AMOUNT_LABEL);
        createdAt = getIntent().getLongExtra(EXTRA_CREATED_AT, System.currentTimeMillis());
        status = getIntent().getStringExtra(EXTRA_STATUS);
        if (status == null) status = "PENDING";
        if (txnId == null || txnId.trim().isEmpty()) {
            FancyText.toast(this, "Withdrawal record not found.", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }
        if (userId == null) userId = "";
        buildUi();
        try {
            loadUserAndUpi();
        } catch (Throwable error) {
            // A malformed user id (or similar) must never stop the detail page from opening.
            FancyText.toast(this, "Some details could not be loaded.", Toast.LENGTH_SHORT).show();
        }
    }

    private static final float CARD_R = 8f; // card corner radius (dp)
    private static final float BTN_R = 6f;  // button / input corner radius (dp)

    private int dp(float v) { return (int) (v * getResources().getDisplayMetrics().density + 0.5f); }

    private GradientDrawable fill(String hex, String strokeHex, float radiusDp, float strokeDp) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(Color.parseColor(hex));
        if (strokeHex != null) d.setStroke(dp(strokeDp), Color.parseColor(strokeHex));
        d.setCornerRadius(dp(radiusDp));
        return d;
    }

    private TextView label(String text, float sizeSp, boolean bold, String hex) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextSize(sizeSp);
        tv.setTypeface(null, bold ? Typeface.BOLD : Typeface.NORMAL);
        tv.setTextColor(Color.parseColor(hex));
        return tv;
    }

    /** A labelled white card shell — icon chip + bold title + optional description. */
    private LinearLayout card(String title) {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setBackground(fill("#FFFFFF", "#E5E3DE", CARD_R, 1f));
        c.setPadding(dp(14), dp(14), dp(14), dp(14));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.topMargin = dp(12);
        c.setLayoutParams(p);
        if (title != null) {
            LinearLayout header = new LinearLayout(this);
            header.setOrientation(LinearLayout.HORIZONTAL);
            header.setGravity(Gravity.CENTER_VERTICAL);
            TextView bar = new TextView(this);
            bar.setText("»");
            bar.setTextColor(Color.parseColor("#2F6FE0"));
            bar.setTypeface(null, Typeface.BOLD);
            bar.setTextSize(14f);
            header.addView(bar);
            TextView t = label(title, 14.5f, true, "#1C1C1E");
            LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(-2, -2);
            tp.leftMargin = dp(8);
            header.addView(t, tp);
            c.addView(header);
        }
        return c;
    }

    private View divider(int marginTopDp, int marginBottomDp) {
        View v = new View(this);
        v.setBackgroundColor(Color.parseColor("#E5E3DE"));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, dp(1));
        p.topMargin = dp(marginTopDp);
        p.bottomMargin = dp(marginBottomDp);
        v.setLayoutParams(p);
        return v;
    }

    private TextView statusChip(String status) {
        TextView chip = new TextView(this);
        String text; String fg; String bg;
        if ("PAID".equalsIgnoreCase(status) || "APPROVED".equalsIgnoreCase(status)) {
            text = "Success"; fg = "#059669"; bg = "#ECFDF5";
        } else if ("REJECTED".equalsIgnoreCase(status)) {
            text = "Rejected"; fg = "#DC2626"; bg = "#FEF2F2";
        } else {
            text = "Pending"; fg = "#B45309"; bg = "#FEF3C7";
        }
        chip.setText(text);
        chip.setTextSize(11f);
        chip.setTypeface(null, Typeface.BOLD);
        chip.setTextColor(Color.parseColor(fg));
        chip.setBackground(fill(bg, null, 6f, 0f));
        chip.setPadding(dp(10), dp(4), dp(10), dp(4));
        return chip;
    }

    /** Flat full-control button (plain TextView so the theme's black MaterialButton tint can never leak in). */
    private TextView flatButton(String text, String fg, String bg, String stroke, float textSp) {
        TextView b = new TextView(this);
        b.setText(text);
        b.setTextSize(textSp);
        b.setTypeface(null, Typeface.BOLD);
        b.setTextColor(Color.parseColor(fg));
        b.setGravity(Gravity.CENTER);
        b.setAllCaps(false);
        b.setBackground(fill(bg, stroke, BTN_R, stroke == null ? 0f : 1f));
        return b;
    }

    /** Round image with a visible outline ring. */
    private ImageView circleImage(int sizeDp, String ringHex, ViewGroup holder, ViewGroup.LayoutParams lp) {
        ImageView iv = new ImageView(this);
        iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
        GradientDrawable ring = new GradientDrawable();
        ring.setShape(GradientDrawable.OVAL);
        ring.setColor(Color.parseColor("#FFFFFF"));
        ring.setStroke(dp(2), Color.parseColor(ringHex));
        iv.setBackground(ring);
        iv.setPadding(dp(2), dp(2), dp(2), dp(2));
        iv.setOutlineProvider(android.view.ViewOutlineProvider.BACKGROUND);
        iv.setClipToOutline(true);
        holder.addView(iv, lp);
        return iv;
    }

    private ImageView avatarView;
    private TextView nameHeaderText;
    private TextView uidText;
    private TextView profileNameText;
    private TextView profileUserIdText;
    private TextView profilePhoneText;
    private TextView profileEmailText;
    private ImageView profilePhoto;
    private TextView upiIdText;
    private TextView upiNameText;
    private ImageView qrImage;
    private TextView pendingTotalText;
    private TextView pendingTabCount;
    private LinearLayout summaryCard;
    private LinearLayout statusChipHolder;

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.parseColor("#F5F4F1"));

        // ---- Top bar ----
        LinearLayout topBar = new LinearLayout(this);
        topBar.setOrientation(LinearLayout.HORIZONTAL);
        topBar.setGravity(Gravity.CENTER_VERTICAL);
        topBar.setPadding(dp(14), dp(14), dp(14), dp(10));
        topBar.setBackgroundColor(Color.parseColor("#FFFFFF"));

        TextView back = new TextView(this);
        back.setText("←");
        back.setTextSize(20f);
        back.setTypeface(null, Typeface.BOLD);
        back.setTextColor(Color.parseColor("#1C1C1E"));
        back.setGravity(Gravity.CENTER);
        back.setBackgroundResource(R.drawable.bg_admin_nav_item);
        back.setLayoutParams(new LinearLayout.LayoutParams(dp(40), dp(40)));
        back.setOnClickListener(v -> finish());
        topBar.addView(back);

        LinearLayout titleCol = new LinearLayout(this);
        titleCol.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams titleColParams = new LinearLayout.LayoutParams(0, -2, 1f);
        titleColParams.leftMargin = dp(10);
        titleCol.setLayoutParams(titleColParams);
        titleCol.addView(label("Payment Management", 16.5f, true, "#1C1C1E"));
        titleCol.addView(label("Withdrawal Requests", 11.5f, false, "#68686D"));
        topBar.addView(titleCol);

        LinearLayout pendingBadge = new LinearLayout(this);
        pendingBadge.setOrientation(LinearLayout.HORIZONTAL);
        pendingBadge.setGravity(Gravity.CENTER_VERTICAL);
        pendingBadge.setBackground(fill("#E8F1FF", null, CARD_R, 0f));
        pendingBadge.setPadding(dp(10), dp(6), dp(10), dp(6));
        TextView walletIcon = new TextView(this);
        walletIcon.setText("👛");
        walletIcon.setTextSize(14f);
        pendingBadge.addView(walletIcon);
        LinearLayout pendingCol = new LinearLayout(this);
        pendingCol.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams pendingColParams = new LinearLayout.LayoutParams(-2, -2);
        pendingColParams.leftMargin = dp(6);
        pendingCol.addView(label("Total Pending", 9.5f, false, "#68686D"));
        pendingTotalText = label("₹ —", 13f, true, "#2F6FE0");
        pendingCol.addView(pendingTotalText);
        pendingBadge.addView(pendingCol, pendingColParams);
        topBar.addView(pendingBadge);
        root.addView(topBar);

        // ---- Status tabs (informational — this page is one transaction's detail) ----
        LinearLayout tabsRow = new LinearLayout(this);
        tabsRow.setOrientation(LinearLayout.HORIZONTAL);
        tabsRow.setPadding(dp(14), dp(6), dp(14), dp(10));
        tabsRow.setBackgroundColor(Color.parseColor("#FFFFFF"));
        tabsRow.addView(buildTab("Pending", true, "count"));
        tabsRow.addView(buildTab("Completed", false, null));
        tabsRow.addView(buildTab("Rejected", false, null));
        tabsRow.addView(buildTab("All", false, null));
        root.addView(tabsRow);
        root.addView(divider(0, 0));

        // ---- Body ----
        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(dp(14), dp(4), dp(14), dp(16));

        // User summary card — tinted light green/red once this request is resolved (see applyResolvedState)
        summaryCard = card(null);
        LinearLayout summaryRow = new LinearLayout(this);
        summaryRow.setOrientation(LinearLayout.HORIZONTAL);
        summaryRow.setGravity(Gravity.CENTER_VERTICAL);

        avatarView = circleImage(54, "#2F6FE0", summaryRow, new LinearLayout.LayoutParams(dp(54), dp(54)));
        avatarView.setImageResource(R.drawable.ic_profile);

        LinearLayout summaryTextCol = new LinearLayout(this);
        summaryTextCol.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams summaryTextParams = new LinearLayout.LayoutParams(0, -2, 1f);
        summaryTextParams.leftMargin = dp(12);
        summaryTextCol.setLayoutParams(summaryTextParams);
        nameHeaderText = label("Loading…", 15.5f, true, "#1C1C1E");
        summaryTextCol.addView(nameHeaderText);
        uidText = label("", 11.5f, false, "#68686D");
        LinearLayout.LayoutParams uidParams = new LinearLayout.LayoutParams(-1, -2);
        uidParams.topMargin = dp(2);
        summaryTextCol.addView(uidText, uidParams);
        TextView userChip = label("User", 10f, true, "#2F6FE0");
        userChip.setBackground(fill("#E8F1FF", null, 5f, 0f));
        userChip.setPadding(dp(8), dp(3), dp(8), dp(3));
        LinearLayout.LayoutParams userChipParams = new LinearLayout.LayoutParams(-2, -2);
        userChipParams.topMargin = dp(6);
        summaryTextCol.addView(userChip, userChipParams);
        summaryRow.addView(summaryTextCol);

        LinearLayout amountCol = new LinearLayout(this);
        amountCol.setOrientation(LinearLayout.VERTICAL);
        amountCol.setGravity(Gravity.END);
        amountCol.addView(label(formatDate(createdAt), 10f, false, "#68686D"));
        TextView amountText = label(amountLabel == null ? "" : amountLabel, 17f, true, "#1C1C1E");
        LinearLayout.LayoutParams amountParams = new LinearLayout.LayoutParams(-2, -2);
        amountParams.topMargin = dp(4);
        amountCol.addView(amountText, amountParams);
        LinearLayout.LayoutParams chipParams = new LinearLayout.LayoutParams(-2, -2);
        chipParams.topMargin = dp(6);
        statusChipHolder = new LinearLayout(this);
        statusChipHolder.addView(statusChip(status));
        amountCol.addView(statusChipHolder, chipParams);
        summaryRow.addView(amountCol);

        summaryCard.addView(summaryRow);
        body.addView(summaryCard);

        // Auto-check warnings (same UPI / same device on many accounts, large amount) — filled after load.
        flagBanner = new TextView(this);
        flagBanner.setTextSize(12.5f);
        flagBanner.setTextColor(0xFFB3261E);
        flagBanner.setPadding(dp(14), dp(10), dp(14), dp(10));
        android.graphics.drawable.GradientDrawable flagBg = new android.graphics.drawable.GradientDrawable();
        flagBg.setColor(0xFFFDECEA);
        flagBg.setCornerRadius(dp(10));
        flagBanner.setBackground(flagBg);
        flagBanner.setVisibility(View.GONE);
        LinearLayout.LayoutParams flagLp = new LinearLayout.LayoutParams(-1, -2);
        flagLp.topMargin = dp(10);
        body.addView(flagBanner, flagLp);

        // UPI details card
        LinearLayout upiCard = card("UPI Details");
        LinearLayout upiBodyRow = new LinearLayout(this);
        upiBodyRow.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams upiBodyParams = new LinearLayout.LayoutParams(-1, -2);
        upiBodyParams.topMargin = dp(10);
        upiBodyRow.setLayoutParams(upiBodyParams);

        LinearLayout upiFieldsCol = new LinearLayout(this);
        upiFieldsCol.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams upiFieldsParams = new LinearLayout.LayoutParams(0, -2, 1f);
        upiFieldsCol.setLayoutParams(upiFieldsParams);

        LinearLayout upiIdRow = new LinearLayout(this);
        upiIdRow.setOrientation(LinearLayout.HORIZONTAL);
        upiIdRow.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout upiIdLabelCol = new LinearLayout(this);
        upiIdLabelCol.setOrientation(LinearLayout.VERTICAL);
        upiIdLabelCol.addView(label("UPI ID", 10.5f, false, "#68686D"));
        upiIdText = label("—", 13f, true, "#1C1C1E");
        upiIdLabelCol.addView(upiIdText);
        LinearLayout.LayoutParams upiIdLabelParams = new LinearLayout.LayoutParams(0, -2, 1f);
        upiIdRow.addView(upiIdLabelCol, upiIdLabelParams);
        TextView copyBtn = new TextView(this);
        copyBtn.setText("⧉");
        copyBtn.setTextSize(15f);
        copyBtn.setTextColor(Color.parseColor("#2F6FE0"));
        copyBtn.setPadding(dp(6), dp(6), dp(6), dp(6));
        copyBtn.setOnClickListener(v -> {
            ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("UPI ID", FancyText.plain(upiIdText.getText())));
            FancyText.toast(this, "UPI ID copied.", Toast.LENGTH_SHORT).show();
        });
        upiIdRow.addView(copyBtn);
        upiFieldsCol.addView(upiIdRow);

        LinearLayout upiNameCol = new LinearLayout(this);
        upiNameCol.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams upiNameParams = new LinearLayout.LayoutParams(-1, -2);
        upiNameParams.topMargin = dp(10);
        upiNameCol.setLayoutParams(upiNameParams);
        upiNameCol.addView(label("Name", 10.5f, false, "#68686D"));
        upiNameText = label("—", 13f, true, "#1C1C1E");
        upiNameCol.addView(upiNameText);
        upiFieldsCol.addView(upiNameCol);

        upiBodyRow.addView(upiFieldsCol);

        LinearLayout qrCol = new LinearLayout(this);
        qrCol.setOrientation(LinearLayout.VERTICAL);
        qrCol.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams qrColParams = new LinearLayout.LayoutParams(-2, -2);
        qrColParams.leftMargin = dp(12);
        qrCol.setLayoutParams(qrColParams);
        qrImage = new ImageView(this);
        qrImage.setBackground(fill("#FFFFFF", "#E5E3DE", BTN_R, 1f));
        qrCol.addView(qrImage, new LinearLayout.LayoutParams(dp(96), dp(96)));
        TextView scanLabel = label("Scan & Pay", 10f, false, "#68686D");
        LinearLayout.LayoutParams scanLabelParams = new LinearLayout.LayoutParams(-2, -2);
        scanLabelParams.topMargin = dp(4);
        qrCol.addView(scanLabel, scanLabelParams);
        upiBodyRow.addView(qrCol);

        upiCard.addView(upiBodyRow);
        body.addView(upiCard);

        // Amount + request-date summary strip
        LinearLayout stripCard = card(null);
        LinearLayout stripRow = new LinearLayout(this);
        stripRow.setOrientation(LinearLayout.HORIZONTAL);
        stripRow.setGravity(Gravity.CENTER_VERTICAL);

        LinearLayout stripLeft = new LinearLayout(this);
        stripLeft.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams stripLeftParams = new LinearLayout.LayoutParams(0, -2, 1f);
        stripLeft.setLayoutParams(stripLeftParams);
        stripLeft.addView(label("Withdrawal Amount", 10.5f, false, "#68686D"));
        stripLeft.addView(label(amountLabel == null ? "" : amountLabel, 15f, true, "#2F6FE0"));
        stripRow.addView(stripLeft);

        View verticalDivider = new View(this);
        verticalDivider.setBackgroundColor(Color.parseColor("#E5E3DE"));
        stripRow.addView(verticalDivider, new LinearLayout.LayoutParams(dp(1), dp(34)));

        LinearLayout stripRight = new LinearLayout(this);
        stripRight.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams stripRightParams = new LinearLayout.LayoutParams(0, -2, 1f);
        stripRightParams.leftMargin = dp(14);
        stripRight.setLayoutParams(stripRightParams);
        stripRight.addView(label("Request Date", 10.5f, false, "#68686D"));
        stripRight.addView(label(formatDate(createdAt), 13f, true, "#1C1C1E"));
        stripRow.addView(stripRight);

        stripCard.addView(stripRow);
        body.addView(stripCard);

        // User information card
        LinearLayout userInfoCard = card("User Information");
        LinearLayout userInfoRow = new LinearLayout(this);
        userInfoRow.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams userInfoRowParams = new LinearLayout.LayoutParams(-1, -2);
        userInfoRowParams.topMargin = dp(10);
        userInfoRow.setLayoutParams(userInfoRowParams);

        LinearLayout infoFieldsCol = new LinearLayout(this);
        infoFieldsCol.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams infoFieldsParams = new LinearLayout.LayoutParams(0, -2, 1f);
        infoFieldsCol.setLayoutParams(infoFieldsParams);
        profileNameText = infoLine(infoFieldsCol, "Name", "—");
        profileUserIdText = infoLine(infoFieldsCol, "UPI ID", "—");
        profilePhoneText = infoLine(infoFieldsCol, "Phone", "—");
        profileEmailText = infoLine(infoFieldsCol, "Email", "—");
        userInfoRow.addView(infoFieldsCol);

        LinearLayout photoCol = new LinearLayout(this);
        photoCol.setOrientation(LinearLayout.VERTICAL);
        photoCol.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams photoColParams = new LinearLayout.LayoutParams(-2, -2);
        photoColParams.leftMargin = dp(12);
        photoCol.setLayoutParams(photoColParams);
        profilePhoto = circleImage(64, "#2F6FE0", photoCol, new LinearLayout.LayoutParams(dp(64), dp(64)));
        profilePhoto.setImageResource(R.drawable.ic_profile);
        userInfoRow.addView(photoCol);

        userInfoCard.addView(userInfoRow);

        TextView viewProfileBtn = flatButton("View Profile", "#2F6FE0", "#E8F1FF", "#C9DDFB", 12.5f);
        viewProfileBtn.setOnClickListener(v -> {
            Intent i = new Intent(this, AdminActivity.class);
            i.putExtra("openWorkspace", "users");
            startActivity(i);
        });
        LinearLayout.LayoutParams viewProfileParams = new LinearLayout.LayoutParams(-1, dp(42));
        viewProfileParams.topMargin = dp(12);
        userInfoCard.addView(viewProfileBtn, viewProfileParams);
        body.addView(userInfoCard);

        // Send notification card — pick Success or Rejected, fill in just the
        // amount (or reason), and the exact STARX24 template is built and put
        // into the message box automatically. No more copy-pasting the same
        // wording every time; the box stays editable if you want to tweak it.
        LinearLayout notifyCard = card("Send Notification");
        notifyCard.addView(label("Select the outcome and fill in the blank — the message is generated for you.", 11f, false, "#68686D"),
                notifyDescParams());

        LinearLayout modeRow = new LinearLayout(this);
        modeRow.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams modeRowParams = new LinearLayout.LayoutParams(-1, -2);
        modeRowParams.topMargin = dp(10);
        modeRow.setLayoutParams(modeRowParams);

        modeSuccessTab = label("✅  Success", 12.5f, true, "#22A06B");
        modeSuccessTab.setGravity(Gravity.CENTER);
        modeSuccessTab.setPadding(dp(10), dp(12), dp(10), dp(12));
        LinearLayout.LayoutParams modeSuccessParams = new LinearLayout.LayoutParams(0, -2, 1f);
        modeSuccessParams.rightMargin = dp(6);
        modeSuccessTab.setOnClickListener(v -> setNotifyMode("SUCCESS"));
        modeRow.addView(modeSuccessTab, modeSuccessParams);

        modeRejectTab = label("🚫  Rejected", 12.5f, true, "#68686D");
        modeRejectTab.setGravity(Gravity.CENTER);
        modeRejectTab.setPadding(dp(10), dp(12), dp(10), dp(12));
        modeRejectTab.setOnClickListener(v -> setNotifyMode("REJECT"));
        modeRow.addView(modeRejectTab, new LinearLayout.LayoutParams(0, -2, 1f));
        notifyCard.addView(modeRow);

        // Amount field (Success mode) — pre-filled with the requested amount, editable
        // in case only part of it was actually sent.
        amountFieldRow = new LinearLayout(this);
        amountFieldRow.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams amountFieldParams = new LinearLayout.LayoutParams(-1, -2);
        amountFieldParams.topMargin = dp(10);
        amountFieldRow.setLayoutParams(amountFieldParams);
        amountFieldRow.addView(label("Amount Sent (₹)", 10.5f, false, "#68686D"));
        amountInput = new EditText(this);
        amountInput.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        amountInput.setHint("Amount you sent");
        amountInput.setTextColor(Color.parseColor("#1C1C1E"));
        amountInput.setTextSize(13f);
        amountInput.setBackground(fill("#FFFFFF", "#E5E3DE", BTN_R, 1f));
        amountInput.setPadding(dp(12), dp(10), dp(12), dp(10));
        amountInput.setText(digitsOnly(amountLabel));
        LinearLayout.LayoutParams amountInputParams = new LinearLayout.LayoutParams(-1, -2);
        amountInputParams.topMargin = dp(4);
        amountFieldRow.addView(amountInput, amountInputParams);
        notifyCard.addView(amountFieldRow);

        // Reason field (Reject mode)
        reasonFieldRow = new LinearLayout(this);
        reasonFieldRow.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams reasonFieldParams = new LinearLayout.LayoutParams(-1, -2);
        reasonFieldParams.topMargin = dp(10);
        reasonFieldRow.setLayoutParams(reasonFieldParams);
        reasonFieldRow.addView(label("Rejection Reason", 10.5f, false, "#68686D"));
        reasonInput = new EditText(this);
        reasonInput.setHint("e.g. Wrong UPI ID provided");
        reasonInput.setTextColor(Color.parseColor("#1C1C1E"));
        reasonInput.setTextSize(13f);
        reasonInput.setBackground(fill("#FFFFFF", "#E5E3DE", BTN_R, 1f));
        reasonInput.setPadding(dp(12), dp(10), dp(12), dp(10));
        LinearLayout.LayoutParams reasonInputParams = new LinearLayout.LayoutParams(-1, -2);
        reasonInputParams.topMargin = dp(4);
        reasonFieldRow.addView(reasonInput, reasonInputParams);
        notifyCard.addView(reasonFieldRow);
        reasonFieldRow.setVisibility(View.GONE);

        TextWatcher regenerateWatcher = new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {}
            @Override public void afterTextChanged(Editable s) { regenerateNotifyMessage(); }
        };
        amountInput.addTextChangedListener(regenerateWatcher);
        reasonInput.addTextChangedListener(regenerateWatcher);

        notifyMessage = new EditText(this);
        notifyMessage.setMinLines(3);
        notifyMessage.setGravity(Gravity.TOP | Gravity.START);
        notifyMessage.setTextColor(Color.parseColor("#1C1C1E"));
        notifyMessage.setTextSize(12.5f);
        notifyMessage.setBackground(fill("#FFFFFF", "#E5E3DE", BTN_R, 1f));
        notifyMessage.setPadding(dp(12), dp(10), dp(12), dp(10));
        LinearLayout.LayoutParams notifyMsgParams = new LinearLayout.LayoutParams(-1, -2);
        notifyMsgParams.topMargin = dp(10);
        notifyCard.addView(notifyMessage, notifyMsgParams);

        TextView sendBtn = flatButton("➤  Send Notification", "#FFFFFF", "#2F6FE0", null, 13.5f);
        sendBtnRef = sendBtn;
        sendBtn.setOnClickListener(v -> sendNotification());
        LinearLayout.LayoutParams sendBtnParams = new LinearLayout.LayoutParams(-1, dp(46));
        sendBtnParams.topMargin = dp(12);
        notifyCard.addView(sendBtn, sendBtnParams);
        body.addView(notifyCard);

        setNotifyMode("SUCCESS");

        ScrollView scroll = new ScrollView(this);
        scroll.addView(body);
        scroll.setLayoutParams(new LinearLayout.LayoutParams(-1, 0, 1f));
        root.addView(scroll);

        // ---- Pinned approve/reject action bar (only when still pending) ----
        actionBar = new LinearLayout(this);
        actionBar.setOrientation(LinearLayout.HORIZONTAL);
        actionBar.setPadding(dp(14), dp(10), dp(14), dp(10));
        actionBar.setBackgroundColor(Color.parseColor("#FFFFFF"));
        {
            String statusText = "PENDING".equalsIgnoreCase(status)
                    ? "This request is pending."
                    : "This request is already " + status.toLowerCase(Locale.ENGLISH) + ".";
            TextView st = label(statusText, 12f, false, "#68686D");
            st.setGravity(Gravity.CENTER);
            actionBar.addView(st, new LinearLayout.LayoutParams(-1, -2));
        }
        root.addView(divider(0, 0));
        root.addView(actionBar);

        setContentView(root);
    }

    private LinearLayout.LayoutParams notifyDescParams() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.topMargin = dp(2);
        return p;
    }

    private TextView infoLine(LinearLayout parent, String label, String value) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams rowParams = new LinearLayout.LayoutParams(-1, -2);
        rowParams.topMargin = dp(6);
        row.setLayoutParams(rowParams);
        TextView labelView = label(label, 11.5f, false, "#68686D");
        labelView.setLayoutParams(new LinearLayout.LayoutParams(dp(72), -2));
        row.addView(labelView);
        TextView valueView = label(value, 12f, true, "#1C1C1E");
        row.addView(valueView);
        parent.addView(row);
        return valueView;
    }

    private View buildTab(String text, boolean active, String suffixTag) {
        TextView tab = new TextView(this);
        tab.setText(text);
        tab.setTextSize(11.5f);
        tab.setTypeface(null, Typeface.BOLD);
        tab.setGravity(Gravity.CENTER);
        tab.setSingleLine(true);
        tab.setPadding(dp(2), dp(10), dp(2), dp(10));
        if (active) {
            tab.setBackground(fill("#2F6FE0", null, BTN_R, 0f));
            tab.setTextColor(Color.WHITE);
        } else {
            tab.setBackground(fill("#F0EFEB", "#E5E3DE", BTN_R, 1f));
            tab.setTextColor(Color.parseColor("#68686D"));
        }
        // Equal-weight, full-width: the four tabs fill the whole row.
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1f);
        if (!"All".equals(text)) lp.setMarginEnd(dp(6));
        tab.setLayoutParams(lp);
        // These tabs describe the queue this transaction belongs to; tapping returns to the list.
        tab.setOnClickListener(v -> finish());
        if ("count".equals(suffixTag)) pendingTabCount = tab;
        return tab;
    }

    // ------------------------------------------------------------------
    // Data
    // ------------------------------------------------------------------

    private void loadUserAndUpi() {
        if (userId.isEmpty() || "null".equals(userId)) nameHeaderText.setText("STARX24 Player");
        else FirebaseRepository.users().child(userId).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override public void onDataChange(DataSnapshot snapshot) {
                if (isFinishing() || isDestroyed()) return;
                Object raw = snapshot.getValue();
                Map<String, Object> data = raw instanceof Map ? (Map<String, Object>) raw : null;
                String name = data == null || data.get("name") == null ? "" : String.valueOf(data.get("name"));
                String email = data == null || data.get("email") == null ? "" : String.valueOf(data.get("email"));
                String phone = data == null || data.get("phone") == null ? "" : String.valueOf(data.get("phone"));
                String photoUrl = data == null || data.get("photoUrl") == null ? "" : String.valueOf(data.get("photoUrl"));
                String displayName = name.isEmpty() || "null".equals(name) ? "STARX24 Player" : name;

                nameHeaderText.setText(displayName);
                uidText.setText(!phone.isEmpty() && !"null".equals(phone) ? phone : (email.isEmpty() || "null".equals(email) ? "" : email));
                profileNameText.setText(displayName);
                profilePhoneText.setText(phone.isEmpty() ? "Not provided" : phone);
                profileEmailText.setText(email.isEmpty() ? "Not provided" : email);
                upiNameText.setText(displayName);

                if (!photoUrl.isEmpty()) {
                    Glide.with(getApplicationContext()).load(photoUrl)
                            .placeholder(R.drawable.ic_profile).error(R.drawable.ic_profile)
                            .centerCrop().into(avatarView);
                    Glide.with(getApplicationContext()).load(photoUrl)
                            .placeholder(R.drawable.ic_profile).error(R.drawable.ic_profile)
                            .centerCrop().into(profilePhoto);
                }
            }
            @Override public void onCancelled(DatabaseError error) {
                nameHeaderText.setText("STARX24 Player");
            }
        });

        FirebaseRepository.withdrawals().child(txnId).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override public void onDataChange(DataSnapshot snapshot) {
                if (isFinishing() || isDestroyed()) return;
                StringBuilder warn = new StringBuilder();
                for (DataSnapshot f : snapshot.child("flags").getChildren()) {
                    String flag = String.valueOf(f.getValue());
                    String[] parts = flag.split("_");
                    if (flag.startsWith("SAME_UPI_")) warn.append("\u26A0 Same UPI ID used by ").append(parts[2]).append(" accounts\n");
                    else if (flag.startsWith("SAME_DEVICE_")) warn.append("\u26A0 Same device used by ").append(parts[2]).append(" accounts\n");
                    else if (flag.startsWith("LARGE_AMOUNT_")) warn.append("\u26A0 Large withdrawal (").append(parts[2]).append(" coins) - verify before paying\n");
                    else warn.append("\u26A0 ").append(flag).append("\n");
                }
                if (flagBanner != null && warn.length() > 0) {
                    flagBanner.setText(warn.toString().trim());
                    flagBanner.setVisibility(View.VISIBLE);
                }
                Object upiVal = snapshot.child("upiId").getValue();
                String upiId = upiVal == null ? "" : String.valueOf(upiVal);
                upiIdText.setText(upiId.isEmpty() ? "Not provided" : upiId);
                profileUserIdText.setText(upiId.isEmpty() ? "Not provided" : upiId);
                if (!upiId.isEmpty()) generateQr("upi://pay?pa=" + upiId + "&pn=" + FancyText.plain(upiNameText.getText()));
            }
            @Override public void onCancelled(DatabaseError error) { upiIdText.setText("Not provided"); }
        });

        // Total pending, across every withdrawal — shown in the top-right badge and the Pending tab.
        FirebaseRepository.withdrawals().addListenerForSingleValueEvent(new ValueEventListener() {
            @Override public void onDataChange(DataSnapshot snapshot) {
                if (isFinishing() || isDestroyed()) return;
                long now = System.currentTimeMillis();
                long total = 0; int count = 0;
                for (DataSnapshot child : snapshot.getChildren()) {
                    String rawStatus = String.valueOf(child.child("status").getValue());
                    Object tsVal = child.child("createdAt").getValue();
                    long ts = tsVal instanceof Number ? ((Number) tsVal).longValue() : now;
                    com.arenax.tournament.admin.WithdrawalStatus.State state =
                            com.arenax.tournament.admin.WithdrawalStatus.resolve(rawStatus, ts, now);
                    boolean pending = !"REJECTED".equalsIgnoreCase(rawStatus)
                            && state != com.arenax.tournament.admin.WithdrawalStatus.State.PAID;
                    if (pending) {
                        count++;
                        Object amt = child.child("amount").getValue();
                        if (amt instanceof Number) total += ((Number) amt).longValue();
                    }
                }
                pendingTotalText.setText("₹ " + total);
                if (pendingTabCount != null) pendingTabCount.setText("Pending (" + count + ")");
            }
            @Override public void onCancelled(DatabaseError error) { pendingTotalText.setText("₹ —"); }
        });
    }

    private void generateQr(String content) {
        try {
            QRCodeWriter writer = new QRCodeWriter();
            int size = dp(96);
            BitMatrix matrix = writer.encode(content, BarcodeFormat.QR_CODE, size, size);
            Bitmap bmp = Bitmap.createBitmap(size, size, Bitmap.Config.RGB_565);
            for (int x = 0; x < size; x++) {
                for (int y = 0; y < size; y++) {
                    bmp.setPixel(x, y, matrix.get(x, y) ? Color.BLACK : Color.WHITE);
                }
            }
            qrImage.setImageBitmap(bmp);
        } catch (WriterException e) {
            // Leave the QR box blank — the UPI ID text above is still usable on its own.
        }
    }

    private String shortId(String uid) {
        if (uid == null) return "";
        return uid.length() > 6 ? uid.substring(uid.length() - 6).toUpperCase(Locale.ENGLISH) : uid;
    }

    private String formatDate(long ts) {
        return new SimpleDateFormat("dd MMM yyyy • hh:mm a", Locale.ENGLISH).format(new java.util.Date(ts));
    }

    private String digitsOnly(String s) {
        if (s == null) return "";
        StringBuilder sb = new StringBuilder();
        for (char c : s.toCharArray()) {
            if (Character.isDigit(c) || c == '.') sb.append(c);
        }
        // Trim a trailing ".00" so the template reads "₹50" instead of "₹50.00".
        String out = sb.toString();
        if (out.endsWith(".00")) out = out.substring(0, out.length() - 3);
        return out;
    }

    private void setNotifyMode(String mode) {
        notifyMode = mode;
        boolean success = "SUCCESS".equals(mode);
        if (modeSuccessTab != null) {
            modeSuccessTab.setBackground(fill(success ? "#ECFDF5" : "#F0EFEB", success ? "#A7E4C6" : "#E5E3DE", BTN_R, 1f));
            modeSuccessTab.setTextColor(Color.parseColor(success ? "#22A06B" : "#68686D"));
        }
        if (modeRejectTab != null) {
            modeRejectTab.setBackground(fill(!success ? "#FEF2F2" : "#F0EFEB", !success ? "#F5B5B5" : "#E5E3DE", BTN_R, 1f));
            modeRejectTab.setTextColor(Color.parseColor(!success ? "#DC2626" : "#68686D"));
        }
        if (amountFieldRow != null) amountFieldRow.setVisibility(success ? View.VISIBLE : View.GONE);
        if (reasonFieldRow != null) reasonFieldRow.setVisibility(success ? View.GONE : View.VISIBLE);
        regenerateNotifyMessage();
    }

    /** Fills the exact STARX24 template with the amount / reason typed above. */
    private void regenerateNotifyMessage() {
        if (notifyMessage == null) return;
        if ("SUCCESS".equals(notifyMode)) {
            String amount = amountInput == null ? "" : amountInput.getText().toString().trim();
            notifyMessage.setText("\uD83C\uDF89 STARX24 | Withdrawal Successful — ₹" + amount + "\u2705\n\n"
                    + "\uD83D\uDCB0 Your withdrawal of ₹" + amount + " has been successfully processed and credited to your selected payment account.\n\n"
                    + "Thank you for choosing STARX24.\u2764\uFE0F\u200D\uD83E\uDE79");
        } else {
            String reason = reasonInput == null ? "" : reasonInput.getText().toString().trim();
            notifyMessage.setText("\uD83D\uDEAB STARX24 | Withdrawal Rejected\n\n"
                    + "Your withdrawal request could not be processed and has been rejected.\n\n"
                    + "\uD83D\uDCB0 If applicable, the requested amount has been returned to your STARX24 wallet.\n\n"
                    + "\uD83D\uDCCC Reason: " + reason + "\n\n"
                    + "Please check the details and submit a new withdrawal request if required.\n\n"
                    + "Thank you for choosing STARX24. \u2764\uFE0F");
        }
    }

    /**
     * Send Notification now also settles the request:
     *  - Success mode  -> withdrawal is marked PAID (shows "Success" and moves to Completed history)
     *  - Rejected mode -> withdrawal is marked REJECTED (shows "Rejected"; backend refunds locked coins)
     * The notice goes to the player only after the status change succeeded, so they are never
     * told "paid" while the request is still pending. Already-resolved requests just get the notice.
     */
    private void sendNotification() {
        String message = notifyMessage.getText().toString().trim();
        if (message.isEmpty()) {
            FancyText.toast(this, "Write a message first.", Toast.LENGTH_SHORT).show();
            return;
        }
        boolean success = "SUCCESS".equals(notifyMode);
        if (success && (amountInput.getText().toString().trim().isEmpty())) {
            FancyText.toast(this, "Enter the amount sent.", Toast.LENGTH_SHORT).show();
            return;
        }
        if (!success && reasonInput.getText().toString().trim().isEmpty()) {
            FancyText.toast(this, "Enter the rejection reason.", Toast.LENGTH_SHORT).show();
            return;
        }
        boolean alreadyResolved = "PAID".equalsIgnoreCase(status)
                || "APPROVED".equalsIgnoreCase(status)
                || "REJECTED".equalsIgnoreCase(status);
        if (alreadyResolved) {
            pushNotice(message, null);
            return;
        }
        resolveWithdrawal(success ? "PAID" : "REJECTED", message);
    }

    /** Payment Update / WITHDRAWAL_NOTICE — push to the user's device + their wallet bell inbox. */
    private void pushNotice(String message, Runnable afterSent) {
        FirebaseRepository.sendAdminNotice(userId, message, FancyText.plain(nameHeaderText.getText()),
                        "Payment Update", "WITHDRAWAL_NOTICE")
                .addOnSuccessListener(v -> {
                    FancyText.toast(this, "Notification sent.", Toast.LENGTH_SHORT).show();
                    if (afterSent != null) afterSent.run();
                })
                .addOnFailureListener(e -> {
                    FancyText.toast(this, "Send failed: " + e.getMessage(), Toast.LENGTH_LONG).show();
                    if (afterSent != null) afterSent.run();
                });
    }

    private TextView flagBanner;

    private void resolveWithdrawal(String action, String noticeMessage) {
        // Guard against double-submit: without this, a second tap while the first
        // request is still in flight (slow network, or just an impatient double-tap)
        // fires a second /admin/approveWithdrawal call. The first call has already
        // claimed the record, so the backend correctly rejects the second one with
        // "This withdrawal was already resolved" — which then just sits there as a
        // red toast the admin can't do anything about. Disabling both buttons the
        // instant one is tapped stops that second call from ever going out.
        if (resolving) return;
        resolving = true;
        if (rejectActionBtn != null) rejectActionBtn.setEnabled(false);
        if (paidActionBtn != null) paidActionBtn.setEnabled(false);
        if (sendBtnRef != null) sendBtnRef.setEnabled(false);

        WithdrawalApiClient.approveWithdrawal(txnId, action, new WithdrawalApiClient.SimpleCallback() {
            @Override public void onSuccess(org.json.JSONObject result) {
                FirebaseRepository.logActivity(action.equals("PAID") ? "WITHDRAWAL_PAID" : "WITHDRAWAL_REJECTED",
                        txnId, "user " + userId);
                status = action;
                applyResolvedState(action);
                setResult(RESULT_OK);
                FancyText.toast(WithdrawalDetailActivity.this,
                        action.equals("PAID") ? "Payment marked Success." : "Payment marked Rejected.",
                        Toast.LENGTH_SHORT).show();
                // Tell the player, then return to the list (brief pause so the status change is visible).
                pushNotice(noticeMessage, () -> new android.os.Handler(getMainLooper())
                        .postDelayed(WithdrawalDetailActivity.this::finish, 900));
            }
            @Override public void onError(String message) {
                resolving = false;
                // Already resolved (e.g. another admin/device beat this one to it, or
                // the pending list this screen was opened from was stale): retrying
                // will only ever fail the same way, so don't leave dead, re-enabled
                // buttons behind — reflect the real state and let the admin move on.
                if (message != null && message.toLowerCase(Locale.ENGLISH).contains("already resolved")) {
                    FancyText.toast(WithdrawalDetailActivity.this,
                            "Already handled elsewhere — refreshing.", Toast.LENGTH_LONG).show();
                    setResult(RESULT_OK);
                    finish();
                    return;
                }
                if (rejectActionBtn != null) rejectActionBtn.setEnabled(true);
                if (paidActionBtn != null) paidActionBtn.setEnabled(true);
                if (sendBtnRef != null) sendBtnRef.setEnabled(true);
                FancyText.toast(WithdrawalDetailActivity.this, "Failed: " + message, Toast.LENGTH_LONG).show();
            }
        });
    }

    /** REJECTED -> light red card, PAID -> light green card; same tints statusChip() already uses. */
    private void applyResolvedState(String action) {
        boolean paid = "PAID".equalsIgnoreCase(action);
        if (summaryCard != null) {
            summaryCard.setBackground(fill(paid ? "#ECFDF5" : "#FEF2F2", paid ? "#A7E4C6" : "#F5B5B5", CARD_R, 1f));
        }
        if (statusChipHolder != null) {
            statusChipHolder.removeAllViews();
            statusChipHolder.addView(statusChip(action));
        }
        if (actionBar != null) {
            actionBar.removeAllViews();
            TextView st = label("This request is now " + action.toLowerCase(Locale.ENGLISH) + ".", 12f, false, "#68686D");
            st.setGravity(Gravity.CENTER);
            actionBar.addView(st, new LinearLayout.LayoutParams(-1, -2));
        }
    }
}
