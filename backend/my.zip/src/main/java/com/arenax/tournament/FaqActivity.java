package com.arenax.tournament;


import com.arenax.tournament.util.FancyText;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.widget.NestedScrollView;

import com.arenax.tournament.data.FirebaseRepository;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Help Center — FAQ list read live from Firebase, browsable by category chip
 *  (All / Prizes / Gameplay / Coins / Matches / Support). White/gold STARX24
 *  theme with colour-coded category cards, matching the rest of the app.
 *  Each row expands in place to reveal its answer, with an escalation button
 *  into Support if the player still needs help. */
public class FaqActivity extends BaseActivity {

    /** category key -> {icon drawable res id, soft background colour, accent/text colour} */
    private static final class Meta {
        final int icon; final String bg, accent;
        Meta(int icon, String bg, String accent) { this.icon = icon; this.bg = bg; this.accent = accent; }
    }
    private static final Map<String, Meta> CATEGORY_META = new LinkedHashMap<>();
    static {
        CATEGORY_META.put("prizes",   new Meta(R.drawable.ic_trophy,   "#FDF3D9", "#8D6B12"));
        CATEGORY_META.put("gameplay", new Meta(R.drawable.ic_gamepad,  "#ECE8FB", "#5B3FC4"));
        CATEGORY_META.put("coins",    new Meta(R.drawable.ic_coin,     "#FDF3D9", "#8D6B12"));
        CATEGORY_META.put("matches",  new Meta(R.drawable.ic_matches,  "#E8EEF7", "#3B5BA0"));
        CATEGORY_META.put("support",  new Meta(R.drawable.am_ic_headset, "#FBE7E7", "#C0392B"));
    }
    private static final Meta DEFAULT_META = new Meta(R.drawable.ic_info, "#F5F4F1", "#68686D"); // fallback

    /** Built-in question/answer content so the Help Center is never empty,
     *  even before an admin adds anything through Firebase. */
    private static final String[][] DEFAULT_FAQS = {
            {"prizes", "Why didn't I receive my prizes?",
                    "\u2022 Check the special notes of the previously joined match to verify if the gameplay recording was required.\n\n"
                    + "\u2022 Ensure you haven't violated match rules & regulations, as this could result in prizes ineligibility."},
            {"gameplay", "When Should I Start Recording?",
                    "\u2022 Before joining the custom room, start screen recording to provide evidence if you are removed from the room and need to request a refund.\n\n"
                    + "\u2022 During the match, use in-game recording tools or a screen recorder for documentation.\n\n"
                    + "\u2022 If suspicious gameplay is identified, We may request your recording. Only the screen recording will be considered valid evidence in such cases, not the in-game recording."},
            {"matches", "Can I know the custom room settings of matches?",
                    "\u2022 Yes, you can contact customer support to request the custom room settings."},
            {"coins", "How can I earn and use bonus coins?",
                    "\u2022 Earn bonus coins by referring your friends. When your friend joins their first paid match, you will receive 5 bonus coins.\n\n"
                    + "\u2022 Use bonus coins to participate in matches."},
            {"matches", "Can I know when matches are added?",
                    "\u2022 No, there is no specific time for adding matches. They can be added at any time."},
            {"support", "What should I do if my prizes are not credited to my account within the given time?",
                    "\u2022 Contact customer support with the match details and proof of your win to get assistance."},
            {"coins", "When will I receive my purchased coins?",
                    "\u2022 Coins are usually credited within seconds to minutes.\n\n"
                    + "\u2022 If there's a delay, contact customer support for help."},
            {"matches", "How do I join a match?",
                    "\u2022 Navigate to the matches section.\n\n"
                    + "\u2022 Select your preferred match and follow the registration steps.\n\n"
                    + "\u2022 Ensure you meet the eligibility criteria before joining."},
            {"coins", "How do I withdraw my earnings?",
                    "\u2022 Go to the wallet section.\n\n"
                    + "\u2022 Select withdraw and provide the required details.\n\n"
                    + "\u2022 The funds will be successfully transferred to your account within 6/12 hours."},
    };

    private final List<DataSnapshot> allFaqs = new ArrayList<>();
    private final List<TextView> chipViews = new ArrayList<>();
    private LinearLayout list;
    private TextView empty;
    private ValueEventListener listener;
    private String selectedCategory = "all";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildScreen();
        loadFaqs();
    }

    // ---------------------------------------------------------------- UI ---

    private void buildScreen() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.parseColor("#F6F5F2"));

        NestedScrollView outer = new NestedScrollView(this);
        outer.setFillViewport(true);
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(18), dp(18), dp(18), dp(18));

        page.addView(buildHeader());
        page.addView(buildChipRow());

        list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams listParams = new LinearLayout.LayoutParams(-1, -2);
        listParams.topMargin = dp(16);
        list.setLayoutParams(listParams);

        empty = label("No FAQs in this category yet. Try another tab or contact support.", 14,
                Color.parseColor("#68686D"), false);
        empty.setGravity(Gravity.CENTER);
        empty.setPadding(0, dp(40), 0, dp(20));
        empty.setVisibility(View.GONE);

        page.addView(list);
        page.addView(empty);
        outer.addView(page);
        root.addView(outer, new LinearLayout.LayoutParams(-1, 0, 1));
        root.addView(buildContactButton());
        setContentView(root);
    }

    private View buildHeader() {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.TOP);

        LinearLayout left = new LinearLayout(this);
        left.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams leftParams = new LinearLayout.LayoutParams(0, -2, 1);
        left.setLayoutParams(leftParams);

        TextView back = label("\u2039", 30, Color.parseColor("#1C1C1E"), true);
        back.setGravity(Gravity.CENTER);
        GradientDrawable backBg = new GradientDrawable();
        backBg.setShape(GradientDrawable.OVAL);
        backBg.setColor(Color.parseColor("#FFFFFF"));
        back.setBackground(backBg);
        back.setOnClickListener(v -> finish());
        LinearLayout.LayoutParams backParams = new LinearLayout.LayoutParams(dp(40), dp(40));
        backParams.bottomMargin = dp(14);
        back.setLayoutParams(backParams);
        left.addView(back);

        TextView titleLine1 = label("Frequently Asked", 25, Color.parseColor("#1C1C1E"), true);
        TextView titleLine2 = label("Questions", 25, Color.parseColor("#2563EB"), true);
        left.addView(titleLine1);
        left.addView(titleLine2);

        TextView subtitle = label("Find quick answers to common questions and get the help you need.",
                13, Color.parseColor("#68686D"), false);
        LinearLayout.LayoutParams subParams = new LinearLayout.LayoutParams(-1, -2);
        subParams.topMargin = dp(8);
        subtitle.setLayoutParams(subParams);
        left.addView(subtitle);

        row.addView(left);
        row.addView(buildHeaderDeco());
        return row;
    }

    /** Small decorative "chat bubble" cluster mirroring the reference art, built
     *  from plain shapes/emoji so no extra drawable assets are needed. */
    private View buildHeaderDeco() {
        FrameLayout deco = new FrameLayout(this);
        deco.setLayoutParams(new LinearLayout.LayoutParams(dp(84), dp(84)));

        GradientDrawable haze = new GradientDrawable();
        haze.setShape(GradientDrawable.OVAL);
        haze.setColor(Color.parseColor("#332F6FED"));
        View hazeView = new View(this);
        hazeView.setBackground(haze);
        FrameLayout.LayoutParams hazeParams = new FrameLayout.LayoutParams(dp(76), dp(76));
        hazeParams.gravity = Gravity.BOTTOM | Gravity.END;
        deco.addView(hazeView, hazeParams);

        GradientDrawable bubbleBg = new GradientDrawable();
        bubbleBg.setOrientation(GradientDrawable.Orientation.TL_BR);
        bubbleBg.setColors(new int[]{Color.parseColor("#7C5CE8"), Color.parseColor("#2F6FED")});
        bubbleBg.setCornerRadius(dp(16));
        TextView bubble = label("?", 22, Color.WHITE, true);
        bubble.setGravity(Gravity.CENTER);
        bubble.setBackground(bubbleBg);
        FrameLayout.LayoutParams bubbleParams = new FrameLayout.LayoutParams(dp(48), dp(48));
        bubbleParams.gravity = Gravity.TOP | Gravity.START;
        deco.addView(bubble, bubbleParams);

        GradientDrawable dotsBg = new GradientDrawable();
        dotsBg.setColor(Color.parseColor("#FFFFFF"));
        dotsBg.setCornerRadius(dp(12));
        TextView dots = label("\u2022\u2022\u2022", 12, Color.parseColor("#EF5DA8"), true);
        dots.setGravity(Gravity.CENTER);
        dots.setBackground(dotsBg);
        FrameLayout.LayoutParams dotsParams = new FrameLayout.LayoutParams(dp(36), dp(26));
        dotsParams.gravity = Gravity.BOTTOM | Gravity.END;
        dotsParams.bottomMargin = dp(4);
        deco.addView(dots, dotsParams);

        return deco;
    }

    private View buildChipRow() {
        HorizontalScrollView scroll = new HorizontalScrollView(this);
        scroll.setHorizontalScrollBarEnabled(false);
        LinearLayout.LayoutParams scrollParams = new LinearLayout.LayoutParams(-1, -2);
        scrollParams.topMargin = dp(20);
        scroll.setLayoutParams(scrollParams);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);

        addChip(row, "all", R.drawable.ic_info, "All");
        addChip(row, "prizes", CATEGORY_META.get("prizes").icon, "Prizes");
        addChip(row, "gameplay", CATEGORY_META.get("gameplay").icon, "Gameplay");
        addChip(row, "coins", 0, "Coins");
        addChip(row, "matches", CATEGORY_META.get("matches").icon, "Matches");
        addChip(row, "support", CATEGORY_META.get("support").icon, "Support");

        scroll.addView(row);
        return scroll;
    }

    private void addChip(LinearLayout row, String key, int iconRes, String text) {
        TextView chip = new TextView(this);
        chip.setTag(key);
        chip.setText("  " + text);
        chip.setTextSize(13.5f);
        chip.setGravity(Gravity.CENTER);
        chip.setPadding(dp(16), dp(11), dp(18), dp(11));
        chip.setCompoundDrawablePadding(dp(6));
        boolean isCoin = "coins".equals(key);
        android.graphics.drawable.Drawable icon = isCoin
                ? CoinEmoji.drawable(this, 16)
                : androidx.core.content.ContextCompat.getDrawable(this, iconRes);
        if (icon != null && !isCoin) {
            icon = icon.mutate();
            icon.setBounds(0, 0, dp(16), dp(16));
        } else if (icon != null) {
            icon.setBounds(0, 0, dp(16), dp(16));
        }
        chip.setCompoundDrawables(icon, null, null, null);
        chip.setOnClickListener(v -> selectCategory(key));
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-2, -2);
        params.rightMargin = dp(10);
        chip.setLayoutParams(params);
        chipViews.add(chip);
        row.addView(chip);
        styleChip(chip, key.equals(selectedCategory));
    }

    private void styleChip(TextView chip, boolean selected) {
        GradientDrawable bg = new GradientDrawable();
        bg.setCornerRadius(dp(100));
        int iconColor;
        if (selected) {
            bg.setOrientation(GradientDrawable.Orientation.LEFT_RIGHT);
            bg.setColors(new int[]{Color.parseColor("#2F6FED"), Color.parseColor("#7C5CE8")});
            chip.setTextColor(Color.WHITE);
            chip.setTypeface(null, Typeface.BOLD);
            iconColor = Color.WHITE;
        } else {
            bg.setColor(Color.WHITE);
            bg.setStroke(dp(1), Color.parseColor("#E5E3DE"));
            chip.setTextColor(Color.parseColor("#1C1C1E"));
            chip.setTypeface(null, Typeface.NORMAL);
            iconColor = Color.parseColor("#1C1C1E");
        }
        chip.setBackground(bg);
        // The coin chip keeps its own golden emoji colour instead of being tinted
        // white/black like the other category icons.
        boolean isCoinChip = "coins".equals(chip.getTag());
        if (!isCoinChip) {
            for (android.graphics.drawable.Drawable d : chip.getCompoundDrawables()) {
                if (d != null) d.setTint(iconColor);
            }
        }
    }

    private void selectCategory(String key) {
        selectedCategory = key;
        for (TextView chip : chipViews) styleChip(chip, key.equals(chip.getTag()));
        render();
    }

    private View buildContactButton() {
        TextView contact = label("NEED HELP? CONTACT SUPPORT", 12.5f, Color.parseColor("#17A2B8"), true);
        contact.setGravity(Gravity.CENTER);
        contact.setAllCaps(true);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.WHITE);
        bg.setCornerRadius(dp(14));
        bg.setStroke(dp(1), Color.parseColor("#17A2B8"));
        contact.setBackground(bg);
        contact.setClickable(true);
        contact.setFocusable(true);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, dp(52));
        params.setMargins(dp(18), dp(10), dp(18), dp(18));
        contact.setLayoutParams(params);
        contact.setOnClickListener(v -> SupportLinks.openTelegramSupport(this));
        return contact;
    }

    // ----------------------------------------------------------- Data/list ---

    private void loadFaqs() {
        render();
        if (!FirebaseRepository.isReady(this)) return;
        listener = new ValueEventListener() {
            @Override public void onDataChange(@NonNull DataSnapshot snapshot) {
                allFaqs.clear();
                for (DataSnapshot child : snapshot.getChildren()) allFaqs.add(child);
                render();
            }
            @Override public void onCancelled(@NonNull DatabaseError error) { toast(error.getMessage()); }
        };
        FirebaseRepository.faq().addValueEventListener(listener);
    }

    private void render() {
        list.removeAllViews();
        int shown = 0;
        for (String[] faq : DEFAULT_FAQS) {
            String category = faq[0];
            if (!"all".equals(selectedCategory) && !category.equals(selectedCategory)) continue;
            list.addView(buildRow(faq[1], faq[2], category));
            shown++;
        }
        for (DataSnapshot faq : allFaqs) {
            String category = normalizeCategory(faq.child("category").getValue());
            if (!"all".equals(selectedCategory) && !category.equals(selectedCategory)) continue;
            String question = String.valueOf(faq.child("question").getValue());
            String answer = String.valueOf(faq.child("answer").getValue());
            list.addView(buildRow(question, answer, category));
            shown++;
        }
        empty.setVisibility(shown == 0 ? View.VISIBLE : View.GONE);
    }

    private String normalizeCategory(Object raw) {
        String value = raw == null ? "" : String.valueOf(raw).trim().toLowerCase();
        return CATEGORY_META.containsKey(value) ? value : (value.isEmpty() ? "general" : value);
    }

    private View buildRow(String question, String answer, String category) {
        Meta meta = CATEGORY_META.containsKey(category) ? CATEGORY_META.get(category) : DEFAULT_META;
        int bgColor = Color.parseColor(meta.bg);
        int accentColor = Color.parseColor(meta.accent);

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable cardBg = new GradientDrawable();
        cardBg.setColor(Color.WHITE);
        cardBg.setCornerRadius(dp(18));
        cardBg.setStroke(dp(1), Color.parseColor("#E5E3DE"));
        card.setBackground(cardBg);
        card.setPadding(dp(16), dp(16), dp(16), dp(16));
        LinearLayout.LayoutParams cardParams = new LinearLayout.LayoutParams(-1, -2);
        cardParams.bottomMargin = dp(12);
        card.setLayoutParams(cardParams);

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);

        android.widget.ImageView icon = new android.widget.ImageView(this);
        if ("coins".equals(category)) {
            icon.setImageDrawable(CoinEmoji.drawable(this, 26));
        } else {
            icon.setImageResource(meta.icon);
            icon.setColorFilter(accentColor);
        }
        icon.setPadding(dp(13), dp(13), dp(13), dp(13));
        GradientDrawable iconBg = new GradientDrawable();
        iconBg.setShape(GradientDrawable.OVAL);
        iconBg.setColor(bgColor);
        icon.setBackground(iconBg);
        top.addView(icon, new LinearLayout.LayoutParams(dp(52), dp(52)));

        LinearLayout mid = new LinearLayout(this);
        mid.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams midParams = new LinearLayout.LayoutParams(0, -2, 1);
        midParams.leftMargin = dp(14);
        mid.setLayoutParams(midParams);

        TextView q = label(question, 15.5f, Color.parseColor("#1C1C1E"), true);
        mid.addView(q);

        TextView pill = label(capitalize(category), 11, accentColor, true);
        pill.setPadding(dp(10), dp(4), dp(10), dp(4));
        GradientDrawable pillBg = new GradientDrawable();
        pillBg.setColor(bgColor);
        pillBg.setCornerRadius(dp(100));
        pill.setBackground(pillBg);
        LinearLayout.LayoutParams pillParams = new LinearLayout.LayoutParams(-2, -2);
        pillParams.topMargin = dp(8);
        pill.setLayoutParams(pillParams);
        mid.addView(pill);

        top.addView(mid);

        TextView chevron = label("\u2304", 20, Color.parseColor("#9A9A9F"), true);
        chevron.setGravity(Gravity.CENTER);
        top.addView(chevron, new LinearLayout.LayoutParams(dp(24), dp(52)));

        TextView answerView = label(answer, 13.5f, Color.parseColor("#68686D"), false);
        answerView.setLineSpacing(dp(3), 1f);
        LinearLayout.LayoutParams answerParams = new LinearLayout.LayoutParams(-1, -2);
        answerParams.topMargin = dp(12);
        answerParams.leftMargin = dp(66);
        answerView.setLayoutParams(answerParams);
        answerView.setVisibility(View.GONE);

        card.setOnClickListener(v -> {
            boolean open = answerView.getVisibility() == View.VISIBLE;
            answerView.setVisibility(open ? View.GONE : View.VISIBLE);
            chevron.setRotation(open ? 0 : 180);
        });

        card.addView(top);
        card.addView(answerView);
        return card;
    }

    private String capitalize(String value) {
        if (value == null || value.isEmpty()) return "General";
        return Character.toUpperCase(value.charAt(0)) + value.substring(1);
    }

    private TextView label(String text, float size, int color, boolean bold) {
        TextView v = new TextView(this);
        v.setText(text);
        v.setTextSize(size);
        v.setTextColor(color);
        v.setTypeface(null, bold ? Typeface.BOLD : Typeface.NORMAL);
        return v;
    }

    private void toast(String message) { FancyText.toast(this, message, Toast.LENGTH_LONG).show(); }
    private int dp(float value) { return Math.round(value * getResources().getDisplayMetrics().density); }

    @Override
    protected void onDestroy() {
        if (listener != null) FirebaseRepository.faq().removeEventListener(listener);
        super.onDestroy();
    }
}
