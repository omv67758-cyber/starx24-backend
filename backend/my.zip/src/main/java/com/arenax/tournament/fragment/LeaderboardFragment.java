package com.arenax.tournament.fragment;


import com.arenax.tournament.util.FancyText;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.animation.ValueAnimator;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.arenax.tournament.R;
import com.arenax.tournament.adapter.LeaderboardAdapter;
import com.arenax.tournament.data.FirebaseRepository;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.resource.bitmap.CircleCrop;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class LeaderboardFragment extends Fragment {
    private final List<String[]> rows = new ArrayList<>();
    private final List<String[]> podium = new ArrayList<>();
    private LeaderboardAdapter adapter;
    private ValueEventListener listener;
    private View rootView;
    private final List<ValueAnimator> podiumAnimations = new ArrayList<>();

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        rootView = inflater.inflate(R.layout.fragment_leaderboard, container, false);
        ((TextView) rootView.findViewById(R.id.leaderboard_title)).setText("Leaderboard");
        if (!FirebaseRepository.isReady(requireContext())) {
            FancyText.toast(requireContext(), "Live arena data is temporarily unavailable. Please try again.", android.widget.Toast.LENGTH_LONG).show();
            return rootView;
        }
        RecyclerView list = rootView.findViewById(R.id.leaderboard_list);
        list.setLayoutManager(new LinearLayoutManager(requireContext()));
        adapter = new LeaderboardAdapter(rows, null);
        list.setAdapter(adapter);
        rootView.findViewById(R.id.tab_weekly).setOnClickListener(v -> selectPeriod("weekly"));
        rootView.findViewById(R.id.tab_monthly).setOnClickListener(v -> selectPeriod("monthly"));
        rootView.findViewById(R.id.tab_fulltime).setOnClickListener(v -> selectPeriod("allTime"));
        bindPodium();
        bindYourRank(-1, "");
        loadPeriod("weekly");
        return rootView;
    }

    private DatabaseReference activeRef;

    private String activeSystem = "KILL";

    private void loadPeriod(String period) {
        if (listener != null && activeRef != null) activeRef.removeEventListener(listener);
        activePeriod = period;
        activeRef = FirebaseRepository.tournaments();
        listener = new ValueEventListener() {
            @Override public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (rootView == null || !isAdded()) return;
                rows.clear();
                podium.clear();
                final long now = System.currentTimeMillis();
                long from = 0L;
                java.util.Calendar calendar = java.util.Calendar.getInstance();
                if ("weekly".equals(period)) { calendar.add(java.util.Calendar.DAY_OF_YEAR, -7); from = calendar.getTimeInMillis(); }
                else if ("monthly".equals(period)) { calendar.set(java.util.Calendar.DAY_OF_MONTH, 1); calendar.set(java.util.Calendar.HOUR_OF_DAY, 0); calendar.set(java.util.Calendar.MINUTE, 0); calendar.set(java.util.Calendar.SECOND, 0); from = calendar.getTimeInMillis(); }
                Map<String, long[]> totals = new HashMap<>();
                Map<String, String> names = new HashMap<>(), photos = new HashMap<>();
                for (DataSnapshot tournament : snapshot.getChildren()) {
                    // Leaderboard ab COINS se chalta hai: KILL / SURVIVAL / TEAM / 1v1 sab match ke coins judte hain.
                    long perKill = number(tournament.child("perKillCoins").getValue());
                    String status = value(tournament.child("status").getValue(), "");
                    if (!"RESULT_PUBLISHED".equalsIgnoreCase(status) && !"COMPLETED".equalsIgnoreCase(status)) continue;
                    long matchAt = number(tournament.child("startAt").getValue());
                    if (matchAt <= 0L) matchAt = number(tournament.child("resultPublishedAt").getValue());
                    if (from > 0L && matchAt > 0L && (matchAt < from || matchAt > now)) continue;
                    for (DataSnapshot result : tournament.child("results").getChildren()) {
                        String uid = result.getKey();
                        if (uid == null) continue;
                        String outcome = value(result.child("result").getValue(), "").toUpperCase(java.util.Locale.ROOT);
                        long kills = number(result.child("kills").getValue());
                        Object coinsRaw = result.child("coins").getValue();
                        long coins = number(coinsRaw);
                        // Purane KILL results me coins save nahi hote the: tab kills x per-kill coins.
                        if (coinsRaw == null && kills > 0 && perKill > 0) coins = kills * perKill;
                        // Jisko na coins mile na kill (jaise 1v1 loss), leaderboard me nahi.
                        // 1VS1 (row has "side") me joined har player ka naam dikhta hai, loss/refund ho tab bhi.
                        boolean battleRow = result.child("side").exists();
                        if ("REFUND".equals(outcome) && battleRow) coins = 0; // refund kamai nahi hai
                        if (coins <= 0 && kills <= 0 && "LOSS".equals(outcome) && !battleRow) continue;
                        long[] aggregate = totals.get(uid);
                        if (aggregate == null) { aggregate = new long[4]; totals.put(uid, aggregate); }
                        aggregate[0] += coins;
                        aggregate[1] += 1;
                        aggregate[2] += kills;
                        aggregate[3] += coins;
                        names.put(uid, value(result.child("username").getValue(), "STARX24 player"));
                        photos.put(uid, value(result.child("photoUrl").getValue(), ""));
                    }
                }
                List<Object[]> all = new ArrayList<>();
                for (Map.Entry<String, long[]> entry : totals.entrySet()) {
                    long[] data = entry.getValue();
                    String display = data[0] + " COINS";
                    all.add(new Object[]{data[0], names.get(entry.getKey()), String.valueOf(data[1]),
                            String.valueOf(data[2]), display, photos.get(entry.getKey()), entry.getKey()});
                }
                java.util.Collections.sort(all, (a, b) -> {
                    int byScore = Long.compare((Long) b[0], (Long) a[0]);
                    if (byScore != 0) return byScore;
                    int byKills = Long.compare(Long.parseLong((String) b[3]), Long.parseLong((String) a[3]));
                    return byKills != 0 ? byKills : String.valueOf(a[1]).compareToIgnoreCase(String.valueOf(b[1]));
                });
                String myUid = com.google.firebase.auth.FirebaseAuth.getInstance().getUid();
                int myRank = -1;
                String myScore = "";
                int rank = 1;
                for (Object[] o : all) {
                    String[] row = new String[]{String.valueOf(rank), (String) o[1], (String) o[2], (String) o[3], (String) o[4], (String) o[5], (String) o[6]};
                    if (rank <= 3) podium.add(row); else rows.add(row);
                    if (myUid != null && myUid.equals(o[6])) { myRank = rank; myScore = (String) o[4]; }
                    rank++;
                }
                bindPodium();
                bindYourRank(myRank, myScore);
                adapter.notifyDataSetChanged();
            }
            @Override public void onCancelled(@NonNull DatabaseError error) {}
        };
        activeRef.addValueEventListener(listener);
    }

    private long number(Object raw) { return raw instanceof Number ? ((Number) raw).longValue() : 0L; }

    private String activePeriod = "weekly";

    private void selectPeriod(String period) {
        loadPeriod(period);
        int inactive = 0xFF7A8091;
        TextView weekly = rootView.findViewById(R.id.tab_weekly);
        TextView monthly = rootView.findViewById(R.id.tab_monthly);
        TextView fulltime = rootView.findViewById(R.id.tab_fulltime);
        weekly.setBackground(null); monthly.setBackground(null); fulltime.setBackground(null);
        weekly.setTextColor(inactive); monthly.setTextColor(inactive); fulltime.setTextColor(inactive);
        TextView selected = "weekly".equals(period) ? weekly : ("monthly".equals(period) ? monthly : fulltime);
        selected.setBackgroundResource(R.drawable.lb2_bg_period_tab_active);
        selected.setTextColor(0xFFFFFFFF);
    }

    private void bindYourRank(int rank, String score) {
        if (rootView == null) return;
        TextView rankValue = rootView.findViewById(R.id.your_rank_value);
        TextView rankPoints = rootView.findViewById(R.id.your_rank_points);
        if (rankValue == null || rankPoints == null) return;
        if (rank > 0) {
            rankValue.setText("#" + rank);
            rankPoints.setText(score == null ? "" : score.toLowerCase(java.util.Locale.ROOT));
        } else {
            rankValue.setText("--");
            rankPoints.setText("Not ranked yet");
        }
    }

    private void bindPodium() {
        bindPodiumItem(R.id.podium_name_1, R.id.podium_score_1, R.id.podium_unit_1, R.id.podium_avatar_1, 0, "Top player");
        bindPodiumItem(R.id.podium_name_2, R.id.podium_score_2, R.id.podium_unit_2, R.id.podium_avatar_2, 1, "Second player");
        bindPodiumItem(R.id.podium_name_3, R.id.podium_score_3, R.id.podium_unit_3, R.id.podium_avatar_3, 2, "Third player");
        animatePodiumGlow();
    }

    /** Soft pulse on the winner crown and all three rank badges: premium, not distracting. */
    private void animatePodiumGlow() {
        stopPodiumGlow();
        int[] ids = {R.id.podium_crown_1, R.id.podium_badge_1, R.id.podium_badge_2, R.id.podium_badge_3};
        for (int i = 0; i < ids.length; i++) {
            View view = rootView == null ? null : rootView.findViewById(ids[i]);
            if (view == null) continue;
            final float pulse = ids[i] == R.id.podium_crown_1 ? 0.12f : 0.07f;
            ValueAnimator animator = ValueAnimator.ofFloat(0f, 1f, 0f);
            animator.setDuration(ids[i] == R.id.podium_crown_1 ? 1100L : 900L);
            animator.setStartDelay(i * 110L);
            animator.setRepeatCount(ValueAnimator.INFINITE);
            animator.setInterpolator(new AccelerateDecelerateInterpolator());
            animator.addUpdateListener(a -> {
                float value = (Float) a.getAnimatedValue();
                view.setScaleX(1f + pulse * value);
                view.setScaleY(1f + pulse * value);
                view.setAlpha(0.88f + 0.12f * value);
                view.setElevation(4f + 8f * value);
            });
            podiumAnimations.add(animator);
            animator.start();
        }
    }

    private void stopPodiumGlow() {
        for (ValueAnimator animator : podiumAnimations) animator.cancel();
        podiumAnimations.clear();
    }

    private void bindPodiumItem(int nameId, int scoreId, int unitId, int avatarId, int index, String fallback) {
        TextView name = rootView.findViewById(nameId);
        TextView score = rootView.findViewById(scoreId);
        TextView unit = rootView.findViewById(unitId);
        ImageView avatar = rootView.findViewById(avatarId);
        String photoUrl = null;
        if (index < podium.size()) {
            String[] row = podium.get(index);
            name.setText(row[1]);
            String display = row[4] == null ? "0" : row[4].replace(" COINS", "");
            score.setText(display);
            unit.setText("COINS");
            photoUrl = row.length > 5 ? row[5] : null;
            name.setOnClickListener(null);
            avatar.setOnClickListener(null);
        } else {
            name.setOnClickListener(null);
            avatar.setOnClickListener(null);
            name.setText(fallback);
            score.setText("0");
            unit.setText("COINS");
        }
        if (photoUrl != null && !photoUrl.trim().isEmpty()) {
            Glide.with(avatar.getContext()).load(photoUrl).transform(new CircleCrop()).into(avatar);
        } else {
            avatar.setImageResource(R.drawable.ic_profile);
        }
    }

    private static String value(Object value, String fallback) { return value == null ? fallback : String.valueOf(value); }

    @Override public void onDestroyView() {
        stopPodiumGlow();
        if (listener != null && activeRef != null) activeRef.removeEventListener(listener);
        rootView = null;
        super.onDestroyView();
    }
}
