package com.arenax.tournament.adapter;

import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.arenax.tournament.R;
import com.arenax.tournament.model.GameMode;
import com.arenax.tournament.util.ImageLoader;

import java.util.List;

/** Admin Categories tab: shows every category as an image-only tile (no text). */
public class CategoryImageAdapter extends RecyclerView.Adapter<CategoryImageAdapter.Holder> {
    public interface OnModeClick { void onClick(GameMode mode); }

    private final List<GameMode> items;
    private final OnModeClick clickListener;
    private final OnModeClick longClickListener;

    public CategoryImageAdapter(List<GameMode> items, OnModeClick clickListener, OnModeClick longClickListener) {
        this.items = items;
        this.clickListener = clickListener;
        this.longClickListener = longClickListener;
    }

    @NonNull
    @Override
    public Holder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new Holder(LayoutInflater.from(parent.getContext()).inflate(R.layout.item_category_image, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull Holder holder, int position) {
        GameMode mode = items.get(position);
        ImageLoader.load(holder.image, mode.getImageUrl());
        holder.itemView.setOnClickListener(v -> {
            if (clickListener != null) clickListener.onClick(mode);
        });
        holder.itemView.setOnLongClickListener(v -> {
            if (longClickListener == null) return false;
            longClickListener.onClick(mode);
            return true;
        });
    }

    @Override
    public int getItemCount() { return items.size(); }

    static class Holder extends RecyclerView.ViewHolder {
        final ImageView image;
        Holder(@NonNull android.view.View view) {
            super(view);
            image = view.findViewById(R.id.category_image);
        }
    }
}
