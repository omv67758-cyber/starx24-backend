package com.arenax.tournament;

import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.core.content.res.ResourcesCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;

import com.arenax.tournament.data.FirebaseRepository;
import com.arenax.tournament.model.Tournament;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Player-facing "Match Result" / leaderboard screen (tap VIEW RESULT on a Resulted-tab card).
 *
 * The admin only types each player's KILLS (Control Center -> Rank & Leaderboard -> Rank Manage).
 * Everything else is built here automatically:
 *   coins = kills x the match's per-kill coin price   (1 kill x 1 coin = 1 coin)
 *   rank  = most kills first (equal kills share a rank)
 *
 * Only publicly readable nodes are used (tournaments/{id} and tournaments/{id}/results, with the
 * older top-level /results as a fallback), so a normal player never hits "Permission denied".
 * White theme, matching the rest of the app.
 */
public class MatchResultActivity extends BaseActivity {

    private static final int NAVY = Color.rgb(20, 40, 70);
    private static final int GREY = Color.rgb(92, 108, 128);
    private static final int BLUE = Color.rgb(38, 116, 236);
    private static final int BG = Color.rgb(245, 248, 254);
    private static final int LINE = Color.rgb(226, 232, 242);

    private static class Row {
        String player;
        String side = "";
        String result = "";
        int kills;
        int coins;
        int rank;
        int placement;
        String message = "";
    }

    /** Same Courbe Sans brand font as the home header. FancyText is bypassed (tag "nofancy") so it renders correctly. */
    private Typeface brandFont = Typeface.DEFAULT;
    private LinearLayout content;
    private String tournamentId;
    private String activeResultSystem = "KILL";

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            Typeface f = ResourcesCompat.getFont(this, R.font.courbe_sans);
            if (f != null) brandFont = f;
        } catch (Exception ignored) { }
        tournamentId = getIntent().getStringExtra("tournamentId");
        if (tournamentId == null) tournamentId = "";
        buildScreen();
        loadResult();
    }

    private void buildScreen() {
        // Light status bar (dark icons) on the white theme.
        WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView()).setAppearanceLightStatusBars(true);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);
        ViewCompat.setOnApplyWindowInsetsListener(root, (view, insets) -> {
            Insets bars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            view.setPadding(bars.left, bars.top, bars.right, bars.bottom);
            return insets;
        });

        LinearLayout top = new LinearLayout(this);
        top.setPadding(dp(14), dp(14), dp(14), dp(10));
        top.setGravity(Gravity.CENTER_VERTICAL);
        TextView back = label("\u2039", 38, NAVY, true);
        back.setContentDescription("Back");
        back.setOnClickListener(v -> finish());
        top.addView(back, new LinearLayout.LayoutParams(dp(40), dp(44)));
        TextView screenTitle = label("MATCH RESULT", 22, NAVY, true);
        screenTitle.setLetterSpacing(0.06f);
        top.addView(screenTitle);
        root.addView(top);

        ScrollView scroll = new ScrollView(this);
        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(16), dp(4), dp(16), dp(24));
        scroll.addView(content);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(root);

        content.addView(stateBox("Loading", "Fetching the published result\u2026"));
    }

    private void showState(String heading, String body) {
        content.removeAllViews();
        content.addView(stateBox(heading, body));
    }

    private void loadResult() {
        if (!FirebaseRepository.isReady(this) || tournamentId.isEmpty()) {
            showState("Unavailable", "This result can't be loaded right now.");
            return;
        }
        FirebaseRepository.tournaments().child(tournamentId).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override public void onDataChange(@NonNull DataSnapshot snapshot) {
                @SuppressWarnings("unchecked")
                Tournament tournament = Tournament.fromMap(snapshot.getKey(), (java.util.Map<String, Object>) snapshot.getValue());
                if (tournament == null) {
                    showState("Not found", "This match record no longer exists.");
                    return;
                }
                activeResultSystem = tournament.getResultSystem();
                // 1) the match's own public leaderboard
                readRows(tournament, snapshot.child("results"), false);
            }
            @Override public void onCancelled(@NonNull DatabaseError error) {
                showState("Couldn't load", "Result abhi load nahi ho pa raha. Thodi der baad dobara try karein.");
            }
        });
    }

    /** Builds rows from either tournaments/{id}/results (keyed by uid) or the older top-level /results. */
    private void readRows(Tournament tournament, DataSnapshot source, boolean legacy) {
        List<Row> rows = new ArrayList<>();
        int perKill = Math.max(0, tournament.getPerKillCoins());
        for (DataSnapshot child : source.getChildren()) {
            if (legacy) {
                Object tid = child.child("tournamentId").getValue();
                if (tid == null || !tournament.getId().equals(String.valueOf(tid))) continue;
            }
            Row r = new Row();
            Object name = child.child("username").getValue();
            r.player = name == null || String.valueOf(name).trim().isEmpty()
                    ? "Player " + (rows.size() + 1) : String.valueOf(name).trim();
            r.kills = intOf(child.child("kills").getValue());
            Object coinsValue = child.child("coins").getValue();
            r.coins = intOf(coinsValue);
            // Only fall back to kills x per-kill when no coins were saved at all (admin may set 0 by hand).
            if (coinsValue == null && "KILL".equals(activeResultSystem)) r.coins = r.kills * perKill;
            r.placement = intOf(child.child("placement").getValue());
            r.side = value(child.child("side").getValue(), "");
            r.message = value(child.child("message").getValue(), "");
            String teamLabel = value(child.child("teamName").getValue(), "");
            if ("TEAM".equals(activeResultSystem) && !teamLabel.isEmpty()) r.player = teamLabel + " • " + r.player;
            r.result = value(child.child("result").getValue(), "");
            if ("SURVIVAL".equals(activeResultSystem) && r.placement <= 0) continue;
            rows.add(r);
        }
        if (rows.isEmpty()) {
            if (!legacy) { loadLegacyResults(tournament); return; }
            render(tournament, rows);
            return;
        }
        buildRanking(tournament, rows);
    }

    /** Matches published before the per-match node existed only have rows in top-level /results. */
    private void loadLegacyResults(Tournament tournament) {
        FirebaseRepository.results().addListenerForSingleValueEvent(new ValueEventListener() {
            @Override public void onDataChange(@NonNull DataSnapshot snapshot) {
                readRows(tournament, snapshot, true);
            }
            @Override public void onCancelled(@NonNull DatabaseError error) {
                // No scary permission error for players: simply treat it as "not published yet".
                render(tournament, new ArrayList<>());
            }
        });
    }

    private void buildRanking(Tournament tournament, List<Row> rows) {
        if ("KILL".equals(activeResultSystem)) {
            Collections.sort(rows, (a, b) -> a.kills != b.kills ? b.kills - a.kills : a.player.compareToIgnoreCase(b.player));
            for (Row r : rows) {
                int better = 0;
                for (Row o : rows) if (o.kills > r.kills) better++;
                r.rank = better + 1;
            }
        } else {
            Collections.sort(rows, (a, b) -> {
                int byPlace = Integer.compare(a.placement <= 0 ? Integer.MAX_VALUE : a.placement,
                        b.placement <= 0 ? Integer.MAX_VALUE : b.placement);
                return byPlace != 0 ? byPlace : a.player.compareToIgnoreCase(b.player);
            });
            for (int i = 0; i < rows.size(); i++) rows.get(i).rank = rows.get(i).placement > 0 ? rows.get(i).placement : i + 1;
        }
        render(tournament, rows);
    }

    private int intOf(Object o) { return o instanceof Number ? ((Number) o).intValue() : 0; }

    private String value(Object o, String fallback) {
        if (o == null) return fallback;
        String text = String.valueOf(o).trim();
        return text.isEmpty() ? fallback : text;
    }

    private void render(Tournament tournament, List<Row> rows) {
        content.removeAllViews();
        TextView matchTitle = label(tournament.getTitle(), 30, NAVY, true);
        matchTitle.setLetterSpacing(0.03f);
        matchTitle.setPadding(0, dp(6), 0, dp(2));
        content.addView(matchTitle);
        content.addView(pageText("Organized on " + tournament.getDate() + " at " + tournament.getTime()));

        LinearLayout metrics = new LinearLayout(this);
        metrics.setOrientation(LinearLayout.HORIZONTAL);
        metrics.setPadding(0, dp(12), 0, dp(6));
        metrics.addView(metric("PRIZE POOL", String.valueOf(tournament.getPrizePoolCoins())));
        if ("KILL".equals(activeResultSystem)) {
            metrics.addView(metric("PER KILL", tournament.getPerKillCoins() + " coin"
                    + (tournament.getPerKillCoins() == 1 ? "" : "s")));
        } else if ("SURVIVAL".equals(activeResultSystem)) {
            metrics.addView(metric("SYSTEM", "Top 10 survive"));
        } else if ("TEAM".equals(activeResultSystem)) {
            metrics.addView(metric("SYSTEM", "Team rank"));
        } else {
            metrics.addView(metric("PAYOUT", "Manual coins"));
        }
        metrics.addView(metric("ENTRY FEE", String.valueOf(tournament.getEntryFeeCoins())));
        if (metrics.getChildCount() > 0) {
            ((LinearLayout.LayoutParams) metrics.getChildAt(metrics.getChildCount() - 1).getLayoutParams()).rightMargin = 0;
        }
        content.addView(metrics);

        if (rows.isEmpty()) {
            content.addView(stateBox("Result not published yet",
                    "The admin hasn't published the leaderboard for this match yet. Check back shortly."));
            return;
        }

        int totalKills = 0, totalCoins = 0;
        for (Row r : rows) { totalKills += r.kills; totalCoins += r.coins; }
        String summary = "KILL".equals(activeResultSystem)
                ? rows.size() + " Players  \u2022  " + totalKills + " Total Kills  \u2022  " + totalCoins + " Total Coins"
                : ("SURVIVAL".equals(activeResultSystem) ? "Top " + rows.size() + " surviving players  •  "
                : ("TEAM".equals(activeResultSystem) ? rows.size() + " players ranked by team  •  " : "1VS1 players  •  "))
                + totalCoins + " reward coins";
        content.addView(pageText(summary));

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setBackground(roundBg(Color.WHITE, 18, LINE));
        box.setClipToOutline(true);
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1, -2);
        bp.topMargin = dp(10);
        box.setLayoutParams(bp);
        String scoreHeading = "KILL".equals(activeResultSystem) ? "Kills" : (("SURVIVAL".equals(activeResultSystem) || "TEAM".equals(activeResultSystem)) ? "Rank" : "Side");
        box.addView(tableRow("#", "Player", scoreHeading, "Coins", true, NAVY, Color.WHITE));
        String[] medals = {"\uD83E\uDD47", "\uD83E\uDD48", "\uD83E\uDD49"};
        for (Row r : rows) {
            boolean top = r.rank <= 3 && (r.kills > 0 || (!"KILL".equals(activeResultSystem) && r.coins > 0));
            String score = "KILL".equals(activeResultSystem) ? String.valueOf(r.kills)
                    : (("SURVIVAL".equals(activeResultSystem) || "TEAM".equals(activeResultSystem)) ? (r.placement > 0 ? "#" + r.placement : "—") : r.side);
            String playerName = r.player + (r.result.isEmpty() ? "" : "  ·  " + r.result);
            box.addView(tableRow(top ? medals[r.rank - 1] : String.valueOf(r.rank), playerName,
                    score, String.valueOf(r.coins), false,
                    top ? Color.rgb(255, 248, 230) : Color.WHITE, NAVY));
            if (!r.message.isEmpty()) {
                TextView note = new TextView(this);
                note.setText("\uD83D\uDCAC " + r.message);
                note.setTextSize(12);
                note.setTextColor(GREY);
                note.setTag(com.arenax.tournament.util.FancyText.NO_FANCY);
                note.setPadding(dp(14), 0, dp(14), dp(12));
                box.addView(note);
            }
        }
        content.addView(box);
    }

    private LinearLayout tableRow(String rank, String player, String kills, String coins,
                                  boolean header, int bgColor, int textColor) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setBackgroundColor(bgColor);
        row.setPadding(dp(14), dp(header ? 14 : 16), dp(14), dp(header ? 14 : 16));
        row.setGravity(Gravity.CENTER_VERTICAL);
        float small = header ? 11 : 13;
        // numbers (rank / kills / coins) use the normal system font; header + player names keep the brand font
        Typeface numFont = header ? brandFont : Typeface.DEFAULT;
        row.addView(cell(rank, 0.6f, textColor, small, numFont));
        TextView p = cell(player, 2.6f, textColor, small, brandFont);
        p.setSingleLine(true);
        p.setEllipsize(android.text.TextUtils.TruncateAt.END);
        row.addView(p);
        row.addView(cell(kills, 0.9f, header ? textColor : GREY, small, numFont));
        row.addView(cell(coins, 0.9f, header ? textColor : BLUE, header ? 11 : 15, header ? brandFont : Typeface.DEFAULT_BOLD));
        if (header) return row;
        LinearLayout wrap = new LinearLayout(this);
        wrap.setOrientation(LinearLayout.VERTICAL);
        wrap.addView(row);
        View line = new View(this);
        line.setBackgroundColor(LINE);
        wrap.addView(line, new LinearLayout.LayoutParams(-1, dp(1)));
        return wrap;
    }

    private TextView cell(String text, float weight, int color, float sizeSp, Typeface font) {
        TextView v = new TextView(this);
        v.setText(text);
        v.setTextColor(color);
        v.setTextSize(sizeSp);
        v.setTypeface(font);
        v.setTag(com.arenax.tournament.util.FancyText.NO_FANCY);
        v.setLayoutParams(new LinearLayout.LayoutParams(0, -2, weight));
        return v;
    }

    private LinearLayout metric(String title, String value) {
        LinearLayout wrap = new LinearLayout(this);
        wrap.setOrientation(LinearLayout.VERTICAL);
        wrap.setGravity(Gravity.CENTER);
        wrap.setBackground(roundBg(Color.WHITE, 16, LINE));
        wrap.setPadding(dp(6), dp(16), dp(6), dp(16));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, -2, 1f);
        p.rightMargin = dp(8);
        wrap.setLayoutParams(p);
        TextView t = label(title, 9, GREY, true);
        t.setGravity(Gravity.CENTER);
        TextView v = label(value, 15, NAVY, true);
        v.setTypeface(Typeface.DEFAULT_BOLD); // values are numbers -> normal font
        v.setGravity(Gravity.CENTER);
        v.setPadding(0, dp(4), 0, 0);
        wrap.addView(t);
        wrap.addView(v);
        return wrap;
    }

    private LinearLayout stateBox(String heading, String body) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(4), dp(24), dp(4), dp(24));
        box.addView(label(heading, 20, NAVY, true));
        box.addView(pageText(body));
        return box;
    }

    private TextView pageText(String text) {
        TextView t = label(text, 10, GREY, false);
        t.setPadding(0, dp(4), 0, dp(4));
        return t;
    }

    private TextView label(String text, int size, int color, boolean bold) {
        TextView v = new TextView(this);
        v.setText(text);
        v.setTextSize(size);
        v.setTextColor(color);
        v.setTypeface(brandFont);
        v.setTag(com.arenax.tournament.util.FancyText.NO_FANCY);
        return v;
    }

    private GradientDrawable roundBg(int fill, int radiusDp, int stroke) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(dp(radiusDp));
        g.setStroke(dp(1), stroke);
        return g;
    }

    private int dp(int value) { return Math.round(value * getResources().getDisplayMetrics().density); }
}
