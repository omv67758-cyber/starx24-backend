package com.arenax.tournament.util;

import android.content.Context;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.arenax.tournament.data.FirebaseRepository;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

/**
 * Right after login (MainActivity.onCreate) downloads every app image (banners, game modes,
 * tournament banners, branding logo) into the encrypted zip in the background. Images already
 * in the zip are skipped, so later launches only fetch what is new. Screens then load instantly
 * through SecureAssetLoader.
 */
public final class AssetSync {
    private static final int MAX_URLS = 600;
    private static final ExecutorService POOL = Executors.newFixedThreadPool(5);
    private static final AtomicBoolean RUNNING = new AtomicBoolean(false);
    // URLs already queued/downloading, so Home + Tournaments + syncAll never fetch the same image twice.
    private static final Set<String> IN_FLIGHT = java.util.Collections.synchronizedSet(new LinkedHashSet<String>());
    // Checks (has()) run here, never on the UI thread.
    private static final ExecutorService SCHEDULER = Executors.newSingleThreadExecutor();
    private static final OkHttpClient HTTP = new OkHttpClient.Builder()
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(25, TimeUnit.SECONDS)
            .retryOnConnectionFailure(true)
            .build();

    private AssetSync() { }

    /** Call once after login / app start. Safe to call repeatedly. */
    public static void syncAll(@Nullable Context context) {
        if (context == null) return;
        final Context app = context.getApplicationContext();
        if (!AssetStore.get(app).isEnabled()) return;
        if (!FirebaseRepository.isFirebaseAvailable(app) || FirebaseRepository.currentUser() == null) return;
        if (!RUNNING.compareAndSet(false, true)) return;

        final DatabaseReference[] refs;
        try {
            refs = new DatabaseReference[] {
                    FirebaseRepository.banners(),
                    FirebaseRepository.gameModes(),
                    FirebaseRepository.tournaments(),
                    FirebaseRepository.appConfig()
            };
        } catch (RuntimeException e) {
            RUNNING.set(false);
            return;
        }
        final AtomicInteger left = new AtomicInteger(refs.length);
        for (DatabaseReference ref : refs) {
            ref.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override public void onDataChange(@NonNull DataSnapshot snapshot) {
                    Set<String> urls = new LinkedHashSet<>();
                    collect(snapshot, urls);
                    prefetch(app, urls); // start downloading NOW, don't wait for the other trees
                    done();
                }
                @Override public void onCancelled(@NonNull DatabaseError error) { done(); }

                private void done() {
                    if (left.decrementAndGet() <= 0) RUNNING.set(false);
                }
            });
        }
    }

    /** Downloads (in the background) every URL that is not yet in the encrypted zip. */
    public static void prefetch(@Nullable Context context, @Nullable Collection<String> urls) {
        if (context == null || urls == null || urls.isEmpty()) return;
        final AssetStore store = AssetStore.get(context.getApplicationContext());
        if (!store.isEnabled()) return;
        final ArrayList<String> copy = new ArrayList<>(urls);
        SCHEDULER.execute(() -> {
            for (String raw : copy) {
                if (raw == null) continue;
                final String url = raw.trim();
                if (!url.startsWith("http") || store.has(url)) continue;
                if (!IN_FLIGHT.add(url)) continue; // already being downloaded
                POOL.execute(() -> {
                    try (Response r = HTTP.newCall(new Request.Builder().url(url).build()).execute()) {
                        if (!r.isSuccessful() || r.body() == null) return;
                        byte[] bytes = r.body().bytes();
                        store.putAsync(url, bytes); // single writer thread inside AssetStore
                    } catch (Exception ignored) {
                        // Offline / bad URL: screen will just load it normally when needed.
                    } finally {
                        IN_FLIGHT.remove(url);
                    }
                });
            }
        });
    }

    private static void collect(DataSnapshot node, Set<String> out) {
        if (out.size() >= MAX_URLS) return;
        for (DataSnapshot child : node.getChildren()) {
            String key = child.getKey();
            if ("participants".equals(key) || "slotIndex".equals(key)) continue; // player data, not app images
            if (child.hasChildren()) { collect(child, out); continue; }
            if (!("imageUrl".equals(key) || "bannerUrl".equals(key) || "logoUrl".equals(key) || "photoUrl".equals(key))) continue;
            Object v = child.getValue();
            if (v instanceof String && ((String) v).trim().startsWith("http")) out.add(((String) v).trim());
        }
    }
}
