package com.arenax.tournament;


import com.arenax.tournament.util.FancyText;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import com.arenax.tournament.data.FirebaseRepository;
import com.arenax.tournament.data.ImgBbUploader;
import com.arenax.tournament.data.StorageUploader;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.resource.bitmap.CircleCrop;
import com.google.android.material.button.MaterialButton;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;
import java.util.Map;

/** "My Profile" edit page opened from the Profile tab's "My Profile" row.
 *  Reads/writes the same users/{uid} fields (name, phone, photoUrl) the rest of
 *  the app already uses, so a change here shows up on the Profile tab, the
 *  leaderboard and everywhere else immediately. Email is shown read-only since
 *  it's tied to the sign-in account and changing it needs re-authentication. */
public class MyProfileActivity extends BaseActivity {

    private static final int BIO_MAX = 150;
    private ImageView avatar;
    private TextView usernameText;
    private TextView rolePill;
    private EditText firstNameInput, lastNameInput, mobileInput, emailInput, bioInput;
    private TextView bioAction, bioCounter;
    private ScrollView pageScroll;
    private MaterialButton save;
    private Uri pickedAvatar;
    private String uid;

    private final ActivityResultLauncher<String> picker = registerForActivityResult(
            new ActivityResultContracts.GetContent(), uri -> {
        if (uri != null) {
            pickedAvatar = uri;
            Glide.with(this).load(uri).transform(new CircleCrop()).into(avatar);
        }
    });

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.WHITE);
        getWindow().setNavigationBarColor(Color.WHITE);
        build();
        loadProfile();
    }

    private int dp(int n) { return Math.round(n * getResources().getDisplayMetrics().density); }

    private TextView label(String s, float size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(size); t.setTextColor(color);
        t.setTypeface(null, bold ? Typeface.BOLD : Typeface.NORMAL);
        return t;
    }

    /** Rounded colored square used behind each field's icon (blue / purple / green / red),
     *  built in code instead of four near-identical drawable XML files. */
    private FrameLayout iconBox(int tint, int glyphRes) {
        FrameLayout box = new FrameLayout(this);
        GradientDrawable bg = new GradientDrawable();
        bg.setShape(GradientDrawable.RECTANGLE);
        bg.setCornerRadius(dp(12));
        bg.setColor((tint & 0x00FFFFFF) | 0x1F000000);
        box.setBackground(bg);
        ImageView icon = new ImageView(this);
        icon.setImageResource(glyphRes);
        icon.setColorFilter(tint);
        FrameLayout.LayoutParams ilp = new FrameLayout.LayoutParams(dp(22), dp(22));
        ilp.gravity = Gravity.CENTER;
        box.addView(icon, ilp);
        return box;
    }

    /** One "First Name / Last Name / Mobile Number" style row: icon box, label above an
     *  editable value, chevron on the end — laid out on the same elevated card used for
     *  the Home tab's stat tiles so it matches the rest of the app. */
    private EditText fieldRow(LinearLayout parent, String labelText, int tint, int glyphRes, String hint) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setBackgroundResource(R.drawable.bg_card_elevated_sm);
        row.setPadding(dp(14), dp(14), dp(14), dp(14));
        row.addView(iconBox(tint, glyphRes), new LinearLayout.LayoutParams(dp(44), dp(44)));

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(12), 0, dp(8), 0);
        col.addView(label(labelText + " :", 12.5f, Color.rgb(120, 120, 126), false));
        EditText value = new EditText(this);
        value.setHint(hint);
        value.setTextSize(16);
        value.setTypeface(null, Typeface.BOLD);
        value.setTextColor(Color.rgb(20, 20, 22));
        value.setHintTextColor(Color.rgb(170, 170, 176));
        value.setBackground(null);
        value.setPadding(0, dp(2), 0, 0);
        value.setSingleLine(true);
        col.addView(value, new LinearLayout.LayoutParams(-1, -2));
        row.addView(col, new LinearLayout.LayoutParams(0, -2, 1));

        ImageView chevron = new ImageView(this);
        chevron.setImageResource(R.drawable.ic_chevron_right);
        chevron.setColorFilter(Color.rgb(180, 180, 186));
        row.addView(chevron, new LinearLayout.LayoutParams(dp(16), dp(16)));

        LinearLayout.LayoutParams rowLp = new LinearLayout.LayoutParams(-1, -2);
        rowLp.topMargin = dp(14);
        parent.addView(row, rowLp);
        return value;
    }

    private void build() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.WHITE);
        // Android 15+ (targetSdk 35) draws behind the status bar by default; keep the
        // back/title bar clear of the clock, battery and notification icons.
        androidx.core.view.ViewCompat.setOnApplyWindowInsetsListener(root, (view, insets) -> {
            androidx.core.graphics.Insets bars = insets.getInsets(
                    androidx.core.view.WindowInsetsCompat.Type.systemBars()
                            | androidx.core.view.WindowInsetsCompat.Type.ime());
            view.setPadding(bars.left, bars.top, bars.right, bars.bottom);
            return insets;
        });

        // Top bar: back + title (no gear — Settings already lives on the Profile tab menu)
        LinearLayout head = new LinearLayout(this);
        head.setGravity(Gravity.CENTER_VERTICAL);
        head.setPadding(dp(8), dp(10), dp(8), dp(6));
        ImageView back = new ImageView(this);
        back.setImageResource(R.drawable.ic_arrow_back);
        back.setBackgroundResource(R.drawable.bg_profile_back);
        back.setPadding(dp(10), dp(10), dp(10), dp(10));
        back.setOnClickListener(v -> finish());
        head.addView(back, new LinearLayout.LayoutParams(dp(42), dp(42)));
        TextView title = label("Profile", 19, Color.rgb(20, 20, 22), true);
        title.setGravity(Gravity.CENTER);
        head.addView(title, new LinearLayout.LayoutParams(0, -2, 1));
        View spacer = new View(this);
        head.addView(spacer, new LinearLayout.LayoutParams(dp(42), dp(42)));
        root.addView(head);

        ScrollView scroll = new ScrollView(this);
        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(dp(18), dp(4), dp(18), dp(28));

        // Header card: avatar + camera badge + username + role pill, on the app's
        // dark gradient so the identity block stands apart from the field list below.
        FrameLayout headerCard = new FrameLayout(this);
        GradientDrawable headerBg = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{0xFF1C1C1E, 0xFF2A2A2D, 0xFF3A3A3D});
        headerBg.setCornerRadius(dp(22));
        headerCard.setBackground(headerBg);
        LinearLayout headerContent = new LinearLayout(this);
        headerContent.setOrientation(LinearLayout.VERTICAL);
        headerContent.setGravity(Gravity.CENTER_HORIZONTAL);
        headerContent.setPadding(dp(20), dp(28), dp(20), dp(24));

        FrameLayout avatarWrap = new FrameLayout(this);
        View ring = new View(this);
        ring.setBackgroundResource(R.drawable.avatar_ring_colorful);
        avatarWrap.addView(ring, new FrameLayout.LayoutParams(dp(92), dp(92)));
        avatar = new ImageView(this);
        avatar.setScaleType(ImageView.ScaleType.CENTER_CROP);
        avatar.setBackgroundResource(R.drawable.avatar_placeholder_bg);
        avatar.setImageResource(R.drawable.ic_profile);
        avatar.setPadding(dp(16), dp(16), dp(16), dp(16));
        FrameLayout.LayoutParams avatarLp = new FrameLayout.LayoutParams(dp(84), dp(84));
        avatarLp.gravity = Gravity.CENTER;
        avatarWrap.addView(avatar, avatarLp);

        TextView camera = label("\uD83D\uDCF7", 14, Color.BLACK, false);
        camera.setGravity(Gravity.CENTER);
        GradientDrawable cameraBg = new GradientDrawable();
        cameraBg.setShape(GradientDrawable.OVAL);
        cameraBg.setColor(getColor(R.color.profile_teal));
        camera.setBackground(cameraBg);
        FrameLayout.LayoutParams cameraLp = new FrameLayout.LayoutParams(dp(28), dp(28));
        cameraLp.gravity = Gravity.BOTTOM | Gravity.END;
        avatarWrap.addView(camera, cameraLp);
        View avatarTapTarget = new View(this);
        avatarTapTarget.setOnClickListener(v -> picker.launch("image/*"));
        avatarWrap.addView(avatarTapTarget, new FrameLayout.LayoutParams(dp(92), dp(92)));
        headerContent.addView(avatarWrap, new LinearLayout.LayoutParams(dp(92), dp(92)));

        LinearLayout usernameRow = new LinearLayout(this);
        usernameRow.setGravity(Gravity.CENTER_VERTICAL);
        usernameRow.setPadding(0, dp(14), 0, dp(4));
        TextView crown = label("\uD83D\uDC51", 14, Color.WHITE, false);
        usernameRow.addView(crown, new LinearLayout.LayoutParams(-2, -2));
        TextView usernameLabel = label(" Username :", 13, 0xFFC9CDD6, false);
        usernameRow.addView(usernameLabel, new LinearLayout.LayoutParams(-2, -2));
        headerContent.addView(usernameRow);

        usernameText = label("Player", 22, Color.WHITE, true);
        headerContent.addView(usernameText);

        rolePill = label("USER", 11, getColor(R.color.profile_purple), true);
        rolePill.setGravity(Gravity.CENTER);
        GradientDrawable pillBg = new GradientDrawable();
        pillBg.setShape(GradientDrawable.RECTANGLE);
        pillBg.setCornerRadius(dp(20));
        pillBg.setColor(0x337C5CE8);
        rolePill.setBackground(pillBg);
        rolePill.setPadding(dp(16), dp(6), dp(16), dp(6));
        LinearLayout.LayoutParams pillLp = new LinearLayout.LayoutParams(-2, -2);
        pillLp.topMargin = dp(10);
        headerContent.addView(rolePill, pillLp);

        headerCard.addView(headerContent, new FrameLayout.LayoutParams(-1, -2));
        body.addView(headerCard, new LinearLayout.LayoutParams(-1, -2));

        firstNameInput = fieldRow(body, "First Name", 0xFF2167C9, R.drawable.ic_profile, "Enter first name");
        lastNameInput = fieldRow(body, "Last Name", 0xFF7A4FD1, R.drawable.ic_profile, "Enter last name");
        mobileInput = fieldRow(body, "Mobile Number", 0xFF14885A, R.drawable.ic_phone, "Enter mobile number");
        mobileInput.setInputType(android.text.InputType.TYPE_CLASS_PHONE);
        EditText emailInput = fieldRow(body, "Email", 0xFFD9241C, R.drawable.ic_email, "");
        emailInput.setEnabled(false);
        emailInput.setTextColor(Color.rgb(120, 120, 126));
        this.emailInput = emailInput;

        addBioCard(body);

        save = new MaterialButton(this);
        save.setText("Save Changes");
        save.setTextSize(15);
        save.setAllCaps(false);
        save.setTypeface(null, Typeface.BOLD);
        save.setTextColor(Color.WHITE);
        save.setCornerRadius(dp(26));
        save.setBackgroundTintList(ColorStateList.valueOf(getColor(R.color.profile_blue)));
        save.setIcon(getDrawable(R.drawable.ic_chevron_right));
        save.setIconGravity(MaterialButton.ICON_GRAVITY_END);
        save.setIconTint(ColorStateList.valueOf(Color.WHITE));
        save.setOnClickListener(v -> saveChanges());
        LinearLayout.LayoutParams saveLp = new LinearLayout.LayoutParams(-1, dp(52));
        saveLp.topMargin = dp(24);
        body.addView(save, saveLp);

        scroll.addView(body, new ScrollView.LayoutParams(-1, -2));
        pageScroll = scroll;
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(root);
    }

    /** Instagram-style bio: no popup. Tapping "Add bio" / the card puts the cursor straight into the
     *  bio box on this page and opens the keyboard; text is written in place and saved with the page. */
    private void addBioCard(LinearLayout parent) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setBackgroundResource(R.drawable.bg_card_elevated_sm);
        card.setPadding(dp(14), dp(12), dp(14), dp(12));

        LinearLayout head = new LinearLayout(this);
        head.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = label("Bio :", 12.5f, Color.rgb(120, 120, 126), false);
        head.addView(title, new LinearLayout.LayoutParams(0, -2, 1));
        bioAction = label("+ Add bio", 13, Color.rgb(47, 111, 237), true);
        bioAction.setPadding(dp(8), dp(4), dp(4), dp(4));
        head.addView(bioAction, new LinearLayout.LayoutParams(-2, -2));
        card.addView(head);

        bioInput = new EditText(this);
        bioInput.setHint("Write something about yourself…");
        bioInput.setTextSize(15);
        bioInput.setTextColor(Color.rgb(20, 20, 22));
        bioInput.setHintTextColor(Color.rgb(170, 170, 176));
        bioInput.setBackground(null);
        bioInput.setPadding(0, dp(6), 0, dp(4));
        bioInput.setMinLines(2);
        bioInput.setMaxLines(6);
        bioInput.setGravity(Gravity.TOP | Gravity.START);
        bioInput.setInputType(android.text.InputType.TYPE_CLASS_TEXT
                | android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE
                | android.text.InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        bioInput.setFilters(new android.text.InputFilter[]{new android.text.InputFilter.LengthFilter(BIO_MAX)});
        card.addView(bioInput, new LinearLayout.LayoutParams(-1, -2));

        bioCounter = label("0/" + BIO_MAX, 11, Color.rgb(150, 150, 156), false);
        bioCounter.setGravity(Gravity.END);
        card.addView(bioCounter, new LinearLayout.LayoutParams(-1, -2));

        bioInput.addTextChangedListener(new android.text.TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void afterTextChanged(android.text.Editable s) {
                bioCounter.setText(s.length() + "/" + BIO_MAX);
                bioAction.setText(s.length() == 0 ? "+ Add bio" : "Edit");
            }
        });
        View.OnClickListener focusBio = v -> focusBio();
        bioAction.setOnClickListener(focusBio);
        card.setOnClickListener(focusBio);

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(14);
        parent.addView(card, lp);
    }

    private void focusBio() {
        bioInput.requestFocus();
        bioInput.setSelection(bioInput.getText().length());
        android.view.inputmethod.InputMethodManager imm =
                (android.view.inputmethod.InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
        if (imm != null) imm.showSoftInput(bioInput, android.view.inputmethod.InputMethodManager.SHOW_IMPLICIT);
        if (pageScroll != null) pageScroll.postDelayed(() -> pageScroll.fullScroll(View.FOCUS_DOWN), 250);
    }

    private void loadProfile() {
        if (FirebaseAuth.getInstance().getCurrentUser() == null) { finish(); return; }
        uid = FirebaseAuth.getInstance().getUid();
        String authEmail = FirebaseAuth.getInstance().getCurrentUser().getEmail();
        if (!FirebaseRepository.isReady(this)) return;
        FirebaseRepository.users().child(uid).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override public void onDataChange(DataSnapshot snapshot) {
                String fullName = text(snapshot.child("name").getValue(), "");
                String phone = text(snapshot.child("phone").getValue(), "");
                String role = text(snapshot.child("role").getValue(), "USER");
                String photoUrl = text(snapshot.child("photoUrl").getValue(), "");
                bioInput.setText(text(snapshot.child("bio").getValue(), ""));
                String[] parts = splitName(fullName);
                firstNameInput.setText(parts[0]);
                lastNameInput.setText(parts[1]);
                mobileInput.setText(phone);
                usernameText.setText(fullName.isEmpty() ? "Player" : fullName);
                rolePill.setText(role.toUpperCase());
                if (!photoUrl.isEmpty()) {
                    Glide.with(MyProfileActivity.this).load(photoUrl).transform(new CircleCrop()).into(avatar);
                }
                String email = authEmail != null ? authEmail : text(snapshot.child("email").getValue(), "");
                emailInput.setText(email);
            }
            @Override public void onCancelled(DatabaseError error) { }
        });
    }

    private void saveChanges() {
        if (uid == null) return;
        String first = firstNameInput.getText().toString().trim();
        String last = lastNameInput.getText().toString().trim();
        String mobile = mobileInput.getText().toString().trim();
        if (first.isEmpty()) { firstNameInput.setError("Required"); return; }
        String fullName = (first + " " + last).trim();
        save.setEnabled(false);
        if (pickedAvatar != null) {
            ImgBbUploader.uploadImage(this, pickedAvatar, new StorageUploader.Callback() {
                @Override public void onSuccess(String url) { writeProfile(fullName, mobile, url); }
                @Override public void onFailure(String message) {
                    save.setEnabled(true);
                    FancyText.toast(MyProfileActivity.this, "Photo upload failed: " + message, Toast.LENGTH_LONG).show();
                }
            });
        } else {
            writeProfile(fullName, mobile, null);
        }
    }

    private void writeProfile(String fullName, String mobile, String photoUrl) {
        Map<String, Object> update = new HashMap<>();
        update.put("name", fullName);
        update.put("phone", mobile);
        if (photoUrl != null) update.put("photoUrl", photoUrl);
        FirebaseRepository.users().child(uid).updateChildren(update)
                .addOnSuccessListener(v -> writeBio())
                .addOnFailureListener(e -> {
                    save.setEnabled(true);
                    FancyText.toast(this, "Could not save: " + e.getMessage(), Toast.LENGTH_LONG).show();
                });
    }

    /** Bio is written on its own (users/{uid}/bio) so a bio problem can never block name/phone/photo. */
    private void writeBio() {
        FirebaseRepository.users().child(uid).child("bio").setValue(bioInput.getText().toString().trim())
                .addOnSuccessListener(v -> {
                    save.setEnabled(true);
                    FancyText.toast(this, "Profile updated.", Toast.LENGTH_SHORT).show();
                    finish();
                })
                .addOnFailureListener(e -> {
                    save.setEnabled(true);
                    String msg = String.valueOf(e.getMessage());
                    boolean denied = msg.toLowerCase(java.util.Locale.ROOT).contains("permission");
                    FancyText.toast(this, denied
                            ? "Name/phone save ho gaya, par bio save nahi hui: Firebase rules me 'bio' allow nahi hai. Admin ko database.rules.json deploy karna hoga."
                            : "Bio save nahi hui: " + msg, Toast.LENGTH_LONG).show();
                });
    }

    /** Best-effort split of a single stored "name" field into first/last for these two
     *  boxes; rejoined into one "name" again on save so every other screen keeps working. */
    private static String[] splitName(String fullName) {
        String trimmed = fullName == null ? "" : fullName.trim();
        if (trimmed.isEmpty()) return new String[]{"", ""};
        int space = trimmed.indexOf(' ');
        if (space < 0) return new String[]{trimmed, ""};
        return new String[]{trimmed.substring(0, space), trimmed.substring(space + 1).trim()};
    }

    private static String text(Object value, String fallback) {
        return value == null || String.valueOf(value).trim().isEmpty() ? fallback : String.valueOf(value);
    }
}
