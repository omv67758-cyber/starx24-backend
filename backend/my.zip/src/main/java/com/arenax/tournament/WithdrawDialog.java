package com.arenax.tournament;


import com.arenax.tournament.util.FancyText;
import android.app.Activity;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.bottomsheet.BottomSheetBehavior;
import com.google.android.material.bottomsheet.BottomSheetDialog;

/**
 * Wallet-themed (white / gold / navy) withdrawal bottom sheet shared by the
 * Wallet screen. It receives winnings-only balance; deposited coins are never passed here.
 *
 * Design: slides up from the bottom, live balance header, drag handle,
 * close button, and expands to full height whenever a field is focused so
 * the keyboard never covers the inputs.
 *
 * Mechanism: quick-amount chips (25% / 50% / Max of balance), live inline
 * validation under each field instead of toast-only errors, the Request
 * button stays disabled until the form is actually valid, and it shows a
 * spinner + gets disabled while the request is in flight so a slow network
 * can't be double-tapped into two withdrawal requests.
 */
public final class WithdrawDialog {

    private WithdrawDialog() { }

    private static final String UPI_PATTERN = "[a-zA-Z0-9._\\-]{2,}@[a-zA-Z]{2,}";

    public static void show(Activity activity, long balance) {
        BottomSheetDialog dialog = new BottomSheetDialog(activity, com.google.android.material.R.style.Theme_Design_Light_BottomSheetDialog);
        View sheet = LayoutInflater.from(activity).inflate(R.layout.dialog_withdraw_bottom_sheet, null, false);
        dialog.setContentView(sheet);

        // Keyboard must push the sheet up (not cover the fields underneath it).
        if (dialog.getWindow() != null) {
            dialog.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        }

        BottomSheetBehavior<FrameLayout> behavior = dialog.getBehavior();
        behavior.setSkipCollapsed(true);
        behavior.setState(BottomSheetBehavior.STATE_EXPANDED);

        TextView balanceLine = sheet.findViewById(R.id.withdraw_sheet_balance);
        EditText amountInput = sheet.findViewById(R.id.withdraw_sheet_amount);
        TextView amountError = sheet.findViewById(R.id.withdraw_sheet_amount_error);
        TextView chip25 = sheet.findViewById(R.id.withdraw_chip_25);
        TextView chip50 = sheet.findViewById(R.id.withdraw_chip_50);
        TextView chipMax = sheet.findViewById(R.id.withdraw_chip_max);
        EditText upiInput = sheet.findViewById(R.id.withdraw_sheet_upi);
        TextView upiError = sheet.findViewById(R.id.withdraw_sheet_upi_error);
        View close = sheet.findViewById(R.id.withdraw_sheet_close);
        View cancel = sheet.findViewById(R.id.withdraw_sheet_cancel);
        FrameLayout request = sheet.findViewById(R.id.withdraw_sheet_request);
        TextView requestText = sheet.findViewById(R.id.withdraw_sheet_request_text);
        ProgressBar requestProgress = sheet.findViewById(R.id.withdraw_sheet_request_progress);

        balanceLine.setText("Winning balance: \u20b9" + balance);

        // Whenever a field gets focus (keyboard about to open), force the sheet
        // to fill the screen so the keyboard never sits on top of the inputs.
        View.OnFocusChangeListener expandOnFocus = (v, hasFocus) -> {
            if (hasFocus) {
                behavior.setState(BottomSheetBehavior.STATE_EXPANDED);
            }
        };

        dialog.setOnShowListener(d -> behavior.setState(BottomSheetBehavior.STATE_EXPANDED));

        // --- Quick-amount chips: fill the amount field from the live balance ---
        View.OnClickListener chipClick = v -> {
            long amount;
            if (v == chip25) amount = Math.round(balance * 0.25);
            else if (v == chip50) amount = Math.round(balance * 0.5);
            else amount = balance;
            amount = Math.max(amount, balance > 0 ? Math.min(50, balance) : 0);
            amountInput.setText(String.valueOf(amount));
            amountInput.setSelection(amountInput.getText().length());
        };
        chip25.setOnClickListener(chipClick);
        chip50.setOnClickListener(chipClick);
        chipMax.setOnClickListener(chipClick);

        // --- Live validation: keep the Request button's enabled state and the
        // inline error text in sync with every keystroke, instead of only
        // surfacing problems as a toast after the user taps Request. ---
        Runnable validate = () -> {
            boolean amountOk = validateAmount(amountInput.getText().toString().trim(), balance) == null;
            boolean upiOk = validateUpi(upiInput.getText().toString().trim()) == null;
            boolean formOk = amountOk && upiOk;
            request.setEnabled(formOk);
            request.setAlpha(formOk ? 1f : 0.45f);
        };
        TextWatcher watcher = new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) { }
            @Override public void afterTextChanged(Editable s) { validate.run(); }
        };
        amountInput.addTextChangedListener(watcher);
        upiInput.addTextChangedListener(watcher);
        validate.run();

        // Clear a field's error state as soon as the user starts fixing it,
        // and keep the "expand sheet on focus" behaviour from above.
        amountInput.setOnFocusChangeListener((v, hasFocus) -> {
            expandOnFocus.onFocusChange(v, hasFocus);
            if (hasFocus) setFieldError(amountInput, amountError, null);
        });
        upiInput.setOnFocusChangeListener((v, hasFocus) -> {
            expandOnFocus.onFocusChange(v, hasFocus);
            if (hasFocus) setFieldError(upiInput, upiError, null);
        });

        FancyText.attach(dialog);
        dialog.show();
        amountInput.requestFocus();

        close.setOnClickListener(v -> dialog.dismiss());
        cancel.setOnClickListener(v -> dialog.dismiss());

        // Let "Done" on the keyboard submit directly, same as tapping Request.
        upiInput.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_DONE
                    || (event != null && event.getKeyCode() == KeyEvent.KEYCODE_ENTER)) {
                request.performClick();
                return true;
            }
            return false;
        });

        request.setOnClickListener(v -> {
            String amountText = amountInput.getText().toString().trim();
            String upiId = upiInput.getText().toString().trim();

            String amountProblem = validateAmount(amountText, balance);
            String upiProblem = validateUpi(upiId);
            setFieldError(amountInput, amountError, amountProblem);
            setFieldError(upiInput, upiError, upiProblem);
            if (amountProblem != null) {
                toast(activity, amountProblem);
                return;
            }
            if (upiProblem != null) {
                toast(activity, upiProblem);
                return;
            }

            int amount = Integer.parseInt(amountText);
            setLoading(true, request, requestText, requestProgress, cancel, close, amountInput, upiInput);
            dialog.setCancelable(false);

            WithdrawalApiClient.requestWithdrawal(amount, upiId, new WithdrawalApiClient.SimpleCallback() {
                @Override public void onSuccess(org.json.JSONObject result) {
                    toast(activity, "Withdrawal request submitted");
                    dialog.dismiss();
                }
                @Override public void onError(String message) {
                    setLoading(false, request, requestText, requestProgress, cancel, close, amountInput, upiInput);
                    dialog.setCancelable(true);
                    toast(activity, message);
                }
            });
        });
    }

    /** @return null if the amount is valid, otherwise a user-facing error message. */
    private static String validateAmount(String amountText, long balance) {
        if (amountText.isEmpty()) return "Enter an amount";
        int amount;
        try {
            amount = Integer.parseInt(amountText);
        } catch (Exception e) {
            return "Enter a valid amount";
        }
        if (amount < 50) return "Minimum withdrawal is \u20b950";
        if (amount > balance) return "You only have \u20b9" + balance + " available";
        return null;
    }

    /** @return null if the UPI id is valid, otherwise a user-facing error message. */
    private static String validateUpi(String upiId) {
        if (upiId.isEmpty()) return "Enter your UPI ID";
        if (!upiId.matches(UPI_PATTERN)) return "Enter a valid UPI ID (e.g. name@bank)";
        return null;
    }

    private static void setFieldError(EditText field, TextView errorView, String message) {
        if (message == null) {
            errorView.setVisibility(View.GONE);
            field.setBackgroundResource(R.drawable.wv_bg_input);
        } else {
            errorView.setText(message);
            errorView.setVisibility(View.VISIBLE);
            field.setBackgroundResource(R.drawable.wv_bg_input_error);
        }
    }

    private static void setLoading(boolean loading, FrameLayout request, TextView requestText,
                                    ProgressBar requestProgress, View cancel, View close,
                                    EditText amountInput, EditText upiInput) {
        request.setEnabled(!loading);
        request.setAlpha(loading ? 0.7f : 1f);
        requestText.setVisibility(loading ? View.GONE : View.VISIBLE);
        requestProgress.setVisibility(loading ? View.VISIBLE : View.GONE);
        cancel.setEnabled(!loading);
        close.setEnabled(!loading);
        amountInput.setEnabled(!loading);
        upiInput.setEnabled(!loading);
    }

    private static void toast(Activity activity, String message) {
        FancyText.toast(activity, message, Toast.LENGTH_LONG).show();
    }
}
