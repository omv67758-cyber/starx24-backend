package com.arenax.tournament;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Matrix;
import android.graphics.Rect;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.InputFilter;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.animation.ValueAnimator;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.LayerDrawable;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.material.bottomsheet.BottomSheetDialog;

import org.json.JSONArray;
import org.json.JSONObject;

/**
 * Profile -> "Support Agent (AI)". Chat with the AI support assistant.
 * The AI is called ONLY through the backend (POST /support/chat) - no AI key lives in the app.
 * The bot cannot see or change the user's wallet/account; for those cases the backend returns
 * an in-app redirect target: Telegram support (there is no ticket page).
 */
public class SupportChatActivity extends BaseActivity {
    private static final int MAX_CHARS = 500;
    private static final String[] QUICK_QUESTIONS = {
            "Coins nahi mile", "Withdraw kaise karein?", "Match kaise join karein?",
            "Prize nahi mila", "Room ID kab milega?"
    };

    private static final String WELCOME =
            "Hi! Main STARX24 ka AI support agent hoon. Matches, coins, withdrawal ya room ke baare me kuch bhi poochho.\n\n"
            + "Main aapka account ya wallet dekh nahi sakta. Payment ya account issue ho to main short steps aur direct support link dunga.\n\n"
            + "Upar left wale menu me app use karne ki puri guide hai.";

    private final JSONArray history = new JSONArray();
    private LinearLayout chat;
    private ScrollView scroll;
    private EditText input;
    private TextView sendButton;
    private View chipsRow;
    private View typingBubble;
    private View headerView;
    private View inputRowView;
    private View rootView;
    private WindowInsetsCompat lastInsets;
    private boolean waiting;
    private final Handler typingHandler = new Handler(Looper.getMainLooper());
    private ValueAnimator shimmerAnimator;
    private int thinkingPhase;
    private final Runnable thinkingSweep = new Runnable() {
        @Override public void run() {
            if (!waiting || !(typingBubble instanceof TextView)) return;
            String[] dots = {"", ".", "..", "...", "..", "."};
            ((TextView) typingBubble).setText("STARX24 AI is thinking" + dots[thinkingPhase]);
            thinkingPhase = (thinkingPhase + 1) % dots.length;
            typingHandler.postDelayed(this, 360L);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildScreen();
        addBot(WELCOME);
    }

    // ---------------------------------------------------------------- UI ---

    private void buildScreen() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackground(buildScreenBackground());

        headerView = buildHeader();
        root.addView(headerView);

        scroll = new ScrollView(this);
        scroll.setFillViewport(false);
        scroll.setFocusable(false);
        scroll.setFocusableInTouchMode(false);
        chat = new LinearLayout(this);
        chat.setOrientation(LinearLayout.VERTICAL);
        chat.setPadding(dp(14), dp(8), dp(14), dp(8));
        scroll.addView(chat, new ScrollView.LayoutParams(-1, -2));
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));

        chipsRow = buildChips();
        root.addView(chipsRow);
        inputRowView = buildInputRow();
        root.addView(inputRowView);
        setContentView(root);

        // Works the same on every Android version (7 -> 16): we handle status bar / nav bar /
        // keyboard ourselves instead of relying on adjustResize (which stops working edge-to-edge).
        WindowCompat.setDecorFitsSystemWindows(getWindow(), false);
        // Colourful theme: bars blend into the gradient, so use LIGHT (white) status / nav icons.
        getWindow().setStatusBarColor(Color.parseColor("#6D3BFF"));
        getWindow().setNavigationBarColor(Color.parseColor("#1F6BFF"));
        WindowCompat.getInsetsController(getWindow(), root).setAppearanceLightStatusBars(false);
        WindowCompat.getInsetsController(getWindow(), root).setAppearanceLightNavigationBars(false);
        View contentView = findViewById(android.R.id.content);
        if (contentView != null) contentView.setBackgroundColor(Color.parseColor("#4A5BFF"));
        rootView = root;
        ViewCompat.setOnApplyWindowInsetsListener(root, (v, insets) -> {
            lastInsets = insets;
            applyInsets();
            return insets;
        });
        root.getViewTreeObserver().addOnGlobalLayoutListener(this::applyInsets);
    }

    /** Header goes below the status bar; input card sits above the keyboard / navigation bar. */
    private void applyInsets() {
        if (rootView == null || headerView == null || inputRowView == null) return;
        int top = 0, bottom = 0;
        if (lastInsets != null) {
            Insets bars = lastInsets.getInsets(WindowInsetsCompat.Type.systemBars()
                    | WindowInsetsCompat.Type.displayCutout());
            Insets ime = lastInsets.getInsets(WindowInsetsCompat.Type.ime());
            top = Math.max(bars.top, lastInsets.getSystemWindowInsetTop());
            // Older Android versions report the keyboard only through the legacy bottom inset.
            bottom = Math.max(Math.max(bars.bottom, ime.bottom), lastInsets.getSystemWindowInsetBottom());
        }
        // Fallback that does not depend on insets at all: measure how much of the window the
        // keyboard covers.
        Rect visible = new Rect();
        rootView.getWindowVisibleDisplayFrame(visible);
        int[] loc = new int[2];
        rootView.getLocationOnScreen(loc);
        int covered = loc[1] + rootView.getHeight() - visible.bottom;
        if (covered > rootView.getRootView().getHeight() * 0.15f) bottom = Math.max(bottom, covered);

        boolean keyboardUp = bottom > dp(120);
        int headerTop = dp(8) + top;
        int inputBottom = dp(12) + bottom;
        if (headerView.getPaddingTop() != headerTop) {
            headerView.setPadding(dp(14), headerTop, dp(14), dp(8));
        }
        if (inputRowView.getPaddingBottom() != inputBottom) {
            inputRowView.setPadding(dp(12), dp(8), dp(12), inputBottom);
            if (keyboardUp) scrollToBottom();
        }
    }

    /** Vibrant page: violet -> blue -> cyan sweep with a pink glow bottom-right and a cyan glow top-left. */
    private Drawable buildScreenBackground() {
        GradientDrawable base = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{Color.parseColor("#6D3BFF"), Color.parseColor("#2F6BFF"), Color.parseColor("#12B8FF")});
        GradientDrawable pink = new GradientDrawable();
        pink.setGradientType(GradientDrawable.RADIAL_GRADIENT);
        pink.setGradientCenter(0.95f, 0.88f);
        pink.setGradientRadius(dp(360));
        pink.setColors(new int[]{Color.parseColor("#80FF3D9A"), Color.parseColor("#00FF3D9A")});
        GradientDrawable amber = new GradientDrawable();
        amber.setGradientType(GradientDrawable.RADIAL_GRADIENT);
        amber.setGradientCenter(0.05f, 0.62f);
        amber.setGradientRadius(dp(260));
        amber.setColors(new int[]{Color.parseColor("#55FFB020"), Color.parseColor("#00FFB020")});
        GradientDrawable cyan = new GradientDrawable();
        cyan.setGradientType(GradientDrawable.RADIAL_GRADIENT);
        cyan.setGradientCenter(0.92f, 0.04f);
        cyan.setGradientRadius(dp(260));
        cyan.setColors(new int[]{Color.parseColor("#6600F0FF"), Color.parseColor("#0000F0FF")});
        return new LayerDrawable(new Drawable[]{base, cyan, amber, pink});
    }

    private GradientDrawable roundedBg(int fill, int stroke, float radiusDp) {
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(fill);
        bg.setCornerRadius(dp(radiusDp));
        if (stroke != 0) bg.setStroke(dp(1), stroke);
        return bg;
    }

    private View iconButton(int iconRes, String description, View.OnClickListener click) {
        ImageView b = new ImageView(this);
        b.setImageResource(iconRes);
        b.setScaleType(ImageView.ScaleType.CENTER);
        b.setBackground(roundedBg(Color.parseColor("#33FFFFFF"), Color.parseColor("#66FFFFFF"), 14));
        b.setColorFilter(Color.WHITE);
        b.setContentDescription(description);
        b.setOnClickListener(click);
        return b;
    }

    private View logoSymbol(int sizeDp) {
        ImageView logo = new ImageView(this);
        logo.setImageResource(R.drawable.starx24_logo);
        logo.setScaleType(ImageView.ScaleType.FIT_CENTER);
        logo.setPadding(dp(sizeDp * 0.16f), dp(sizeDp * 0.16f), dp(sizeDp * 0.16f), dp(sizeDp * 0.16f));
        GradientDrawable bg = new GradientDrawable();
        bg.setShape(GradientDrawable.OVAL);
        bg.setColor(Color.WHITE);
        bg.setStroke(dp(2f), Color.parseColor("#FFC93C"));
        logo.setBackground(bg);
        logo.setClipToOutline(true);
        logo.setContentDescription("STARX24");
        return logo;
    }

    private View buildHeader() {
        FrameLayout header = new FrameLayout(this);
        header.setPadding(dp(14), dp(14), dp(14), dp(8));

        // Left: back + menu (app guide)
        LinearLayout left = new LinearLayout(this);
        left.setOrientation(LinearLayout.HORIZONTAL);
        left.setGravity(Gravity.CENTER_VERTICAL);
        View back = iconButton(R.drawable.ic_ai_back, "Go back", v -> finish());
        left.addView(back, new LinearLayout.LayoutParams(dp(38), dp(38)));
        View menu = iconButton(R.drawable.ic_ai_menu, "App guide menu", v -> showGuideMenu());
        LinearLayout.LayoutParams menuLp = new LinearLayout.LayoutParams(dp(38), dp(38));
        menuLp.leftMargin = dp(6);
        left.addView(menu, menuLp);
        header.addView(left, new FrameLayout.LayoutParams(-2, -2, Gravity.START | Gravity.CENTER_VERTICAL));

        // Center: card with the STARX symbol + name
        LinearLayout pill = new LinearLayout(this);
        pill.setOrientation(LinearLayout.HORIZONTAL);
        pill.setGravity(Gravity.CENTER_VERTICAL);
        pill.setPadding(dp(6), dp(5), dp(16), dp(5));
        pill.setBackground(roundedBg(Color.WHITE, 0, 22));
        pill.setElevation(dp(6));
        pill.addView(logoSymbol(30), new LinearLayout.LayoutParams(dp(30), dp(30)));
        TextView name = label("STARX24 AI", 15, Color.parseColor("#3A1FB8"), true);
        name.setTag("nofancy");
        name.setSingleLine(true);
        name.setPadding(dp(8), 0, 0, 0);
        pill.addView(name);
        header.addView(pill, new FrameLayout.LayoutParams(-2, -2, Gravity.CENTER));

        // Right: settings (language)
        View gear = iconButton(R.drawable.ic_ai_settings, "Settings", v -> showSettingsSheet());
        header.addView(gear, new FrameLayout.LayoutParams(dp(38), dp(38), Gravity.END | Gravity.CENTER_VERTICAL));
        return header;
    }

    private View buildChips() {
        HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        LinearLayout chips = new LinearLayout(this);
        chips.setOrientation(LinearLayout.HORIZONTAL);
        chips.setPadding(dp(14), dp(10), dp(14), dp(8));
        final String[][] chipColors = {
                {"#FF7A18", "#FF3D6E"}, {"#00C98D", "#00A3C4"}, {"#FFC53D", "#FF8A00"},
                {"#B44CFF", "#6D3BFF"}, {"#FF4D8D", "#C22BFF"}};
        int chipIndex = 0;
        for (String q : QUICK_QUESTIONS) {
            TextView chip = label(q, 12.5f, Color.WHITE, true);
            chip.setPadding(dp(15), dp(9), dp(15), dp(9));
            String[] cc = chipColors[chipIndex++ % chipColors.length];
            GradientDrawable chipBg = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                    new int[]{Color.parseColor(cc[0]), Color.parseColor(cc[1])});
            chipBg.setCornerRadius(dp(20));
            chip.setBackground(chipBg);
            chip.setElevation(dp(3));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
            lp.rightMargin = dp(8);
            chip.setLayoutParams(lp);
            chip.setOnClickListener(v -> send(q));
            chips.addView(chip);
        }
        hs.addView(chips);
        return hs;
    }

    private View buildInputRow() {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(12), dp(8), dp(12), dp(12));
        row.setBackgroundColor(Color.TRANSPARENT);

        input = new EditText(this);
        input.setHint("Ask STARX24 AI\u2026");
        input.setSingleLine(false);
        input.setTextSize(15);
        input.setTextColor(Color.parseColor("#1B1740"));
        input.setHintTextColor(Color.parseColor("#8E86B8"));
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE
                | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        input.setMaxLines(4);
        input.setFilters(new InputFilter[]{new InputFilter.LengthFilter(MAX_CHARS)});
        input.setImeOptions(EditorInfo.IME_ACTION_SEND);
        input.setPadding(dp(18), dp(11), dp(18), dp(11));
        input.setBackground(roundedBg(Color.WHITE, Color.parseColor("#FFC93C"), 24));
        input.setElevation(dp(5));
        input.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_SEND) { sendFromInput(); return true; }
            return false;
        });
        row.addView(input, new LinearLayout.LayoutParams(0, -2, 1));

        sendButton = label("\u2191", 22, Color.WHITE, true);
        sendButton.setGravity(Gravity.CENTER);
        sendButton.setContentDescription("Send message");
        GradientDrawable sendBg = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{Color.parseColor("#FF9A1F"), Color.parseColor("#FF2D87")});
        sendBg.setShape(GradientDrawable.OVAL);
        sendButton.setBackground(sendBg);
        sendButton.setElevation(dp(6));
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(dp(46), dp(46));
        sp.leftMargin = dp(8);
        sendButton.setLayoutParams(sp);
        sendButton.setOnClickListener(v -> sendFromInput());
        row.addView(sendButton);
        return row;
    }

    // ------------------------------------------------- Menu (app guide) ---

    /** Ready-made "how to use the app" answers. Shown instantly, no AI call needed. */
    private static final String[][] GUIDES = {
            {"Match kaise join karein?",
                    "Match join karne ke steps:\n\n"
                            + "1. Home par apni game category chuno (jaise BR ya Clash Squad).\n"
                            + "2. Match chuno aur entry coins check karo.\n"
                            + "3. Join dabao, slot select karo aur confirm karo.\n"
                            + "4. Join hone ke baad aap match detail page par pahunch jaoge, wahin se room details milenge."},
            {"Coins kaise add karein?",
                    "Coins add karne ke steps:\n\n"
                            + "1. Neeche Wallet tab kholo.\n"
                            + "2. Add Coins me amount chuno (10, 20, 50, 100, 200, 500) ya Custom Amount dalo.\n"
                            + "3. Pay karo.\n"
                            + "4. Payment hote hi coins wallet me aa jate hain.\n\n"
                            + "Payment hua par coins nahi mile? Telegram Support se admin ko contact karo."},
            {"Withdraw kaise karein?",
                    "Withdraw karne ke steps:\n\n"
                            + "1. Wallet tab kholo.\n"
                            + "2. Withdraw dabao.\n"
                            + "3. Amount aur payment details bharo.\n"
                            + "4. Submit karo. Status History me dikhta rahega."},
            {"Room ID aur password kab milega?",
                    "Room ID / password match start hone se pehle admin release karta hai.\n\n"
                            + "- Sirf joined players ko milta hai.\n"
                            + "- Release hote hi notification aata hai.\n"
                            + "- Match detail page me bhi dikhta hai.\n\n"
                            + "Match start se pehle lobby me ready raho."},
            {"Result aur prize kaise dekhein?",
                    "Match khatam hone ke baad admin result publish karta hai.\n\n"
                            + "1. \"Result Published\" notification aayega.\n"
                            + "2. Leaderboard tab me apna rank dekho.\n"
                            + "3. Prize coins wallet me credit hote hain, History me dikhte hain.\n\n"
                            + "Prize na mile to Telegram Support me match ka naam bhejo."},
            {"Wallet history kaise dekhein?",
                    "Wallet tab kholo aur History dabao. Wahan add coins, entry fee, prize aur withdrawals ki puri list milegi."},
            {"Profile aur bio kaise edit karein?",
                    "Profile tab kholo, upar wale profile card par tap karo. Bio card khulega, uske pencil icon se bio likho aur Save karo.\n\n"
                            + "Name, email aur phone number yahan se change nahi hote."},
            {"Language kaise badlein?",
                    "Is chat me upar right wale Settings (gear) icon par tap karo aur Language chuno. "
                            + "Ya Profile tab me Language par jao."},
            {"Support se kaise contact karein?",
                    "Payment ya account ka issue ho to neeche diye links se seedha support se baat karo."}
    };

    private void showGuideMenu() {
        final BottomSheetDialog dialog = new BottomSheetDialog(this);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(18), dp(10), dp(18), dp(18));
        box.setBackground(sheetBg());

        box.addView(sheetHandle());
        TextView title = label("App guide", 19, Color.parseColor("#17233F"), true);
        title.setPadding(dp(2), dp(10), 0, 0);
        box.addView(title);
        TextView sub = label("Kisi bhi topic par tap karo, steps turant mil jayenge.", 12.5f, Color.parseColor("#68686D"), false);
        sub.setPadding(dp(2), dp(2), 0, dp(10));
        box.addView(sub);

        ScrollView sv = new ScrollView(this);
        sv.setVerticalScrollBarEnabled(false);
        LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        for (int i = 0; i < GUIDES.length; i++) {
            final int index = i;
            list.addView(sheetRow(String.valueOf(i + 1), GUIDES[i][0], null, v -> {
                dialog.dismiss();
                showGuide(index);
            }));
        }
        sv.addView(list);
        box.addView(sv, new LinearLayout.LayoutParams(-1, -2));

        dialog.setContentView(box);
        showSheet(dialog);
    }

    private void showGuide(int index) {
        if (waiting) return;
        String question = GUIDES[index][0];
        String answer = GUIDES[index][1];
        chipsRow.setVisibility(View.GONE);
        addUser(question);
        addBot(answer);
        try {
            history.put(new JSONObject().put("role", "user").put("content", question));
            history.put(new JSONObject().put("role", "assistant").put("content", answer));
        } catch (Exception ignored) { }
        if (index == GUIDES.length - 1) {
            addRedirectLink("telegram");
        }
    }

    // --------------------------------------------------------- Settings ---

    private void showSettingsSheet() {
        final BottomSheetDialog dialog = new BottomSheetDialog(this);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(18), dp(10), dp(18), dp(22));
        box.setBackground(sheetBg());
        box.addView(sheetHandle());
        TextView title = label("Settings", 19, Color.parseColor("#17233F"), true);
        title.setPadding(dp(2), dp(10), 0, dp(10));
        box.addView(title);

        String lang;
        try { lang = com.arenax.tournament.util.LanguageManager.currentLabel(this); }
        catch (RuntimeException e) { lang = ""; }
        box.addView(sheetRow("A", "Language", lang, v -> {
            dialog.dismiss();
            com.arenax.tournament.util.LanguageManager.showPicker(this);
        }));
        box.addView(sheetRow("\u00D7", "Clear chat", null, v -> {
            dialog.dismiss();
            clearChat();
        }));
        dialog.setContentView(box);
        showSheet(dialog);
    }

    private void clearChat() {
        if (waiting) return;
        while (history.length() > 0) history.remove(history.length() - 1);
        chat.removeAllViews();
        chipsRow.setVisibility(View.VISIBLE);
        addBot(WELCOME);
    }

    private GradientDrawable sheetBg() {
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.WHITE);
        float r = dp(26);
        bg.setCornerRadii(new float[]{r, r, r, r, 0, 0, 0, 0});
        return bg;
    }

    private View sheetHandle() {
        View h = new View(this);
        h.setBackground(roundedBg(Color.parseColor("#D5DBE8"), 0, 3));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(40), dp(5));
        lp.gravity = Gravity.CENTER_HORIZONTAL;
        h.setLayoutParams(lp);
        return h;
    }

    private View sheetRow(String badge, String title, String value, View.OnClickListener click) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(12), dp(11), dp(14), dp(11));
        row.setBackground(roundedBg(Color.parseColor("#F6F2FF"), Color.parseColor("#E3D9FF"), 16));
        LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(-1, -2);
        rlp.topMargin = dp(5);
        rlp.bottomMargin = dp(5);
        row.setLayoutParams(rlp);

        TextView b = label(badge, 13, Color.WHITE, true);
        b.setGravity(Gravity.CENTER);
        final String[][] pal = {{"#FF7A18", "#FF3D6E"}, {"#00C98D", "#00A3C4"}, {"#FFC53D", "#FF8A00"},
                {"#B44CFF", "#6D3BFF"}, {"#FF4D8D", "#C22BFF"}, {"#2F80FF", "#12B8FF"}};
        String[] pc = pal[Math.abs(title.hashCode()) % pal.length];
        GradientDrawable bb = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{Color.parseColor(pc[0]), Color.parseColor(pc[1])});
        bb.setShape(GradientDrawable.OVAL);
        b.setBackground(bb);
        row.addView(b, new LinearLayout.LayoutParams(dp(32), dp(32)));

        TextView t = label(title, 14.5f, Color.parseColor("#17233F"), true);
        t.setPadding(dp(12), 0, dp(8), 0);
        row.addView(t, new LinearLayout.LayoutParams(0, -2, 1));
        if (value != null && !value.isEmpty()) {
            TextView v = label(value, 12.5f, Color.parseColor("#68686D"), false);
            v.setPadding(0, 0, dp(8), 0);
            row.addView(v);
        }
        row.addView(label("\u203A", 20, Color.parseColor("#8A94AA"), true));
        row.setOnClickListener(click);
        return row;
    }

    private void showSheet(BottomSheetDialog dialog) {
        dialog.setOnShowListener(d -> {
            View sheet = dialog.findViewById(com.google.android.material.R.id.design_bottom_sheet);
            if (sheet != null) sheet.setBackgroundColor(Color.TRANSPARENT);
        });
        dialog.show();
    }

    // ------------------------------------------------------------- Chat ---

    private void sendFromInput() {
        send(input.getText().toString());
    }

    private void send(String raw) {
        String text = raw == null ? "" : raw.trim();
        if (text.isEmpty() || waiting) return;
        boolean hadFocus = input.hasFocus();
        input.setText("");
        chipsRow.setVisibility(View.GONE);
        addUser(text);
        try {
            history.put(new JSONObject().put("role", "user").put("content", text));
        } catch (Exception ignored) { }
        setWaiting(true);
        if (hadFocus) input.requestFocus();

        WithdrawalApiClient.supportChat(history, new WithdrawalApiClient.SimpleCallback() {
            @Override public void onSuccess(JSONObject result) {
                if (isFinishing() || isDestroyed()) return;
                setWaiting(false);
                boolean keepFocus = input.hasFocus();
                String reply = cleanBrand(result.optString("reply", "").trim());
                if (reply.isEmpty()) reply = "Sorry, jawab nahi mil paya. Please dobara try karo.";
                try {
                    history.put(new JSONObject().put("role", "assistant").put("content", reply));
                } catch (Exception ignored) { }
                addBot(reply);
                String redirect = result.optString("redirect", "").trim();
                if (!redirect.isEmpty()) addRedirectLink(redirect);
                if (keepFocus && !input.hasFocus()) input.requestFocus();
            }

            @Override public void onError(String message) {
                if (isFinishing() || isDestroyed()) return;
                setWaiting(false);
                // Drop the unanswered question so roles keep alternating, and let the user retry it.
                history.remove(history.length() - 1);
                input.setText(text);
                input.setSelection(input.getText().length());
                addBot(message == null || message.isEmpty() ? "Kuch gadbad ho gayi. Dobara try karo." : message);
            }
        });
    }

    private static final String THINKING_TEXT = "STARX24 AI is thinking";

    private void setWaiting(boolean value) {
        waiting = value;
        sendButton.setAlpha(value ? 0.4f : 1f);
        if (value) {
            thinkingPhase = 0;
            TextView tv = (TextView) bubble(THINKING_TEXT, false);
            tv.setTextIsSelectable(false);
            // Lock the card width to the longest state ("...") so growing dots never resize it.
            float full = tv.getPaint().measureText(THINKING_TEXT + "...");
            tv.setWidth((int) Math.ceil(full) + tv.getPaddingLeft() + tv.getPaddingRight());
            typingBubble = tv;
            chat.addView(tv);
            startThinkingShimmer(tv);
            typingHandler.post(thinkingSweep);
            scrollToBottom();
        } else if (typingBubble != null) {
            typingHandler.removeCallbacks(thinkingSweep);
            stopThinkingShimmer();
            chat.removeView(typingBubble);
            typingBubble = null;
        }
    }

    /** Light sweep: a soft bright band glides across the dim text, then repeats. */
    private void startThinkingShimmer(TextView textView) {
        final int base = Color.parseColor("#B7AEE0");
        final int glow = Color.parseColor("#FF2D87");
        final float textW = textView.getPaint().measureText(THINKING_TEXT + "...");
        final float band = Math.max(dp(70), textW * 0.45f);
        final LinearGradient gradient = new LinearGradient(
                0, 0, band, 0,
                new int[]{base, glow, base},
                new float[]{0f, 0.5f, 1f},
                Shader.TileMode.CLAMP);
        final Matrix matrix = new Matrix();
        textView.setTextColor(base);
        textView.getPaint().setShader(gradient);
        stopShimmerAnimatorOnly();
        shimmerAnimator = ValueAnimator.ofFloat(-band, textW);
        shimmerAnimator.setDuration(1300L);
        shimmerAnimator.setInterpolator(new android.view.animation.LinearInterpolator());
        shimmerAnimator.setRepeatCount(ValueAnimator.INFINITE);
        shimmerAnimator.addUpdateListener(animation -> {
            matrix.setTranslate((Float) animation.getAnimatedValue(), 0);
            gradient.setLocalMatrix(matrix);
            textView.invalidate();
        });
        shimmerAnimator.start();
    }

    private void stopShimmerAnimatorOnly() {
        if (shimmerAnimator != null) {
            shimmerAnimator.cancel();
            shimmerAnimator = null;
        }
    }

    private void stopThinkingShimmer() {
        stopShimmerAnimatorOnly();
        if (typingBubble instanceof TextView) {
            ((TextView) typingBubble).getPaint().setShader(null);
            ((TextView) typingBubble).invalidate();
        }
    }

    private void addUser(String text) {
        chat.addView(bubble(text, true));
        scrollToBottom();
    }

    /** The app is only ever called STARX24 - never show the old "ArenaX" name from the AI. */
    private static String cleanBrand(String text) {
        if (text == null) return "";
        return text.replaceAll("(?i)\\s*\\(\\s*arena\\s*x\\s*\\)", "")
                .replaceAll("(?i)arena\\s*x", "STARX24");
    }

    private void addBot(String text) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.TOP);
        LinearLayout.LayoutParams rowLp = new LinearLayout.LayoutParams(-2, -2);
        rowLp.gravity = Gravity.START;
        row.setLayoutParams(rowLp);

        LinearLayout.LayoutParams avLp = new LinearLayout.LayoutParams(dp(28), dp(28));
        avLp.topMargin = dp(6);
        row.addView(logoSymbol(28), avLp);

        TextView b = (TextView) bubble(cleanBrand(text), false);
        b.setMaxWidth((int) (getResources().getDisplayMetrics().widthPixels * 0.70f));
        LinearLayout.LayoutParams bLp = new LinearLayout.LayoutParams(-2, -2);
        bLp.leftMargin = dp(8);
        bLp.topMargin = dp(4);
        bLp.bottomMargin = dp(4);
        b.setLayoutParams(bLp);
        row.addView(b);
        chat.addView(row);
        scrollToBottom();
    }

    private void addRedirectLink(String target) {
        String labelText = "Contact Support (Telegram)  →";
        TextView link = label(labelText, 13.5f, Color.parseColor("#245FC7"), true);
        link.setTextColor(Color.WHITE);
        link.setGravity(Gravity.CENTER);
        link.setPadding(dp(18), dp(11), dp(18), dp(11));
        GradientDrawable bg = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                new int[]{Color.parseColor("#00D68F"), Color.parseColor("#00A3FF")});
        bg.setCornerRadius(dp(20));
        link.setElevation(dp(4));
        link.setBackground(bg);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
        lp.gravity = Gravity.START;
        lp.topMargin = dp(2);
        lp.bottomMargin = dp(8);
        link.setLayoutParams(lp);
        link.setOnClickListener(v -> {
            SupportLinks.openTelegramSupport(this);
        });
        chat.addView(link);
        scrollToBottom();
    }

    private View bubble(String text, boolean mine) {
        TextView tv = label(text, 14, mine ? Color.WHITE : Color.parseColor("#1B1740"), false);
        tv.setTextIsSelectable(!mine);
        tv.setLineSpacing(0, 1.08f);
        tv.setPadding(dp(14), dp(10), dp(14), dp(10));
        tv.setMaxWidth((int) (getResources().getDisplayMetrics().widthPixels * 0.78f));
        GradientDrawable bg;
        float a = dp(18), sm = dp(5);
        if (mine) {
            bg = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                    new int[]{Color.parseColor("#FF8A1F"), Color.parseColor("#FF2D87")});
            bg.setCornerRadii(new float[]{a, a, a, a, sm, sm, a, a});
        } else {
            bg = new GradientDrawable();
            bg.setColor(Color.WHITE);
            bg.setCornerRadii(new float[]{sm, sm, a, a, a, a, a, a});
        }
        tv.setBackground(bg);
        tv.setElevation(dp(3));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
        lp.gravity = mine ? Gravity.END : Gravity.START;
        lp.topMargin = dp(4);
        lp.bottomMargin = dp(4);
        tv.setLayoutParams(lp);
        return tv;
    }

    private void scrollToBottom() {
        // NOTE: do NOT use fullScroll(FOCUS_DOWN) here - it moves keyboard focus to the last
        // (selectable) bubble, so the EditText loses focus and typing stops showing until tapped.
        scroll.post(() -> scroll.scrollTo(0, Math.max(0, chat.getBottom() - scroll.getHeight()
                + scroll.getPaddingBottom())));
    }

    private TextView label(String text, float size, int color, boolean bold) {
        TextView v = new TextView(this);
        v.setText(text);
        v.setTextSize(size);
        v.setTextColor(color);
        v.setTypeface(null, bold ? Typeface.BOLD : Typeface.NORMAL);
        return v;
    }

    private int dp(float value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    @Override protected void onDestroy() {
        typingHandler.removeCallbacksAndMessages(null);
        stopThinkingShimmer();
        super.onDestroy();
    }
}
