package com.arenax.tournament;

import android.content.Context;

import androidx.annotation.NonNull;

import com.bumptech.glide.Glide;
import com.bumptech.glide.GlideBuilder;
import com.bumptech.glide.Registry;
import com.bumptech.glide.annotation.GlideModule;
import com.bumptech.glide.integration.okhttp3.OkHttpUrlLoader;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.load.engine.cache.InternalCacheDiskCacheFactory;
import com.bumptech.glide.load.engine.cache.LruResourceCache;
import com.bumptech.glide.load.engine.cache.MemorySizeCalculator;
import com.bumptech.glide.load.model.GlideUrl;
import com.bumptech.glide.module.AppGlideModule;
import com.bumptech.glide.request.RequestOptions;

import java.io.InputStream;
import java.util.concurrent.TimeUnit;

import okhttp3.Cache;
import okhttp3.ConnectionPool;
import okhttp3.Dispatcher;
import okhttp3.Interceptor;
import okhttp3.OkHttpClient;
import okhttp3.Response;

/**
 * Wires every Glide.with(...).load(...) call in the app (banners, tournament
 * cards, avatars, chat images, everywhere) to OkHttp with generous timeouts,
 * a bigger memory + disk cache, connection reuse, and a cache-control
 * interceptor — so images show fast on first load and are instant after.
 *
 * Why this was needed: with no AppGlideModule, Glide falls back to plain
 * HttpURLConnection, whose default connect/read timeout is only ~2.5s. On an
 * average mobile connection a banner/tournament image often didn't finish
 * downloading in that window, so Glide silently gave up and fell back to
 * .error(R.drawable.ic_arenax) — which is exactly the "default logo shows
 * everywhere and nothing loads" symptom.
 *
 * Upgrades over the plain OkHttp wiring:
 *  - A dedicated 25MB OkHttp response cache PLUS a forced Cache-Control
 *    header on every image response, so images from APIs that don't send
 *    their own cache headers (common with plain REST/CDN image URLs) still
 *    get reused instead of re-downloaded on every screen visit.
 *  - A larger in-memory bitmap cache (1.2x Glide's default calculation) so
 *    images already seen this session reappear instantly while scrolling —
 *    no disk read at all.
 *  - A shared OkHttp ConnectionPool so back-to-back image requests (a list
 *    of tournament cards, for example) reuse open connections instead of
 *    renegotiating TLS for every single image.
 */
@GlideModule
public final class AppGlideConfig extends AppGlideModule {

    @Override public void applyOptions(@NonNull Context context, @NonNull GlideBuilder builder) {
        // 250MB disk cache (default is 250MB too, but set explicitly so it's easy to tune later).
        builder.setDiskCache(new InternalCacheDiskCacheFactory(context, 250L * 1024 * 1024));
        // Bigger in-memory bitmap cache than Glide's default sizing, so images already
        // decoded this session reappear instantly (no disk/network hit) while scrolling.
        MemorySizeCalculator calculator = new MemorySizeCalculator.Builder(context)
                .setMemoryCacheScreens(2.4f)
                .build();
        builder.setMemoryCache(new LruResourceCache(calculator.getMemoryCacheSize()));
        // Cache both the original download and the resized bitmap, so a banner/avatar
        // seen once loads instantly next time, even if the URL is only reachable
        // over a slow connection the first time.
        // NONE: images are stored ONLY in the encrypted zip (SecureAssetLoader), never as plain files in Glide's cache.
        builder.setDefaultRequestOptions(new RequestOptions().diskCacheStrategy(DiskCacheStrategy.NONE));
    }

    @Override public void registerComponents(@NonNull Context context, @NonNull Glide glide, @NonNull Registry registry) {
        // OkHttp's default is only 5 parallel requests PER HOST — a grid of banners/cards from one
        // CDN/Firebase host was queueing behind 5 downloads at a time. Allow many more in parallel.
        Dispatcher dispatcher = new Dispatcher();
        dispatcher.setMaxRequests(64);
        dispatcher.setMaxRequestsPerHost(16);
        OkHttpClient client = new OkHttpClient.Builder()
                .dispatcher(dispatcher)
                .connectTimeout(15, TimeUnit.SECONDS)
                .readTimeout(20, TimeUnit.SECONDS)
                .writeTimeout(20, TimeUnit.SECONDS)
                .retryOnConnectionFailure(true)
                .connectionPool(new ConnectionPool(8, 30, TimeUnit.SECONDS))
                .build();
        registry.replace(GlideUrl.class, InputStream.class,
                new com.arenax.tournament.util.SecureAssetLoader.Factory(context, new OkHttpUrlLoader.Factory(client)));
    }

    @Override public boolean isManifestParsingEnabled() {
        return false;
    }
}
