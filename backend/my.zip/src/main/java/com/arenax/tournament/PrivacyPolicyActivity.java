package com.arenax.tournament;

import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.style.StyleSpan;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import com.arenax.tournament.data.FirebaseRepository;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.ValueEventListener;
import androidx.core.widget.NestedScrollView;

/** Privacy Policy — in-app, read-only rulebook. Light, airy theme: soft
 *  lavender backdrop, a bold centred header with a short gradient underline,
 *  and one rounded white card per policy — each with a pastel icon badge,
 *  a numbered/chevron corner, a colour-coded underline and a decorative
 *  colour "leaf" tucked into the bottom-right corner. Fully self-contained,
 *  built the same programmatic way as TermsActivity/FaqActivity (no extra
 *  layout/drawable resources). */
public class PrivacyPolicyActivity extends BaseActivity {

    private static final String BRAND = "STARX24";
    private static final int PAGE_BG = Color.parseColor("#F2F4FC");

    /** One policy card: heading, emoji icon, colour theme and either a plain
     *  body or a bulleted list. */
    private static final class Section {
        final String title;
        final String emoji;
        final int iconBg;
        final int accent;
        final String[] bullets;
        final boolean allCapsWarning;
        Section(String title, String emoji, int iconBg, int accent, boolean allCapsWarning, String... bullets) {
            this.title = title; this.emoji = emoji; this.iconBg = iconBg; this.accent = accent;
            this.allCapsWarning = allCapsWarning; this.bullets = bullets;
        }
    }

    private static final Section[] sections = new Section[]{

            new Section("Match Cancellation Policy", "\uD83D\uDEE1\uFE0F",
                    Color.parseColor("#E4ECFB"), Color.parseColor("#2F6FED"), false,
                    BRAND + " reserves the right to cancel any match at any time without any reason."),
            new Section("Age Requirement", "\uD83D\uDD1E",
                    Color.parseColor("#E1F5EC"), Color.parseColor("#1E7F5C"), false,
                    "By participating in " + BRAND + " Matches, you accept and agree that you are above 18 years in age."),
            new Section("Suspicious Activity", "\uD83D\uDEA8",
                    Color.parseColor("#FBE4E4"), Color.parseColor("#C0392B"), false,
                    "In case the investigators or spectators find any suspicious player in the gameplay, " + BRAND +
                            " reserves the right to disqualify, suspend or put the doer's account on hold and also cancel " +
                            "their Prize prizes or amount."),
            new Section("Multiple Account Policy", "\uD83E\uDEAA",
                    Color.parseColor("#ECE7FB"), Color.parseColor("#5B3FC4"), true,
                    "IF WE FOUND USING MULTIPLE ID THEN YOU WILL BE BANNED FROM OUR APP"),
            new Section("Technical Issues", "\uD83D\uDEE0\uFE0F",
                    Color.parseColor("#FDF3D9"), Color.parseColor("#8D6B12"), false,
                    "In case of any technical glitch, the match may get cancelled and in such cases the entry fees will " +
                            "be refunded to the participants or re-match may take place.",
                    "In case any player fails to submit correct details while participating in any match then the " +
                            "reward/prize amount will be cancelled for that player and no refund will be processed."),
            new Section("Prohibited Activities", "\uD83D\uDEAB",
                    Color.parseColor("#E9E6FA"), Color.parseColor("#4A3AA8"), false,
                    "Players are not allowed to use any Mod or Hack in the Gameplay. If anyone is found suspicious, " +
                            "immediate action will be taken, the account will be suspended, all the pending withdrawals " +
                            "will be cancelled and wallet balance will become useless.",
                    "Mis-using any in-game glitches or errors will result in disqualification of that player from the " +
                            "match and no reward for the same match will be considered."),
            new Section("Emulator Usage", "\uD83D\uDDA5\uFE0F",
                    Color.parseColor("#E1F3F6"), Color.parseColor("#1F8FA6"), false,
                    "Do not use any Emulator to Play in non-emulator matches. Such players will be kicked and if " +
                            "remains un-kicked then they may not get the match rewards/prizes."),
            new Section("Match Participation Guidelines", "\uD83D\uDCCB",
                    Color.parseColor("#FBE9DE"), Color.parseColor("#B0552E"), false,
                    "\u2022 Participants need to make sure to grab Match Details such as Room ID and Password before the " +
                            "match start time. The Room Id and Password are shared in the app and also through SMS. Grab " +
                            "them and join the room quickly. In case the participants fail to join the room before the " +
                            "match start time, they won't be able to join the match later on and no refund will be " +
                            "processed for the same.",
                    "\u2022 In case participants fail to join the room due to any external issues from participants end " +
                            "(incl. Slow internet, multi-tasking, minimizing game, Receiving Calls or SMS, etc.) then no " +
                            "refund will be processed.",
                    "\u2022 If the participants are kicked or auto-kicked from the room without any reasons then the " +
                            "refund will be issued upon submitting proper valid evidences such as a Screenshot of the " +
                            "Error Screen or Message.",
                    "\u2022 Any of the policies mentioned here can change, get updates or removed at any time, so keep " +
                            "checking here for the latest policies and rules."),
            new Section("Fair Play Policy", "\uD83E\uDD1D",
                    Color.parseColor("#FDF3D9"), Color.parseColor("#8D6B12"), false,
                    "Before participating in any match at " + BRAND + ", you agree to the Fair Play Policy and accept it."),
    };

    /** Section list currently on screen (defaults, or the admin's own) — used for card numbering. */
    private Section[] shown = sections;

    /** Built-in text as {title, body} pairs (paragraphs joined by a blank line) for the admin editor. */
    public static String[][] defaultContent() {
        String[][] out = new String[sections.length][2];
        for (int i = 0; i < sections.length; i++) {
            out[i][0] = sections[i].title;
            out[i][1] = android.text.TextUtils.join("\n\n", sections[i].bullets);
        }
        return out;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildScreen();
    }

    private void buildScreen() {
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(PAGE_BG);

        // Soft decorative blobs peeking off the top-right and bottom-left of the page.
        root.addView(pageBlob(220, Color.parseColor("#DCE6FB"), Gravity.TOP | Gravity.END, -60, -70));
        root.addView(pageBlob(160, Color.parseColor("#E7E1FB"), Gravity.BOTTOM | Gravity.START, -50, -50));

        NestedScrollView scroll = new NestedScrollView(this);
        scroll.setFillViewport(true);
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(18), dp(14), dp(18), dp(28));

        page.addView(buildHeader());
        LinearLayout cards = new LinearLayout(this);
        cards.setOrientation(LinearLayout.VERTICAL);
        for (Section section : sections) cards.addView(buildCard(section));
        page.addView(cards);
        page.addView(buildFooter());
        loadAdminSections(cards);

        scroll.addView(page);
        root.addView(scroll);
        setContentView(root);
    }

    private View pageBlob(int sizeDp, int color, int gravity, int marginEndDp, int marginBottomDp) {
        View blob = new View(this);
        GradientDrawable bg = new GradientDrawable();
        bg.setShape(GradientDrawable.OVAL);
        bg.setColor(color);
        blob.setBackground(bg);
        blob.setAlpha(0.55f);
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(dp(sizeDp), dp(sizeDp));
        lp.gravity = gravity;
        lp.rightMargin = dp(marginEndDp);
        lp.topMargin = dp(marginEndDp);
        lp.leftMargin = dp(marginEndDp);
        lp.bottomMargin = dp(marginBottomDp);
        blob.setLayoutParams(lp);
        return blob;
    }

    private View buildHeader() {
        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.VERTICAL);
        header.setGravity(Gravity.CENTER_HORIZONTAL);
        header.setPadding(0, dp(6), 0, dp(22));

        LinearLayout topRow = new LinearLayout(this);
        topRow.setGravity(Gravity.CENTER_VERTICAL);
        topRow.setLayoutParams(new LinearLayout.LayoutParams(-1, -2));

        TextView back = label("\u2039", 24, Color.parseColor("#1C1C1E"), true);
        back.setGravity(Gravity.CENTER);
        GradientDrawable backBg = new GradientDrawable();
        backBg.setShape(GradientDrawable.OVAL);
        backBg.setColor(Color.WHITE);
        back.setBackground(backBg);
        back.setOnClickListener(v -> finish());
        LinearLayout.LayoutParams backParams = new LinearLayout.LayoutParams(dp(40), dp(40));
        back.setLayoutParams(backParams);
        topRow.addView(back);
        header.addView(topRow);

        TextView title = label("Privacy Policy", 26, Color.parseColor("#14141A"), true);
        title.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams titleParams = new LinearLayout.LayoutParams(-1, -2);
        titleParams.topMargin = dp(10);
        title.setLayoutParams(titleParams);
        header.addView(title);

        TextView subtitle = label("Your privacy matters to us", 13.5f, Color.parseColor("#7A7E8C"), false);
        subtitle.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams subParams = new LinearLayout.LayoutParams(-1, -2);
        subParams.topMargin = dp(4);
        subtitle.setLayoutParams(subParams);
        header.addView(subtitle);

        View underline = new View(this);
        GradientDrawable underlineBg = new GradientDrawable();
        underlineBg.setOrientation(GradientDrawable.Orientation.LEFT_RIGHT);
        underlineBg.setColors(new int[]{Color.parseColor("#2F6FED"), Color.parseColor("#7C5CE8")});
        underlineBg.setCornerRadius(dp(3));
        underline.setBackground(underlineBg);
        LinearLayout.LayoutParams ulParams = new LinearLayout.LayoutParams(dp(64), dp(5));
        ulParams.topMargin = dp(14);
        underline.setLayoutParams(ulParams);
        header.addView(underline);

        return header;
    }

    /** If the admin saved their own policy text (appContent/privacy/sections), show that instead. */
    private void loadAdminSections(LinearLayout cards) {
        try {
            FirebaseRepository.appContent().child("privacy").child("sections")
                    .addListenerForSingleValueEvent(new ValueEventListener() {
                @Override public void onDataChange(@NonNull DataSnapshot snapshot) {
                    if (isFinishing() || isDestroyed()) return;
                    java.util.List<Section> custom = new java.util.ArrayList<>();
                    for (DataSnapshot c : snapshot.getChildren()) {
                        String title = c.child("title").getValue(String.class);
                        String body = c.child("body").getValue(String.class);
                        if (title == null) title = "";
                        if (body == null) body = "";
                        if (title.trim().isEmpty() && body.trim().isEmpty()) continue;
                        java.util.List<String> paras = new java.util.ArrayList<>();
                        for (String para : body.split("\\n\\s*\\n")) if (!para.trim().isEmpty()) paras.add(para.trim());
                        if (paras.isEmpty()) paras.add("");
                        Section base = sections[custom.size() % sections.length];
                        custom.add(new Section(title, base.emoji, base.iconBg, base.accent, false,
                                paras.toArray(new String[0])));
                    }
                    if (custom.isEmpty()) return;
                    shown = custom.toArray(new Section[0]);
                    cards.removeAllViews();
                    for (Section sec : shown) cards.addView(buildCard(sec));
                }
                @Override public void onCancelled(@NonNull DatabaseError error) { /* keep defaults */ }
            });
        } catch (RuntimeException ignored) { /* keep defaults */ }
    }

    private View buildCard(Section section) {
        FrameLayout cardFrame = new FrameLayout(this);
        GradientDrawable cardBg = new GradientDrawable();
        cardBg.setColor(Color.WHITE);
        cardBg.setCornerRadius(dp(20));
        cardFrame.setBackground(cardBg);
        cardFrame.setClipToOutline(true);
        FrameLayout.LayoutParams cardParams0 = new FrameLayout.LayoutParams(-1, -2);
        LinearLayout.LayoutParams outerParams = new LinearLayout.LayoutParams(-1, -2);
        outerParams.bottomMargin = dp(16);
        cardFrame.setLayoutParams(outerParams);

        // Decorative colour "leaf" tucked into the bottom-right corner.
        View leaf = new View(this);
        GradientDrawable leafBg = new GradientDrawable();
        leafBg.setShape(GradientDrawable.OVAL);
        leafBg.setColor(section.iconBg);
        leaf.setBackground(leafBg);
        leaf.setAlpha(0.7f);
        FrameLayout.LayoutParams leafParams = new FrameLayout.LayoutParams(dp(64), dp(64));
        leafParams.gravity = Gravity.BOTTOM | Gravity.END;
        leafParams.rightMargin = dp(-20);
        leafParams.bottomMargin = dp(-20);
        leaf.setLayoutParams(leafParams);
        cardFrame.addView(leaf);

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(16), dp(16), dp(14), dp(18));
        cardFrame.addView(content, cardParams0);

        // Top row: icon badge, title + underline, number + chevron.
        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);

        FrameLayout iconBadge = new FrameLayout(this);
        GradientDrawable iconBadgeBg = new GradientDrawable();
        iconBadgeBg.setShape(GradientDrawable.OVAL);
        iconBadgeBg.setColor(section.iconBg);
        iconBadge.setBackground(iconBadgeBg);
        TextView iconText = label(section.emoji, 20, Color.BLACK, false);
        iconText.setGravity(Gravity.CENTER);
        iconBadge.addView(iconText, new FrameLayout.LayoutParams(-1, -1));
        LinearLayout.LayoutParams iconBadgeParams = new LinearLayout.LayoutParams(dp(48), dp(48));
        iconBadge.setLayoutParams(iconBadgeParams);
        top.addView(iconBadge);

        LinearLayout titleBlock = new LinearLayout(this);
        titleBlock.setOrientation(LinearLayout.VERTICAL);
        TextView title = label(section.title, 16.5f, Color.parseColor("#14141A"), true);
        titleBlock.addView(title);
        View titleUnderline = new View(this);
        GradientDrawable tuBg = new GradientDrawable();
        tuBg.setColor(section.accent);
        tuBg.setCornerRadius(dp(2));
        titleUnderline.setBackground(tuBg);
        LinearLayout.LayoutParams tuParams = new LinearLayout.LayoutParams(dp(34), dp(3));
        tuParams.topMargin = dp(6);
        titleUnderline.setLayoutParams(tuParams);
        titleBlock.addView(titleUnderline);
        LinearLayout.LayoutParams titleBlockParams = new LinearLayout.LayoutParams(0, -2, 1);
        titleBlockParams.leftMargin = dp(12);
        titleBlockParams.rightMargin = dp(6);
        titleBlock.setLayoutParams(titleBlockParams);
        top.addView(titleBlock);

        LinearLayout numberRow = new LinearLayout(this);
        numberRow.setGravity(Gravity.CENTER_VERTICAL);
        TextView number = label(String.format("%02d", indexOf(section) + 1), 12, section.accent, true);
        number.setGravity(Gravity.CENTER);
        GradientDrawable numberBg = new GradientDrawable();
        numberBg.setShape(GradientDrawable.OVAL);
        numberBg.setColor(section.iconBg);
        number.setBackground(numberBg);
        numberRow.addView(number, new LinearLayout.LayoutParams(dp(26), dp(26)));
        TextView chevron = label("\u203A", 18, Color.parseColor("#B9BCC6"), true);
        LinearLayout.LayoutParams chevronParams = new LinearLayout.LayoutParams(-2, -2);
        chevronParams.leftMargin = dp(2);
        chevron.setLayoutParams(chevronParams);
        numberRow.addView(chevron);
        top.addView(numberRow);

        content.addView(top);

        if (section.allCapsWarning) {
            LinearLayout warnBox = new LinearLayout(this);
            warnBox.setOrientation(LinearLayout.HORIZONTAL);
            warnBox.setGravity(Gravity.CENTER_VERTICAL);
            GradientDrawable warnBg = new GradientDrawable();
            warnBg.setColor(section.iconBg);
            warnBg.setCornerRadius(dp(12));
            warnBox.setBackground(warnBg);
            warnBox.setPadding(dp(12), dp(12), dp(12), dp(12));
            LinearLayout.LayoutParams warnParams = new LinearLayout.LayoutParams(-1, -2);
            warnParams.topMargin = dp(14);
            warnBox.setLayoutParams(warnParams);

            TextView warnIcon = label("\u26A0\uFE0F", 18, Color.BLACK, false);
            warnBox.addView(warnIcon);

            TextView warnText = label(section.bullets[0], 12.5f, section.accent, true);
            LinearLayout.LayoutParams warnTextParams = new LinearLayout.LayoutParams(0, -2, 1);
            warnTextParams.leftMargin = dp(10);
            warnText.setLayoutParams(warnTextParams);
            warnBox.addView(warnText);

            content.addView(warnBox);
        } else {
            for (int i = 0; i < section.bullets.length; i++) {
                TextView body = label(boldBrand(section.bullets[i]), 13.5f, Color.parseColor("#4A4E58"), false);
                body.setLineSpacing(dp(3), 1f);
                LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
                p.topMargin = dp(i == 0 ? 14 : 12);
                body.setLayoutParams(p);
                content.addView(body);
            }
        }

        return cardFrame;
    }

    private View buildFooter() {
        TextView footer = label("\u2014  G A M E X  \u2014", 12, Color.parseColor("#AEB1BC"), false);
        footer.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, -2);
        params.topMargin = dp(8);
        footer.setLayoutParams(params);
        return footer;
    }

    private int indexOf(Section section) {
        for (int i = 0; i < shown.length; i++) if (shown[i] == section) return i;
        return 0;
    }

    /** Bold every mention of the brand name inline within a paragraph. */
    private CharSequence boldBrand(String text) {
        SpannableStringBuilder builder = new SpannableStringBuilder(text);
        int index = text.indexOf(BRAND);
        while (index >= 0) {
            builder.setSpan(new StyleSpan(Typeface.BOLD), index, index + BRAND.length(),
                    Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            index = text.indexOf(BRAND, index + BRAND.length());
        }
        return builder;
    }

    private TextView label(CharSequence text, float size, int color, boolean bold) {
        TextView v = new TextView(this);
        v.setText(text);
        v.setTextSize(size);
        v.setTextColor(color);
        v.setTypeface(null, bold ? Typeface.BOLD : Typeface.NORMAL);
        return v;
    }

    private int dp(float value) { return Math.round(value * getResources().getDisplayMetrics().density); }
}
