package com.arenax.tournament;


import com.arenax.tournament.util.FancyText;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import com.arenax.tournament.data.FirebaseRepository;
import com.arenax.tournament.data.ImgBbUploader;
import com.arenax.tournament.data.StorageUploader;
import com.bumptech.glide.Glide;
import com.google.android.material.button.MaterialButton;

import java.util.HashMap;
import java.util.Map;

public class BannerEditorActivity extends BaseActivity {
    private EditText title, subtitle, url;
    private ImageView preview;
    private Uri selected;
    private MaterialButton save;
    private final ActivityResultLauncher<String> picker = registerForActivityResult(new ActivityResultContracts.GetContent(), uri -> {
        if (uri != null) { selected = uri; preview.setImageURI(uri); }
    });
    private int dp(int n) { return Math.round(n * getResources().getDisplayMetrics().density); }
    private TextView text(String value, float size, boolean bold) { TextView t = new TextView(this); t.setText(value); t.setTextSize(size); t.setTextColor(Color.rgb(18,31,55)); t.setTypeface(null, bold ? Typeface.BOLD : Typeface.NORMAL); return t; }
    private TextView sectionTitle(String value) { TextView t = text(value, 16, true); t.setTag("nofancy"); t.setText(FancyText.heading(value)); return t; }
    private EditText field(String hint) { EditText e = new EditText(this); e.setHint(hint); e.setTextSize(14); e.setSingleLine(true); e.setTextColor(Color.rgb(20,30,50)); e.setHintTextColor(Color.rgb(120,130,145)); e.setPadding(dp(14), 0, dp(14), 0); e.setBackgroundResource(R.drawable.bg_input_dark_outline); return e; }
    @Override protected void onCreate(Bundle state) { super.onCreate(state); build(); }
    private void build() {
        getWindow().setStatusBarColor(Color.WHITE); getWindow().setNavigationBarColor(Color.WHITE);
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(Color.WHITE);
        LinearLayout head = new LinearLayout(this); head.setGravity(Gravity.CENTER_VERTICAL); head.setPadding(dp(16), dp(12), dp(16), dp(10));
        TextView back = text("‹", 30, true); back.setGravity(Gravity.CENTER); back.setBackgroundResource(R.drawable.bg_category_back); back.setOnClickListener(v -> finish()); head.addView(back, new LinearLayout.LayoutParams(dp(42), dp(42)));
        LinearLayout ht = new LinearLayout(this); ht.setOrientation(LinearLayout.VERTICAL); ht.setPadding(dp(10), 0, 0, 0); TextView bannerTitle = text("Add Banner", 21, true); bannerTitle.setTag("nofancy"); bannerTitle.setText(FancyText.heading("Add Banner")); bannerTitle.setLetterSpacing(0.01f); ht.addView(bannerTitle); head.addView(ht, new LinearLayout.LayoutParams(0, -2, 1)); root.addView(head);
        View line = new View(this); line.setBackgroundColor(0xFFE6EAF0); root.addView(line, new LinearLayout.LayoutParams(-1, dp(1)));
        ScrollView scroll = new ScrollView(this); LinearLayout body = new LinearLayout(this); body.setOrientation(LinearLayout.VERTICAL); body.setPadding(dp(18), dp(16), dp(18), dp(22));
        body.addView(sectionTitle("Banner details"));
        title = field("Enter banner title"); add(body, title, 48, 8);
        subtitle = field("Enter short subtitle (optional)"); add(body, subtitle, 48, 8);
        body.addView(sectionTitle("Banner image"), lp(0, 16));
        LinearLayout upload = new LinearLayout(this); upload.setGravity(Gravity.CENTER_VERTICAL); upload.setPadding(dp(12), dp(12), dp(12), dp(12)); upload.setBackgroundResource(R.drawable.bg_input_dark_outline);
        preview = new ImageView(this); preview.setScaleType(ImageView.ScaleType.CENTER_CROP); preview.setImageResource(R.drawable.ic_arenax); upload.addView(preview, new LinearLayout.LayoutParams(dp(116), dp(68)));
        MaterialButton choose = button("Upload image", 0xFFE8F1FF, 0xFF2167C9); choose.setOnClickListener(v -> picker.launch("image/*")); LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(0, dp(44), 1); cp.leftMargin = dp(12); upload.addView(choose, cp); body.addView(upload, lp(0, 6));
        TextView hint = text("Recommended: landscape image, 1200 × 500 px", 10.5f, false); hint.setTextColor(0xFF778399); body.addView(hint, lp(0, 6));
        url = field("Or paste public image URL (optional)"); add(body, url, 48, 14);
        TextView previewTitle = sectionTitle("Live preview"); body.addView(previewTitle, lp(0, 12));
        save = button("+  Publish Banner", 0xFFE8F8F1, 0xFF14885A); save.setOnClickListener(v -> publish()); body.addView(save, lp(0, 52));
        scroll.addView(body); root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1)); setContentView(root);
    }
    private void add(LinearLayout p, View v, int h, int top) { p.addView(v, lp(h, top)); }
    private LinearLayout.LayoutParams lp(int h, int top) { LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, h == 0 ? -2 : dp(h)); p.topMargin = dp(top); return p; }
    private MaterialButton button(String s, int bg, int fg) { MaterialButton b = new MaterialButton(this); b.setText(s); b.setTextSize(12); b.setAllCaps(false); b.setTypeface(null, Typeface.BOLD); b.setTextColor(fg); b.setInsetTop(0); b.setInsetBottom(0); b.setMinWidth(0); b.setMinHeight(0); b.setCornerRadius(dp(7)); b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(bg)); b.setStrokeColor(android.content.res.ColorStateList.valueOf(0xFF374151)); b.setStrokeWidth(dp(1)); return b; }
    private void publish() {
        String t = title.getText().toString().trim(), st = subtitle.getText().toString().trim(), imageUrl = url.getText().toString().trim();
        if (t.isEmpty()) { title.setError("Enter banner title"); return; }
        String id = FirebaseRepository.banners().push().getKey(); if (id == null) { toast("Could not create banner key"); return; }
        save.setEnabled(false);
        if (selected != null) ImgBbUploader.uploadImage(this, selected, new StorageUploader.Callback() { public void onSuccess(String u) { saveBanner(id,t,st,u); } public void onFailure(String m) { save.setEnabled(true); toast("Upload failed: " + m); } });
        else saveBanner(id,t,st,imageUrl);
    }
    private void saveBanner(String id, String t, String st, String imageUrl) { Map<String,Object> b = new HashMap<>(); b.put("title",t); b.put("subtitle",st); b.put("imageUrl",imageUrl); b.put("displayOrder",System.currentTimeMillis()); b.put("createdAt",System.currentTimeMillis()); b.put("active",true); FirebaseRepository.saveBanner(id,b).addOnSuccessListener(v -> { toast("Banner published live"); setResult(RESULT_OK); finish(); }).addOnFailureListener(e -> { save.setEnabled(true); toast("Publish failed: " + e.getMessage()); }); }
    private void toast(String s) { FancyText.toast(this,s,Toast.LENGTH_LONG).show(); }
}
