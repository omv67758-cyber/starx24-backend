package com.arenax.tournament;


import com.arenax.tournament.util.FancyText;
import com.arenax.tournament.util.FullScreenDialog;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.arenax.tournament.data.FirebaseRepository;
import com.arenax.tournament.model.Match;
import com.arenax.tournament.util.RoomReleaseScheduler;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.card.MaterialCardView;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Small, intentionally role-scoped admin surface for the restructured roles.
 * Each role renders only its allowed workflow; the database rules remain the
 * source of truth for enforcement.
 */
public class RoleAdminActivity extends BaseActivity {
    private String role;
    private LinearLayout content;
    private TextView subtitle;
    private ValueEventListener activeListener;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        role = AdminRoles.normalize(getIntent().getStringExtra("adminRole"));
        buildShell();
        renderHome();
    }

    private void buildShell() {
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setBackgroundColor(0xFF0A0405);
        // Android 15+ (targetSdk 35) edge-to-edge: keep "STARX24 Admin" / role label clear
        // of the status bar's clock, battery and notification icons.
        androidx.core.view.ViewCompat.setOnApplyWindowInsetsListener(page, (view, insets) -> {
            androidx.core.graphics.Insets bars = insets.getInsets(
                    androidx.core.view.WindowInsetsCompat.Type.systemBars());
            view.setPadding(bars.left, bars.top, bars.right, bars.bottom);
            return insets;
        });

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.VERTICAL);
        header.setPadding(dp(20), dp(22), dp(20), dp(16));
        header.setBackgroundColor(0xFF1D090D);
        TextView title = text("STARX24 Admin", 26, 0xFFFFFFFF, true);
        subtitle = text(AdminRoles.label(role), 14, 0xFFFF4757, true);
        header.addView(title);
        subtitle.setVisibility(android.view.View.GONE);
        header.addView(subtitle, marginParams(-1, -2, 4, 0, 0, 0));
        page.addView(header);

        ScrollView scroll = new ScrollView(this);
        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(16), dp(14), dp(16), dp(30));
        scroll.addView(content);
        page.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(page);
    }

    private void renderHome() {
        content.removeAllViews();
        addTitle("Dashboard");
        addText("Admin login opens directly on this dashboard. Use the device back action to leave this screen.");
        loadDashboardSummary();
    }

    /** Landing screen intentionally contains no role/workspace button menu. */
    private void loadDashboardSummary() {
        FirebaseRepository.users().addListenerForSingleValueEvent(collectionListener(snapshot ->
                addCard("Users", details(String.valueOf(snapshot.getChildrenCount()), "Registered accounts"))));
        FirebaseRepository.tournaments().addListenerForSingleValueEvent(collectionListener(snapshot ->
                addCard("Matches", details(String.valueOf(snapshot.getChildrenCount()), "Configured tournaments"))));
        FirebaseRepository.withdrawals().addListenerForSingleValueEvent(collectionListener(snapshot ->
                addCard("Withdrawals", details(String.valueOf(snapshot.getChildrenCount()), "Requests awaiting admin review"))));
    }

    private void showMatchOperations() {
        clearSection("Match Operations", "Manage the 48 fixed slots, match metadata, and room release schedule.");
        addAction("New match", v -> showMatchForm(null, null));
        FirebaseRepository.tournaments().addListenerForSingleValueEvent(collectionListener(snapshot -> {
            for (DataSnapshot child : snapshot.getChildren()) {
                String id = child.getKey();
                if (id == null) continue;
                addCard(child.child("title").getValue(String.class), details(
                        value(child, "status", "UPCOMING") + "  •  "
                                + number(child, "joinedSlots", 0) + "/" + number(child, "totalSlots", 48) + " slots",
                        "Per kill: " + number(child, "perKillCoins", 1) + " coins"));
                LinearLayout actions = row();
                addSmallAction(actions, "Edit", v -> showMatchForm(id, snapshotMap(child)));
                addSmallAction(actions, "Room release", v -> showRoomReleaseForm(id, child));
                addSmallAction(actions, "Delete", v -> confirmDelete("Delete this match?", () ->
                        FirebaseRepository.deleteTournament(id).addOnSuccessListener(done ->
                                FancyText.toast(this, "Match deleted.", Toast.LENGTH_SHORT).show())
                                .addOnFailureListener(this::showError)));
                content.addView(actions, marginParams(-1, -2, 8, 0, 0, 0));
            }
            if (snapshot.getChildrenCount() == 0) addText("No matches yet. Create the first 48-slot match.");
        }));
    }

    private void showMatchForm(String id, Map<String, Object> existing) {
        LinearLayout form = form();
        EditText title = field("Match title", string(existing, "title"));
        EditText mode = field("Category or mode", string(existing, "mode"));
        EditText date = field("Date, e.g. 12 Sep 2026", string(existing, "date"));
        date.setFocusable(false);
        date.setClickable(true);
        Spinner time = new Spinner(this);
        Calendar selectedDay = Calendar.getInstance();
        String existingDate = string(existing, "date");
        if (!existingDate.isEmpty()) {
            try {
                Date parsed = new SimpleDateFormat("dd MMM yyyy", Locale.ENGLISH).parse(existingDate);
                if (parsed != null) selectedDay.setTime(parsed);
            } catch (Exception ignored) {
                // Keep today's date if the stored value doesn't parse.
            }
        }
        date.setText(new SimpleDateFormat("dd MMM yyyy", Locale.ENGLISH).format(selectedDay.getTime()));
        refreshMatchTimeSlots(time, selectedDay, date);
        date.setOnClickListener(v -> {
            Calendar picker = (Calendar) selectedDay.clone();
            new DatePickerDialog(this, (view, year, month, day) -> {
                selectedDay.set(Calendar.YEAR, year);
                selectedDay.set(Calendar.MONTH, month);
                selectedDay.set(Calendar.DAY_OF_MONTH, day);
                date.setText(new SimpleDateFormat("dd MMM yyyy", Locale.ENGLISH).format(selectedDay.getTime()));
                refreshMatchTimeSlots(time, selectedDay, date);
            }, picker.get(Calendar.YEAR), picker.get(Calendar.MONTH), picker.get(Calendar.DAY_OF_MONTH)).show();
        });
        Spinner entry = coinAmountSpinner((int) number(existing, "entryFeeCoins", 0));
        EditText prize = numberField("Prize pool coins", number(existing, "prizePoolCoins", 0));
        Spinner perKill = coinAmountSpinner((int) number(existing, "perKillCoins", 1));
        Spinner matchType = matchTypeSpinner(string(existing, "matchType"));
        EditText description = field("Description", string(existing, "description"));
        form.addView(title);
        form.addView(mode);
        form.addView(date);
        form.addView(time);
        form.addView(fieldLabel("MATCH TYPE"));
        form.addView(matchType);
        form.addView(fieldLabel("ENTRY FEE (COINS)"));
        form.addView(entry);
        form.addView(prize);
        form.addView(fieldLabel("REWARD PER KILL (COINS)"));
        form.addView(perKill);
        form.addView(description);

        FullScreenDialog dialog = new FullScreenDialog.Builder(this)
                .setTitle(id == null ? "New match" : "Edit match")
                .setMessage("Every match uses exactly 48 player slots.")
                .setView(form)
                .setNegativeButton("CANCEL", null)
                .setPositiveButton("SAVE MATCH", null)
                .create();
        dialog.setOnShowListener(ignored -> dialog.getButton(android.content.DialogInterface.BUTTON_POSITIVE).setOnClickListener(v -> {
            if (value(title).isEmpty() || value(mode).isEmpty()) {
                title.setError("Required");
                mode.setError("Required");
                return;
            }
            String matchId = id == null ? FirebaseRepository.tournaments().push().getKey() : id;
            if (matchId == null) {
                showError(new IllegalStateException("Could not create match"));
                return;
            }
            Map<String, Object> values = existing == null ? new HashMap<>() : new HashMap<>(existing);
            values.put("title", value(title));
            values.put("mode", value(mode));
            values.put("categoryId", value(mode));
            values.put("date", value(date));
            values.put("time", time.getSelectedItem() == null ? "TBA" : (String) time.getSelectedItem());
            values.put("description", value(description));
            values.put("entryFeeCoins", Integer.parseInt((String) entry.getSelectedItem()));
            values.put("prizePoolCoins", integer(prize, 0));
            values.put("perKillCoins", Integer.parseInt((String) perKill.getSelectedItem()));
            values.put("matchType", (String) matchType.getSelectedItem());
            values.put("totalSlots", 48);
            values.put("joinedSlots", number(existing, "joinedSlots", 0));
            values.put("status", string(existing, "status").isEmpty() ? "UPCOMING" : string(existing, "status"));
            values.put("registrationStatus", "OPEN");
            values.put("active", true);
            Map<String, Object> matchMeta = new HashMap<>();
            matchMeta.put("title", value(title));
            matchMeta.put("status", values.get("status"));
            matchMeta.put("maxSlots", 48);
            matchMeta.put("coinsPerKill", values.get("perKillCoins"));
            Map<String, Object> updates = new HashMap<>();
            updates.put("tournaments/" + matchId, values);
            updates.put("matches/" + matchId, matchMeta);
            FirebaseRepository.tournaments().getRoot().updateChildren(updates)
                    .addOnSuccessListener(done -> {
                        dialog.dismiss();
                        showMatchOperations();
                    }).addOnFailureListener(this::showError);
        }));
        dialog.show();
    }

    private void showRoomReleaseForm(String matchId, DataSnapshot match) {
        LinearLayout form = form();
        EditText roomId = field("Room ID", value(match, "roomId", ""));
        EditText password = field("Room password", value(match, "roomPassword", ""));
        EditText release = numberField("Release time in Unix milliseconds", numberLong(match, "roomReleaseAt", System.currentTimeMillis()));
        form.addView(roomId);
        form.addView(password);
        form.addView(release);
        new FullScreenDialog.Builder(this)
                .setTitle("Schedule room release")
                .setMessage("Only users joined to this match receive the notification. The backend releases it even if the app is closed.")
                .setView(form)
                .setNegativeButton("CANCEL", null)
                .setPositiveButton("SCHEDULE", (dialog, which) -> {
                    long releaseAt = longValue(release, System.currentTimeMillis());
                    FirebaseRepository.saveRoomRelease(matchId, value(roomId), value(password), releaseAt)
                            .addOnSuccessListener(done -> {
                                // A20 — exact-time auto release: an AlarmManager alarm fires
                                // RoomReleaseAlarmReceiver right at releaseAt, even if the app
                                // is closed, and pushes room id/password only to joined players.
                                RoomReleaseScheduler.cancel(this, matchId);
                                RoomReleaseScheduler.schedule(this, matchId, releaseAt);
                                FancyText.toast(this, "Room release scheduled.", Toast.LENGTH_SHORT).show();
                            })
                            .addOnFailureListener(this::showError);
                })
                .show();
    }

    private void showCategories() {
        clearSection("Categories", "These categories are visible to users when they browse matches.");
        addAction("New category", v -> showCategoryForm(null, null));
        FirebaseRepository.gameModes().addListenerForSingleValueEvent(collectionListener(snapshot -> {
            for (DataSnapshot child : snapshot.getChildren()) {
                String id = child.getKey();
                addCard(value(child, "name", value(child, "title", "Unnamed category")),
                        details(value(child, "active", "true"), value(child, "imageUrl", "")));
                LinearLayout actions = row();
                addSmallAction(actions, "Edit", v -> showCategoryForm(id, snapshotMap(child)));
                addSmallAction(actions, "Delete", v -> confirmDelete("Delete category?", () ->
                        FirebaseRepository.deleteGameMode(id).addOnFailureListener(this::showError)));
                content.addView(actions, marginParams(-1, -2, 8, 0, 0, 0));
            }
            if (snapshot.getChildrenCount() == 0) addText("No categories yet.");
        }));
    }

    private void showCategoryForm(String id, Map<String, Object> existing) {
        LinearLayout form = form();
        EditText name = field("Category name", string(existing, "name"));
        EditText image = field("Image URL (optional)", string(existing, "imageUrl"));
        form.addView(name);
        form.addView(image);
        new FullScreenDialog.Builder(this)
                .setTitle(id == null ? "New category" : "Edit category")
                .setView(form)
                .setNegativeButton("CANCEL", null)
                .setPositiveButton("SAVE", (dialog, which) -> {
                    Map<String, Object> value = new HashMap<>();
                    value.put("name", value(name));
                    value.put("title", value(name));
                    value.put("imageUrl", value(image));
                    value.put("active", true);
                    FirebaseRepository.saveGameMode(id, value)
                            .addOnSuccessListener(done -> showCategories())
                            .addOnFailureListener(this::showError);
                }).show();
    }

    private void showBanners() {
        clearSection("Banners", "Publish, edit, or remove the promotional banners shown on the user home screen.");
        addAction("New banner", v -> showBannerForm(null, null));
        FirebaseRepository.banners().addListenerForSingleValueEvent(collectionListener(snapshot -> {
            for (DataSnapshot child : snapshot.getChildren()) {
                String id = child.getKey();
                addCard(value(child, "title", "Untitled banner"),
                        details(value(child, "active", "true"), value(child, "imageUrl", "")));
                LinearLayout actions = row();
                addSmallAction(actions, "Edit", v -> showBannerForm(id, snapshotMap(child)));
                addSmallAction(actions, "Delete", v -> confirmDelete("Delete banner?", () ->
                        FirebaseRepository.deleteBanner(id).addOnFailureListener(this::showError)));
                content.addView(actions, marginParams(-1, -2, 8, 0, 0, 0));
            }
            if (snapshot.getChildrenCount() == 0) addText("No banners yet.");
        }));
    }

    private void showBannerForm(String id, Map<String, Object> existing) {
        LinearLayout form = form();
        EditText title = field("Banner title", string(existing, "title"));
        EditText image = field("Image URL", string(existing, "imageUrl"));
        form.addView(title);
        form.addView(image);
        new FullScreenDialog.Builder(this)
                .setTitle(id == null ? "New banner" : "Edit banner")
                .setView(form)
                .setNegativeButton("CANCEL", null)
                .setPositiveButton("SAVE", (dialog, which) -> {
                    Map<String, Object> value = new HashMap<>();
                    value.put("title", value(title));
                    value.put("imageUrl", value(image));
                    value.put("active", true);
                    value.put("displayOrder", number(existing, "displayOrder", 0));
                    String keepLink = string(existing, "linkUrl");
                    if (keepLink != null && !keepLink.isEmpty()) value.put("linkUrl", keepLink);
                    FirebaseRepository.saveBanner(id, value)
                            .addOnSuccessListener(done -> showBanners())
                            .addOnFailureListener(this::showError);
                }).show();
    }

    private void showResultsMatches() {
        clearSection("Results & Coins", "Choose a tournament to manage its separate KILL, SURVIVAL or 1VS1 leaderboard and reward settlement. Legacy matches remain below.");
        FirebaseRepository.matches().addListenerForSingleValueEvent(collectionListener(snapshot -> {
            int legacyCount = 0;
            for (DataSnapshot child : snapshot.getChildren()) {
                String id = child.getKey();
                if (id == null) continue;
                legacyCount++;
                String title = value(child, "title", "Match " + id);
                addAction(title + "  •  " + value(child, "status", "UPCOMING"),
                        v -> openMatchAdminCenter(id, child));
            }
            final int matchesFound = legacyCount;
            FirebaseRepository.tournaments().addListenerForSingleValueEvent(collectionListener(tournaments -> {
                int tournamentCount = 0;
                for (DataSnapshot child : tournaments.getChildren()) {
                    String id = child.getKey();
                    if (id == null) continue;
                    tournamentCount++;
                    String title = value(child, "title", "Tournament " + id);
                    String system = value(child, "resultSystem", "KILL").replace('_', ' ');
                    addAction(title + "  •  " + system + "  •  " + value(child, "status", "UPCOMING"),
                            v -> {
                                Intent intent = new Intent(this, TournamentControlCenterActivity.class);
                                intent.putExtra("tournamentId", id);
                                intent.putExtra("title", title);
                                startActivity(intent);
                            });
                }
                if (matchesFound == 0 && tournamentCount == 0) {
                    addText("No result matches yet. Create a tournament from Match Operations first.");
                }
            }));
        }));
    }

    /** Opens the one-screen Overview / Participants / Rank Manage swipe center for a match. */
    private void openMatchAdminCenter(String id, DataSnapshot child) {
        @SuppressWarnings("unchecked")
        Map<String, Object> raw = (Map<String, Object>) child.getValue();
        Match parsed = Match.fromMap(id, raw);
        String legacyTitle = value(child, "title", "Match " + id);
        boolean needsPatch = parsed == null || parsed.getName() == null || parsed.getName().trim().isEmpty();
        Match match = !needsPatch ? parsed : new Match(id,
                parsed == null ? "" : parsed.getTournamentId(), parsed == null ? "" : parsed.getTournamentTitle(),
                legacyTitle, parsed == null ? 1 : parsed.getRound(), parsed == null ? "" : parsed.getMap(),
                parsed == null ? "" : parsed.getMode(), parsed == null ? 0 : parsed.getScheduledAt(),
                parsed == null ? 0 : parsed.getMaxSlots(), parsed == null ? "" : parsed.getRules(),
                parsed == null ? Match.UPCOMING : parsed.getStatus(), parsed == null ? "" : parsed.getRoomId(),
                parsed == null ? "" : parsed.getRoomPassword(), parsed != null && parsed.isRoomReleased(),
                parsed == null ? 0 : parsed.getRoomReleasedAt(), parsed == null ? "" : parsed.getDelayReason(),
                parsed == null ? 0 : parsed.getDelayExpectedAt());
        Intent intent = new Intent(this, MatchAdminCenterActivity.class);
        intent.putExtra(MatchAdminCenterActivity.EXTRA_MATCH, match);
        startActivity(intent);
    }

    private void showJoinedUsers(String matchId, String title, int defaultRate) {
        clearSection(title, "48-slot results table. Game identity comes from the join flow; coin requests remain pending until explicitly approved.");
        FirebaseRepository.joinedUsers(matchId).addListenerForSingleValueEvent(collectionListener(snapshot -> {
            int totalPlayers = 0, totalKills = 0, totalCoins = 0;
            for (DataSnapshot child : snapshot.getChildren()) {
                totalPlayers++;
                totalKills += number(child, "kills", 0);
                totalCoins += number(child, "kills", 0) * defaultRate;
            }
            final int fPlayers = totalPlayers, fKills = totalKills, fCoins = totalCoins;
            addCard("Preview before publishing",
                    "TOTAL PLAYERS: " + fPlayers + "\nTOTAL KILLS: " + fKills + "\nTOTAL COINS: " + fCoins);
            addAction("Publish result (Complete match)", v ->
                    confirmAndPublish(matchId, title, defaultRate, fPlayers, fKills, fCoins, false));
            addAction("Edit Result (correct an already-published match)", v ->
                    showCorrectionReasonForm(matchId, title, defaultRate, fPlayers, fKills, fCoins));
            for (DataSnapshot child : snapshot.getChildren()) {
                String uid = child.getKey();
                if (uid == null) continue;
                String player = value(child, "gameName", value(child, "userId", uid));
                int kills = number(child, "kills", 0);
                Integer placement = child.child("placement").getValue(Integer.class);
                int amount = number(child.child("coinRequest"), "amount", kills * defaultRate);
                String status = value(child.child("coinRequest"), "status", "NOT GENERATED");
                String slotLabel = "Slot " + number(child, "slotNumber", 0);
                DataSnapshot slotNumbersNode = child.child("slotNumbers");
                DataSnapshot playersNode = child.child("players");
                String detailText;
                if (playersNode.getChildrenCount() > 1) {
                    // Duo/Squad or multi-slot join with a separate player per slot:
                    // list every slot's own Game UID/Name instead of one shared pair.
                    StringBuilder extraSlots = new StringBuilder();
                    StringBuilder playerLines = new StringBuilder();
                    for (DataSnapshot p : playersNode.getChildren()) {
                        int pSlot = number(p, "slotNumber", 0);
                        if (extraSlots.length() > 0) extraSlots.append(", ");
                        extraSlots.append(pSlot);
                        if (playerLines.length() > 0) playerLines.append("\n");
                        playerLines.append("Slot ").append(pSlot).append(": ")
                                .append(value(p, "gameName", "")).append(" (UID: ").append(value(p, "gameUid", "")).append(")");
                    }
                    slotLabel = "Slots " + extraSlots + " (" + playersNode.getChildrenCount() + " players)";
                    detailText = playerLines + "\nKills: " + kills
                            + (placement != null ? "  •  Placement: #" + placement : "")
                            + "\nCoin request: " + amount + "  •  " + status;
                } else {
                    if (slotNumbersNode.getChildrenCount() > 1) {
                        // Multi-slot join without per-player data (older join, or same
                        // person across all slots): show every slot this player holds.
                        StringBuilder extra = new StringBuilder();
                        for (DataSnapshot s : slotNumbersNode.getChildren()) {
                            if (extra.length() > 0) extra.append(", ");
                            extra.append(s.getValue(Integer.class));
                        }
                        slotLabel = "Slots " + extra + " (" + slotNumbersNode.getChildrenCount() + " entries)";
                    }
                    detailText = "UID: " + value(child, "gameUid", "") + "\nKills: " + kills
                            + (placement != null ? "  •  Placement: #" + placement : "")
                            + "\nCoin request: " + amount + "  •  " + status;
                }
                addCard(slotLabel + "  •  " + player, detailText);
                LinearLayout actions = row();
                addSmallAction(actions, "Set kills", v -> showKillsForm(matchId, uid, child, defaultRate));
                if ("PENDING".equals(status)) {
                    String requestId = matchId + "_" + uid;
                    addSmallAction(actions, "Approve & give coins", v ->
                            FirebaseRepository.approveCoinRequest(requestId, uid, amount, matchId, kills, title)
                                    .addOnSuccessListener(done -> {
                                        FancyText.toast(this, "Coins approved.", Toast.LENGTH_SHORT).show();
                                        showJoinedUsers(matchId, title, defaultRate);
                                    }).addOnFailureListener(this::showError));
                    addSmallAction(actions, "Reject", v -> showRejectReasonForm(requestId, matchId, title, defaultRate));
                }
                content.addView(actions, marginParams(-1, -2, 8, 0, 0, 0));
            }
            if (snapshot.getChildrenCount() == 0) addText("No users have joined this match.");
        }));
    }

    /** Final confirmation with the totals the admin already saw in the preview card. */
    private void confirmAndPublish(String matchId, String title, int defaultRate,
                                    int players, int kills, int coins, boolean isCorrection) {
        new FullScreenDialog.Builder(this)
                .setTitle(isCorrection ? "Re-publish corrected result?" : "Publish this result?")
                .setMessage("TOTAL PLAYERS: " + players + "\nTOTAL KILLS: " + kills + "\nTOTAL COINS: " + coins
                        + "\n\nThis creates one pending coin request per player. Already-approved rows are never touched or duplicated. This cannot be un-published — only corrected afterwards with a reason.")
                .setNegativeButton("CANCEL", null)
                .setPositiveButton("PUBLISH RESULT", (dialog, which) ->
                        FirebaseRepository.completeMatchAndCreateCoinRequests(matchId, defaultRate)
                                .addOnSuccessListener(done -> {
                                    FancyText.toast(this, "Result published.", Toast.LENGTH_SHORT).show();
                                    showJoinedUsers(matchId, title, defaultRate);
                                }).addOnFailureListener(this::showError))
                .show();
    }

    /** "Edit Result" requires a reason — this is the audit trail for why a published result changed. */
    private void showCorrectionReasonForm(String matchId, String title, int defaultRate,
                                           int players, int kills, int coins) {
        EditText reason = field("Reason for correction (required)", "");
        new FullScreenDialog.Builder(this)
                .setTitle("Correct published result")
                .setMessage("Only PENDING/never-generated rows are recalculated. Any row already APPROVED (coins already credited) is left exactly as-is.")
                .setView(reason)
                .setNegativeButton("CANCEL", null)
                .setPositiveButton("CONTINUE", (dialog, which) -> {
                    String reasonText = value(reason);
                    if (reasonText.isEmpty()) { FancyText.toast(this, "A reason is required.", Toast.LENGTH_SHORT).show(); return; }
                    FirebaseRepository.editPublishedMatchResult(matchId, defaultRate, reasonText)
                            .addOnSuccessListener(done -> {
                                FancyText.toast(this, "Result corrected.", Toast.LENGTH_SHORT).show();
                                showJoinedUsers(matchId, title, defaultRate);
                            }).addOnFailureListener(this::showError);
                }).show();
    }

    private void showRejectReasonForm(String requestId, String matchId, String title, int defaultRate) {
        EditText reason = field("Reason (optional)", "");
        new FullScreenDialog.Builder(this)
                .setTitle("Reject this coin request?")
                .setView(reason)
                .setNegativeButton("CANCEL", null)
                .setPositiveButton("REJECT", (dialog, which) ->
                        FirebaseRepository.rejectCoinRequest(requestId, value(reason))
                                .addOnSuccessListener(done -> {
                                    FancyText.toast(this, "Request rejected.", Toast.LENGTH_SHORT).show();
                                    showJoinedUsers(matchId, title, defaultRate);
                                }).addOnFailureListener(this::showError))
                .show();
    }

    private void showKillsForm(String matchId, String uid, DataSnapshot player, int defaultRate) {
        EditText kills = numberField("Kills", number(player, "kills", 0));
        Integer existingPlacement = player.child("placement").getValue(Integer.class);
        EditText placement = numberField("Placement / rank (optional, 0 = not set)", existingPlacement == null ? 0 : existingPlacement);
        LinearLayout form = form();
        form.addView(kills);
        form.addView(placement);
        new FullScreenDialog.Builder(this)
                .setTitle("Update verified kills")
                .setView(form)
                .setNegativeButton("CANCEL", null)
                .setPositiveButton("SAVE", (dialog, which) ->
                        FirebaseRepository.saveKillCount(matchId, uid, integer(kills, 0), integer(placement, 0), defaultRate)
                                .addOnSuccessListener(done -> FancyText.toast(this,
                                        "Kills saved.", Toast.LENGTH_SHORT).show())
                                .addOnFailureListener(this::showError))
                .show();
    }

    private void showSupport() {
        clearSection("Support chat", "Open conversations are shown here as one-to-one threads. Reply inline and mark the conversation resolved.");
        FirebaseRepository.support().addListenerForSingleValueEvent(collectionListener(snapshot -> {
            for (DataSnapshot child : snapshot.getChildren()) {
                String id = child.getKey();
                if (id == null) continue;
                String subject = value(child, "subject", "Support conversation");
                addCard(subject, value(child, "description", "") + "\nStatus: " + value(child, "status", "OPEN"));
                addAction("Reply", v -> showReplyForm(id, subject, value(child, "reply", "")));
            }
            if (snapshot.getChildrenCount() == 0) addText("No support conversations.");
        }));
    }

    private void showReplyForm(String id, String subject, String currentReply) {
        EditText reply = field("Reply to the user", currentReply);
        reply.setMinLines(4);
        reply.setGravity(Gravity.TOP);
        new FullScreenDialog.Builder(this)
                .setTitle(subject)
                .setView(reply)
                .setNegativeButton("CANCEL", null)
                .setPositiveButton("SEND", (dialog, which) ->
                        FirebaseRepository.replyToTicket(id, value(reply), "RESOLVED")
                                .addOnSuccessListener(done -> {
                                    FancyText.toast(this, "Reply sent.", Toast.LENGTH_SHORT).show();
                                    showSupport();
                                }).addOnFailureListener(this::showError))
                .show();
    }

    private void showBroadcastDialog() {
        LinearLayout form = form();
        EditText title = field("Notification title", "");
        EditText description = field("Description", "");
        description.setMinLines(4);
        description.setGravity(Gravity.TOP);
        form.addView(title);
        form.addView(description);
        final com.arenax.tournament.util.RedirectPickerDialog.Field redirectField =
                com.arenax.tournament.util.RedirectPickerDialog.addField(this, form);
        new FullScreenDialog.Builder(this)
                .setTitle("Broadcast to all users")
                .setMessage("This creates an in-app notification and queues a device push for every user.")
                .setView(form)
                .setNegativeButton("CANCEL", null)
                .setPositiveButton("SEND NOW", (dialog, which) ->
                        FirebaseRepository.sendBroadcastNotification(value(title), value(description), redirectField.get())
                                .addOnSuccessListener(done -> FancyText.toast(this,
                                        "Broadcast queued.", Toast.LENGTH_SHORT).show())
                                .addOnFailureListener(this::showError))
                .show();
    }

    private void showAnalytics() {
        clearSection("Master analytics", "Money remains separate from match-reward coins. This view surfaces both systems without allowing the operational roles to touch withdrawals.");
        FirebaseRepository.users().get().addOnSuccessListener(users ->
                FirebaseRepository.coinHistory().get().addOnSuccessListener(history ->
                        FirebaseRepository.withdrawals().get().addOnSuccessListener(withdrawals ->
                                FirebaseRepository.matches().get().addOnSuccessListener(matches -> {
                                    long now = System.currentTimeMillis();
                                    long day = 24L * 60L * 60L * 1000L;
                                    int today = 0;
                                    int week = 0;
                                    for (DataSnapshot user : users.getChildren()) {
                                        long created = numberLong(user, "createdAt", 0L);
                                        if (created >= now - day) today++;
                                        if (created >= now - 7L * day) week++;
                                    }
                                    int approved = 0;
                                    for (DataSnapshot uid : history.getChildren()) {
                                        for (DataSnapshot item : uid.getChildren()) {
                                            if ("APPROVED".equals(value(item, "status", ""))) {
                                                approved += number(item, "amount", 0);
                                            }
                                        }
                                    }
                                    addMetric("New users today", String.valueOf(today));
                                    addMetric("New users this week", String.valueOf(week));
                                    addMetric("Coins approved", String.valueOf(approved));
                                    addMetric("Withdrawal records", String.valueOf(withdrawals.getChildrenCount()));
                                    addMetric("Matches", String.valueOf(matches.getChildrenCount()));
                                }).addOnFailureListener(this::showError))
                        .addOnFailureListener(this::showError))
                .addOnFailureListener(this::showError))
                .addOnFailureListener(this::showError);
    }

    private void showWithdrawals() {
        clearSection("Withdrawals", "Master Admin visibility for the existing real-money flow. This screen does not expose it to the other three roles.");
        FirebaseRepository.withdrawals().addListenerForSingleValueEvent(collectionListener(snapshot -> {
            int pending = 0;
            for (DataSnapshot item : snapshot.getChildren()) {
                if ("PENDING".equalsIgnoreCase(value(item, "status", ""))) pending++;
                addText(value(item, "uid", "Unknown user") + "  •  "
                        + value(item, "status", "UNKNOWN") + "  •  ₹" + value(item, "amount", "0"));
            }
            addMetric("Pending withdrawals", String.valueOf(pending));
            if (snapshot.getChildrenCount() == 0) addText("No withdrawal records.");
        }));
    }

    private void clearSection(String title, String description) {
        content.removeAllViews();
        MaterialButton back = action("Back to role home", v -> renderHome());
        content.addView(back, marginParams(-1, -2, 0, 0, 0, 10));
        addTitle(title);
        addText(description);
    }

    private void addMetric(String title, String value) {
        addCard(title, value);
    }

    private void addCard(String title, String body) {
        MaterialCardView card = new MaterialCardView(this);
        card.setCardBackgroundColor(0xFF140709);
        card.setStrokeColor(0xFF2E1016);
        card.setStrokeWidth(dp(1));
        card.setRadius(dp(14));
        LinearLayout inner = form();
        inner.setPadding(dp(14), dp(12), dp(14), dp(12));
        inner.addView(text(title == null ? "Untitled" : title, 16, 0xFFFFFFFF, true));
        if (body != null && !body.isEmpty()) inner.addView(text(body, 13, 0xFF9C909A, false),
                marginParams(-1, -2, 7, 0, 0, 0));
        card.addView(inner);
        content.addView(card, marginParams(-1, -2, 10, 0, 0, 0));
    }

    private void addTitle(String title) {
        content.addView(text(title, 22, 0xFFFFFFFF, true),
                marginParams(-1, -2, 2, 0, 0, 4));
    }

    private void addText(String value) {
        content.addView(text(value, 13, 0xFF9C909A, false),
                marginParams(-1, -2, 0, 0, 0, 8));
    }

    private String details(String first, String second) {
        if (second == null || second.trim().isEmpty()) return first == null ? "" : first;
        return (first == null ? "" : first) + "\n" + second;
    }

    private void addAction(String label, View.OnClickListener listener) {
        MaterialButton button = action(label, listener);
        content.addView(button, marginParams(-1, -2, 8, 0, 0, 0));
    }

    private MaterialButton action(String label, View.OnClickListener listener) {
        MaterialButton button = new MaterialButton(this);
        button.setText(label);
        button.setTextColor(0xFFFFFFFF);
        button.setOnClickListener(listener);
        button.setStrokeColorResource(com.arenax.tournament.R.color.blood_red);
        button.setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xFFE22E3C));
        return button;
    }

    private void addSmallAction(LinearLayout row, String label, View.OnClickListener listener) {
        MaterialButton button = action(label, listener);
        button.setTextSize(11);
        row.addView(button, new LinearLayout.LayoutParams(0, -2, 1));
    }

    private LinearLayout row() {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        return row;
    }

    private LinearLayout form() {
        LinearLayout form = new LinearLayout(this);
        form.setOrientation(LinearLayout.VERTICAL);
        form.setPadding(dp(16), dp(4), dp(16), dp(4));
        return form;
    }

    private EditText field(String hint, String value) {
        EditText field = new EditText(this);
        field.setHint(hint);
        field.setText(value == null ? "" : value);
        field.setTextColor(0xFFFFFFFF);
        field.setHintTextColor(0xFF6E6270);
        field.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        field.setMinHeight(dp(48));
        return field;
    }

    private EditText numberField(String hint, int value) {
        EditText field = field(hint, String.valueOf(value));
        field.setInputType(InputType.TYPE_CLASS_NUMBER);
        return field;
    }

    private EditText numberField(String hint, long value) {
        EditText field = field(hint, String.valueOf(value));
        field.setInputType(InputType.TYPE_CLASS_NUMBER);
        return field;
    }

    /** Populates the start-time dropdown for a chosen date — see AdminActivity's version of this
     *  same helper for the full explanation. For today it only offers times from right now
     *  onward, rounded up to the next 30-minute mark; for a future date it offers the whole
     *  day. If the clock has already passed 11:30 PM today, the date itself rolls to tomorrow. */
    private void refreshMatchTimeSlots(Spinner timeSpinner, Calendar selectedDay, EditText dateField) {
        Calendar now = Calendar.getInstance();
        boolean isToday = now.get(Calendar.YEAR) == selectedDay.get(Calendar.YEAR)
                && now.get(Calendar.DAY_OF_YEAR) == selectedDay.get(Calendar.DAY_OF_YEAR);

        Calendar cursor = (Calendar) selectedDay.clone();
        if (isToday) {
            cursor.setTime(now.getTime());
            int minute = cursor.get(Calendar.MINUTE);
            cursor.set(Calendar.SECOND, 0);
            cursor.set(Calendar.MILLISECOND, 0);
            if (minute < 30) {
                cursor.set(Calendar.MINUTE, 30);
            } else {
                cursor.set(Calendar.MINUTE, 0);
                cursor.add(Calendar.HOUR_OF_DAY, 1);
            }
        } else {
            cursor.set(Calendar.HOUR_OF_DAY, 0);
            cursor.set(Calendar.MINUTE, 0);
            cursor.set(Calendar.SECOND, 0);
            cursor.set(Calendar.MILLISECOND, 0);
        }

        List<String> slots = new ArrayList<>();
        SimpleDateFormat formatter = new SimpleDateFormat("hh:mm a", Locale.ENGLISH);
        while (cursor.get(Calendar.DAY_OF_YEAR) == selectedDay.get(Calendar.DAY_OF_YEAR)
                && cursor.get(Calendar.YEAR) == selectedDay.get(Calendar.YEAR)) {
            slots.add(formatter.format(cursor.getTime()));
            cursor.add(Calendar.MINUTE, 30);
        }

        if (slots.isEmpty()) {
            selectedDay.add(Calendar.DAY_OF_YEAR, 1);
            dateField.setText(new SimpleDateFormat("dd MMM yyyy", Locale.ENGLISH).format(selectedDay.getTime()));
            refreshMatchTimeSlots(timeSpinner, selectedDay, dateField);
            return;
        }

        timeSpinner.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, slots));
    }

    private TextView fieldLabel(String label) {
        TextView view = text(label, 11, 0xFF9C909A, true);
        view.setPadding(0, dp(8), 0, dp(2));
        return view;
    }

    /** Coin-amount dropdown for entry fee / per-kill reward — replaces free-text number entry
     *  so the admin picks from a fixed, mistake-proof list. Offers common denominations from
     *  0 up to 10,000 instead of every single integer. If an existing match's value isn't one
     *  of the presets, it's inserted in sorted position so editing that match doesn't silently
     *  change its value. Whatever is selected here is written to entryFeeCoins / perKillCoins
     *  exactly, and that's the exact value the backend deducts from a player's wallet on /joinMatch. */
    private static final int[] COIN_AMOUNT_PRESETS = {
            0, 1, 2, 5, 10, 20, 25, 50, 75, 100, 150, 200, 250, 300, 400, 500,
            750, 1000, 1500, 2000, 2500, 3000, 4000, 5000, 7500, 10000
    };

    private Spinner coinAmountSpinner(int defaultValue) {
        java.util.List<Integer> values = new java.util.ArrayList<>();
        for (int preset : COIN_AMOUNT_PRESETS) values.add(preset);
        if (!values.contains(defaultValue)) {
            int insertAt = 0;
            while (insertAt < values.size() && values.get(insertAt) < defaultValue) insertAt++;
            values.add(insertAt, defaultValue);
        }
        String[] amounts = new String[values.size()];
        for (int i = 0; i < values.size(); i++) amounts[i] = String.valueOf(values.get(i));
        Spinner spinner = new Spinner(this);
        spinner.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, amounts));
        spinner.setSelection(values.indexOf(defaultValue));
        return spinner;
    }

    private Spinner matchTypeSpinner(String existingValue) {
        String[] types = {"SOLO", "DUO", "SQUAD"};
        Spinner spinner = new Spinner(this);
        spinner.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, types));
        int index = 0;
        if (existingValue != null) {
            for (int i = 0; i < types.length; i++) {
                if (types[i].equalsIgnoreCase(existingValue.trim())) { index = i; break; }
            }
        }
        spinner.setSelection(index);
        return spinner;
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextSize(size);
        view.setTextColor(color);
        view.setTypeface(null, bold ? android.graphics.Typeface.BOLD : android.graphics.Typeface.NORMAL);
        return view;
    }

    private LinearLayout.LayoutParams marginParams(int width, int height, int top, int left,
                                                   int right, int bottom) {
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(width, height);
        params.setMargins(dp(left), dp(top), dp(right), dp(bottom));
        return params;
    }

    private void confirmDelete(String message, Runnable action) {
        new FullScreenDialog.Builder(this).setTitle(message)
                .setNegativeButton("CANCEL", null)
                .setPositiveButton("DELETE", (d, w) -> action.run()).show();
    }

    private ValueEventListener collectionListener(java.util.function.Consumer<DataSnapshot> onData) {
        return new ValueEventListener() {
            @Override public void onDataChange(DataSnapshot snapshot) { onData.accept(snapshot); }
            @Override public void onCancelled(DatabaseError error) { showError(error.toException()); }
        };
    }

    private Map<String, Object> snapshotMap(DataSnapshot snapshot) {
        Map<String, Object> map = new HashMap<>();
        for (DataSnapshot child : snapshot.getChildren()) map.put(child.getKey(), child.getValue());
        return map;
    }

    private String value(Map<String, Object> map, String key) {
        return map == null ? "" : string(map, key);
    }

    private String string(Map<String, Object> map, String key) {
        Object value = map == null ? null : map.get(key);
        return value == null ? "" : String.valueOf(value);
    }

    private String value(DataSnapshot snapshot, String key, String fallback) {
        Object raw = snapshot.child(key).getValue();
        if (raw == null) return fallback;
        String value = String.valueOf(raw);
        return value.isEmpty() ? fallback : value;
    }

    private int number(Map<String, Object> map, String key, int fallback) {
        Object value = map == null ? null : map.get(key);
        return value instanceof Number ? ((Number) value).intValue() : fallback;
    }

    private int number(DataSnapshot snapshot, String key, int fallback) {
        Object raw = snapshot.child(key).getValue();
        if (raw == null) return fallback;
        try { return raw instanceof Number ? ((Number) raw).intValue() : Integer.parseInt(String.valueOf(raw)); }
        catch (NumberFormatException ignored) { return fallback; }
    }

    private long numberLong(DataSnapshot snapshot, String key, long fallback) {
        Object raw = snapshot.child(key).getValue();
        if (raw == null) return fallback;
        try { return raw instanceof Number ? ((Number) raw).longValue() : Long.parseLong(String.valueOf(raw)); }
        catch (NumberFormatException ignored) { return fallback; }
    }

    private int integer(EditText field, int fallback) {
        try { return Integer.parseInt(value(field)); } catch (NumberFormatException ignored) { return fallback; }
    }

    private long longValue(EditText field, long fallback) {
        try { return Long.parseLong(value(field)); } catch (NumberFormatException ignored) { return fallback; }
    }

    private String value(EditText field) {
        return field.getText() == null ? "" : field.getText().toString().trim();
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private void showError(Exception error) {
        FancyText.toast(this, error.getMessage() == null ? "Something went wrong." : error.getMessage(),
                Toast.LENGTH_LONG).show();
    }

    @Override
    protected void onDestroy() {
        if (activeListener != null) {
            FirebaseRepository.tournaments().removeEventListener(activeListener);
            FirebaseRepository.matches().removeEventListener(activeListener);
            FirebaseRepository.support().removeEventListener(activeListener);
        }
        super.onDestroy();
    }
}
