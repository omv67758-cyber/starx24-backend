package com.arenax.tournament.admin;

/**
 * Shared UI status rules for withdrawal cards.
 * Server timestamp should be supplied by the repository/backend.
 */
public final class WithdrawalStatus {
    private WithdrawalStatus() {}

    public enum State { PAID, PENDING_UNDER_24H, PENDING_OVER_24H }

    public static State resolve(String status, long requestedAtMillis, long nowMillis) {
        if ("PAID".equalsIgnoreCase(status)) return State.PAID;
        long age = Math.max(0L, nowMillis - requestedAtMillis);
        return age >= 24L * 60L * 60L * 1000L
                ? State.PENDING_OVER_24H
                : State.PENDING_UNDER_24H;
    }
}
