package com.arenax.tournament.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.arenax.tournament.R;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.resource.bitmap.CircleCrop;
import java.util.List;

public class LeaderboardAdapter extends RecyclerView.Adapter<LeaderboardAdapter.Holder> {
    private final List<String[]> rows;
    public interface OnPlayerClick { void onClick(String uid, String name); }
    private final OnPlayerClick onPlayerClick;
    public LeaderboardAdapter(List<String[]> rows, OnPlayerClick onPlayerClick) { this.rows = rows; this.onPlayerClick = onPlayerClick; }
    @NonNull @Override public Holder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new Holder(LayoutInflater.from(parent.getContext()).inflate(R.layout.item_leaderboard, parent, false));
    }
    @Override public void onBindViewHolder(@NonNull Holder h, int position) {
        String[] row = rows.get(position);
        int rank;
        try { rank = Integer.parseInt(row[0].trim()); } catch (NumberFormatException e) { rank = position + 1; }
        h.itemView.setOnClickListener(v -> {
            if (onPlayerClick != null && row.length > 6) onPlayerClick.onClick(row[6], row[1]);
        });
        h.rank.setText(row[0]);
        h.avatar.setText(row[1].isEmpty() ? "P" : row[1].substring(0, 1).toUpperCase());
        h.name.setText(row[1]);
        h.stats.setText(ordinal(rank) + " place");
        h.winning.setText(row[4]);
        // Medal styling for the rare case a top-three row ever reaches this list;
        // everything else gets the flat neutral rank badge used in the design.
        if (rank == 1) {
            h.rank.setBackgroundResource(R.drawable.lb2_bg_rank_gold);
            h.rank.setTextColor(0xFFFFFFFF);
        } else if (rank == 2) {
            h.rank.setBackgroundResource(R.drawable.lb2_bg_rank_silver);
            h.rank.setTextColor(0xFF12172B);
        } else if (rank == 3) {
            h.rank.setBackgroundResource(R.drawable.lb2_bg_rank_bronze);
            h.rank.setTextColor(0xFFFFFFFF);
        } else {
            h.rank.setBackgroundResource(R.drawable.lb2_bg_rank_neutral);
            h.rank.setTextColor(0xFF12172B);
        }
        // Alternate the avatar ring color (blue / mint) for the same lively look as the reference design.
        if (position % 2 == 0) {
            h.avatar.setBackgroundResource(R.drawable.lb2_bg_avatar_blue);
            h.avatar.setTextColor(0xFF2F7BF0);
        } else {
            h.avatar.setBackgroundResource(R.drawable.lb2_bg_avatar_mint);
            h.avatar.setTextColor(0xFF18C993);
        }
        // Profile photo (uploaded at signup) takes over from the initials circle when present.
        String photoUrl = row.length > 5 ? row[5] : null;
        if (photoUrl != null && !photoUrl.trim().isEmpty()) {
            h.avatarPhoto.setVisibility(View.VISIBLE);
            h.avatar.setVisibility(View.GONE);
            Glide.with(h.avatarPhoto.getContext())
                    .load(photoUrl)
                    .transform(new CircleCrop())
                    .into(h.avatarPhoto);
        } else {
            h.avatarPhoto.setVisibility(View.GONE);
            h.avatar.setVisibility(View.VISIBLE);
        }
        // Only the last row in the card hides its divider.
        h.divider.setVisibility(position == rows.size() - 1 ? View.GONE : View.VISIBLE);
    }
    @Override public int getItemCount() { return rows.size(); }

    private static String ordinal(int n) {
        if (n % 100 >= 11 && n % 100 <= 13) return n + "th";
        switch (n % 10) {
            case 1: return n + "st";
            case 2: return n + "nd";
            case 3: return n + "rd";
            default: return n + "th";
        }
    }

    static class Holder extends RecyclerView.ViewHolder {
        TextView rank, avatar, name, stats, winning;
        ImageView avatarPhoto;
        View divider;
        Holder(View v) {
            super(v);
            rank = v.findViewById(R.id.leaderboard_rank);
            avatar = v.findViewById(R.id.leaderboard_avatar);
            avatarPhoto = v.findViewById(R.id.leaderboard_avatar_photo);
            name = v.findViewById(R.id.leaderboard_name);
            stats = v.findViewById(R.id.leaderboard_stats);
            winning = v.findViewById(R.id.leaderboard_winning);
            divider = v.findViewById(R.id.item_divider);
        }
    }
}
