package com.arenax.tournament;


import com.arenax.tournament.util.FancyText;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.arenax.tournament.data.FirebaseRepository;
import com.arenax.tournament.model.Match;
import com.arenax.tournament.model.Tournament;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.ValueEventListener;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Two views in one Activity, exactly as before (B34 + B35):
 *
 *  1. Opened WITH EXTRA_TOURNAMENT_ID (from a tournament's detail screen / after joining) — the
 *     LIVE match page: UPCOMING + countdown → WAIT FOR ROOM ID & PASSWORD → Room ID/Password +
 *     Copy → LIVE → COMPLETED. Unchanged from the original implementation.
 *
 *  2. Opened with NO extra (Profile → "My Matches") — the aggregate history across every
 *     tournament the player has joined. This is now the white-theme "My Statistics" list: rank
 *     badge, title, date, PAID/WON coin chips and a PAID / PENDING / WIN / CANCELLED status pill,
 *     with a Match Info / Paid / Won filter tab bar, matching the reference design. It is a
 *     one-shot history read (not a live listener) — for each joined tournament it reads that
 *     tournament's matches, and for each match the player's own joinedUsers/{uid} node
 *     (coinRequest) to work out what was paid (entry fee) and won (approved coin request amount).
 */
public class MyMatchesActivity extends BaseActivity {
    public static final String EXTRA_TOURNAMENT_ID = "tournamentId";

    private static final String TAB_INFO = "info";
    private static final String TAB_PAID = "paid";
    private static final String TAB_WON = "won";

    // Rank badge palette (bg, icon/number colour) — cycles per row, purely cosmetic ordering.
    private static final String[] BADGE_BG = {"#FDECC8", "#ECEDF1", "#FBE3D2", "#DCEAFE", "#DFF6E9", "#EAE1FB"};
    private static final String[] BADGE_FG = {"#D9A22C", "#9098A8", "#D98A4B", "#2F6FE4", "#1FAA59", "#8354E0"};
    // Coin-chip wash colour — cycles per row.
    private static final String[] CHIP_BG = {"#E7F8EF", "#E9F1FF", "#F1EAFB", "#FDEAF1", "#E7F8F0", "#E9F1FF"};

    private LinearLayout content;
    private final List<CountDownTimer> timers = new ArrayList<>();
    private final List<ValueEventListener> liveListeners = new ArrayList<>();
    private final List<com.google.firebase.database.Query> liveQueries = new ArrayList<>();

    // ---- Stats-view only state ----
    private boolean statsMode;
    private LinearLayout tabInfo, tabPaid, tabWon;
    private String activeTab = TAB_INFO;
    private final List<StatRow> allRows = new ArrayList<>();
    private final AtomicInteger pending = new AtomicInteger(0);

    /** One row of the "My Statistics" list — one match the player took part in. */
    private static class StatRow {
        String title;
        long scheduledAt;
        double paid;
        double won;
        String status; // PAID, PENDING, WIN, CANCELLED
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (!FirebaseRepository.isReady(this)) {
            FancyText.toast(this, "Live services are unavailable. Please try again later.", Toast.LENGTH_LONG).show();
            finish();
            return;
        }

        String tournamentId = getIntent().getStringExtra(EXTRA_TOURNAMENT_ID);
        statsMode = tournamentId == null;

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(statsMode ? Color.WHITE : getColor(R.color.ink));

        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(statsMode ? 12 : 16), dp(18), dp(16), dp(statsMode ? 10 : 14));
        TextView back = text(statsMode ? "‹" : "‹", statsMode ? 26 : 22, statsMode ? "#1C1C1E" : hex(R.color.text_primary), true);
        back.setPadding(dp(statsMode ? 4 : 0), 0, dp(14), 0);
        back.setOnClickListener(v -> finish());
        bar.addView(back);
        if (statsMode) {
            TextView title = text("My Statistics", 19, "#1C1C1E", true);
            LinearLayout.LayoutParams titleLp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
            title.setGravity(Gravity.CENTER);
            bar.addView(title, titleLp);
            TextView spacer = text("", 22, "#1C1C1E", false);
            spacer.setWidth(dp(28));
            bar.addView(spacer);
        } else {
            bar.addView(text("MATCHES", 18, hex(R.color.text_primary), true));
        }
        root.addView(bar);

        if (statsMode) {
            LinearLayout tabsRow = new LinearLayout(this);
            tabsRow.setOrientation(LinearLayout.HORIZONTAL);
            tabsRow.setPadding(dp(16), dp(2), dp(16), dp(12));
            tabInfo = tabPill("# Match Info");
            tabPaid = tabPill("Paid");
            tabWon = tabPill("Won");
            LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
            tp.setMarginEnd(dp(8));
            tabsRow.addView(tabInfo, tp);
            LinearLayout.LayoutParams tp2 = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
            tp2.setMarginEnd(dp(8));
            tabsRow.addView(tabPaid, tp2);
            tabsRow.addView(tabWon, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
            tabInfo.setOnClickListener(v -> setActiveTab(TAB_INFO));
            tabPaid.setOnClickListener(v -> setActiveTab(TAB_PAID));
            tabWon.setOnClickListener(v -> setActiveTab(TAB_WON));
            root.addView(tabsRow);
            applyTabStyles();
        }

        ScrollView scroll = new ScrollView(this);
        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(16), dp(4), dp(16), dp(24));
        scroll.addView(content);
        root.addView(scroll, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        setContentView(root);

        if (statsMode) {
            content.addView(pageText("Loading your matches…"));
            loadMyStatsAcrossTournaments();
        } else {
            loadMatchesForTournament(tournamentId);
        }
    }

    private String hex(int colorRes) { return String.format("#%06X", 0xFFFFFF & getColor(colorRes)); }

    // =====================================================================
    // Live per-tournament match view (unchanged behaviour)
    // =====================================================================

    private void loadMatchesForTournament(String tournamentId) {
        content.addView(pageText("Live schedule for this tournament. Countdown is computed from the admin's exact time and stays correct on refresh."));
        com.google.firebase.database.Query q = FirebaseRepository.matches().orderByChild("tournamentId").equalTo(tournamentId);
        ValueEventListener listener = new ValueEventListener() {
            @Override public void onDataChange(@NonNull DataSnapshot snapshot) { renderMatches(snapshot); }
            @Override public void onCancelled(@NonNull DatabaseError error) { content.addView(pageText("Matches unavailable right now.")); }
        };
        q.addValueEventListener(listener);
        liveListeners.add(listener);
        liveQueries.add(q);
    }

    private void renderMatches(DataSnapshot snapshot) {
        if (!snapshot.exists() || snapshot.getChildrenCount() == 0) {
            content.addView(pageText("No matches scheduled yet."));
            return;
        }
        for (DataSnapshot child : snapshot.getChildren()) {
            @SuppressWarnings("unchecked")
            Match m = Match.fromMap(child.getKey(), (java.util.Map<String, Object>) child.getValue());
            if (m != null) content.addView(matchCard(m));
        }
    }

    private LinearLayout matchCard(Match m) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(14), dp(14), dp(14), dp(14));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(getColor(R.color.surface));
        bg.setCornerRadius(dp(12));
        bg.setStroke(dp(1), getColor(R.color.stroke));
        card.setBackground(bg);
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        cp.topMargin = dp(12);
        card.setLayoutParams(cp);

        TextView name = text((m.getTournamentTitle().isEmpty() ? "" : m.getTournamentTitle() + " — ")
                + "ROUND " + m.getRound() + " • " + m.getName(), 14, hex(R.color.text_primary), true);
        card.addView(name);
        card.addView(pageText(m.getMap() + "  •  " + m.getMode()
                + (m.getScheduledAt() > 0 ? "  •  " + new SimpleDateFormat("dd MMM, hh:mm a", Locale.ENGLISH).format(new Date(m.getScheduledAt())) : "")));

        TextView state = text("", 13, hex(R.color.text_primary), true);
        state.setPadding(0, dp(8), 0, 0);
        card.addView(state);

        String status = m.getEffectiveStatus();
        if (Match.CANCELLED.equals(status)) {
            state.setText("MATCH CANCELLED");
            state.setTextColor(getColor(R.color.text_muted));
        } else if (Match.COMPLETED.equals(status)) {
            state.setText("COMPLETED — check Results & Leaderboard");
            state.setTextColor(getColor(R.color.text_secondary));
        } else if (Match.LIVE.equals(status)) {
            state.setText("● LIVE NOW");
            state.setTextColor(getColor(R.color.blood_red));
            if (m.isRoomReleased()) card.addView(roomBlock(m));
        } else if (Match.DELAYED.equals(status) || m.isDelayed()) {
            state.setText("MATCH DELAYED — WAIT FOR ROOM ID & PASSWORD"
                    + (m.getDelayReason().isEmpty() ? "" : "\n" + m.getDelayReason()));
            state.setTextColor(getColor(R.color.warning));
        } else if (m.isRoomReleased()) {
            state.setText("ROOM RELEASED");
            state.setTextColor(getColor(R.color.success));
            card.addView(roomBlock(m));
        } else if (Match.WAITING.equals(status)) {
            state.setText("WAIT FOR ROOM ID & PASSWORD");
            state.setTextColor(getColor(R.color.warning));
        } else if (m.getScheduledAt() > 0) {
            startCountdown(state, m.getScheduledAt());
        } else {
            state.setText("SCHEDULE TBA");
            state.setTextColor(getColor(R.color.text_secondary));
        }
        return card;
    }

    private LinearLayout roomBlock(Match m) {
        LinearLayout block = new LinearLayout(this);
        block.setOrientation(LinearLayout.VERTICAL);
        block.setPadding(dp(12), dp(10), dp(12), dp(10));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(getColor(R.color.accent_green_tint));
        bg.setCornerRadius(dp(8));
        bg.setStroke(dp(1), getColor(R.color.accent_green_stroke));
        block.setBackground(bg);
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        bp.topMargin = dp(10);
        block.setLayoutParams(bp);

        TextView roomId = text("ROOM ID   " + (m.getRoomId().isEmpty() ? "Posting shortly…" : m.getRoomId()) + "   (tap to copy)", 13, hex(R.color.text_primary), true);
        TextView roomPass = text("PASSWORD   " + (m.getRoomPassword().isEmpty() ? "—" : m.getRoomPassword()) + "   (tap to copy)", 13, hex(R.color.text_primary), true);
        roomId.setPadding(0, dp(4), 0, dp(4));
        roomPass.setPadding(0, dp(4), 0, dp(4));
        roomId.setOnClickListener(v -> copy("Room ID", m.getRoomId()));
        roomPass.setOnClickListener(v -> copy("Password", m.getRoomPassword()));
        block.addView(roomId);
        block.addView(roomPass);
        return block;
    }

    private void startCountdown(TextView target, long scheduledAt) {
        long remaining = scheduledAt - System.currentTimeMillis();
        if (remaining <= 0) {
            target.setText("WAIT FOR ROOM ID & PASSWORD");
            target.setTextColor(getColor(R.color.warning));
            return;
        }
        CountDownTimer timer = new CountDownTimer(remaining, 1000L) {
            @Override public void onTick(long millisUntilFinished) {
                long secs = millisUntilFinished / 1000L;
                long days = secs / 86400L;
                long hours = (secs % 86400L) / 3600L;
                long minutes = (secs % 3600L) / 60L;
                long seconds = secs % 60L;
                if (millisUntilFinished < 5 * 60 * 1000L) {
                    target.setTextColor(0xFFFF4757);
                } else if (millisUntilFinished < 15 * 60 * 1000L) {
                    target.setTextColor(0xFFE22E3C);
                } else {
                    target.setTextColor(getColor(R.color.text_primary));
                }
                target.setText(String.format(Locale.ROOT, "%02dd %02dh %02dm %02ds", days, hours, minutes, seconds));
            }
            @Override public void onFinish() {
                target.setText("WAIT FOR ROOM ID & PASSWORD");
                target.setTextColor(getColor(R.color.warning));
            }
        };
        timer.start();
        timers.add(timer);
    }

    private void copy(String label, String value) {
        if (value == null || value.isEmpty()) return;
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        cm.setPrimaryClip(ClipData.newPlainText(label, value));
        FancyText.toast(this, "Copied", Toast.LENGTH_SHORT).show();
    }

    // =====================================================================
    // "My Statistics" aggregate view (Profile → My Matches) — new white design
    // =====================================================================

    private LinearLayout tabPill(String label) {
        LinearLayout pill = new LinearLayout(this);
        pill.setOrientation(LinearLayout.HORIZONTAL);
        pill.setGravity(Gravity.CENTER);
        pill.setPadding(dp(10), dp(10), dp(10), dp(10));
        TextView t = text(label, 13, "#1C1C1E", true);
        t.setGravity(Gravity.CENTER);
        pill.addView(t);
        pill.setTag(t);
        return pill;
    }

    private void setActiveTab(String tab) {
        activeTab = tab;
        applyTabStyles();
        renderRows();
    }

    private void applyTabStyles() {
        stylePill(tabInfo, activeTab.equals(TAB_INFO));
        stylePill(tabPaid, activeTab.equals(TAB_PAID));
        stylePill(tabWon, activeTab.equals(TAB_WON));
    }

    private void stylePill(LinearLayout pill, boolean active) {
        GradientDrawable bg = new GradientDrawable();
        bg.setCornerRadius(dp(22));
        bg.setColor(Color.parseColor(active ? "#1C1C1E" : "#F5F4F1"));
        pill.setBackground(bg);
        ((TextView) pill.getTag()).setTextColor(Color.parseColor(active ? "#FFFFFF" : "#68686D"));
    }

    private void loadMyStatsAcrossTournaments() {
        String uid = FirebaseRepository.currentUser() == null ? null : FirebaseRepository.currentUser().getUid();
        if (uid == null) {
            content.removeAllViews();
            content.addView(pageText("Sign in to see your matches."));
            return;
        }
        FirebaseRepository.tournaments().addListenerForSingleValueEvent(new ValueEventListener() {
            @Override public void onDataChange(@NonNull DataSnapshot snapshot) {
                List<String> myTournamentIds = new ArrayList<>();
                List<DataSnapshot> pendingList = new ArrayList<>();
                for (DataSnapshot t : snapshot.getChildren()) pendingList.add(t);
                checkNextForStats(pendingList, 0, myTournamentIds, uid);
            }
            @Override public void onCancelled(@NonNull DatabaseError error) {
                content.removeAllViews();
                content.addView(pageText("Could not load your tournaments."));
            }
        });
    }

    private void checkNextForStats(List<DataSnapshot> all, int index, List<String> myTournamentIds, String uid) {
        if (index >= all.size()) {
            if (myTournamentIds.isEmpty()) {
                content.removeAllViews();
                content.addView(pageText("You haven't registered for any tournament yet. Join one to see your stats here."));
                return;
            }
            for (String tid : myTournamentIds) {
                pending.incrementAndGet();
                loadStatsForTournament(tid, uid);
            }
            return;
        }
        DataSnapshot t = all.get(index);
        FirebaseRepository.tournamentParticipants(t.getKey()).child(uid).get()
                .addOnSuccessListener(p -> {
                    if (p.exists()) myTournamentIds.add(t.getKey());
                    checkNextForStats(all, index + 1, myTournamentIds, uid);
                })
                .addOnFailureListener(e -> checkNextForStats(all, index + 1, myTournamentIds, uid));
    }

    private void loadStatsForTournament(String tournamentId, String uid) {
        FirebaseRepository.tournaments().child(tournamentId).get().addOnCompleteListener(tTask -> {
            Tournament tour = null;
            if (tTask.isSuccessful() && tTask.getResult() != null && tTask.getResult().getValue() != null) {
                @SuppressWarnings("unchecked")
                java.util.Map<String, Object> v = (java.util.Map<String, Object>) tTask.getResult().getValue();
                tour = Tournament.fromMap(tournamentId, v);
            }
            final Tournament tournament = tour;

            pending.incrementAndGet();
            FirebaseRepository.matches().orderByChild("tournamentId").equalTo(tournamentId).get()
                    .addOnCompleteListener(mTask -> {
                        if (mTask.isSuccessful() && mTask.getResult() != null && mTask.getResult().exists()) {
                            for (DataSnapshot child : mTask.getResult().getChildren()) {
                                @SuppressWarnings("unchecked")
                                Match m = Match.fromMap(child.getKey(), (java.util.Map<String, Object>) child.getValue());
                                if (m != null) {
                                    pending.incrementAndGet();
                                    fetchJoinedUserForStats(m, tournament, uid);
                                }
                            }
                        }
                        maybeFinishStats();
                    });
            maybeFinishStats();
        });
    }

    private void fetchJoinedUserForStats(Match m, Tournament tournament, String uid) {
        FirebaseRepository.joinedUsers(m.getId()).child(uid).get().addOnCompleteListener(jTask -> {
            StatRow row = new StatRow();
            row.title = tournament != null && !tournament.getTitle().isEmpty()
                    ? tournament.getTitle()
                    : (m.getTournamentTitle().isEmpty() ? m.getName() : m.getTournamentTitle());
            row.scheduledAt = m.getScheduledAt();
            row.paid = tournament != null ? tournament.getEntryFeeCoins() : 0;

            String coinStatus = "";
            double amount = 0;
            if (jTask.isSuccessful() && jTask.getResult() != null && jTask.getResult().exists()) {
                DataSnapshot cr = jTask.getResult().child("coinRequest");
                if (cr.exists()) {
                    Object st = cr.child("status").getValue();
                    coinStatus = st == null ? "" : String.valueOf(st);
                    Object amt = cr.child("amount").getValue();
                    if (amt instanceof Number) amount = ((Number) amt).doubleValue();
                }
            }
            row.won = "APPROVED".equals(coinStatus) ? amount : 0;

            String effective = m.getEffectiveStatus();
            if (Match.CANCELLED.equals(effective)) {
                row.status = "CANCELLED";
            } else if ("APPROVED".equals(coinStatus) && row.won > 0) {
                row.status = "WIN";
            } else if ("APPROVED".equals(coinStatus) || Match.COMPLETED.equals(effective)) {
                row.status = "PAID";
            } else {
                row.status = "PENDING";
            }

            synchronized (allRows) {
                allRows.add(row);
            }
            maybeFinishStats();
        });
    }

    private void maybeFinishStats() {
        if (pending.decrementAndGet() <= 0) {
            Collections.sort(allRows, (a, b) -> Long.compare(b.scheduledAt, a.scheduledAt));
            renderRows();
        }
    }

    private void renderRows() {
        content.removeAllViews();
        List<StatRow> filtered = new ArrayList<>();
        for (StatRow row : allRows) {
            if (TAB_PAID.equals(activeTab) && row.paid <= 0) continue;
            if (TAB_WON.equals(activeTab) && row.won <= 0) continue;
            filtered.add(row);
        }
        if (filtered.isEmpty()) {
            content.addView(pageText(allRows.isEmpty()
                    ? "No matches to show yet."
                    : "Nothing here for this filter yet."));
            return;
        }
        for (int i = 0; i < filtered.size(); i++) {
            content.addView(statCard(filtered.get(i), i));
        }
    }

    private LinearLayout statCard(StatRow row, int index) {
        int palette = index % BADGE_BG.length;

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(14), dp(14), dp(14), dp(14));
        GradientDrawable cardBg = new GradientDrawable();
        cardBg.setColor(Color.WHITE);
        cardBg.setCornerRadius(dp(14));
        cardBg.setStroke(dp(1), Color.parseColor("#E5E3DE"));
        card.setBackground(cardBg);
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        cp.topMargin = dp(12);
        card.setLayoutParams(cp);

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.TOP);

        FrameLayout badge = new FrameLayout(this);
        GradientDrawable badgeBg = new GradientDrawable();
        badgeBg.setCornerRadius(dp(12));
        badgeBg.setColor(Color.parseColor(BADGE_BG[palette]));
        badge.setBackground(badgeBg);
        LinearLayout.LayoutParams badgeLp = new LinearLayout.LayoutParams(dp(50), dp(50));
        badgeLp.setMarginEnd(dp(12));
        badge.setLayoutParams(badgeLp);
        LinearLayout badgeInner = new LinearLayout(this);
        badgeInner.setOrientation(LinearLayout.VERTICAL);
        badgeInner.setGravity(Gravity.CENTER);
        TextView crown = text("♛", 13, BADGE_FG[palette], false);
        crown.setGravity(Gravity.CENTER);
        TextView num = text(String.valueOf(index + 1), 18, BADGE_FG[palette], true);
        num.setGravity(Gravity.CENTER);
        badgeInner.addView(crown);
        badgeInner.addView(num);
        badge.addView(badgeInner, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        top.addView(badge);

        LinearLayout middle = new LinearLayout(this);
        middle.setOrientation(LinearLayout.VERTICAL);
        TextView titleView = text(row.title.isEmpty() ? "Match" : row.title, 14, "#1C1C1E", true);
        middle.addView(titleView);
        TextView dateView = text("\uD83D\uDCC5 " + formatDate(row.scheduledAt), 12, "#68686D", false);
        dateView.setPadding(0, dp(6), 0, 0);
        middle.addView(dateView);
        top.addView(middle, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        TextView chevron = text("›", 20, "#B5B3AC", true);
        chevron.setPadding(dp(8), 0, 0, 0);
        LinearLayout.LayoutParams chevLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        chevLp.gravity = Gravity.CENTER_VERTICAL;
        top.addView(chevron, chevLp);
        card.addView(top);

        LinearLayout chipRow = new LinearLayout(this);
        chipRow.setOrientation(LinearLayout.HORIZONTAL);
        chipRow.setPadding(0, dp(12), 0, 0);
        chipRow.addView(coinChip(row.paid, palette));
        LinearLayout.LayoutParams chipSpacing = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        chipSpacing.setMarginStart(dp(8));
        chipRow.addView(coinChip(row.won, palette), chipSpacing);
        card.addView(chipRow);

        LinearLayout pillRow = new LinearLayout(this);
        pillRow.setOrientation(LinearLayout.HORIZONTAL);
        pillRow.setGravity(Gravity.CENTER);
        pillRow.setPadding(0, dp(10), 0, 0);
        pillRow.addView(statusPill(row.status));
        card.addView(pillRow);

        return card;
    }

    private LinearLayout coinChip(double amount, int palette) {
        LinearLayout chip = new LinearLayout(this);
        chip.setOrientation(LinearLayout.HORIZONTAL);
        chip.setGravity(Gravity.CENTER_VERTICAL);
        chip.setPadding(dp(10), dp(8), dp(10), dp(8));
        GradientDrawable bg = new GradientDrawable();
        bg.setCornerRadius(dp(18));
        bg.setColor(Color.parseColor(CHIP_BG[palette]));
        chip.setBackground(bg);
        TextView coin = text("\uD83E\uDE99", 13, "#1C1C1E", false);
        coin.setPadding(0, 0, dp(6), 0);
        chip.addView(coin);
        chip.addView(text(String.format(Locale.ENGLISH, "\u20B9%.2f", amount), 13, "#1C1C1E", true));
        return chip;
    }

    private TextView statusPill(String status) {
        String bg, fg, icon, label;
        switch (status) {
            case "PAID":
                bg = "#DFF5E8"; fg = "#1FAA59"; icon = "✓"; label = "PAID"; break;
            case "WIN":
                bg = "#EFE6FB"; fg = "#7C4FE0"; icon = "🏆"; label = "WIN"; break;
            case "CANCELLED":
                bg = "#ECECEE"; fg = "#8A8A8E"; icon = "✕"; label = "CANCELLED"; break;
            default:
                bg = "#E4EEFF"; fg = "#2F6FE4"; icon = "⏱"; label = "PENDING"; break;
        }
        TextView pill = text(icon + "  " + label, 12, fg, true);
        pill.setPadding(dp(16), dp(8), dp(16), dp(8));
        GradientDrawable pbg = new GradientDrawable();
        pbg.setCornerRadius(dp(18));
        pbg.setColor(Color.parseColor(bg));
        pill.setBackground(pbg);
        return pill;
    }

    private String formatDate(long millis) {
        if (millis <= 0) return "Date TBA";
        return new SimpleDateFormat("dd/MM/yyyy hh:mm a", Locale.ENGLISH).format(new Date(millis));
    }

    // =====================================================================
    // Shared helpers
    // =====================================================================

    private TextView text(String value, int sizeSp, String colorHex, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(sizeSp);
        t.setTextColor(Color.parseColor(colorHex));
        if (bold) t.setTypeface(null, Typeface.BOLD);
        return t;
    }

    private TextView pageText(String value) {
        TextView t = text(value, 12, statsMode ? "#68686D" : hex(R.color.text_secondary), false);
        t.setPadding(0, dp(4), 0, dp(4));
        return t;
    }

    private int dp(int value) { return Math.round(value * getResources().getDisplayMetrics().density); }

    @Override
    protected void onDestroy() {
        for (CountDownTimer timer : timers) timer.cancel();
        for (int i = 0; i < liveQueries.size(); i++) liveQueries.get(i).removeEventListener(liveListeners.get(i));
        super.onDestroy();
    }
}
