package com.arenax.tournament.fragment;


import com.arenax.tournament.util.FancyText;
import com.arenax.tournament.util.ImageLoader;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.arenax.tournament.R;
import com.arenax.tournament.MatchResultActivity;
import com.arenax.tournament.TournamentDetailActivity;
import com.arenax.tournament.adapter.TournamentAdapter;
import com.arenax.tournament.data.FirebaseRepository;
import com.arenax.tournament.model.Tournament;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class TournamentsFragment extends Fragment {
    private final List<Tournament> allTournaments = new ArrayList<>();
    private final List<Tournament> filtered = new ArrayList<>();
    private TournamentAdapter adapter;
    private ValueEventListener listener;
    private ValueEventListener showTimeListener;
    private final android.os.Handler showScheduleHandler = new android.os.Handler(android.os.Looper.getMainLooper());
    private DataSnapshot lastSnapshot;
    private String activeFilter = "ALL";
    private String activeCategoryId = "";
    private String query = "";
    private final List<TextView> filterPills = new ArrayList<>();
    // Ref 1 pro tabs: pills carry live counts, so their TextViews are kept as fields.
    private TextView chipOngoing, chipUpcoming, chipResulted;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_tournaments, container, false);
        if (!FirebaseRepository.isReady(requireContext())) {
            FancyText.toast(requireContext(),
                    "Live arena data is temporarily unavailable. Please try again.",
                    android.widget.Toast.LENGTH_LONG).show();
            return view;
        }        RecyclerView list = view.findViewById(R.id.tournament_list);
        list.setLayoutManager(new LinearLayoutManager(requireContext()));
        adapter = new TournamentAdapter(filtered, tournament -> {
            if (Tournament.COMPLETED.equals(tournament.getEffectiveStatus())) {
                // Resulted card -> VIEW RESULT shows the published leaderboard.
                Intent result = new Intent(requireContext(), MatchResultActivity.class);
                result.putExtra("tournamentId", tournament.getId());
                startActivity(result);
                return;
            }
            Intent intent = new Intent(requireContext(), TournamentDetailActivity.class);
            intent.putExtra("tournament", tournament);
            startActivity(intent);
        });
        list.setAdapter(adapter);
        EditText search = view.findViewById(R.id.tournament_search);
        search.addTextChangedListener(new android.text.TextWatcher() {
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                query = s == null ? "" : s.toString().trim().toLowerCase(java.util.Locale.ROOT);
                refreshFiltered();
            }
            public void afterTextChanged(android.text.Editable s) {}
        });

        TextView all = view.findViewById(R.id.chip_all);
        TextView upcoming = view.findViewById(R.id.chip_upcoming);
        TextView ongoing = view.findViewById(R.id.chip_ongoing);
        TextView completed = view.findViewById(R.id.chip_completed);
        chipOngoing = ongoing;
        chipUpcoming = upcoming;
        chipResulted = completed;
        filterPills.clear();
        Collections.addAll(filterPills, all, upcoming, ongoing, completed);
        // Remember each pill's English keyword now, before any translation touches its label.
        final java.util.Map<View, String> filterKeys = new java.util.HashMap<>();
        for (TextView pill : filterPills) {
            filterKeys.put(pill, FancyText.plain(pill.getText()).split(" ")[0]);
        }
        View.OnClickListener filterListener = v -> {
            // Pills carry live counts ("ONGOING 2") - the first word is the filter keyword.
            activeFilter = filterKeys.get(v);
            updatePillStyles((TextView) v);
            refreshFiltered();
        };
        for (TextView pill : filterPills) pill.setOnClickListener(filterListener);
        updatePillStyles(all);
        activeCategoryId = requireActivity().getIntent().getStringExtra("categoryId");
        if (activeCategoryId == null) activeCategoryId = "";
        listener = new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                if (!isAdded()) return;
                lastSnapshot = snapshot;
                allTournaments.clear();
                long nextShowAt = 0L;
                for (DataSnapshot child : snapshot.getChildren()) {
                    Object rawValue = child.getValue();
                    if (!(rawValue instanceof java.util.Map)) continue;
                    @SuppressWarnings("unchecked")
                    java.util.Map<String, Object> valueMap = (java.util.Map<String, Object>) rawValue;
                    Tournament tournament = Tournament.fromMap(child.getKey(), valueMap);
                    if (tournament != null && tournament.isActive() && !tournament.isDraft()
                            && !tournament.isVisibleBySchedule()) {
                        // "Show schedule" time not reached yet: hidden, remember the earliest one.
                        if (nextShowAt == 0L || tournament.getShowAt() < nextShowAt) nextShowAt = tournament.getShowAt();
                        continue;
                    }
                    if (tournament != null && tournament.isActive()
                            && !com.arenax.tournament.util.MatchShowTime.isHidden(tournament)) allTournaments.add(tournament);
                }
                showScheduleHandler.removeCallbacksAndMessages(null);
                if (nextShowAt > 0L) {
                    long delay = Math.max(500L, nextShowAt - System.currentTimeMillis() + 300L);
                    showScheduleHandler.postDelayed(() -> {
                        if (isAdded() && lastSnapshot != null && listener != null) listener.onDataChange(lastSnapshot);
                    }, delay);
                }
                Collections.sort(allTournaments,
                        Comparator.comparingLong(Tournament::getEffectiveStartAt));
                refreshFiltered();
                // Background: fetch match banners into the disk cache before the cards scroll in.
                java.util.List<String> bannerUrls = new java.util.ArrayList<>();
                for (Tournament t : allTournaments) bannerUrls.add(t.getBannerUrl());
                ImageLoader.preload(requireContext(), bannerUrls);
            }

            @Override
            public void onCancelled(DatabaseError error) {
                if (isAdded()) FancyText.toast(requireContext(),
                        "Live tournaments unavailable: " + error.getMessage(), android.widget.Toast.LENGTH_LONG).show();
            }
        };
        FirebaseRepository.tournaments().addValueEventListener(listener);
        // Admin "Match showing time" changed -> re-filter with the last snapshot.
        showTimeListener = com.arenax.tournament.util.MatchShowTime.listen(() -> {
            if (isAdded() && lastSnapshot != null) listener.onDataChange(lastSnapshot);
        });
        return view;
    }

    private void updatePillStyles(TextView selected) {
        for (TextView pill : filterPills) {
            boolean isSelected = pill == selected;
            pill.setBackgroundResource(isSelected ? R.drawable.bg_tab_active_red : R.drawable.bg_tab_inactive);
            pill.setTextColor(androidx.core.content.ContextCompat.getColor(requireContext(),
                    isSelected ? R.color.on_accent : R.color.text_primary));
        }
    }

    /** Ref 1 pro tabs: live counts on each filter pill (ONGOING n / UPCOMING n / RESULTED n). */
    private void updateChipCounts() {
        int ongoing = 0, upcoming = 0, resulted = 0;
        for (Tournament tournament : allTournaments) {
            String status = tournament.getEffectiveStatus();
            if (Tournament.ONGOING.equals(status)) ongoing++;
            else if (Tournament.COMPLETED.equals(status)) resulted++;
            else upcoming++;
        }
        if (chipOngoing != null) chipOngoing.setText("ONGOING " + ongoing);
        if (chipUpcoming != null) chipUpcoming.setText("UPCOMING " + upcoming);
        if (chipResulted != null) chipResulted.setText("RESULTED " + resulted);
    }

    private void refreshFiltered() {
        updateChipCounts();
        filtered.clear();
        for (Tournament tournament : allTournaments) {
            // Effective status (time-aware) so "RESULTED" shows COMPLETED matches and
            // "ONGOING" includes matches whose scheduled time has passed.
            boolean statusMatches = "ALL".equals(activeFilter)
                    || activeFilter.equalsIgnoreCase(tournament.getEffectiveStatus());
            boolean categoryMatches = activeCategoryId.isEmpty() || activeCategoryId.equals(tournament.getCategoryId());
            String searchable = (tournament.getTitle() + " " + tournament.getMode() + " "
                    + tournament.getMatchType()).toLowerCase(java.util.Locale.ROOT);
            boolean queryMatches = query.isEmpty() || searchable.contains(query);
            if (statusMatches && categoryMatches && queryMatches) filtered.add(tournament);
        }
        if (adapter != null) adapter.notifyDataSetChanged();
        View empty = getView() == null ? null : getView().findViewById(R.id.tournament_empty);
        if (empty != null) empty.setVisibility(filtered.isEmpty() ? View.VISIBLE : View.GONE);
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        if (listener != null) FirebaseRepository.tournaments().removeEventListener(listener);
        com.arenax.tournament.util.MatchShowTime.unlisten(showTimeListener);
        showScheduleHandler.removeCallbacksAndMessages(null);
    }
}