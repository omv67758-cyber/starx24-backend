package com.arenax.tournament.util;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.arenax.tournament.data.FirebaseRepository;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.Query;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/**
 * Owner-side FULL-SCREEN, detailed history of one admin key: every activity that admin did, with
 * date + time, grouped by day, filterable (All / Today / 7 days / 30 days), searchable, and each
 * row can be tapped to expand the complete details.
 *
 * Entries are matched by the key stored in the log (adminKey) and, for older entries, by the
 * auth uid of any session that signed in with this key (adminUid / backend actorUid).
 */
public final class AdminKeyHistory {

    private static final String INK = "#1C1C1E";
    private static final String MUTED = "#68686D";
    private static final String BLUE = "#2563EB";
    private static final String GREEN = "#059669";
    private static final String RED = "#DC2626";
    private static final String AMBER = "#D97706";
    private static final String PURPLE = "#7C3AED";

    // Work categories: har kaam apni alag category me dikhta hai (match / user / coins ...)
    private static final String[] CAT_NAMES = {"All", "Match", "User", "Coins & Withdraw", "Content", "Admin Keys", "Other"};
    private static final String[] CAT_COLORS = {BLUE, "#2563EB", "#7C3AED", "#D97706", "#059669", "#0F766E", "#68686D"};
    private static final String[] CAT_HINTS = {
            "",
            "Match / Tournament / Room / Result ka kaam",
            "User ban-unban, team, report, dispute ka kaam",
            "Coin request, deposit, withdrawal, manual coins",
            "Banner, announcement, FAQ, content, push",
            "Admin key banana / badalna / hatana",
            "Baaki activity"};

    private static final class Entry {
        String id, action, target, details, admin; long at; int cat;
    }

    /** Mutable screen state shared by the callbacks. */
    private static final class State {
        final List<Entry> all = new ArrayList<>();
        int periodDays = 0;          // 0 = all time, 1 = today, 7, 30
        int cat = 0;                 // 0 = All, else index in CAT_NAMES
        final List<TextView> catChips = new ArrayList<>();
        String query = "";
        String lastError = null;
        boolean loading = true;
    }

    private AdminKeyHistory() {}

    public static void show(Activity activity, String key, String label, String roleLabel) {
        final State st = new State();
        final String name = label == null || label.isEmpty() ? "Admin" : label;

        LinearLayout root = new LinearLayout(activity);
        root.setOrientation(LinearLayout.VERTICAL);

        // ---- header card: who + role + key ----
        LinearLayout head = card(activity, "#FFFFFF");
        head.addView(text(activity, name, 18, INK, true));
        head.addView(text(activity, roleLabel + "  \u2022  " + key, 12, MUTED, false));
        final TextView summary = text(activity, "Loading history...", 12, BLUE, true);
        summary.setPadding(0, dp(activity, 6), 0, 0);
        head.addView(summary);
        root.addView(head, matchWrap(activity, 0));

        // ---- stats row ----
        LinearLayout stats = new LinearLayout(activity);
        stats.setOrientation(LinearLayout.HORIZONTAL);
        final TextView sTotal = statCard(activity, stats, "Total", BLUE);
        final TextView sToday = statCard(activity, stats, "Today", GREEN);
        final TextView sWeek = statCard(activity, stats, "7 days", PURPLE);
        root.addView(stats, matchWrap(activity, 10));

        // ---- category tabs (Match / User / Coins ...) ----
        HorizontalScrollView catScroll = new HorizontalScrollView(activity);
        catScroll.setHorizontalScrollBarEnabled(false);
        LinearLayout catRow = new LinearLayout(activity);
        catRow.setOrientation(LinearLayout.HORIZONTAL);
        catScroll.addView(catRow);
        root.addView(catScroll, matchWrap(activity, 10));

        // ---- period filter chips ----
        HorizontalScrollView chipScroll = new HorizontalScrollView(activity);
        chipScroll.setHorizontalScrollBarEnabled(false);
        LinearLayout chips = new LinearLayout(activity);
        chips.setOrientation(LinearLayout.HORIZONTAL);
        chipScroll.addView(chips);
        root.addView(chipScroll, matchWrap(activity, 10));

        // ---- search ----
        final EditText search = new EditText(activity);
        search.setHint("Search action, target or details");
        search.setSingleLine(true);
        search.setTextSize(14);
        search.setTextColor(Color.parseColor(INK));
        search.setHintTextColor(Color.parseColor("#9A9AA0"));
        search.setBackground(round(activity, "#FFFFFF", 12, "#E5E3DE"));
        search.setPadding(dp(activity, 14), dp(activity, 10), dp(activity, 14), dp(activity, 10));
        root.addView(search, matchWrap(activity, 10));

        // ---- list ----
        final LinearLayout list = new LinearLayout(activity);
        list.setOrientation(LinearLayout.VERTICAL);
        root.addView(list, matchWrap(activity, 4));

        final Runnable[] rerender = new Runnable[1];
        rerender[0] = () -> render(activity, list, summary, sTotal, sToday, sWeek, st);

        for (int i = 0; i < CAT_NAMES.length; i++) {
            final int ci = i;
            TextView c = text(activity, CAT_NAMES[i], 13, MUTED, true);
            c.setGravity(Gravity.CENTER);
            c.setPadding(dp(activity, 14), dp(activity, 8), dp(activity, 14), dp(activity, 8));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.rightMargin = dp(activity, 8);
            catRow.addView(c, lp);
            st.catChips.add(c);
            c.setOnClickListener(v -> {
                st.cat = ci;
                rerender[0].run();
            });
        }

        final String[] chipNames = {"All time", "Today", "7 days", "30 days"};
        final int[] chipDays = {0, 1, 7, 30};
        final List<TextView> chipViews = new ArrayList<>();
        for (int i = 0; i < chipNames.length; i++) {
            final int days = chipDays[i];
            TextView c = text(activity, chipNames[i], 13, MUTED, true);
            c.setGravity(Gravity.CENTER);
            c.setPadding(dp(activity, 16), dp(activity, 8), dp(activity, 16), dp(activity, 8));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.rightMargin = dp(activity, 8);
            chips.addView(c, lp);
            chipViews.add(c);
            c.setOnClickListener(v -> {
                st.periodDays = days;
                styleChips(activity, chipViews, chipDays, st.periodDays);
                rerender[0].run();
            });
        }
        styleChips(activity, chipViews, chipDays, st.periodDays);

        search.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void afterTextChanged(Editable s) {
                st.query = s.toString().trim().toLowerCase(Locale.ENGLISH);
                rerender[0].run();
            }
        });

        // Full-screen page (back arrow + title + sticky CLOSE button)
        new FullScreenDialog.Builder(activity)
                .setTitle(name + " \u2022 History")
                .setView(root)
                .setPositiveButton("CLOSE", null)
                .show();

        rerender[0].run();
        load(activity, key, st, rerender[0]);
    }

    // ------------------------------------------------------------------ data

    private static void load(Activity activity, String key, State st, Runnable done) {
        final Map<String, Entry> merged = new HashMap<>();
        // 1) which auth uids ever signed in with this key
        FirebaseRepository.adminSessions().get().addOnSuccessListener(sessions -> {
            Set<String> uids = new HashSet<>();
            for (DataSnapshot s : sessions.getChildren()) {
                Object k = s.child("key").getValue();
                if (k != null && key.equals(String.valueOf(k))) uids.add(s.getKey());
            }
            List<Query> queries = new ArrayList<>();
            queries.add(FirebaseRepository.activityLogs().orderByChild("adminKey").equalTo(key).limitToLast(1000));
            for (String uid : uids) {
                queries.add(FirebaseRepository.activityLogs().orderByChild("adminUid").equalTo(uid).limitToLast(1000));
                queries.add(FirebaseRepository.activityLogs().orderByChild("actorUid").equalTo(uid).limitToLast(1000));
            }
            final int[] pending = {queries.size()};
            final String[] firstError = {null};
            for (Query q : queries) {
                q.get().addOnCompleteListener(task -> {
                    if (task.isSuccessful() && task.getResult() != null) {
                        for (DataSnapshot d : task.getResult().getChildren()) {
                            if (merged.containsKey(d.getKey())) continue;
                            Object logKey = d.child("adminKey").getValue();
                            // an entry tagged with a different key belongs to that key, not this one
                            if (logKey != null && !key.equals(String.valueOf(logKey))) continue;
                            merged.put(d.getKey(), read(d));
                        }
                    } else if (firstError[0] == null && task.getException() != null) {
                        firstError[0] = task.getException().getMessage();
                    }
                    if (--pending[0] == 0) {
                        st.all.clear();
                        st.all.addAll(merged.values());
                        Collections.sort(st.all, (x, y) -> Long.compare(y.at, x.at));
                        st.loading = false;
                        st.lastError = st.all.isEmpty() ? firstError[0] : null;
                        if (!activity.isFinishing() && !activity.isDestroyed()) done.run();
                    }
                });
            }
        }).addOnFailureListener(e -> {
            st.loading = false;
            st.lastError = e.getMessage();
            if (!activity.isFinishing() && !activity.isDestroyed()) done.run();
        });
    }

    private static Entry read(DataSnapshot d) {
        Entry e = new Entry();
        e.id = d.getKey();
        e.action = str(d.child("action").getValue());
        e.target = str(d.child("target").getValue());
        e.details = str(d.child("details").getValue());
        e.admin = str(d.child("admin").getValue());
        e.cat = catOf(e.action);
        Object at = d.child("timestamp").getValue();
        if (!(at instanceof Number)) at = d.child("at").getValue();
        e.at = at instanceof Number ? ((Number) at).longValue() : 0L;
        return e;
    }

    // ---------------------------------------------------------------- render

    private static void render(Activity a, LinearLayout list, TextView summary,
                               TextView sTotal, TextView sToday, TextView sWeek, State st) {
        if (a.isFinishing() || a.isDestroyed()) return;
        list.removeAllViews();

        if (st.loading) {
            summary.setText("Loading history...");
            sTotal.setText("-"); sToday.setText("-"); sWeek.setText("-");
            return;
        }
        if (st.lastError != null) {
            summary.setText("History unavailable");
            sTotal.setText("-"); sToday.setText("-"); sWeek.setText("-");
            boolean perm = st.lastError.toLowerCase(Locale.ENGLISH).contains("permission");
            list.addView(text(a, st.lastError + (perm
                    ? "\n\nDatabase rules update nahi hui hai. database.rules.json ko Firebase me publish karo "
                    + "(deploy_rules.sh), phir ye page dobara kholo."
                    : ""), 13, RED, false));
            return;
        }

        long startToday = startOfDay(0);
        long start7 = startOfDay(6);
        int today = 0, week = 0;
        for (Entry e : st.all) {
            if (e.at >= startToday) today++;
            if (e.at >= start7) week++;
        }
        sTotal.setText(String.valueOf(st.all.size()));
        sToday.setText(String.valueOf(today));
        sWeek.setText(String.valueOf(week));

        long since = st.periodDays == 0 ? 0L : startOfDay(st.periodDays - 1);
        List<Entry> rows = new ArrayList<>();
        for (Entry e : st.all) {
            if (since > 0 && e.at < since) continue;
            if (!st.query.isEmpty()) {
                String hay = (e.action + " " + e.target + " " + e.details + " " + e.admin)
                        .toLowerCase(Locale.ENGLISH);
                if (!hay.contains(st.query)) continue;
            }
            rows.add(e);
        }

        int[] catCount = new int[CAT_NAMES.length];
        for (Entry e : rows) { catCount[0]++; catCount[e.cat]++; }
        for (int i = 0; i < st.catChips.size(); i++) {
            TextView c = st.catChips.get(i);
            boolean on = st.cat == i;
            c.setText(CAT_NAMES[i] + " " + catCount[i]);
            c.setTextColor(Color.parseColor(on ? "#FFFFFF" : CAT_COLORS[i]));
            c.setBackground(on ? round(a, CAT_COLORS[i], 20, null) : round(a, "#FFFFFF", 20, CAT_COLORS[i]));
        }

        if (st.all.isEmpty()) {
            summary.setText("Koi activity nahi");
            list.addView(text(a, "Is admin ne abhi tak koi activity nahi ki.", 13, MUTED, false));
            return;
        }
        summary.setText(st.all.size() + " activities  \u2022  last: " + fmt(st.all.get(0).at)
                + (st.all.get(st.all.size() - 1).at > 0
                ? "  \u2022  first: " + fmt(st.all.get(st.all.size() - 1).at) : ""));
        if (rows.isEmpty()) {
            list.addView(text(a, "Is filter me koi activity nahi mili.", 13, MUTED, false));
            return;
        }

        if (st.cat == 0) {
            // ALL: har category ka alag section
            for (int c = 1; c < CAT_NAMES.length; c++) addSection(a, list, c, rows, true);
        } else {
            addSection(a, list, st.cat, rows, false);
        }
    }

    /** One category block: coloured header + per-action counts + day-wise rows. */
    private static void addSection(Activity a, LinearLayout list, int cat, List<Entry> rows, boolean showEmpty) {
        List<Entry> sub = new ArrayList<>();
        for (Entry e : rows) if (e.cat == cat) sub.add(e);
        if (sub.isEmpty()) {
            if (!showEmpty) list.addView(text(a, CAT_NAMES[cat] + " me is filter me koi activity nahi mili.", 13, MUTED, false));
            return;
        }
        String color = CAT_COLORS[cat];

        LinearLayout box = card(a, "#FFFFFF");
        box.setBackground(round(a, "#FFFFFF", 16, color));
        box.addView(text(a, CAT_NAMES[cat].toUpperCase(Locale.ENGLISH) + "  \u2022  " + sub.size(), 15, color, true));
        box.addView(text(a, CAT_HINTS[cat], 11, MUTED, false));
        // per-action breakdown, e.g. "Match created x3  \u2022  Match edited x5"
        Map<String, Integer> counts = new java.util.LinkedHashMap<>();
        for (Entry e : sub) {
            String k = pretty(e.action);
            Integer n = counts.get(k);
            counts.put(k, n == null ? 1 : n + 1);
        }
        StringBuilder sb = new StringBuilder();
        for (Map.Entry<String, Integer> en : counts.entrySet()) {
            if (sb.length() > 0) sb.append("\n");
            sb.append("\u2022 ").append(en.getKey()).append("  \u00D7").append(en.getValue());
        }
        TextView br = text(a, sb.toString(), 12, INK, false);
        br.setPadding(0, dp(a, 8), 0, 0);
        box.addView(br);
        list.addView(box, matchWrap(a, 16));

        SimpleDateFormat dayFmt = new SimpleDateFormat("EEE, dd MMM yyyy", Locale.ENGLISH);
        SimpleDateFormat timeFmt = new SimpleDateFormat("hh:mm:ss a", Locale.ENGLISH);
        Map<String, Integer> perDay = new HashMap<>();
        for (Entry e : sub) {
            String d = e.at > 0 ? dayFmt.format(new Date(e.at)) : "Unknown date";
            Integer n = perDay.get(d);
            perDay.put(d, n == null ? 1 : n + 1);
        }
        String lastDay = "";
        for (Entry e : sub) {
            String day = e.at > 0 ? dayFmt.format(new Date(e.at)) : "Unknown date";
            if (!day.equals(lastDay)) {
                lastDay = day;
                TextView h = text(a, day + "  \u2022  " + perDay.get(day), 13, color, true);
                h.setPadding(0, dp(a, 12), 0, dp(a, 2));
                list.addView(h);
            }
            list.addView(buildRow(a, e, timeFmt));
        }
    }

    private static int catOf(String action) {
        String s = action == null ? "" : action.toUpperCase(Locale.ENGLISH);
        if (s.startsWith("COIN_REQUEST") || s.startsWith("DEPOSIT") || s.startsWith("WITHDRAW")
                || s.startsWith("MANUAL_COINS") || s.equals("MATCH_COINS_CREDITED")
                || s.equals("TOURNAMENT_SETTLED")) return 3;
        if (s.startsWith("USER_") || s.startsWith("TEAM_") || s.equals("MATCH_LEFT")
                || s.startsWith("REPORT_") || s.startsWith("DISPUTE_")) return 2;
        if (s.startsWith("MATCH") || s.startsWith("ROOM_") || s.startsWith("KILLS")
                || s.startsWith("RESULT_") || s.startsWith("TOURNAMENT") || s.startsWith("WAITLIST")
                || s.startsWith("CATEGORY")) return 1;
        if (s.startsWith("BANNER") || s.startsWith("ANNOUNCEMENT") || s.startsWith("FAQ")
                || s.startsWith("CONTENT") || s.equals("ADMIN_PUSH")) return 4;
        if (s.startsWith("ADMIN_KEY")) return 5;
        return 6;
    }

    private static View buildRow(Activity a, Entry e, SimpleDateFormat timeFmt) {
        final String color = actionColor(e.action);
        LinearLayout row = new LinearLayout(a);
        row.setOrientation(LinearLayout.VERTICAL);
        row.setPadding(dp(a, 14), dp(a, 12), dp(a, 14), dp(a, 12));
        row.setBackground(round(a, "#FFFFFF", 14, "#E5E3DE"));
        row.setLayoutParams(matchWrap(a, 8));

        // top line: colored action badge + time
        LinearLayout top = new LinearLayout(a);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        TextView badge = text(a, pretty(e.action), 12, "#FFFFFF", true);
        badge.setPadding(dp(a, 10), dp(a, 4), dp(a, 10), dp(a, 4));
        badge.setBackground(round(a, color, 20, null));
        top.addView(badge, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        View spacer = new View(a);
        top.addView(spacer, new LinearLayout.LayoutParams(0, 1, 1f));
        top.addView(text(a, e.at > 0 ? timeFmt.format(new Date(e.at)) : "-", 12, MUTED, true));
        row.addView(top);

        if (!e.target.isEmpty()) {
            TextView t = text(a, e.target, 14, INK, true);
            t.setPadding(0, dp(a, 8), 0, 0);
            row.addView(t);
        }
        if (!e.details.isEmpty()) {
            final TextView d = text(a, e.details, 13, "#3A3A3C", false);
            d.setPadding(0, dp(a, 4), 0, 0);
            d.setMaxLines(3);
            d.setEllipsize(android.text.TextUtils.TruncateAt.END);
            row.addView(d);

            // expandable extra info
            final TextView more = text(a, buildMore(e), 11, MUTED, false);
            more.setPadding(0, dp(a, 8), 0, 0);
            more.setVisibility(View.GONE);
            row.addView(more);
            final TextView hint = text(a, "Tap for full details", 11, BLUE, true);
            hint.setPadding(0, dp(a, 6), 0, 0);
            row.addView(hint);
            row.setOnClickListener(v -> {
                boolean open = more.getVisibility() == View.VISIBLE;
                more.setVisibility(open ? View.GONE : View.VISIBLE);
                d.setMaxLines(open ? 3 : Integer.MAX_VALUE);
                d.setEllipsize(open ? android.text.TextUtils.TruncateAt.END : null);
                hint.setText(open ? "Tap for full details" : "Tap to collapse");
            });
        } else {
            TextView more = text(a, buildMore(e), 11, MUTED, false);
            more.setPadding(0, dp(a, 6), 0, 0);
            row.addView(more);
        }
        return row;
    }

    private static String buildMore(Entry e) {
        StringBuilder sb = new StringBuilder();
        if (e.at > 0) sb.append(new SimpleDateFormat("dd MMM yyyy, hh:mm:ss a", Locale.ENGLISH).format(new Date(e.at)));
        if (!e.admin.isEmpty() && !"unknown".equals(e.admin)) {
            if (sb.length() > 0) sb.append("\n");
            sb.append("Signed in as: ").append(e.admin);
        }
        if (e.id != null && !e.id.isEmpty()) {
            if (sb.length() > 0) sb.append("\n");
            sb.append("Log ID: ").append(e.id);
        }
        return sb.toString();
    }

    // --------------------------------------------------------------- helpers

    private static String actionColor(String action) {
        String s = action.toUpperCase(Locale.ENGLISH);
        if (s.contains("DELETE") || s.contains("REMOVE") || s.contains("REJECT") || s.contains("BAN")
                || s.contains("REVOKE") || s.contains("CANCEL") || s.contains("CLEAR")) return RED;
        if (s.contains("APPROVE") || s.contains("CREATE") || s.contains("ADD") || s.contains("PUBLISH")
                || s.contains("RELEASE") || s.contains("GENERATE") || s.contains("PAID")) return GREEN;
        if (s.contains("UPDATE") || s.contains("EDIT") || s.contains("CHANGE") || s.contains("SET")) return BLUE;
        if (s.contains("COIN") || s.contains("WITHDRAW") || s.contains("PAYMENT")) return AMBER;
        return PURPLE;
    }

    private static void styleChips(Activity a, List<TextView> views, int[] days, int selected) {
        for (int i = 0; i < views.size(); i++) {
            boolean on = days[i] == selected;
            TextView c = views.get(i);
            c.setTextColor(Color.parseColor(on ? "#FFFFFF" : MUTED));
            c.setBackground(on ? round(a, BLUE, 20, null) : round(a, "#FFFFFF", 20, "#E5E3DE"));
        }
    }

    private static TextView statCard(Activity a, LinearLayout parent, String label, String color) {
        LinearLayout box = new LinearLayout(a);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER);
        box.setPadding(dp(a, 8), dp(a, 12), dp(a, 8), dp(a, 12));
        box.setBackground(round(a, "#FFFFFF", 14, "#E5E3DE"));
        TextView num = text(a, "-", 22, color, true);
        num.setGravity(Gravity.CENTER);
        TextView lab = text(a, label, 11, MUTED, false);
        lab.setGravity(Gravity.CENTER);
        box.addView(num);
        box.addView(lab);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        if (parent.getChildCount() > 0) lp.setMarginStart(dp(a, 8));
        parent.addView(box, lp);
        return num;
    }

    private static LinearLayout card(Activity a, String bg) {
        LinearLayout c = new LinearLayout(a);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(a, 16), dp(a, 14), dp(a, 16), dp(a, 14));
        c.setBackground(round(a, bg, 16, "#E5E3DE"));
        return c;
    }

    private static LinearLayout.LayoutParams matchWrap(Activity a, int topDp) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(a, topDp);
        return lp;
    }

    private static GradientDrawable round(Activity a, String fill, int radiusDp, String stroke) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(Color.parseColor(fill));
        g.setCornerRadius(dp(a, radiusDp));
        if (stroke != null) g.setStroke(dp(a, 1), Color.parseColor(stroke));
        return g;
    }

    private static long startOfDay(int daysAgo) {
        Calendar c = Calendar.getInstance();
        c.set(Calendar.HOUR_OF_DAY, 0);
        c.set(Calendar.MINUTE, 0);
        c.set(Calendar.SECOND, 0);
        c.set(Calendar.MILLISECOND, 0);
        c.add(Calendar.DAY_OF_YEAR, -daysAgo);
        return c.getTimeInMillis();
    }

    private static String pretty(String action) {
        if (action.isEmpty()) return "Activity";
        String s = action.replace('_', ' ').toLowerCase(Locale.ENGLISH);
        return Character.toUpperCase(s.charAt(0)) + s.substring(1);
    }

    private static String fmt(long at) {
        return at <= 0 ? "-" : new SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.ENGLISH).format(new Date(at));
    }

    private static TextView text(Activity a, String s, int sp, String color, boolean bold) {
        TextView t = new TextView(a);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(Color.parseColor(color));
        t.setGravity(Gravity.START);
        if (bold) t.setTypeface(t.getTypeface(), Typeface.BOLD);
        return t;
    }

    private static int dp(Activity a, int v) {
        return Math.round(v * a.getResources().getDisplayMetrics().density);
    }

    private static String str(Object o) { return o == null ? "" : String.valueOf(o); }
}
