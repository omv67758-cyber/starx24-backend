package com.arenax.tournament.util;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.Typeface;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * In-app language selection (player app, Profile -> Language).
 *
 * English + every Indian / global language that translates on-device without an API key. The chosen language is stored in
 * SharedPreferences, applied as the app Locale (RTL for Urdu/Arabic/...) and the text shown on
 * screen is translated by {@link AppTranslator}.
 */
public final class LanguageManager {

    public static final class Lang {
        public final String code;        // app + translation code (ML Kit / Google Translate)
        public final String localeTag;   // Android Locale tag
        public final String nativeName;
        public final String englishName;
        public final boolean rtl;

        Lang(String code, String localeTag, String nativeName, String englishName, boolean rtl) {
            this.code = code;
            this.localeTag = localeTag;
            this.nativeName = nativeName;
            this.englishName = englishName;
            this.rtl = rtl;
        }
    }

    private static final String PREFS = "starx_language";
    private static final String KEY = "code";
    private static final List<Lang> ALL = new ArrayList<>();

    private static volatile String current = "en";
    private static volatile String saved = null;
    private static volatile boolean loaded = false;
    private static volatile int version = 0;

    private static void add(String code, String tag, String nativeName, String english, boolean rtl) {
        // Languages that would need a Google Translate API key (Odia, Punjabi, Assamese, Malayalam,
        // Maithili, Sanskrit, Nepali, Sindhi, Dogri, Konkani, Manipuri, Sinhala, Burmese, Khmer)
        // are not offered: only free on-device (ML Kit) languages are listed.
        if (!AppTranslator.worksWithoutApiKey(code)) return;
        ALL.add(new Lang(code, tag, nativeName, english, rtl));
    }

    static {
        add("en", "en", "English", "English", false);
        // ---- India ----
        add("hi", "hi", "हिन्दी", "Hindi", false);
        add("bn", "bn", "বাংলা", "Bengali", false);
        add("te", "te", "తెలుగు", "Telugu", false);
        add("mr", "mr", "मराठी", "Marathi", false);
        add("ta", "ta", "தமிழ்", "Tamil", false);
        add("ur", "ur", "اردو", "Urdu", true);
        add("gu", "gu", "ગુજરાતી", "Gujarati", false);
        add("kn", "kn", "ಕನ್ನಡ", "Kannada", false);
        add("ml", "ml", "മലയാളം", "Malayalam", false);
        add("or", "or", "ଓଡ଼ିଆ", "Odia", false);
        add("pa", "pa", "ਪੰਜਾਬੀ", "Punjabi", false);
        add("as", "as", "অসমীয়া", "Assamese", false);
        add("mai", "mai", "मैथिली", "Maithili", false);
        add("sa", "sa", "संस्कृतम्", "Sanskrit", false);
        add("ne", "ne", "नेपाली", "Nepali", false);
        add("sd", "sd", "سنڌي", "Sindhi", true);
        add("doi", "doi", "डोगरी", "Dogri", false);
        add("gom", "kok", "कोंकणी", "Konkani", false);
        add("mni-Mtei", "mni", "ꯃꯦꯇꯦꯏꯂꯣꯟ", "Meiteilon (Manipuri)", false);
        // ---- World ----
        add("es", "es", "Español", "Spanish", false);
        add("fr", "fr", "Français", "French", false);
        add("de", "de", "Deutsch", "German", false);
        add("pt", "pt", "Português", "Portuguese", false);
        add("it", "it", "Italiano", "Italian", false);
        add("ru", "ru", "Русский", "Russian", false);
        add("ar", "ar", "العربية", "Arabic", true);
        add("zh", "zh", "中文", "Chinese", false);
        add("ja", "ja", "日本語", "Japanese", false);
        add("ko", "ko", "한국어", "Korean", false);
        add("tr", "tr", "Türkçe", "Turkish", false);
        add("id", "in", "Bahasa Indonesia", "Indonesian", false);
        add("ms", "ms", "Bahasa Melayu", "Malay", false);
        add("th", "th", "ไทย", "Thai", false);
        add("vi", "vi", "Tiếng Việt", "Vietnamese", false);
        add("fa", "fa", "فارسی", "Persian", true);
        add("he", "iw", "עברית", "Hebrew", true);
        add("nl", "nl", "Nederlands", "Dutch", false);
        add("pl", "pl", "Polski", "Polish", false);
        add("uk", "uk", "Українська", "Ukrainian", false);
        add("ro", "ro", "Română", "Romanian", false);
        add("el", "el", "Ελληνικά", "Greek", false);
        add("cs", "cs", "Čeština", "Czech", false);
        add("sv", "sv", "Svenska", "Swedish", false);
        add("da", "da", "Dansk", "Danish", false);
        add("fi", "fi", "Suomi", "Finnish", false);
        add("no", "nb", "Norsk", "Norwegian", false);
        add("hu", "hu", "Magyar", "Hungarian", false);
        add("bg", "bg", "Български", "Bulgarian", false);
        add("hr", "hr", "Hrvatski", "Croatian", false);
        add("sk", "sk", "Slovenčina", "Slovak", false);
        add("sl", "sl", "Slovenščina", "Slovenian", false);
        add("sw", "sw", "Kiswahili", "Swahili", false);
        add("af", "af", "Afrikaans", "Afrikaans", false);
        add("tl", "fil", "Filipino", "Filipino (Tagalog)", false);
        add("si", "si", "සිංහල", "Sinhala", false);
        add("my", "my", "မြန်မာ", "Burmese", false);
        add("km", "km", "ខ្មែរ", "Khmer", false);
        add("sq", "sq", "Shqip", "Albanian", false);
        add("ca", "ca", "Català", "Catalan", false);
    }

    private LanguageManager() {}

    // ------------------------------------------------------------------ state

    public static void init(Context ctx) {
        if (loaded) return;
        SharedPreferences p = ctx.getApplicationContext() == null
                ? ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                : ctx.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        String c = p.getString(KEY, null);
        if (c != null && find(c) == null) c = null;
        saved = c;
        current = c == null ? "en" : c;
        loaded = true;
    }

    public static List<Lang> all() { return ALL; }

    public static Lang find(String code) {
        if (code == null) return null;
        for (Lang l : ALL) if (l.code.equals(code)) return l;
        return null;
    }

    /** Current language code, "en" when the user never picked one. */
    public static String code() { return current; }

    public static boolean isTranslating() { return !"en".equals(current); }

    public static int version() { return version; }

    public static String currentLabel(Context ctx) {
        init(ctx);
        Lang l = find(current);
        return l == null ? "English" : l.nativeName;
    }

    public static void setLanguage(Context ctx, String code) {
        init(ctx);
        Context app = ctx.getApplicationContext() == null ? ctx : ctx.getApplicationContext();
        app.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, code).apply();
        saved = code;
        current = code;
        version++;
        AppTranslator.onLanguageChanged();
    }

    /** Applies the saved Locale (layout direction included) to a base context. */
    public static Context wrap(Context base) {
        init(base);
        String c = saved;
        Lang l = find(c);
        if (l == null) return base;
        Locale loc = Locale.forLanguageTag(l.localeTag);
        Locale.setDefault(loc);
        Configuration cfg = new Configuration(base.getResources().getConfiguration());
        cfg.setLocale(loc);
        cfg.setLayoutDirection(loc);
        return base.createConfigurationContext(cfg);
    }

    // ------------------------------------------------------------------ picker

    /** Opens the full-screen language page. */
    public static void showPicker(final Activity act) {
        init(act);
        act.startActivity(new android.content.Intent(act, com.arenax.tournament.LanguageActivity.class));
    }

    /** Called when the user taps a language on the language page. */
    public static void choose(final Activity act, final Lang l) {
        if (l.code.equals(current)) return;
        if (!AppTranslator.isSupported(l.code)) {
            FancyText.toast(act, l.englishName + " needs a Google Translate API key "
                    + "(translate.api.key in local.properties).", Toast.LENGTH_LONG).show();
            return;
        }
        if ("en".equals(l.code)) {
            applyAndRestart(act, l);
            return;
        }
        final androidx.appcompat.app.AlertDialog wait = new FancyText.AppCompatBuilder(act)
                .setMessage("Preparing " + l.englishName + "... (first time needs internet)")
                .setCancelable(false)
                .create();
        wait.show();
        AppTranslator.prepare(l.code, ok -> {
            if (act.isFinishing()) return;
            try { wait.dismiss(); } catch (RuntimeException ignored) { }
            if (ok) {
                applyAndRestart(act, l);
            } else {
                FancyText.toast(act, "Could not prepare the language. Check your internet and try again.",
                        Toast.LENGTH_LONG).show();
            }
        });
    }

    private static void applyAndRestart(Activity act, Lang l) {
        setLanguage(act, l.code);
        if (act instanceof com.arenax.tournament.LanguageActivity) {
            act.finish(); // back to Profile, which rebuilds itself in the new language
        } else {
            act.recreate();
        }
    }
}
