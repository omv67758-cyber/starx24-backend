package com.arenax.tournament;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;

/**
 * The 🪙 emoji coin used across the app. In layouts it is a plain TextView with
 * the emoji; where a Drawable is required (ImageView.setImageDrawable,
 * TextView compound drawables) use {@link #drawable(Context, int)}.
 */
public final class CoinEmoji {
    public static final String EMOJI = "\uD83E\uDE99"; // 🪙

    private CoinEmoji() { }

    public static Drawable drawable(Context context, int sizeDp) {
        int px = Math.max(1, Math.round(sizeDp * context.getResources().getDisplayMetrics().density));
        Bitmap bitmap = Bitmap.createBitmap(px, px, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        paint.setTextSize(px * 0.85f);
        paint.setTextAlign(Paint.Align.CENTER);
        Paint.FontMetrics fm = paint.getFontMetrics();
        float baseline = px / 2f - (fm.ascent + fm.descent) / 2f;
        canvas.drawText(EMOJI, px / 2f, baseline, paint);
        return new BitmapDrawable(context.getResources(), bitmap);
    }
}
