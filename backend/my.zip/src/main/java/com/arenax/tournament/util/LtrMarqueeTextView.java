package com.arenax.tournament.util;

import android.content.Context;
import android.graphics.Canvas;
import android.os.SystemClock;
import android.util.AttributeSet;
import android.widget.TextView;

/**
 * Single-line text that continuously scrolls from LEFT to RIGHT.
 * The text enters from the left edge, travels across and leaves from the right edge, then repeats.
 */
public class LtrMarqueeTextView extends TextView {

    private static final float SPEED_DP_PER_SEC = 55f;
    private static final float GAP_DP = 24f;

    private float offset = Float.NaN;
    private long lastFrame = 0L;
    private final float speedPx;
    private final float gapPx;

    public LtrMarqueeTextView(Context context) { this(context, null); }

    public LtrMarqueeTextView(Context context, AttributeSet attrs) { this(context, attrs, android.R.attr.textViewStyle); }

    public LtrMarqueeTextView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        float d = context.getResources().getDisplayMetrics().density;
        speedPx = SPEED_DP_PER_SEC * d;
        gapPx = GAP_DP * d;
        setSingleLine(true);
    }

    @Override
    protected void onTextChanged(CharSequence text, int start, int lengthBefore, int lengthAfter) {
        super.onTextChanged(text, start, lengthBefore, lengthAfter);
        offset = Float.NaN; // restart from the left edge for new text
        lastFrame = 0L;
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        lastFrame = 0L;
        postInvalidateOnAnimation();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        CharSequence cs = getText();
        if (cs == null || cs.length() == 0) return;
        String text = cs.toString();

        int left = getPaddingLeft();
        int right = getWidth() - getPaddingRight();
        float avail = right - left;
        if (avail <= 0) return;

        getPaint().setColor(getCurrentTextColor());
        float textW = getPaint().measureText(text);

        if (Float.isNaN(offset)) offset = -textW;

        long now = SystemClock.uptimeMillis();
        if (lastFrame == 0L) lastFrame = now;
        long dt = Math.min(now - lastFrame, 50L);
        lastFrame = now;
        offset += speedPx * dt / 1000f;
        if (offset > avail + gapPx) offset = -textW - gapPx; // wrap: re-enter from the left

        canvas.save();
        canvas.clipRect(left, 0, right, getHeight());
        canvas.drawText(text, left + offset, getBaseline(), getPaint());
        canvas.restore();

        postInvalidateOnAnimation();
    }
}
