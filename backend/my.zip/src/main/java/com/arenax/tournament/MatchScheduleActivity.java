package com.arenax.tournament;


import com.arenax.tournament.util.FancyText;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.arenax.tournament.data.FirebaseRepository;
import com.arenax.tournament.data.ImgBbUploader;
import com.arenax.tournament.data.StorageUploader;
import com.arenax.tournament.model.Tournament;
import com.google.android.material.button.MaterialButton;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

/**
 * Full-screen match scheduling console (replaces the old floating "Add match" dialog).
 *
 * Everything about the match economy is REAL here, not demo:
 *  - "Entry coins" is the exact amount the backend's /joinMatch debits from the player's
 *    real wallet balance (users/<uid>/wallet/balance) the moment they join, and the amount
 *    /leaveMatch refunds. The wallet itself is topped up through real ZapUPI transactions
 *    (WalletActivity -> ZapUpiClient.createOrder/verifyOrder).
 *  - "Per kill coins" is the multiplier the results pipeline uses to build each player's
 *    coin request (kills x perKillCoins) which credits real coins after approval.
 *  - The schedule below is stored as an exact epoch timestamp, so player countdowns,
 *    room release and status flips are real-time.
 */
public class MatchScheduleActivity extends BaseActivity {

    private static final int REQ_MATCH_IMAGE = 8101;

    private String categoryId = "";
    private String categoryTitle = "CATEGORY";

    private Uri selectedImage;
    private ImageView preview;
    private EditText imageUrlField, titleField, dateField, timeField, prizeField, prizePoolField,
            entryFeeField, perKillField, gameTypeField, slotsField, teamSizeField, matchTypeField,
            mapField, descriptionField, rulesField, roomField;
    private long pickedAt = 0L;
    /** "Show schedule": when players start seeing this match in their category list (0 = immediately). */
    private long showAtMillis = 0L;
    private final Calendar showSchedule = Calendar.getInstance();
    private boolean showDateChosen, showTimeChosen;
    private EditText showDateField, showTimeField;
    private final Calendar schedule = Calendar.getInstance();
    private boolean dateChosen, timeChosen;
    private MaterialButton saveButton;
    /** KILL (full map), BATTLE_1V1, TEAM or SURVIVAL - chosen in the Add Match chooser. */
    private String matchSystem = "KILL";
    private EditText rankPrizeField;
    /** Daily mode: ON = this match re-appears every day at the same time, forever. */
    private android.widget.Switch dailySwitch;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        String id = getIntent().getStringExtra("categoryId");
        if (id != null) categoryId = id;
        String title = getIntent().getStringExtra("categoryTitle");
        if (title != null && !title.trim().isEmpty()) categoryTitle = title;
        String system = getIntent().getStringExtra("matchSystem");
        if ("BATTLE_1V1".equals(system) || "TEAM".equals(system) || "SURVIVAL".equals(system)) matchSystem = system;
        buildScreen();
    }

    private String systemTitle() {
        switch (matchSystem) {
            case "BATTLE_1V1": return "1 vs 1 Battle";
            case "TEAM": return "Team Match";
            case "SURVIVAL": return "Survival Match";
            default: return "Full Map (Kill) Match";
        }
    }

    private String systemRule() {
        switch (matchSystem) {
            case "BATTLE_1V1":
                return "1v1: Result Rank & Leaderboard me dono players ke coins khud daalo (manual) aur publish karo. "
                        + "Jise jitne coins dene hain utne type karo.";
            case "TEAM":
                return "Team match: Result me har team ko rank number do (1, 2, 3...). Leaderboard khud ban jayega "
                        + "aur team ke rank ke hisaab se coins milenge (team ke members me barabar).";
            case "SURVIVAL":
                return "Survival: Kill nahi, last tak survive karne par coins. Last 10 team ko paise milenge - "
                        + "1st, 2nd, 3rd ko zyada aur baaki ko kam.";
            default:
                return "Full map: Sabhi players ke naam leaderboard me aayenge, har player ke saamne kill daalo - "
                        + "coins = kills x per kill coins.";
        }
    }

    private void buildScreen() {
        getWindow().setStatusBarColor(Color.WHITE);
        getWindow().setNavigationBarColor(Color.WHITE);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.WHITE);
        // top inset is handled once by BaseActivity

        // ---- header ----
        LinearLayout top = new LinearLayout(this);
        top.setPadding(dp(16), dp(16), dp(16), dp(12));
        top.setGravity(Gravity.CENTER_VERTICAL);
        TextView back = label("‹", 28, Color.rgb(18,31,55), true);
        back.setOnClickListener(v -> finish());
        top.addView(back, new LinearLayout.LayoutParams(dp(40), dp(52)));
        LinearLayout heading = new LinearLayout(this);
        heading.setOrientation(LinearLayout.VERTICAL);
        TextView addMatchTitle = label("Add Match", 21, Color.rgb(18,31,55), true);
        addMatchTitle.setTag("nofancy");
        addMatchTitle.setText(com.arenax.tournament.util.FancyText.heading("Add Match"));
        addMatchTitle.setLetterSpacing(0.01f);
        heading.addView(addMatchTitle);
        top.addView(heading, new LinearLayout.LayoutParams(0, -2, 1));
        root.addView(top, new LinearLayout.LayoutParams(-1, -2));

        // ---- form ----
        LinearLayout form = new LinearLayout(this);
        form.setOrientation(LinearLayout.VERTICAL);
        form.setPadding(dp(16), dp(4), dp(16), dp(16));

        TextView typeBadge = label("MATCH TYPE:  " + systemTitle().toUpperCase(Locale.ROOT), 13, Color.rgb(18, 31, 55), true);
        typeBadge.setPadding(dp(12), dp(10), dp(12), dp(10));
        typeBadge.setBackgroundResource(R.drawable.bg_card_dark_outline);
        form.addView(typeBadge);
        form.addView(note(systemRule()));

        form.addView(sectionLabel("MATCH IMAGE"));
        MaterialButton chooseImage = primaryButton("SELECT PNG/JPG FROM DEVICE", dp(48));
        chooseImage.setOnClickListener(v -> chooseImage());
        LinearLayout.LayoutParams chooseParams = new LinearLayout.LayoutParams(-1, dp(48));
        chooseParams.topMargin = dp(6);
        chooseParams.bottomMargin = dp(10);
        chooseImage.setLayoutParams(chooseParams);
        form.addView(chooseImage);

        preview = new ImageView(this);
        preview.setLayoutParams(new LinearLayout.LayoutParams(-1, dp(112)));
        preview.setScaleType(ImageView.ScaleType.CENTER_CROP);
        preview.setBackgroundResource(R.drawable.bg_input_dark_outline);
        form.addView(preview);

        imageUrlField = field("Or paste image URL instead");
        form.addView(imageUrlField);

        form.addView(sectionLabel("MATCH NAME"));
        titleField = field("Match name");
        form.addView(titleField);

        form.addView(sectionLabel("REAL-TIME SCHEDULE"));
        dateField = field("Tap to pick date");
        timeField = field("Tap to pick time");
        dateField.setFocusable(false); dateField.setClickable(true);
        timeField.setFocusable(false); timeField.setClickable(true);
        dateField.setOnClickListener(v -> pickDate());
        timeField.setOnClickListener(v -> pickTime());
        form.addView(row(dateField, timeField));
        form.addView(note("Exact date + time save hota hai, isliye player side countdown aur room"
                + " release real-time chalta hai."));

        form.addView(sectionLabel("SHOW SCHEDULE (OPTIONAL)"));
        showDateField = field("Show date");
        showTimeField = field("Show time");
        showDateField.setFocusable(false); showDateField.setClickable(true);
        showTimeField.setFocusable(false); showTimeField.setClickable(true);
        showDateField.setOnClickListener(v -> pickShowDate());
        showTimeField.setOnClickListener(v -> pickShowTime());
        form.addView(row(showDateField, showTimeField));
        form.addView(note("Is time tak ye match user ke category page me HIDE rahega, time aate hi apne aap"
                + " dikhne lagega. Khali chhodo to match turant dikhega. Match start time isse alag hai,"
                + " wo upar wale REAL-TIME SCHEDULE se hi chalega."));
        TextView clearShow = new TextView(this);
        clearShow.setText("Clear show schedule (turant dikhao)");
        clearShow.setTextSize(12.5f);
        clearShow.setTextColor(Color.rgb(200, 40, 50));
        clearShow.setPadding(dp(4), dp(8), dp(4), dp(8));
        clearShow.setOnClickListener(v -> {
            showDateChosen = false; showTimeChosen = false; showAtMillis = 0L;
            showDateField.setText(""); showTimeField.setText("");
        });
        form.addView(clearShow);

        form.addView(sectionLabel("REAL COIN ECONOMY"));
        boolean oneVsOne = "BATTLE_1V1".equals(matchSystem);
        boolean kill = "KILL".equals(matchSystem);
        boolean rankBased = "TEAM".equals(matchSystem) || "SURVIVAL".equals(matchSystem);
        entryFeeField = numberField(oneVsOne ? "Entry coins (har player ka)" : "Entry coins (wallet se katega)");
        perKillField = numberField("Per kill coins (wallet me milega)");
        if (kill) form.addView(row(entryFeeField, perKillField)); else form.addView(entryFeeField);
        prizePoolField = numberField(oneVsOne ? "Prize pool coins (khali = 2 x entry)" : "Prize pool coins");
        gameTypeField = field("Game type (BATTLE ROYALE / CLASH SQUAD)");
        form.addView(row(prizePoolField, gameTypeField));
        rankPrizeField = field("Prize per rank (e.g. 500,300,200,100) - optional");
        if (rankBased) {
            form.addView(rankPrizeField);
            form.addView(note("Prize per rank khali chhodo to prize pool apne aap rank ke hisaab se bat jayega: "
                    + "1st 30%, 2nd 20%, 3rd 15%, 4th 10%, 5th 7%, 6th 5%, 7th 4%, 8-10th 3% (top 10 tak)."));
        }
        prizeField = field("Prize information (e.g. Diamonds / Bundle)");
        form.addView(prizeField);

        // Fields the chosen type does not use stay as hidden dummies so reads never hit null.
        slotsField = numberField("Total slots");
        teamSizeField = numberField("Team size");
        matchTypeField = field("Match type (SOLO / DUO / SQUAD)");
        mapField = field("Map name");
        form.addView(sectionLabel("SLOTS & TYPE"));
        if (oneVsOne) {
            form.addView(note("1v1: slots 2 aur team size 1 apne aap set hote hain."));
            form.addView(mapField);
        } else if (kill) {
            // Admin only picks the team size number; the match type writes itself.
            teamSizeField.setHint("Team size (1 / 2 / 4)");
            matchTypeField.setHint("Match type (auto)");
            matchTypeField.setText("SOLO");
            matchTypeField.setEnabled(false);
            teamSizeField.addTextChangedListener(new android.text.TextWatcher() {
                @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) { }
                @Override public void onTextChanged(CharSequence s, int a, int b, int c) { }
                @Override public void afterTextChanged(android.text.Editable e) {
                    String raw = e.toString().trim();
                    String auto = raw.isEmpty() ? "SOLO" : matchTypeForTeamSize(integer(teamSizeField, 0));
                    matchTypeField.setText(auto == null ? "" : auto);
                }
            });
            form.addView(note("Team size likho: 1 = SOLO (sirf 1 slot), 2 = DUO (max 2 slot), 4 = SQUAD (max 4 slot). Match type apne aap ban jayega."));
            form.addView(row(slotsField, teamSizeField));
            form.addView(row(matchTypeField, mapField));
        } else {
            slotsField.setHint("Total players (slots)");
            teamSizeField.setHint("Team size (players per team)");
            form.addView(row(slotsField, teamSizeField));
            form.addView(mapField);
        }

        form.addView(sectionLabel("DESCRIPTION & RULES"));
        descriptionField = field("Match description (optional)");
        form.addView(descriptionField);
        rulesField = field("Rules (optional)");
        rulesField.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE
                | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        rulesField.setMinLines(6);
        rulesField.setMaxLines(14);
        rulesField.setGravity(android.view.Gravity.TOP | android.view.Gravity.START);
        rulesField.setText(com.arenax.tournament.util.DefaultMatchRules.TEXT); // auto rules (editable)
        form.addView(rulesField);
        // Per-category saved description / rules: SAVE buttons under the fields + auto-fill of saved text.
        com.arenax.tournament.util.CategoryPresetUi.attach(this, form, descriptionField, rulesField,
                categoryId, categoryTitle, com.arenax.tournament.util.DefaultMatchRules.TEXT);

        form.addView(sectionLabel("DAILY MODE"));
        dailySwitch = new android.widget.Switch(this);
        dailySwitch.setText("Daily mode ON — roz isi time par ye match dobara aayega");
        dailySwitch.setTextSize(13f);
        dailySwitch.setTextColor(Color.rgb(20, 30, 50));
        dailySwitch.setPadding(dp(4), dp(10), dp(4), dp(10));
        form.addView(dailySwitch);
        form.addView(note("ON karne par ye match agle din, teesre din... roz isi time par apne aap ban jayega (jab tak OFF na karo)."));

        form.addView(sectionLabel("ROOM (OPTIONAL)"));
        roomField = field("Room ID (optional)");
        form.addView(roomField);

        ScrollView scroll = new ScrollView(this);
        scroll.addView(form);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));

        // ---- sticky footer ----
        LinearLayout footer = new LinearLayout(this);
        footer.setPadding(dp(18), dp(10), dp(18), dp(18));
        saveButton = primaryButton("PUBLISH MATCH", dp(52));
        saveButton.setOnClickListener(v -> submit());
        footer.addView(saveButton, new LinearLayout.LayoutParams(-1, dp(52)));
        root.addView(footer, new LinearLayout.LayoutParams(-1, -2));

        setContentView(root);
    }

    // ---------------- save ----------------

    private void submit() {
        String name = value(titleField);
        if (name.isEmpty()) { titleField.setError("Enter match name"); return; }
        if (!dateChosen || !timeChosen) { toast("Match ka date aur time choose karein."); return; }
        if (showDateChosen != showTimeChosen) {
            toast("Show schedule ka date aur time dono choose karein (ya Clear karein)."); return;
        }
        if (showDateChosen && showAtMillis >= pickedAt) {
            toast("Show time match start time se pehle ka hona chahiye."); return;
        }

        int entry = integer(entryFeeField, 0);
        int perKill = integer(perKillField, 0);
        String dateValue = value(dateField).toUpperCase(Locale.ROOT);
        String timeValue = value(timeField).toUpperCase(Locale.ROOT);
        String prizeValue = value(prizeField).isEmpty() ? "Free entry" : value(prizeField);
        int slots = integer(slotsField, 48);
        int team = Math.max(1, integer(teamSizeField, 1));
        String matchType = value(matchTypeField).isEmpty() ? "SOLO" : value(matchTypeField).toUpperCase(Locale.ROOT);
        if ("KILL".equals(matchSystem)) {
            String auto = matchTypeForTeamSize(team);
            if (auto == null) {
                teamSizeField.setError("Team size 1 (SOLO), 2 (DUO) ya 4 (SQUAD) hi ho sakta hai");
                return;
            }
            matchType = auto;
        }
        if ("BATTLE_1V1".equals(matchSystem)) { slots = 2; team = 1; matchType = "1VS1"; perKill = 0; }
        else if ("TEAM".equals(matchSystem)) { team = Math.max(2, integer(teamSizeField, 4)); matchType = "TEAM"; perKill = 0; }
        else if ("SURVIVAL".equals(matchSystem)) { matchType = "SURVIVAL"; perKill = 0; }
        if (("TEAM".equals(matchSystem) || "SURVIVAL".equals(matchSystem))
                && integer(prizePoolField, 0) <= 0 && value(rankPrizeField).isEmpty() && entry <= 0) {
            prizePoolField.setError("Prize pool ya Prize per rank daalo");
            return;
        }
        String mapValue = value(mapField).isEmpty() ? "TBA" : value(mapField);
        String descriptionValue = value(descriptionField).isEmpty()
                ? "Live match in " + categoryTitle : value(descriptionField);

        final int fSlots = slots, fTeam = team, fPerKill = perKill;
        final String fType = matchType;
        saveButton.setEnabled(false);
        if (selectedImage != null) {
            FancyText.toast(this, "Uploading image securely…", Toast.LENGTH_SHORT).show();
            ImgBbUploader.uploadImage(this, selectedImage, new StorageUploader.Callback() {
                @Override public void onSuccess(String fileUrl) {
                    save(name, fileUrl, descriptionValue, dateValue, timeValue, prizeValue, fSlots,
                            fTeam, mapValue, fType, entry, fPerKill);
                }
                @Override public void onFailure(String message) {
                    saveButton.setEnabled(true);
                    toast("Image upload failed: " + message);
                }
            });
        } else {
            save(name, value(imageUrlField), descriptionValue, dateValue, timeValue, prizeValue,
                    fSlots, fTeam, mapValue, fType, entry, fPerKill);
        }
    }

    private void save(String name, String bannerUrl, String description, String dateValue,
                      String timeValue, String prizeValue, int slots, int team, String mapValue,
                      String matchType, int entryFeeCoins, int perKillCoins) {
        Tournament match = new Tournament(null, name, categoryTitle, categoryId, bannerUrl, description,
                dateValue, timeValue, pickedAt, 0L, 0L, prizeValue, slots, 0,
                team, mapValue, matchType, rulesValue(), rankPrizeText(), value(roomField), "",
                false, "", "UPCOMING", "OPEN", true, Color.rgb(226, 46, 60));
        match.setResultSystem(matchSystem);
        match.setShowAt(showDateChosen && showTimeChosen ? showAtMillis : 0L);
        match.setDailyMode(dailySwitch != null && dailySwitch.isChecked());
        match.setCoinDetails(entryFeeCoins, integer(prizePoolField, 0), perKillCoins,
                value(gameTypeField).isEmpty() ? "BATTLE ROYALE" : value(gameTypeField).toUpperCase(Locale.ROOT));
        FirebaseRepository.saveTournament(match)
                .addOnSuccessListener(done -> {
                    mirrorToMessengerApp(match);
                    FirebaseRepository.logActivity("MATCH_CREATED", name,
                            categoryTitle + " • " + dateValue + " " + timeValue
                                    + " • entry " + entryFeeCoins + " coins • per kill " + perKillCoins);
                    // Hidden ("show schedule" in the future) match: backend sends this push at show time.
                    if (match.isVisibleBySchedule()) FirebaseRepository.publishNotification("New Match Scheduled",
                            name + " • " + dateValue + " " + timeValue
                                    + (entryFeeCoins > 0 ? " • Entry " + entryFeeCoins + " coins" : " • Free entry"));
                    toast("Match published in " + categoryTitle);
                    finish();
                })
                .addOnFailureListener(error -> {
                    saveButton.setEnabled(true);
                    toast("Save failed: " + error.getMessage());
                });
    }

    /** 1 = SOLO, 2 = DUO, 4 = SQUAD; anything else is not allowed (null). */
    private static String matchTypeForTeamSize(int size) {
        return size == 1 ? "SOLO" : size == 2 ? "DUO" : size == 4 ? "SQUAD" : null;
    }

    private String rankPrizeText() {
        if (!"TEAM".equals(matchSystem) && !"SURVIVAL".equals(matchSystem)) return "";
        return value(rankPrizeField).replaceAll("[^0-9,; ]", "");
    }

    /** Same /matches mirror the old dialog wrote, so the messenger app's match list stays in sync. */
    private void mirrorToMessengerApp(Tournament match) {
        Map<String, Object> mirror = new HashMap<>();
        mirror.put("tournamentTitle", match.getTitle());
        mirror.put("name", match.getTitle());
        mirror.put("category", categoryTitle);
        mirror.put("imageUrl", match.getBannerUrl());
        mirror.put("scheduledAt", pickedAt);
        mirror.put("roomId", value(roomField));
        mirror.put("roomPassword", "");
        mirror.put("roomReleased", false);
        mirror.put("status", "UPCOMING");
        mirror.put("participants", new HashMap<String, Object>());
        FirebaseRepository.matches().push().setValue(mirror);
    }

    // ---------------- pickers ----------------

    private void pickDate() {
        Calendar now = Calendar.getInstance();
        DatePickerDialog dialog = new DatePickerDialog(this, android.R.style.Theme_Holo_Dialog_MinWidth,
                (view, year, month, day) -> {
                    schedule.set(Calendar.YEAR, year);
                    schedule.set(Calendar.MONTH, month);
                    schedule.set(Calendar.DAY_OF_MONTH, day);
                    dateChosen = true;
                    dateField.setText(new SimpleDateFormat("dd MMM yyyy", Locale.ENGLISH)
                            .format(schedule.getTime()).toUpperCase(Locale.ROOT));
                    syncSchedule();
                },
                now.get(Calendar.YEAR), now.get(Calendar.MONTH), now.get(Calendar.DAY_OF_MONTH));
        dialog.getDatePicker().setMinDate(System.currentTimeMillis() - 1000);
        FancyText.attach(dialog);
        dialog.show();
    }

    private void pickTime() {
        Calendar now = Calendar.getInstance();
        new TimePickerDialog(this, (view, hour, minute) -> {
            schedule.set(Calendar.HOUR_OF_DAY, hour);
            schedule.set(Calendar.MINUTE, minute);
            timeChosen = true;
            timeField.setText(new SimpleDateFormat("hh:mm a", Locale.ENGLISH)
                    .format(schedule.getTime()).toUpperCase(Locale.ROOT));
            syncSchedule();
        }, now.get(Calendar.HOUR_OF_DAY), now.get(Calendar.MINUTE), false).show();
    }

    private void pickShowDate() {
        Calendar now = Calendar.getInstance();
        DatePickerDialog dialog = new DatePickerDialog(this, android.R.style.Theme_Holo_Dialog_MinWidth,
                (view, year, month, day) -> {
                    showSchedule.set(Calendar.YEAR, year);
                    showSchedule.set(Calendar.MONTH, month);
                    showSchedule.set(Calendar.DAY_OF_MONTH, day);
                    showDateChosen = true;
                    showDateField.setText(new SimpleDateFormat("dd MMM yyyy", Locale.ENGLISH)
                            .format(showSchedule.getTime()).toUpperCase(Locale.ROOT));
                    syncShowSchedule();
                },
                now.get(Calendar.YEAR), now.get(Calendar.MONTH), now.get(Calendar.DAY_OF_MONTH));
        dialog.getDatePicker().setMinDate(System.currentTimeMillis() - 1000);
        FancyText.attach(dialog);
        dialog.show();
    }

    private void pickShowTime() {
        Calendar now = Calendar.getInstance();
        new TimePickerDialog(this, (view, hour, minute) -> {
            showSchedule.set(Calendar.HOUR_OF_DAY, hour);
            showSchedule.set(Calendar.MINUTE, minute);
            showTimeChosen = true;
            showTimeField.setText(new SimpleDateFormat("hh:mm a", Locale.ENGLISH)
                    .format(showSchedule.getTime()).toUpperCase(Locale.ROOT));
            syncShowSchedule();
        }, now.get(Calendar.HOUR_OF_DAY), now.get(Calendar.MINUTE), false).show();
    }

    private void syncShowSchedule() {
        showSchedule.set(Calendar.SECOND, 0);
        showSchedule.set(Calendar.MILLISECOND, 0);
        showAtMillis = showSchedule.getTimeInMillis();
    }

    /** Exact epoch millis -> real-time countdown / auto status flips on the player side. */
    private void syncSchedule() {
        schedule.set(Calendar.SECOND, 0);
        schedule.set(Calendar.MILLISECOND, 0);
        pickedAt = schedule.getTimeInMillis();
    }

    private void chooseImage() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("image/*");
        startActivityForResult(intent, REQ_MATCH_IMAGE);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_MATCH_IMAGE && resultCode == RESULT_OK && data != null && data.getData() != null) {
            selectedImage = data.getData();
            preview.setImageURI(selectedImage);
        }
    }

    // ---------------- tiny view helpers ----------------

    /** Admin ne rules edit kiye to wahi, khali chhode to default rules. */
    private String rulesValue() {
        String v = value(rulesField);
        return v.isEmpty() ? com.arenax.tournament.util.DefaultMatchRules.TEXT : v;
    }

    private EditText field(String hint) {
        EditText input = new EditText(this);
        input.setHint(hint);
        input.setHintTextColor(Color.rgb(120, 130, 145));
        input.setTextColor(Color.rgb(20, 30, 50));
        input.setTextSize(14.5f);
        input.setPadding(dp(14), dp(14), dp(14), dp(14));
        input.setBackgroundResource(R.drawable.bg_input_dark_outline);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, -2);
        params.topMargin = dp(6);
        input.setLayoutParams(params);
        return input;
    }

    private EditText numberField(String hint) {
        EditText input = field(hint);
        input.setInputType(InputType.TYPE_CLASS_NUMBER);
        return input;
    }

    private LinearLayout row(View left, View right) {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        lp.rightMargin = dp(6);
        left.setLayoutParams(lp);
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        rp.leftMargin = dp(6);
        right.setLayoutParams(rp);
        r.addView(left);
        r.addView(right);
        return r;
    }

    private TextView sectionLabel(String text) {
        TextView view = label(text, 11, Color.rgb(50, 65, 90), true);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, -2);
        params.topMargin = dp(16);
        params.bottomMargin = dp(2);
        view.setLayoutParams(params);
        return view;
    }

    private TextView note(String text) {
        TextView view = label(text, 12, Color.rgb(100, 115, 135), false);
        view.setLineSpacing(dp(2), 1f);
        view.setBackgroundResource(R.drawable.bg_card_dark_outline);
        view.setPadding(dp(12), dp(10), dp(12), dp(10));
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, -2);
        params.topMargin = dp(10);
        view.setLayoutParams(params);
        return view;
    }

    private MaterialButton primaryButton(String text, int height) {
        MaterialButton button = new MaterialButton(this);
        button.setText(text);
        button.setTextColor(Color.rgb(24, 92, 175));
        button.setAllCaps(false);
        button.setTypeface(null, Typeface.BOLD);
        button.setCornerRadius(dp(7));
        button.setBackgroundTintList(ColorStateList.valueOf(Color.rgb(232, 241, 255)));
        button.setStrokeColor(ColorStateList.valueOf(Color.rgb(55, 65, 81))); button.setStrokeWidth(dp(1));
        button.setElevation(0f);
        button.setInsetTop(0);
        button.setInsetBottom(0);
        button.setLayoutParams(new LinearLayout.LayoutParams(-1, height));
        return button;
    }

    private TextView label(String text, float size, int color, boolean bold) {
        TextView view = new TextView(this);
        view.setText(text);
        view.setTextSize(size);
        view.setTextColor(color);
        if (bold) view.setTypeface(null, Typeface.BOLD);
        return view;
    }

    private String value(EditText input) {
        return input == null || input.getText() == null ? "" : input.getText().toString().trim();
    }

    private int integer(EditText input, int fallback) {
        try { return Integer.parseInt(value(input)); } catch (NumberFormatException e) { return fallback; }
    }

    private int statusBarHeight() {
        int id = getResources().getIdentifier("status_bar_height", "dimen", "android");
        return id > 0 ? getResources().getDimensionPixelSize(id) : dp(24);
    }

    private int dp(int value) {
        return Math.round(getResources().getDisplayMetrics().density * value);
    }

    private void toast(String message) {
        FancyText.toast(this, message, Toast.LENGTH_SHORT).show();
    }
}
