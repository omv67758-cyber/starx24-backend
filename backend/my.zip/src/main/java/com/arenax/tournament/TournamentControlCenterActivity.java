package com.arenax.tournament;


import com.arenax.tournament.util.FancyText;
import com.arenax.tournament.util.FullScreenDialog;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.graphics.Typeface;
import android.os.Bundle;
import android.text.InputFilter;
import android.text.InputType;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.text.style.ForegroundColorSpan;
import android.view.Gravity;
import android.view.View;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.arenax.tournament.data.FirebaseRepository;
import com.arenax.tournament.model.Match;
import com.arenax.tournament.model.Team;
import com.arenax.tournament.model.Tournament;
import com.arenax.tournament.util.FcmSender;
import com.arenax.tournament.util.RoomReleaseScheduler;
import com.google.android.material.button.MaterialButton;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Calendar;
import java.text.SimpleDateFormat;
import java.util.Map;

public class TournamentControlCenterActivity extends BaseActivity {
    private static final String[] TABS = {"Overview", "Participants", "Rank & Leaderboard"};
    private static final int TAB_RANK = 2;

    private String tournamentId;
    private String title;
    private Tournament tournament;
    private final Map<String, ValueEventListener> listeners = new HashMap<>();
    private LinearLayout content;
    private TextView status;
    private int selectedTab;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        tournamentId = getIntent().getStringExtra("tournamentId");
        title = getIntent().getStringExtra("title");
        if (tournamentId == null) tournamentId = "";
        if (title == null || title.trim().isEmpty()) title = "Tournament Control Center";
        buildScreen();
        loadTournament();
    }

    private final List<MaterialButton> tabButtons = new ArrayList<>();

    private void buildScreen() {
        final int navy = Color.rgb(20, 40, 70), grey = Color.rgb(92, 108, 128);
        ScrollView root = new ScrollView(this);
        root.setBackgroundColor(Color.rgb(245, 248, 254));
        root.setClipToPadding(false);
        // Edge-to-edge: keep the header clear of the status bar / gesture bar.
        ViewCompat.setOnApplyWindowInsetsListener(root, (view, insets) -> {
            Insets bars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            view.setPadding(bars.left, bars.top, bars.right, bars.bottom);
            return insets;
        });

        LinearLayout container = new LinearLayout(this);
        container.setOrientation(LinearLayout.VERTICAL);
        container.setPadding(dp(10), dp(4), dp(10), dp(8));
        root.addView(container, new ScrollView.LayoutParams(-1, -2));

        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        TextView back = label("\u2039", 26, navy, true);
        back.setGravity(Gravity.CENTER);
        back.setContentDescription("Back");
        back.setOnClickListener(v -> finish());
        top.addView(back, new LinearLayout.LayoutParams(dp(30), dp(34)));
        LinearLayout heading = new LinearLayout(this);
        heading.setOrientation(LinearLayout.VERTICAL);
        TextView matchTitle = label(title, 14, navy, true);
        matchTitle.setSingleLine(true);
        matchTitle.setEllipsize(TextUtils.TruncateAt.END);
        heading.addView(matchTitle);
        status = label("Loading\u2026", 9, grey, false);
        status.setSingleLine(true);
        status.setEllipsize(TextUtils.TruncateAt.END);
        status.setVisibility(View.GONE);
        heading.addView(status);
        top.addView(heading, new LinearLayout.LayoutParams(0, -2, 1));
        container.addView(top);

        LinearLayout tabRow = new LinearLayout(this);
        tabRow.setOrientation(LinearLayout.HORIZONTAL);
        tabButtons.clear();
        for (int i = 0; i < TABS.length; i++) {
            final int index = i;
            MaterialButton tab = smallButton(TABS[i], false, v -> switchTab(index));
            tab.setTextSize(11);
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, dp(30), 1f);
            p.rightMargin = i == TABS.length - 1 ? 0 : dp(4);
            tab.setLayoutParams(p);
            tabButtons.add(tab);
            tabRow.addView(tab);
        }
        LinearLayout.LayoutParams tabsParams = new LinearLayout.LayoutParams(-1, -2);
        tabsParams.topMargin = dp(4);
        container.addView(tabRow, tabsParams);

        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(0, dp(6), 0, dp(6));
        container.addView(content);
        setContentView(root);
        switchTab(0);
    }

    /** Selected tab = solid blue + white text; others = soft blue-grey. */
    private void styleTabs() {
        for (int i = 0; i < tabButtons.size(); i++) {
            MaterialButton b = tabButtons.get(i);
            boolean on = i == selectedTab;
            b.setBackgroundTintList(ColorStateList.valueOf(on ? Color.rgb(38, 116, 236) : Color.rgb(233, 240, 251)));
            b.setTextColor(on ? Color.WHITE : Color.rgb(20, 40, 70));
            b.setTypeface(null, on ? Typeface.BOLD : Typeface.NORMAL);
        }
    }

    private void loadTournament() {
        if (!FirebaseRepository.isReady(this)) {
            status.setText("Firebase unavailable. Control center is read-only until the backend is ready.");
            showMessage("Firebase unavailable right now.");
            return;
        }
        FirebaseRepository.tournaments().child(tournamentId).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override public void onDataChange(DataSnapshot snapshot) {
                tournament = Tournament.fromMap(snapshot.getKey(), castMap(snapshot.getValue()));
                if (tournament == null) {
                    status.setText("Tournament record not found.");
                    renderCurrentTab();
                    return;
                }
                status.setText("Connected to live Firebase data.");
                renderCurrentTab();
            }
            @Override public void onCancelled(DatabaseError error) {
                status.setText("Tournament load cancelled: " + error.getMessage());
                showMessage("Could not load tournament: " + error.getMessage());
            }
        });
    }

    private void switchTab(int index) {
        if (selectedTab == TAB_RANK && index != TAB_RANK) clearRankFields();
        selectedTab = index;
        styleTabs();
        renderCurrentTab();
    }

    private void renderCurrentTab() {
        removeListeners();
        content.removeAllViews();
        if (tournament == null) {
            content.addView(stateView("Loading", "Waiting for live match data from Firebase."));
            return;
        }
        if (selectedTab == 0) renderOverview();
        else if (selectedTab == 1) renderParticipants();
        else renderRankTab();
    }

    /** Joining is full once every slot is taken (uses the live participant count when we have it). */
    private boolean isFull() {
        return tournament != null && tournament.getTotalSlots() > 0
                && tournament.getJoinedSlots() >= tournament.getTotalSlots();
    }

    /** True once the admin has made the leaderboard public (match moved to Resulted). */
    private boolean isPublished() {
        return tournament != null && Tournament.COMPLETED.equals(tournament.getEffectiveStatus());
    }

    private void renderOverview() {
        final int navy = Color.rgb(20, 40, 70), grey = Color.rgb(92, 108, 128);
        boolean full = isFull(), published = isPublished();
        int joined = tournament.getJoinedSlots(), totalSlots = tournament.getTotalSlots();

        // ---------------- Status strip: slots + Joining Full state ----------------
        LinearLayout strip = box();
        strip.setOrientation(LinearLayout.HORIZONTAL);
        strip.setGravity(Gravity.CENTER_VERTICAL);
        if (full) strip.setBackground(sq(Color.rgb(255, 244, 219), Color.rgb(245, 208, 130)));
        TextView slotText = label(full ? "\uD83D\uDD12 Joining Full  \u2022  " + joined + "/" + totalSlots
                : "\uD83D\uDC65 " + joined + "/" + totalSlots + " joined", 12,
                full ? Color.rgb(146, 84, 6) : navy, true);
        strip.addView(slotText, new LinearLayout.LayoutParams(0, -2, 1f));
        TextView stateChip = published ? chip("\u25CF Public \u2022 Completed", Color.rgb(21, 128, 61), Color.rgb(230, 248, 238))
                : full ? chip("Edit leaderboard \u203A", Color.rgb(29, 78, 216), Color.rgb(231, 240, 255))
                : chip("Registration open", Color.rgb(71, 85, 105), Color.rgb(238, 242, 247));
        strip.addView(stateChip);
        if (full || published) strip.setOnClickListener(v -> switchTab(TAB_RANK));
        content.addView(strip);

        // ---------------- Room Access ----------------
        long existingReleaseAt = tournament.getRoomReleaseAt();
        TextView statusChip;
        if (tournament.isRoomReleased()) {
            statusChip = chip("\u2705 Released", Color.rgb(21, 128, 61), Color.rgb(230, 248, 238));
        } else if (existingReleaseAt > System.currentTimeMillis()) {
            statusChip = chip("\u23F0 " + new SimpleDateFormat("dd MMM, hh:mm a", Locale.ENGLISH).format(new java.util.Date(existingReleaseAt)),
                    Color.rgb(180, 83, 9), Color.rgb(255, 244, 219));
        } else {
            statusChip = chip("Hidden", Color.rgb(71, 85, 105), Color.rgb(238, 242, 247));
        }
        LinearLayout roomCard = box();
        roomCard.addView(cardHeader("Room Access", statusChip));
        EditText roomId = compactField("Room ID");
        roomId.setText(tournament.getRoomId() == null ? "" : tournament.getRoomId());
        EditText roomPassword = compactField("Password");
        roomPassword.setText(tournament.getRoomPassword() == null ? "" : tournament.getRoomPassword());
        if (!tournament.isRoomReleased() && tournamentId != null) {
            FirebaseRepository.matches().child(tournamentId).child("roomRelease").get().addOnSuccessListener(rr -> {
                if (roomId.getText().length() == 0) roomId.setText(text(rr.child("roomId").getValue(), ""));
                if (roomPassword.getText().length() == 0) roomPassword.setText(text(rr.child("roomPassword").getValue(), ""));
            });
        }
        LinearLayout fields = new LinearLayout(this);
        LinearLayout.LayoutParams idParams = new LinearLayout.LayoutParams(0, dp(34), 1f);
        idParams.rightMargin = dp(4);
        fields.addView(roomId, idParams);
        fields.addView(roomPassword, new LinearLayout.LayoutParams(0, dp(34), 1f));
        LinearLayout.LayoutParams fieldsParams = new LinearLayout.LayoutParams(-1, -2);
        fieldsParams.topMargin = dp(6);
        roomCard.addView(fields, fieldsParams);
        MaterialButton pushRoom = smallButton("Push Room ID & Password", true, v -> pushRoomNow(roomId, roomPassword, v));
        LinearLayout.LayoutParams pushParams = new LinearLayout.LayoutParams(-1, dp(34));
        pushParams.topMargin = dp(6);
        roomCard.addView(pushRoom, pushParams);
        content.addView(roomCard);

        // ---------------- Notify joined players ----------------
        LinearLayout notif = box();
        notif.addView(cardHeader("Notify Joined Players",
                chip(joined + "/" + totalSlots + " joined", Color.rgb(29, 78, 216), Color.rgb(231, 240, 255))));
        EditText msg = compactField("Message to joined players\u2026");
        msg.setFilters(new InputFilter[]{new InputFilter.LengthFilter(200)});
        msg.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        LinearLayout notifRow = new LinearLayout(this);
        LinearLayout.LayoutParams msgParams = new LinearLayout.LayoutParams(0, dp(34), 1f);
        msgParams.rightMargin = dp(4);
        notifRow.addView(msg, msgParams);
        notifRow.addView(smallButton("Send", true, v -> sendMatchNotification(msg)), new LinearLayout.LayoutParams(dp(64), dp(34)));
        LinearLayout.LayoutParams notifRowParams = new LinearLayout.LayoutParams(-1, -2);
        notifRowParams.topMargin = dp(6);
        notif.addView(notifRow, notifRowParams);
        content.addView(notif);

        // ---------------- Match start time (display only) ----------------
        LinearLayout start = box();
        start.addView(cardHeader("Match Start Time", null));
        EditText date = compactField("Select date");
        date.setText(tournament.getDate()); date.setFocusable(false); date.setOnClickListener(v -> pickScheduleDate(date));
        EditText time = compactField("Select time");
        time.setText(tournament.getTime()); time.setFocusable(false); time.setOnClickListener(v -> pickScheduleTime(time));
        LinearLayout startRow = new LinearLayout(this);
        LinearLayout.LayoutParams dp1 = new LinearLayout.LayoutParams(0, dp(34), 1.2f); dp1.rightMargin = dp(4);
        LinearLayout.LayoutParams dp2 = new LinearLayout.LayoutParams(0, dp(34), 1f); dp2.rightMargin = dp(4);
        startRow.addView(date, dp1);
        startRow.addView(time, dp2);
        startRow.addView(smallButton("Save", true, v -> saveSchedule(date, time)), new LinearLayout.LayoutParams(dp(56), dp(34)));
        LinearLayout.LayoutParams startRowParams = new LinearLayout.LayoutParams(-1, -2);
        startRowParams.topMargin = dp(6);
        start.addView(startRow, startRowParams);
        content.addView(start);
    }

    /** Room ID + password go live for players instantly (no schedule), and every joined player is
     *  notified: a push to their device plus a durable inbox row that carries the match id. */
    private void pushRoomNow(EditText id, EditText password, View button) {
        final String roomId = id.getText().toString().trim(), roomPass = password.getText().toString().trim();
        if (roomId.isEmpty() || roomPass.isEmpty()) { showMessage("Room ID and password dono enter karein."); return; }
        button.setEnabled(false);
        // An older scheduled release (if any) must not fire on top of this manual push.
        RoomReleaseScheduler.cancel(this, tournamentId);
        FirebaseRepository.pushRoomNow(tournamentId, roomId, roomPass)
                .addOnSuccessListener(v -> {
                    FirebaseRepository.logActivity("ROOM_PUSHED", title, "Room " + roomId);
                    showMessage("Room ID & password are now live for players.");
                    String heading = (title == null || title.trim().isEmpty() ? "Match" : title) + " — Room Released!";
                    String body = "Room ID: " + roomId + " | Password: " + roomPass;
                    saveInboxForJoinedPlayers(heading, body);
                    sendPushToJoinedPlayers(heading, body);
                    loadTournament();
                })
                .addOnFailureListener(e -> {
                    button.setEnabled(true);
                    showMessage("Room push failed: " + e.getMessage());
                });
    }

    /** Durable inbox row per joined player (same shape RoomReleaseAlarmReceiver writes). */
    private void saveInboxForJoinedPlayers(String heading, String body) {
        FirebaseRepository.tournamentParticipants(tournamentId).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override public void onDataChange(DataSnapshot snapshot) {
                for (DataSnapshot participant : snapshot.getChildren()) {
                    String uid = participant.getKey();
                    if (uid == null || uid.trim().isEmpty()) continue;
                    Map<String, Object> row = new HashMap<>();
                    row.put("userId", uid);
                    row.put("title", heading);
                    row.put("message", body);
                    row.put("type", "MATCH_ROOM_RELEASED");
                    row.put("matchId", tournamentId);
                    row.put("createdAt", System.currentTimeMillis());
                    row.put("read", false);
                    FirebaseRepository.notifications().push().setValue(row);
                }
            }
            @Override public void onCancelled(DatabaseError error) { }
        });
    }

    /** Device push to ONLY the players who joined this match (never "All Users"). */
    private void sendPushToJoinedPlayers(String heading, String body) {
        FirebaseRepository.collectParticipantFcmTokens(FirebaseRepository.tournamentParticipants(tournamentId), tokens -> {
            if (tokens.isEmpty()) {
                runOnUiThread(() -> showMessage("No joined players with notifications enabled."));
                return;
            }
            new Thread(() -> {
                try {
                    FcmSender.sendToAllTokens(null, tokens, heading, body, "",
                            (successCount, total, errorLog) -> runOnUiThread(() ->
                                    showMessage("Notified " + successCount + "/" + total + " joined player(s).")));
                } catch (Exception e) {
                    runOnUiThread(() -> showMessage("Push failed: " + e.getMessage()));
                }
            }).start();
        });
    }

    /** Free-text message to the joined players of this match. */
    private void sendMatchNotification(EditText field) {
        String body = field.getText().toString().trim();
        if (body.isEmpty()) { showMessage("Type a message first."); return; }
        final String heading = (title == null || title.trim().isEmpty()) ? "Match update" : title;
        sendPushToJoinedPlayers(heading, body);
        field.setText("");
        FirebaseRepository.logActivity("MATCH_NOTIFICATION_SENT", title, body);
    }

    // ---------- compact UI helpers (all corners kept tiny: max 4dp) ----------
    private GradientDrawable pill(int fill, int stroke, int radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(dp(Math.min(radiusDp, 4)));
        if (stroke != 0) g.setStroke(dp(1), stroke);
        return g;
    }

    private GradientDrawable sq(int fill, int stroke) { return pill(fill, stroke, 3); }

    private TextView chip(String text, int fg, int bg) {
        TextView v = label(text, 9, fg, true);
        v.setSingleLine(true);
        v.setEllipsize(TextUtils.TruncateAt.END);
        v.setMaxWidth(dp(150));
        v.setGravity(Gravity.CENTER);
        v.setPadding(dp(6), dp(3), dp(6), dp(3));
        v.setBackground(sq(bg, 0));
        return v;
    }

    /** One-line card title with an optional chip on the right. */
    private LinearLayout cardHeader(String heading, View right) {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.addView(label(heading, 12, Color.rgb(20, 40, 70), true), new LinearLayout.LayoutParams(0, -2, 1f));
        if (right != null) row.addView(right, new LinearLayout.LayoutParams(-2, -2));
        return row;
    }

    private EditText compactField(String hint) {
        EditText f = new EditText(this);
        f.setHint(hint);
        f.setTextSize(12);
        f.setSingleLine(true);
        f.setTextColor(Color.rgb(20, 40, 70));
        f.setHintTextColor(Color.rgb(140, 155, 175));
        f.setPadding(dp(8), 0, dp(8), 0);
        f.setGravity(Gravity.CENTER_VERTICAL);
        f.setBackground(sq(Color.rgb(248, 250, 255), Color.rgb(220, 230, 245)));
        return f;
    }

    /** Small flat button: solid blue, or light outlined when solid == false. Caller sets the height. */
    private MaterialButton smallButton(String text, boolean solid, View.OnClickListener click) {
        MaterialButton b = new MaterialButton(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextSize(12);
        b.setTypeface(null, Typeface.BOLD);
        b.setInsetTop(0);
        b.setInsetBottom(0);
        b.setMinWidth(0);
        b.setMinimumWidth(0);
        b.setMinHeight(0);
        b.setMinimumHeight(0);
        b.setPadding(dp(8), 0, dp(8), 0);
        b.setElevation(0f);
        b.setCornerRadius(dp(4));
        b.setBackgroundTintList(ColorStateList.valueOf(solid ? Color.rgb(38, 116, 236) : Color.rgb(233, 240, 251)));
        b.setTextColor(solid ? Color.WHITE : Color.rgb(20, 40, 70));
        b.setOnClickListener(click);
        return b;
    }

    private EditText inputField(String hint) {
        EditText field = compactField(hint);
        field.setLayoutParams(new LinearLayout.LayoutParams(-1, dp(34)));
        return field;
    }

    private void pickScheduleDate(EditText target) {
        Calendar now = Calendar.getInstance();
        new DatePickerDialog(this, (v, year, month, day) -> {
            Calendar picked = Calendar.getInstance(); picked.set(year, month, day);
            target.setText(new SimpleDateFormat("dd MMM yyyy", Locale.ENGLISH).format(picked.getTime()).toUpperCase(Locale.ROOT));
        }, now.get(Calendar.YEAR), now.get(Calendar.MONTH), now.get(Calendar.DAY_OF_MONTH)).show();
    }
    private void pickScheduleTime(EditText target) {
        Calendar now = Calendar.getInstance();
        new TimePickerDialog(this, (v, hour, minute) -> {
            Calendar picked = Calendar.getInstance(); picked.set(Calendar.HOUR_OF_DAY, hour); picked.set(Calendar.MINUTE, minute);
            target.setText(new SimpleDateFormat("hh:mm a", Locale.ENGLISH).format(picked.getTime()).toUpperCase(Locale.ROOT));
        }, now.get(Calendar.HOUR_OF_DAY), now.get(Calendar.MINUTE), false).show();
    }
    /** Match start date/time ONLY — display/scheduling metadata for the match card.
     *  Deliberately does not touch roomId/roomPassword/roomReleaseAt/roomReleased or the
     *  RoomReleaseScheduler alarm; that is entirely the "Room Release" card's job above.
     *  Keeping these separate is the fix: previously this method also silently re-armed the
     *  room-release alarm at the match's start time using whatever room ID happened to be
     *  saved (often still blank), which is why players saw the countdown stuck at 00:00:00
     *  and never got a real release. */
    private void saveSchedule(EditText date, EditText time) {
        String d = date.getText().toString().trim(), t = time.getText().toString().trim();
        if (d.isEmpty() || t.isEmpty()) { showMessage("Date aur time select karein."); return; }
        long scheduledAt;
        try { scheduledAt = new SimpleDateFormat("dd MMM yyyy hh:mm a", Locale.ENGLISH).parse(d + " " + t).getTime(); }
        catch (Exception e) { showMessage("Date/time format invalid hai."); return; }
        if (scheduledAt <= 0L) { showMessage("Date/time format invalid hai."); return; }
        // A past start time would flip the match to ONGOING instantly and close joining for everyone.
        if (!isPublished() && scheduledAt <= System.currentTimeMillis()) {
            showMessage("Start time future ka hona chahiye. Past time se match turant ONGOING ho jayega.");
            return;
        }
        Map<String,Object> update = new HashMap<>(); update.put("date", d); update.put("time", t); update.put("startAt", scheduledAt);
        FirebaseRepository.tournaments().child(tournamentId).updateChildren(update)
                .addOnSuccessListener(v -> {
                    showMessage("Match start time saved.");
                    FirebaseRepository.logActivity("MATCH_SCHEDULE_UPDATED", title, d + " " + t);
                    loadTournament();
                }).addOnFailureListener(e -> showMessage("Schedule save failed: " + e.getMessage()));
    }

    private DataSnapshot participantsSnapshot;
    private LinearLayout participantsListBox;
    private TextView participantsCountBadge;
    private EditText participantSearchInput;

    private long longValue(Object value) {
        if (value instanceof Number) return ((Number) value).longValue();
        try { return value == null ? 0L : Long.parseLong(String.valueOf(value)); } catch (Exception e) { return 0L; }
    }

    // =====================================================================
    // PARTICIPANTS — compact one-line rows (no banner images, no big cards)
    // =====================================================================
    private void renderParticipants() {
        ValueEventListener listener = new ValueEventListener() {
            @Override public void onDataChange(DataSnapshot snapshot) {
                participantsSnapshot = snapshot;
                buildParticipantsChrome();
                filterParticipants("");
            }
            @Override public void onCancelled(DatabaseError error) {
                content.removeAllViews();
                content.addView(stateView("Error", error.getMessage()));
            }
        };
        listeners.put("participants", listener);
        FirebaseRepository.tournamentParticipants(tournamentId).addValueEventListener(listener);
        content.addView(stateView("Loading", "Fetching participants\u2026"));
    }

    /** Search bar + count + empty list container, built ONCE per data load so typing in the
     *  search box only repopulates participantsListBox (keeps focus and the keyboard). */
    private void buildParticipantsChrome() {
        content.removeAllViews();
        LinearLayout searchRow = new LinearLayout(this);
        searchRow.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams searchRowParams = new LinearLayout.LayoutParams(-1, -2);
        searchRowParams.bottomMargin = dp(6);
        searchRow.setLayoutParams(searchRowParams);

        participantSearchInput = compactField("Search UID / Game Name\u2026");
        LinearLayout.LayoutParams fieldParams = new LinearLayout.LayoutParams(0, dp(34), 1f);
        fieldParams.rightMargin = dp(4);
        participantSearchInput.setLayoutParams(fieldParams);
        participantSearchInput.addTextChangedListener(new android.text.TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void afterTextChanged(android.text.Editable s) { filterParticipants(s.toString()); }
        });
        searchRow.addView(participantSearchInput);

        participantsCountBadge = chip("0", Color.rgb(38, 116, 236), Color.rgb(231, 240, 255));
        participantsCountBadge.setMinHeight(dp(34));
        searchRow.addView(participantsCountBadge, new LinearLayout.LayoutParams(-2, dp(34)));
        content.addView(searchRow);

        participantsListBox = new LinearLayout(this);
        participantsListBox.setOrientation(LinearLayout.VERTICAL);
        content.addView(participantsListBox);
    }

    private boolean isRealParticipant(DataSnapshot child) {
        // A bare RESERVING record is an interrupted join, not a registration.
        return !"RESERVING".equals(child.child("status").getValue(String.class));
    }

    private void filterParticipants(String rawQuery) {
        if (participantsListBox == null) return;
        participantsListBox.removeAllViews();
        String query = rawQuery == null ? "" : rawQuery.trim().toLowerCase(Locale.ROOT);
        if (participantsSnapshot == null || !participantsSnapshot.exists()) {
            if (participantsCountBadge != null) participantsCountBadge.setText("0");
            participantsListBox.addView(stateView("No participants yet", "Players appear here after they join."));
            return;
        }
        int shown = 0, index = 0;
        for (DataSnapshot child : participantsSnapshot.getChildren()) {
            if (!isRealParticipant(child)) continue;
            index++;
            String gameUid = text(child.child("gameUid").getValue(), "");
            String gameName = text(child.child("gameName").getValue(), child.getKey());
            if (!query.isEmpty() && !gameUid.toLowerCase(Locale.ROOT).contains(query)
                    && !gameName.toLowerCase(Locale.ROOT).contains(query)) continue;
            participantsListBox.addView(participantRow(index, child));
            shown++;
        }
        if (participantsCountBadge != null) {
            participantsCountBadge.setText(shown + "/" + (tournament == null ? 0 : tournament.getTotalSlots()));
        }
        if (shown == 0) participantsListBox.addView(stateView("No matches", "No participant matches that search."));
    }

    /** #  avatar  Game name / UID + slot  |  joined time */
    private LinearLayout participantRow(int index, DataSnapshot child) {
        String uidKey = child.getKey();
        String gameUid = text(child.child("gameUid").getValue(), "\u2014");
        String gameName = text(child.child("gameName").getValue(), uidKey);
        long createdAt = longValue(child.child("createdAt").getValue());
        java.util.List<Integer> slots = new ArrayList<>();
        DataSnapshot slotNumbersSnap = child.child("slotNumbers");
        if (slotNumbersSnap.exists()) {
            for (DataSnapshot sn : slotNumbersSnap.getChildren()) {
                Long v = sn.getValue(Long.class);
                if (v != null) slots.add(v.intValue());
            }
        } else {
            Long single = child.child("slotNumber").getValue(Long.class);
            if (single != null) slots.add(single.intValue());
        }
        String slotLabel = slots.isEmpty() ? "\u2014" : slots.toString().replace("[", "").replace("]", "");

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setBackground(sq(Color.WHITE, Color.rgb(226, 232, 242)));
        row.setPadding(dp(8), dp(10), dp(8), dp(10));
        row.setMinimumHeight(dp(66));
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(-1, -2);
        rp.bottomMargin = dp(6);
        row.setLayoutParams(rp);

        TextView idx = label(String.valueOf(index), 11, Color.rgb(140, 155, 175), true);
        row.addView(idx, new LinearLayout.LayoutParams(dp(22), -2));
        row.addView(participantAvatar(uidKey, 30));

        LinearLayout info = new LinearLayout(this);
        info.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(0, -2, 1f);
        ip.leftMargin = dp(8);
        info.setLayoutParams(ip);
        TextView nameView = label(gameName, 12, Color.rgb(20, 40, 70), true);
        nameView.setSingleLine(true);
        nameView.setEllipsize(TextUtils.TruncateAt.END);
        info.addView(nameView);
        info.addView(label("UID " + gameUid + "  \u2022  Slot " + slotLabel, 10, Color.rgb(92, 108, 128), false));
        TextView phoneView = label("Phone: \u2026", 10, Color.rgb(92, 108, 128), false);
        phoneView.setSingleLine(true);
        info.addView(phoneView);
        bindParticipantPhone(uidKey, phoneView);
        row.addView(info);

        if (createdAt > 0) {
            row.addView(label(new SimpleDateFormat("dd MMM, hh:mm a", Locale.ENGLISH).format(new java.util.Date(createdAt)),
                    9, Color.rgb(140, 155, 175), false));
        }
        return row;
    }

    /** Phone numbers already fetched for the participants list (filtering rebuilds rows on every keystroke). */
    private final Map<String, String> participantPhoneCache = new HashMap<>();

    /** Fills the "Phone: ..." line from users/{uid}/phone (cached after the first read). */
    private void bindParticipantPhone(String uid, TextView target) {
        if (uid == null || uid.isEmpty()) { target.setText("Phone: \u2014"); return; }
        String cached = participantPhoneCache.get(uid);
        if (cached != null) { target.setText("Phone: " + cached); return; }
        FirebaseRepository.users().child(uid).child("phone").get().addOnCompleteListener(task -> {
            if (isFinishing() || isDestroyed()) return;
            String phone = "";
            if (task.isSuccessful() && task.getResult() != null) phone = text(task.getResult().getValue(), "").trim();
            if (phone.isEmpty()) phone = "\u2014";
            participantPhoneCache.put(uid, phone);
            target.setText("Phone: " + phone);
        });
    }

    private android.widget.ImageView participantAvatar(String uid, int sizeDp) {
        android.widget.ImageView avatar = new android.widget.ImageView(this);
        avatar.setLayoutParams(new LinearLayout.LayoutParams(dp(sizeDp), dp(sizeDp)));
        avatar.setBackgroundResource(R.drawable.bg_avatar);
        avatar.setPadding(dp(5), dp(5), dp(5), dp(5));
        avatar.setImageResource(R.drawable.ic_cd_person);
        avatar.setScaleType(android.widget.ImageView.ScaleType.CENTER_INSIDE);
        avatar.setColorFilter(Color.rgb(38, 116, 236));
        if (uid != null && !uid.isEmpty()) {
            FirebaseRepository.users().child(uid).child("photoUrl").get().addOnSuccessListener(snap -> {
                String url = text(snap.getValue(), "");
                if (url.isEmpty() || isFinishing() || isDestroyed()) return;
                avatar.clearColorFilter();
                avatar.setPadding(0, 0, 0, 0);
                avatar.setScaleType(android.widget.ImageView.ScaleType.CENTER_CROP);
                com.bumptech.glide.Glide.with(this).load(url)
                        .transform(new com.bumptech.glide.load.resource.bitmap.CircleCrop()).into(avatar);
            });
        }
        return avatar;
    }

    // =====================================================================
    // RANK & LEADERBOARD — one tab, three small views:
    //   Rank Manage  : ONLY kills are typed. Coins (kills x per-kill price) and the ranking are automatic.
    //   Leaderboard  : the ranked table as players will see it (Draft or Public)
    //   Edit Logs    : who changed what, and when
    // Editing unlocks once joining is full (or the match has started). "Publish" makes the
    // leaderboard public: the match flips to RESULT_PUBLISHED, moves to players' Resulted
    // tab, and VIEW RESULT shows this leaderboard. Editing after publish updates it live.
    // =====================================================================
    private int rankSub = 0; // 0 = Rank Manage, 1 = Leaderboard, 2 = Edit Logs
    private DataSnapshot rankParticipantsSnapshot;
    private boolean rankHasPublishedResults;
    private final Map<String, Integer> rankPrefillPlace = new HashMap<>();
    private final Map<String, Integer> rankPrefillKills = new HashMap<>();
    private final Map<String, EditText> rankKillFields = new HashMap<>();
    private final Map<String, Integer> rankPrefillCoins = new HashMap<>();
    private final Map<String, EditText> rankCoinFields = new HashMap<>();
    private LinearLayout rankBody;
    private LinearLayout rankTableBox;
    private final List<String> survivalSelection = new ArrayList<>();
    private final Map<String, String> survivalNames = new HashMap<>();
    private final Map<String, android.widget.CheckBox> survivalChecks = new HashMap<>();
    private EditText lossNoticeField;
    private EditText refundNoticeField;

    private void clearRankFields() {
        rankKillFields.clear();
        rankCoinFields.clear();
    }

    private void renderRankTab() {
        LinearLayout seg = new LinearLayout(this);
        String[] names = {"Rank Manage", "Leaderboard", "Edit Logs"};
        for (int i = 0; i < names.length; i++) {
            final int idx = i;
            MaterialButton b = smallButton(names[i], i == rankSub, v -> { rankSub = idx; renderCurrentTab(); });
            b.setTextSize(11);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(28), 1f);
            lp.rightMargin = i == names.length - 1 ? 0 : dp(4);
            seg.addView(b, lp);
        }
        LinearLayout.LayoutParams segParams = new LinearLayout.LayoutParams(-1, -2);
        segParams.bottomMargin = dp(6);
        content.addView(seg, segParams);

        rankBody = new LinearLayout(this);
        rankBody.setOrientation(LinearLayout.VERTICAL);
        content.addView(rankBody);
        rankBody.addView(stateView("Loading", "Fetching joined players\u2026"));
        loadRankData(rankBody);
    }

    /** Joined players (participants) -> already-public results -> admin draft, then draw. */
    private void loadRankData(LinearLayout body) {
        FirebaseRepository.tournamentParticipants(tournamentId).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override public void onDataChange(DataSnapshot snapshot) {
                rankParticipantsSnapshot = snapshot;
                FirebaseRepository.results().addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override public void onDataChange(DataSnapshot resultsSnap) {
                        Map<String, Integer> pubPlace = new HashMap<>(), pubKills = new HashMap<>(), pubCoins = new HashMap<>();
                        for (DataSnapshot row : resultsSnap.getChildren()) {
                            if (!tournamentId.equals(text(row.child("tournamentId").getValue(), ""))) continue;
                            String uid = text(row.child("userId").getValue(), "");
                            if (uid.isEmpty()) continue;
                            pubPlace.put(uid, (int) longValue(row.child("placement").getValue()));
                            pubKills.put(uid, (int) longValue(row.child("kills").getValue()));
                            if (row.child("coins").exists()) pubCoins.put(uid, (int) longValue(row.child("coins").getValue()));
                        }
                        rankHasPublishedResults = !pubPlace.isEmpty() && isPublished();
                        FirebaseRepository.rankDrafts().child(tournamentId).child("rows").get()
                                .addOnCompleteListener(task -> {
                                    rankPrefillPlace.clear();
                                    rankPrefillKills.clear();
                                    rankPrefillCoins.clear();
                                    if (rankHasPublishedResults) {
                                        rankPrefillPlace.putAll(pubPlace);
                                        rankPrefillKills.putAll(pubKills);
                                        rankPrefillCoins.putAll(pubCoins);
                                    } else if (task.isSuccessful() && task.getResult() != null) {
                                        for (DataSnapshot d : task.getResult().getChildren()) {
                                            rankPrefillPlace.put(d.getKey(), (int) longValue(d.child("placement").getValue()));
                                            rankPrefillKills.put(d.getKey(), (int) longValue(d.child("kills").getValue()));
                                            if (d.child("coins").exists()) rankPrefillCoins.put(d.getKey(), (int) longValue(d.child("coins").getValue()));
                                        }
                                        // Older results published before drafts existed still pre-fill the table.
                                        if (rankPrefillPlace.isEmpty()) {
                                            rankPrefillPlace.putAll(pubPlace);
                                            rankPrefillKills.putAll(pubKills);
                                            rankPrefillCoins.putAll(pubCoins);
                                        }
                                    }
                                    drawRankBody(body);
                                });
                    }
                    @Override public void onCancelled(DatabaseError error) { rankFail(body, error); }
                });
            }
            @Override public void onCancelled(DatabaseError error) { rankFail(body, error); }
        });
    }

    private void rankFail(LinearLayout body, DatabaseError error) {
        if (body.getParent() == null) return;
        body.removeAllViews();
        body.addView(stateView("Error", error.getMessage()));
    }

    private List<DataSnapshot> rankPlayers() {
        List<DataSnapshot> players = new ArrayList<>();
        if (rankParticipantsSnapshot != null) {
            for (DataSnapshot child : rankParticipantsSnapshot.getChildren()) {
                if (isRealParticipant(child)) players.add(child);
            }
        }
        return players;
    }

    private void drawRankBody(LinearLayout body) {
        // The admin may have switched tab / sub-view while Firebase was answering.
        if (body.getParent() == null || body != rankBody) return;
        body.removeAllViews();
        if (rankSub == 1) drawLeaderboardView(body);
        else if (rankSub == 2) drawLogsView(body);
        else drawRankManageView(body);
    }

    private boolean rankUnlocked(int joinedCount) {
        if (tournament != null && "BATTLE_1V1".equals(tournament.getResultSystem()) && joinedCount >= 1) return true;
        int total = tournament == null ? 0 : tournament.getTotalSlots();
        boolean full = total > 0 && Math.max(joinedCount, tournament.getJoinedSlots()) >= total;
        return full || rankHasPublishedResults || isPublished()
                || (tournament != null && Tournament.ONGOING.equals(tournament.getEffectiveStatus()));
    }

    private String ordinal(int n) {
        if (n == 11 || n == 12 || n == 13) return n + "th";
        switch (n % 10) {
            case 1: return n + "st";
            case 2: return n + "nd";
            case 3: return n + "rd";
            default: return n + "th";
        }
    }

    /** Coins won per kill for this match (1 kill = perKillCoins coins). */
    private int perKillCoins() {
        return tournament == null ? 0 : Math.max(0, tournament.getPerKillCoins());
    }

    /** kills x per-kill price. */
    private int coinsFor(int kills) { return Math.max(0, kills) * perKillCoins(); }

    /** Competition ranking by kills: most kills = rank 1, equal kills share the same rank. */
    private int autoPlacement(int kills, List<Integer> allKills) {
        int better = 0;
        for (int k : allKills) if (k > kills) better++;
        return better + 1;
    }

    private int parseIntOrZero(String s) {
        try { return Integer.parseInt(s.trim()); } catch (Exception e) { return 0; }
    }

    private TextView rankHeaderCell(String text, float weight) {
        TextView v = label(text, 10, Color.rgb(140, 155, 175), true);
        v.setGravity(Gravity.CENTER_VERTICAL);
        v.setLayoutParams(new LinearLayout.LayoutParams(0, -2, weight));
        return v;
    }

    // ---------------------------------------------------------------- Rank Manage
    private void drawRankManageView(LinearLayout body) {
        if (tournament != null && !"KILL".equals(tournament.getResultSystem())) {
            drawSpecialResultSystem(body);
            return;
        }
        List<DataSnapshot> players = rankPlayers();
        int total = tournament == null ? 0 : tournament.getTotalSlots();
        boolean unlocked = rankUnlocked(players.size());

        LinearLayout head = new LinearLayout(this);
        head.setGravity(Gravity.CENTER_VERTICAL);
        head.addView(label("Joined " + players.size() + "/" + total, 12, Color.rgb(20, 40, 70), true),
                new LinearLayout.LayoutParams(0, -2, 1f));
        head.addView(rankHasPublishedResults
                ? chip("\u25CF Public", Color.rgb(21, 128, 61), Color.rgb(230, 248, 238))
                : chip("\u25CF Draft", Color.rgb(146, 84, 6), Color.rgb(255, 244, 219)));
        LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(-1, -2);
        hp.bottomMargin = dp(6);
        body.addView(head, hp);

        if (!unlocked) {
            body.addView(stateView("\uD83D\uDD12 Leaderboard locked",
                    "Unlocks when joining is full (" + players.size() + "/" + total + ") or the match starts."));
            return;
        }
        if (players.isEmpty()) {
            body.addView(stateView("No players yet", "Nobody has joined this match."));
            return;
        }

        EditText search = compactField("Search by Name or UID\u2026");
        search.setLayoutParams(new LinearLayout.LayoutParams(-1, dp(34)));
        search.addTextChangedListener(new android.text.TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void afterTextChanged(android.text.Editable s) { renderRankRows(s.toString()); }
        });
        body.addView(search);

        LinearLayout header = new LinearLayout(this);
        header.setPadding(dp(8), dp(6), dp(8), dp(2));
        header.addView(rankHeaderCell("#", 0.4f));
        header.addView(rankHeaderCell("Player / UID", 2.2f));
        header.addView(rankHeaderCell("Kills", 1.2f));
        header.addView(rankHeaderCell("Coins", 1.2f));
        body.addView(header);

        rankTableBox = new LinearLayout(this);
        rankTableBox.setOrientation(LinearLayout.VERTICAL);
        body.addView(rankTableBox);
        renderRankRows("");

        int pk = perKillCoins();
        TextView ptsView = label("1 kill = " + pk + " coin" + (pk == 1 ? "" : "s") + "  \u2022  Kills daalte hi coins auto fill "
                + "honge (Kills \u00D7 " + pk + "). Coins box par tap karke keyboard se jyada/kam bhi kar sakte ho.",
                10, Color.rgb(92, 108, 128), false);
        LinearLayout.LayoutParams ptsParams = new LinearLayout.LayoutParams(-1, -2);
        ptsParams.topMargin = dp(4);
        ptsParams.bottomMargin = dp(6);
        body.addView(ptsView, ptsParams);

        lossNoticeField = compactField("Optional admin message for players who lose");
        lossNoticeField.setSingleLine(false);
        lossNoticeField.setMinLines(1);
        lossNoticeField.setMaxLines(2);
        lossNoticeField.setFilters(new InputFilter[]{new InputFilter.LengthFilter(300)});
        body.addView(lossNoticeField, new LinearLayout.LayoutParams(-1, dp(38)));

        LinearLayout buttons = new LinearLayout(this);
        if (!rankHasPublishedResults) {
            MaterialButton draft = smallButton("Save Draft", false, v -> saveRank(false, v));
            LinearLayout.LayoutParams dpm = new LinearLayout.LayoutParams(0, dp(36), 1f);
            dpm.rightMargin = dp(4);
            buttons.addView(draft, dpm);
        }
        MaterialButton publish = smallButton(rankHasPublishedResults ? "Update Public Leaderboard" : "Publish Leaderboard", true,
                v -> saveRank(true, v));
        buttons.addView(publish, new LinearLayout.LayoutParams(0, dp(36), rankHasPublishedResults ? 1f : 1.4f));
        body.addView(buttons);
    }

    /** Separate result UI: survival chooses up to ten survivors; 1VS1 chooses only an outcome. */
    private void drawSpecialResultSystem(LinearLayout body) {
        List<DataSnapshot> players = rankPlayers();
        boolean survival = "SURVIVAL".equals(tournament.getResultSystem());
        boolean teamMode = "TEAM".equals(tournament.getResultSystem());
        body.addView(stateView(teamMode ? "TEAM MATCH → MANUAL LEADERBOARD" : (survival ? "SURVIVAL → MANUAL LEADERBOARD" : "1VS1 BATTLE"),
                teamMode ? "Har team ko Rank do aur har player ke samne coins keyboard se likho. Publish karte hi leaderboard public + coins wallet me."
                : (survival ? "Jo survive kiya sirf unko Rank (1-10) do aur coins likho. Baaki khali chhod do. Publish karte hi leaderboard public."
                        : "Jitne player join hue (1 ya 2) un sabke samne coins likho aur chaho to har player ko alag message do. Slot full na ho tab bhi publish hoga.")));
        if (players.isEmpty()) {
            body.addView(stateView("No players yet", "Players must register before results can be settled."));
            if (!teamMode && !survival) addCancelNoOpponentButton(body);
            return;
        }
        if (teamMode) {
            drawManualLeaderboard(body, players, false);
            return;
        }
        if (survival) {
            drawManualLeaderboard(body, players, true);
            return;
        }

        List<DataSnapshot> sides = new ArrayList<>(players);
        java.util.Collections.sort(sides, (x, y) -> {
            long aSlot = longValue(x.child("slotNumber").getValue()), bSlot = longValue(y.child("slotNumber").getValue());
            int bySlot = Long.compare(aSlot <= 0 ? Long.MAX_VALUE : aSlot, bSlot <= 0 ? Long.MAX_VALUE : bSlot);
            return bySlot != 0 ? bySlot : text(x.child("gameName").getValue(), "").compareToIgnoreCase(text(y.child("gameName").getValue(), ""));
        });
        if (sides.size() == 1) {
            body.addView(stateView("Sirf 1 player joined hai",
                    "Doosra player nahi aaya. Neeche us player ko coins do ya Refund se entry fee wapas karo."));
        }
        long battlePool = tournament.getPrizePoolCoins() > 0 ? tournament.getPrizePoolCoins()
                : (long) tournament.getEntryFeeCoins() * 2;
        final long entryFee = Math.max(0, tournament.getEntryFeeCoins());
        body.addView(label("Prize pool: " + battlePool + " coins  \u2022  Har player ko kitne coins dene hain wo khud daalo (manual).",
                11, Color.rgb(38, 116, 236), true));
        final List<String> uids = new ArrayList<>();
        final List<EditText> coinFields = new ArrayList<>();
        final List<EditText> messageFields = new ArrayList<>();
        for (int i = 0; i < sides.size(); i++) {
            DataSnapshot sp = sides.get(i);
            String name = text(sp.child("gameName").getValue(), "Player");
            uids.add(sp.getKey());
            coinFields.add(battleCoinRow(body, sides.size() == 1 ? "PLAYER" : (i == 0 ? "LEFT" : "RIGHT"), name));
            EditText msg = compactField("Message for " + name + " (optional)");
            msg.setFilters(new InputFilter[]{new InputFilter.LengthFilter(300)});
            body.addView(msg, new LinearLayout.LayoutParams(-1, dp(38)));
            messageFields.add(msg);
        }
        // Already published? show the coins that were given last time so the admin can correct them.
        FirebaseRepository.tournaments().child(tournamentId).child("results").get().addOnSuccessListener(snap -> {
            if (snap == null || !snap.exists()) return;
            for (int i = 0; i < uids.size(); i++) {
                DataSnapshot c = snap.child(uids.get(i)).child("coins");
                if (c.exists() && coinFields.get(i).getText().toString().trim().isEmpty())
                    coinFields.get(i).setText(String.valueOf(longValue(c.getValue())));
                String savedMsg = text(snap.child(uids.get(i)).child("message").getValue(), "");
                if (!savedMsg.isEmpty() && messageFields.get(i).getText().toString().trim().isEmpty())
                    messageFields.get(i).setText(savedMsg);
            }
        });
        addNoticeFields(body, false);
        // Refund: fills every player's entry fee back (admin can still edit the numbers before sending).
        body.addView(smallButton("Refund Entry Fee (" + entryFee + " coins each)", false, v -> {
            for (EditText f : coinFields) f.setText(String.valueOf(entryFee));
            showMessage("Entry fee fill ho gayi. Neeche 'Send Refund' dabao.");
        }));
        body.addView(smallButton("Send Refund", false, v -> submitBattle(v, uids, coinFields, messageFields, true)));
        body.addView(smallButton("Publish 1VS1 Result & Coins", true, v -> submitBattle(v, uids, coinFields, messageFields, false)));
        if (sides.size() < 2) addCancelNoOpponentButton(body);
    }

    /**
     * Opponent never joined: admin closes the match. It moves to Completed (players never see "Cancelled"),
     * joining closes, and the manual coin leaderboard above can be published at any time — even before the
     * scheduled start. No coins move here; money only moves when the admin publishes coins / refund.
     */
    private void addCancelNoOpponentButton(LinearLayout body) {
        if (tournament == null || rankHasPublishedResults || isPublished()) return;
        body.addView(smallButton("Cancel Match (opponent nahi aaya)", false, v ->
                new android.app.AlertDialog.Builder(this)
                        .setTitle("Cancel this match?")
                        .setMessage("Match Completed me chala jayega aur joining band ho jayegi. "
                                + "Is step me koi coin wapas nahi jata; coins ya refund neeche se manually do.")
                        .setNegativeButton("BACK", null)
                        .setPositiveButton("CANCEL MATCH", (d, w) -> {
                            Map<String, Object> up = new HashMap<>();
                            up.put("status", Tournament.COMPLETED);
                            up.put("registrationStatus", "CLOSED");
                            up.put("noOpponent", true);
                            up.put("noOpponentAt", System.currentTimeMillis());
                            FirebaseRepository.tournaments().child(tournamentId).updateChildren(up)
                                    .addOnSuccessListener(x -> {
                                        try { FirebaseRepository.matches().child(tournamentId).child("status").setValue("COMPLETED"); }
                                        catch (Exception ignored) { }
                                        showMessage("Match Completed me chala gaya. Ab coins daalke leaderboard publish karo.");
                                        loadTournament();
                                    })
                                    .addOnFailureListener(e -> showMessage("Cancel failed: " + e.getMessage()));
                        }).show()));
    }

    private void submitBattle(View v, List<String> uids, List<EditText> coinFields, List<EditText> messageFields, boolean refund) {
        if (tournament != null && !tournament.hasStarted() && !refund) {
            showMessage("Match abhi start nahi hua. Result start time ke baad hi publish hoga.");
            return;
        }
        Map<String, Integer> amounts = new HashMap<>();
        for (int i = 0; i < uids.size(); i++) {
            String t = coinFields.get(i).getText().toString().trim();
            if (t.isEmpty()) { showMessage("Har player ke coins daalo (0 bhi chalega)."); return; }
            int c = parseIntOrZero(t);
            if (c < 0 || c > 10000000) { showMessage("Coins 0 se 10000000 ke beech hone chahiye."); return; }
            amounts.put(uids.get(i), c);
        }
        String loss = lossNoticeField == null ? "" : lossNoticeField.getText().toString().trim();
        Map<String, String> playerMessages = new HashMap<>();
        for (int i = 0; i < uids.size(); i++) playerMessages.put(uids.get(i), messageFields.get(i).getText().toString().trim());
        v.setEnabled(false);
        WithdrawalApiClient.settleBattleManual(tournamentId, amounts, loss, refund, playerMessages, new WithdrawalApiClient.SimpleCallback() {
            @Override public void onSuccess(org.json.JSONObject result) {
                v.setEnabled(true);
                if (isFinishing() || isDestroyed()) return;
                int failed = result.optInt("failed", 0);
                showMessage(failed > 0
                        ? "Result public ho gaya; " + failed + " wallet update fail hue. Dobara dabao."
                        : (refund ? "Refund ho gaya. Coins wallet me chale gaye." : "Result public ho gaya. Coins wallet me chale gaye."));
                rankHasPublishedResults = true;
                loadTournament();
            }
            @Override public void onError(String message) {
                v.setEnabled(true);
                if (isFinishing() || isDestroyed()) return;
                String m = message == null ? "" : message;
                showMessage(m.contains("exactly two registered players")
                        ? "Server purana chal raha hai. backend/index.js dobara deploy karo, tabhi 1 player ko coins/refund jayenge."
                        : "Settlement failed: " + m);
            }
        });
    }

    /** One 1VS1 row: "LEFT  <name>   [ coins ]" - returns the coin field. */
    private EditText battleCoinRow(LinearLayout body, String side, String name) {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setBackground(sq(Color.WHITE, Color.rgb(226, 232, 242)));
        row.setPadding(dp(8), dp(6), dp(8), dp(6));
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(-1, -2);
        rp.topMargin = dp(6);
        row.setLayoutParams(rp);
        TextView nameView = label(side + "  \u2022  " + name, 12, Color.rgb(20, 40, 70), true);
        nameView.setSingleLine(true);
        nameView.setEllipsize(TextUtils.TruncateAt.END);
        row.addView(nameView, new LinearLayout.LayoutParams(0, -2, 2.2f));
        EditText coins = rankCell("", 1.3f);
        coins.setHint("Coins");
        coins.setTextColor(Color.rgb(38, 116, 236));
        coins.setFilters(new android.text.InputFilter[] { new android.text.InputFilter.LengthFilter(8) });
        row.addView(coins);
        body.addView(row);
        return coins;
    }

    /** Team matches group players by teamName; solo players (and non-team matches) are their own unit. */
    private List<List<DataSnapshot>> teamUnits(List<DataSnapshot> players) {
        boolean teamMatch = tournament != null && tournament.getTeamSize() > 1;
        Map<String, List<DataSnapshot>> grouped = new java.util.LinkedHashMap<>();
        for (DataSnapshot player : players) {
            String team = text(player.child("teamName").getValue(), "").trim();
            String key = teamMatch && !team.isEmpty() ? "team:" + team.toLowerCase(Locale.ROOT) : "solo:" + player.getKey();
            List<DataSnapshot> list = grouped.get(key);
            if (list == null) { list = new ArrayList<>(); grouped.put(key, list); }
            list.add(player);
        }
        return new ArrayList<>(grouped.values());
    }

    private String unitLabel(List<DataSnapshot> unit) {
        DataSnapshot first = unit.get(0);
        String team = text(first.child("teamName").getValue(), "").trim();
        if (tournament != null && tournament.getTeamSize() > 1 && !team.isEmpty()) {
            return team + " (" + unit.size() + " players)";
        }
        return text(first.child("gameName").getValue(), "Player");
    }

    private final Map<String, EditText> teamRankFields = new java.util.LinkedHashMap<>();

    /** TEAM match: admin types only a rank number per team; server builds leaderboard + coins. */
    private void drawTeamRankEntry(LinearLayout body, List<DataSnapshot> players) {
        final long pool = tournament.getPrizePoolCoins() > 0 ? tournament.getPrizePoolCoins()
                : (long) tournament.getEntryFeeCoins() * players.size();
        String custom = tournament.getPrizeDistribution();
        body.addView(label("Reward pool: " + pool + " coins"
                + (custom != null && custom.matches(".*\\d.*") ? "  •  Prize per rank: " + custom : "  •  auto split by rank (30/20/15/10/7/5/4/3/3/3 %)"),
                11, Color.rgb(38, 116, 236), true));
        LinearLayout header = new LinearLayout(this);
        header.setPadding(dp(8), dp(6), dp(8), dp(2));
        header.addView(rankHeaderCell("Team / Players", 2.6f));
        header.addView(rankHeaderCell("Rank #", 1.2f));
        body.addView(header);
        teamRankFields.clear();
        for (List<DataSnapshot> unit : teamUnits(players)) {
            String repUid = unit.get(0).getKey();
            LinearLayout row = new LinearLayout(this);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setBackground(sq(Color.WHITE, Color.rgb(226, 232, 242)));
            row.setPadding(dp(8), dp(4), dp(8), dp(4));
            LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(-1, -2);
            rp.bottomMargin = dp(3);
            row.setLayoutParams(rp);
            LinearLayout nameCol = new LinearLayout(this);
            nameCol.setOrientation(LinearLayout.VERTICAL);
            nameCol.setLayoutParams(new LinearLayout.LayoutParams(0, -2, 2.6f));
            TextView nameView = label(unitLabel(unit), 12, Color.rgb(20, 40, 70), true);
            nameView.setSingleLine(true);
            nameView.setEllipsize(TextUtils.TruncateAt.END);
            nameCol.addView(nameView);
            StringBuilder members = new StringBuilder();
            for (DataSnapshot m : unit) {
                if (members.length() > 0) members.append(", ");
                members.append(text(m.child("gameName").getValue(), "Player"));
            }
            nameCol.addView(label(members.toString(), 9, Color.rgb(140, 155, 175), false));
            row.addView(nameCol);
            int saved = rankPrefillPlace.getOrDefault(repUid, 0);
            EditText rank = rankCell(saved > 0 ? String.valueOf(saved) : "", 1.2f);
            rank.setHint("#");
            teamRankFields.put(repUid, rank);
            row.addView(rank);
            body.addView(row);
        }
        addNoticeFields(body, false);
        body.addView(smallButton("Publish Team Leaderboard & Coins", true, v -> {
            Map<String, Integer> ranks = new java.util.LinkedHashMap<>();
            java.util.Set<Integer> used = new java.util.HashSet<>();
            for (Map.Entry<String, EditText> e : teamRankFields.entrySet()) {
                int value = parseIntOrZero(e.getValue().getText().toString());
                if (value <= 0) continue;
                if (!used.add(value)) { showMessage("Rank " + value + " do teams ko diya hai. Har team ka rank alag hona chahiye."); return; }
                ranks.put(e.getKey(), value);
            }
            if (ranks.isEmpty()) { showMessage("Kam se kam ek team ka rank number daalo."); return; }
            settleTeamResult(ranks);
        }));
    }

    // ---------------------------------------------------------------- Manual TEAM / SURVIVAL leaderboard
    // Admin types Rank + Coins with the keyboard, then publishes. Same publish path as KILL:
    // results are written to tournaments/{id}/results (public), match moves to Resulted, coins credited.
    private final Map<String, EditText> manualRankFields = new java.util.LinkedHashMap<>();
    private final Map<String, EditText> manualCoinFields = new java.util.LinkedHashMap<>();
    private List<List<DataSnapshot>> manualUnits = new ArrayList<>();

    private void drawManualLeaderboard(LinearLayout body, List<DataSnapshot> players, boolean survival) {
        manualRankFields.clear();
        manualCoinFields.clear();
        manualUnits = teamUnits(players);
        final long pool = tournament.getPrizePoolCoins() > 0 ? tournament.getPrizePoolCoins()
                : (long) tournament.getEntryFeeCoins() * players.size();
        body.addView(label("Reward pool: " + pool + " coins  \u2022  "
                + (survival ? "Max 10 rank (1 = winner). Rank khali = survive nahi kiya."
                            : "Rank khali = team leaderboard me nahi aayegi."),
                11, Color.rgb(38, 116, 236), true));

        LinearLayout header = new LinearLayout(this);
        header.setPadding(dp(8), dp(6), dp(8), dp(2));
        header.addView(rankHeaderCell(survival ? "Team / Player" : "Team / Players", 2.2f));
        header.addView(rankHeaderCell("Rank #", 1.0f));
        header.addView(rankHeaderCell("Coins", 1.3f));
        body.addView(header);

        for (List<DataSnapshot> unit : manualUnits) {
            String repUid = unit.get(0).getKey();
            boolean multi = unit.size() > 1;
            int savedRank = rankPrefillPlace.getOrDefault(repUid, 0);
            EditText rank = rankCell(savedRank > 0 ? String.valueOf(savedRank) : "", 1.0f);
            rank.setHint("#");
            rank.setFilters(new InputFilter[]{new InputFilter.LengthFilter(3)});
            manualRankFields.put(repUid, rank);

            if (!multi) {
                LinearLayout row = manualRow();
                String name = text(unit.get(0).child("gameName").getValue(), "Player");
                TextView nv = label(name, 12, Color.rgb(20, 40, 70), true);
                nv.setSingleLine(true);
                nv.setEllipsize(TextUtils.TruncateAt.END);
                row.addView(nv, new LinearLayout.LayoutParams(0, -2, 2.2f));
                row.addView(rank);
                row.addView(manualCoinCell(repUid));
                body.addView(row);
                continue;
            }
            // Team: one header row with the team Rank, then one coins row per member.
            LinearLayout head = manualRow();
            TextView tv = label(unitLabel(unit), 12, Color.rgb(20, 40, 70), true);
            tv.setSingleLine(true);
            tv.setEllipsize(TextUtils.TruncateAt.END);
            head.addView(tv, new LinearLayout.LayoutParams(0, -2, 2.2f));
            head.addView(rank);
            head.addView(new View(this), new LinearLayout.LayoutParams(0, 1, 1.3f));
            body.addView(head);
            for (DataSnapshot m : unit) {
                LinearLayout mr = manualRow();
                mr.setPadding(dp(20), dp(2), dp(8), dp(2));
                TextView mv = label("\u21B3 " + text(m.child("gameName").getValue(), "Player"), 11, Color.rgb(92, 108, 128), false);
                mv.setSingleLine(true);
                mv.setEllipsize(TextUtils.TruncateAt.END);
                mr.addView(mv, new LinearLayout.LayoutParams(0, -2, 2.2f));
                mr.addView(new View(this), new LinearLayout.LayoutParams(0, 1, 1.0f));
                mr.addView(manualCoinCell(m.getKey()));
                body.addView(mr);
            }
        }
        addNoticeFields(body, false);
        body.addView(smallButton(rankHasPublishedResults ? "Update Public Leaderboard" : "Publish Leaderboard & Coins", true,
                v -> publishManualLeaderboard(survival, v)));
    }

    private LinearLayout manualRow() {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setBackground(sq(Color.WHITE, Color.rgb(226, 232, 242)));
        row.setPadding(dp(8), dp(4), dp(8), dp(4));
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(-1, -2);
        rp.bottomMargin = dp(3);
        row.setLayoutParams(rp);
        return row;
    }

    private EditText manualCoinCell(String uid) {
        Integer saved = rankPrefillCoins.get(uid);
        EditText coins = rankCell(saved != null ? String.valueOf(saved) : "", 1.3f);
        coins.setHint("Coins");
        coins.setTextColor(Color.rgb(38, 116, 236));
        coins.setFilters(new InputFilter[]{new InputFilter.LengthFilter(8)});
        manualCoinFields.put(uid, coins);
        return coins;
    }

    private void publishManualLeaderboard(boolean survival, View button) {
        if (tournament != null && !tournament.hasStarted()) {
            showMessage("Match abhi start nahi hua. Result start time ke baad hi publish hoga.");
            return;
        }
        List<FirebaseRepository.ResultEntry> entries = new ArrayList<>();
        Map<String, String> teamLabels = new HashMap<>();
        java.util.Set<Integer> usedRanks = new java.util.HashSet<>();
        long totalCoins = 0;
        boolean teamMatch = tournament != null && tournament.getTeamSize() > 1;
        for (List<DataSnapshot> unit : manualUnits) {
            String repUid = unit.get(0).getKey();
            EditText rf = manualRankFields.get(repUid);
            int rank = rf == null ? 0 : parseIntOrZero(rf.getText().toString());
            String unitName = unitLabel(unit);
            boolean anyCoins = false;
            for (DataSnapshot m : unit) {
                EditText cf = manualCoinFields.get(m.getKey());
                if (cf != null && parseIntOrZero(cf.getText().toString()) > 0) anyCoins = true;
            }
            if (rank <= 0) {
                if (anyCoins) { showMessage(unitName + " ko coins diye hain par Rank nahi. Rank bhi daalo."); return; }
                continue;
            }
            if (survival && rank > 10) { showMessage(unitName + ": Survival me rank 1 se 10 ke beech hi hota hai."); return; }
            if (!usedRanks.add(rank)) { showMessage("Rank " + rank + " do jagah diya hai. Har rank alag hona chahiye."); return; }
            for (DataSnapshot m : unit) {
                EditText cf = manualCoinFields.get(m.getKey());
                int coins = cf == null ? 0 : parseIntOrZero(cf.getText().toString());
                if (coins < 0 || coins > 10000000) { showMessage("Coins 0 se 10000000 ke beech hone chahiye."); return; }
                String pname = text(m.child("gameName").getValue(), "Player");
                entries.add(new FirebaseRepository.ResultEntry(m.getKey(), pname, 0, rank, coins));
                totalCoins += coins;
                if (teamMatch) {
                    String team = text(m.child("teamName").getValue(), "").trim();
                    if (!team.isEmpty()) teamLabels.put(m.getKey(), team);
                }
            }
        }
        if (entries.isEmpty()) { showMessage("Kam se kam ek rank daalo."); return; }
        final long total = totalCoins;
        final boolean firstPublish = !isPublished();
        new FullScreenDialog.Builder(this)
                .setTitle(firstPublish ? "Publish leaderboard?" : "Update public leaderboard?")
                .setMessage(entries.size() + " players  \u2022  " + total + " coins total wallet me jayenge.")
                .setNegativeButton("CANCEL", null)
                .setPositiveButton("PUBLISH", (d, w) -> runManualPublish(entries, teamLabels, firstPublish, button))
                .show();
    }

    private void runManualPublish(List<FirebaseRepository.ResultEntry> entries, Map<String, String> teamLabels,
                                  boolean firstPublish, View button) {
        final StringBuilder sb = new StringBuilder();
        for (FirebaseRepository.ResultEntry e : entries) {
            if (sb.length() > 0) sb.append("; ");
            sb.append(e.username).append(": #").append(e.placement).append(" = ").append(e.coins).append(" coins");
            if (sb.length() > 400) { sb.append("; ..."); break; }
        }
        final String changes = sb.toString();
        button.setEnabled(false);
        FirebaseRepository.saveRankDraft(tournamentId, entries)
                .onSuccessTask(x -> FirebaseRepository.publishMatchResults(tournamentId, entries))
                .onSuccessTask(x -> FirebaseRepository.publishTeamLabels(tournamentId, teamLabels))
                .onSuccessTask(x -> firstPublish
                        ? FirebaseRepository.markResultPublished(tournamentId)
                        : com.google.android.gms.tasks.Tasks.<Void>forResult(null))
                .addOnSuccessListener(x -> {
                    FirebaseRepository.addEditLog(tournamentId, firstPublish ? "PUBLISHED" : "PUBLIC_EDITED", changes);
                    FirebaseRepository.logActivity(firstPublish ? "RESULT_PUBLISHED" : "RESULT_EDITED", title, changes);
                    if (firstPublish) {
                        FirebaseRepository.publishNotification("Result Published", title + " results are live. Check the leaderboard!");
                    }
                    rankHasPublishedResults = true;
                    WithdrawalApiClient.creditMatchCoins(tournamentId, new WithdrawalApiClient.SimpleCallback() {
                        @Override public void onSuccess(org.json.JSONObject result) {
                            if (isFinishing() || isDestroyed()) return;
                            int failed = result.optInt("failed", 0);
                            showMessage(failed > 0
                                    ? "Leaderboard public hai; " + failed + " wallet update fail hue. Update Public Leaderboard dobara dabao."
                                    : "Leaderboard public ho gaya aur coins wallet me chale gaye.");
                        }
                        @Override public void onError(String message) {
                            if (isFinishing() || isDestroyed()) return;
                            showMessage("Leaderboard public hai, par coins nahi gaye: " + message + " \u2014 dobara publish dabao.");
                        }
                    });
                    loadTournament();
                })
                .addOnFailureListener(e -> {
                    button.setEnabled(true);
                    showMessage("Publish failed: " + e.getMessage());
                });
    }

    private void settleTeamResult(Map<String, Integer> ranks) {
        if (tournament != null && !tournament.hasStarted()) {
            showMessage("Match abhi start nahi hua. Result settlement start time ke baad hi hoga.");
            return;
        }
        String loss = lossNoticeField == null ? "" : lossNoticeField.getText().toString().trim();
        WithdrawalApiClient.settleTournament(tournamentId, "TEAM", null, null, null, null, loss, "", ranks,
                new WithdrawalApiClient.SimpleCallback() {
                    @Override public void onSuccess(org.json.JSONObject result) {
                        int failed = result.optInt("failed", 0);
                        showMessage(failed > 0
                                ? "Result published; " + failed + " wallet update(s) failed. Publish again to retry."
                                : "Team leaderboard public ho gaya. " + result.optInt("credited", 0) + " players ko coins mil gaye.");
                        rankHasPublishedResults = true;
                        loadTournament();
                    }
                    @Override public void onError(String message) { showMessage("Settlement failed: " + message); }
                });
    }

    private long slotForUid(List<DataSnapshot> players, String uid) {
        for (DataSnapshot player : players) {
            if (uid.equals(player.getKey())) return longValue(player.child("slotNumber").getValue());
        }
        return 0;
    }

    private void addNoticeFields(LinearLayout body, boolean includeRefund) {
        lossNoticeField = compactField("Optional admin-defined LOSS notice");
        lossNoticeField.setFilters(new InputFilter[]{new InputFilter.LengthFilter(300)});
        body.addView(lossNoticeField, new LinearLayout.LayoutParams(-1, dp(38)));
        refundNoticeField = null;
        if (includeRefund) {
            refundNoticeField = compactField("Optional admin-defined 20% REFUND notice");
            refundNoticeField.setFilters(new InputFilter[]{new InputFilter.LengthFilter(300)});
            body.addView(refundNoticeField, new LinearLayout.LayoutParams(-1, dp(38)));
        }
    }

    private void settleCustomResult(String system, List<String> winners, String winnerUid, String joinedUid, String payout) {
        if (tournament != null && !tournament.hasStarted()) {
            showMessage("Match abhi start nahi hua. Result settlement start time ke baad hi hoga.");
            return;
        }
        String loss = lossNoticeField == null ? "" : lossNoticeField.getText().toString().trim();
        String refund = refundNoticeField == null ? "" : refundNoticeField.getText().toString().trim();
        WithdrawalApiClient.settleTournament(tournamentId, system, winners, winnerUid, joinedUid, payout,
                loss, refund, new WithdrawalApiClient.SimpleCallback() {
                    @Override public void onSuccess(org.json.JSONObject result) {
                        int failed = result.optInt("failed", 0);
                        showMessage(failed > 0
                                ? "Result published; " + failed + " wallet update(s) failed. Publish again to retry; those players' notices are held."
                                : "Result published. " + result.optInt("credited", 0) + " player rewards credited; notices are queued.");
                        survivalSelection.clear();
                        rankHasPublishedResults = true;
                        loadTournament();
                    }
                    @Override public void onError(String message) { showMessage("Settlement failed: " + message); }
                });
    }

    /** Re-draws ONLY the rows for the current search text; already-typed values survive because
     *  rankRow() reads back from the existing field for that player. */
    private void renderRankRows(String rawQuery) {
        if (rankTableBox == null) return;
        String query = rawQuery == null ? "" : rawQuery.trim().toLowerCase(Locale.ROOT);
        rankTableBox.removeAllViews();
        int index = 0, shown = 0;
        for (DataSnapshot child : rankPlayers()) {
            index++;
            String uid = child.getKey();
            String gameUid = text(child.child("gameUid").getValue(), "\u2014");
            String gameName = text(child.child("gameName").getValue(), uid);
            String teamName = text(child.child("teamName").getValue(), "");
            if (!query.isEmpty() && !gameUid.toLowerCase(Locale.ROOT).contains(query)
                    && !gameName.toLowerCase(Locale.ROOT).contains(query)) continue;
            rankTableBox.addView(rankRow(index, uid, gameName, gameUid, teamName));
            shown++;
        }
        if (shown == 0) rankTableBox.addView(stateView("No matches", "No player matches that search."));
    }

    private LinearLayout rankRow(int index, String uid, String gameName, String gameUid, String teamName) {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setBackground(sq(Color.WHITE, Color.rgb(226, 232, 242)));
        row.setPadding(dp(8), dp(4), dp(8), dp(4));
        LinearLayout.LayoutParams rowParams = new LinearLayout.LayoutParams(-1, -2);
        rowParams.bottomMargin = dp(3);
        row.setLayoutParams(rowParams);

        row.addView(label(String.valueOf(index), 11, Color.rgb(92, 108, 128), true), new LinearLayout.LayoutParams(0, -2, 0.4f));

        LinearLayout nameCol = new LinearLayout(this);
        nameCol.setOrientation(LinearLayout.VERTICAL);
        nameCol.setLayoutParams(new LinearLayout.LayoutParams(0, -2, 2.2f));
        TextView nameView = label(gameName, 12, Color.rgb(20, 40, 70), true);
        nameView.setSingleLine(true);
        nameView.setEllipsize(TextUtils.TruncateAt.END);
        nameCol.addView(nameView);
        nameCol.addView(label(teamName == null || teamName.trim().isEmpty() ? "UID " + gameUid : teamName + " \u2022 " + gameUid,
                9, Color.rgb(140, 155, 175), false));
        row.addView(nameCol);

        EditText prevKills = rankKillFields.get(uid);
        Integer savedKills = rankPrefillKills.get(uid);
        String killsInit = prevKills != null ? prevKills.getText().toString()
                : String.valueOf(savedKills != null ? savedKills : 0);

        EditText kills = rankCell(killsInit, 1.2f);
        // Coins: auto-filled from kills, but the admin can overwrite them with the keyboard.
        EditText prevCoins = rankCoinFields.get(uid);
        Integer savedCoins = rankPrefillCoins.get(uid);
        String coinsInit = prevCoins != null ? prevCoins.getText().toString()
                : String.valueOf(savedCoins != null ? savedCoins : coinsFor(parseIntOrZero(killsInit)));
        EditText coinField = rankCell(coinsInit, 1.2f);
        coinField.setTextColor(Color.rgb(38, 116, 236));
        coinField.setTypeface(coinField.getTypeface(), android.graphics.Typeface.BOLD);
        coinField.setFilters(new android.text.InputFilter[] { new android.text.InputFilter.LengthFilter(8) });
        kills.addTextChangedListener(new android.text.TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void afterTextChanged(android.text.Editable s) {
                // Every kills change re-fills coins (kills x per-kill); admin can then edit coins by hand.
                coinField.setText(String.valueOf(coinsFor(parseIntOrZero(kills.getText().toString()))));
            }
        });
        rankKillFields.put(uid, kills);
        rankCoinFields.put(uid, coinField);
        row.addView(kills);
        row.addView(coinField);
        return row;
    }

    private EditText rankCell(String initial, float weight) {
        EditText field = new EditText(this);
        field.setText(initial);
        field.setTextSize(12);
        field.setGravity(Gravity.CENTER);
        field.setSingleLine(true);
        field.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        field.setTextColor(Color.rgb(20, 40, 70));
        field.setBackground(sq(Color.rgb(248, 250, 255), Color.rgb(220, 230, 245)));
        field.setPadding(dp(2), 0, dp(2), 0);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, dp(32), weight);
        p.leftMargin = dp(3); p.rightMargin = dp(3);
        field.setLayoutParams(p);
        return field;
    }

    /** Reads every Kills field (the ONLY thing the admin types). Placement is worked out here from the
     *  kills: most kills = rank 1, equal kills share a rank (duo/squad teammates naturally tie). */
    private List<FirebaseRepository.ResultEntry> collectRankEntries() {
        List<DataSnapshot> players = rankPlayers();
        List<String> uids = new ArrayList<>(), names = new ArrayList<>();
        List<Integer> killsList = new ArrayList<>(), coinsList = new ArrayList<>();
        for (DataSnapshot child : players) {
            String uid = child.getKey();
            String name = text(child.child("gameName").getValue(), "Player");
            EditText kf = rankKillFields.get(uid);
            int kills;
            if (kf != null) {
                kills = parseIntOrZero(kf.getText().toString());
            } else {
                Integer sk = rankPrefillKills.get(uid);
                kills = sk != null ? sk : 0;
            }
            if (kills < 0 || kills > 99) {
                showMessage("Check kills for " + name + " \u2014 it must be between 0 and 99.");
                return null;
            }
            EditText cf = rankCoinFields.get(uid);
            int coins;
            if (cf != null) {
                String ct = cf.getText().toString().trim();
                coins = ct.isEmpty() ? 0 : parseIntOrZero(ct);
            } else {
                Integer sc = rankPrefillCoins.get(uid);
                coins = sc != null ? sc : coinsFor(kills);
            }
            if (coins < 0 || coins > 10000000) {
                showMessage("Check coins for " + name + " \u2014 it must be between 0 and 10000000.");
                return null;
            }
            uids.add(uid); names.add(name); killsList.add(kills); coinsList.add(coins);
        }
        List<FirebaseRepository.ResultEntry> entries = new ArrayList<>();
        for (int i = 0; i < uids.size(); i++) {
            int k = killsList.get(i);
            entries.add(new FirebaseRepository.ResultEntry(uids.get(i), names.get(i), k, autoPlacement(k, killsList), coinsList.get(i)));
        }
        return entries;
    }

    /** Short "who changed what" text for the Edit Logs view, compared with what was saved before. */
    private String describeRankChanges(List<FirebaseRepository.ResultEntry> entries) {
        List<String> changes = new ArrayList<>();
        int pk = perKillCoins();
        for (FirebaseRepository.ResultEntry e : entries) {
            Integer oldKills = rankPrefillKills.get(e.uid);
            int ok = oldKills == null ? 0 : oldKills;
            Integer oldCoinsSaved = rankPrefillCoins.get(e.uid);
            int oc = oldCoinsSaved != null ? oldCoinsSaved : ok * pk;
            int nc = e.coins >= 0 ? e.coins : e.kills * pk;
            if (ok == e.kills && oc == nc) continue;
            String coinPart = nc + " coin" + (nc == 1 ? "" : "s") + (nc != e.kills * pk ? ", manual" : "");
            changes.add(e.username + ": kills " + ok + "\u2192" + e.kills
                    + (oc != nc ? ", coins " + oc + "\u2192" + coinPart : " (" + coinPart + ")"));
        }
        if (changes.isEmpty()) return entries.size() + " players saved (no value changes)";
        StringBuilder out = new StringBuilder();
        for (int i = 0; i < changes.size() && i < 6; i++) { if (i > 0) out.append("; "); out.append(changes.get(i)); }
        if (changes.size() > 6) out.append("; +").append(changes.size() - 6).append(" more");
        return out.toString();
    }

    private void saveRank(boolean publish, View button) {
        List<FirebaseRepository.ResultEntry> entries = collectRankEntries();
        if (entries == null) return;
        if (entries.isEmpty()) { showMessage("No players to save."); return; }
        final boolean firstPublish = publish && !isPublished();
        // Publishing makes the leaderboard public + moves the match to Resulted, so it must never
        // happen before the match has actually started (a full match may still be UPCOMING).
        if (firstPublish && tournament != null && !tournament.hasStarted()) {
            showMessage("Match abhi start nahi hua. Publish start time ke baad hi hoga (Draft save kar sakte ho).");
            return;
        }
        if (firstPublish) {
            new FullScreenDialog.Builder(this)
                    .setTitle("Publish leaderboard?")
                    .setMessage("Players will see this leaderboard and the match moves to their Resulted tab.")
                    .setNegativeButton("CANCEL", null)
                    .setPositiveButton("PUBLISH", (d, w) -> runRankSave(entries, true, true, button))
                    .show();
            return;
        }
        runRankSave(entries, publish, false, button);
    }

    private void runRankSave(List<FirebaseRepository.ResultEntry> entries, boolean publish, boolean firstPublish, View button) {
        final String changes = describeRankChanges(entries);
        button.setEnabled(false);
        com.google.android.gms.tasks.Task<Void> task = FirebaseRepository.saveRankDraft(tournamentId, entries);
        if (publish) {
            task = task.continueWithTask(t -> FirebaseRepository.publishMatchResults(tournamentId, entries))
                    .continueWithTask(t -> firstPublish
                            ? FirebaseRepository.markResultPublished(tournamentId)
                            : com.google.android.gms.tasks.Tasks.<Void>forResult(null));
        }
        task.addOnSuccessListener(v -> {
            String action = !publish ? "DRAFT_SAVED" : (firstPublish ? "PUBLISHED" : "PUBLIC_EDITED");
            FirebaseRepository.addEditLog(tournamentId, action, changes);
            if (publish) {
                FirebaseRepository.logActivity(firstPublish ? "RESULT_PUBLISHED" : "RESULT_EDITED", title, changes);
                if (firstPublish) {
                    FirebaseRepository.publishNotification("Result Published", title + " results are live. Check the leaderboard!");
                }
            }
            showMessage(!publish ? "Draft saved." : (firstPublish
                    ? "Leaderboard is public \u2014 match moved to Resulted."
                    : "Public leaderboard updated."));
            clearRankFields();
            if (publish) {
                // Leaderboard public ho gaya -> jitne coins leaderboard me hain utne hi har player ke
                // wallet me chale jaenge (edit par sirf difference).
                creditLeaderboardCoins();
                loadTournament();
            } else {
                renderCurrentTab();
            }
        }).addOnFailureListener(e -> {
            button.setEnabled(true);
            showMessage("Save failed: " + e.getMessage());
        });
    }

    /** Sends the public leaderboard's coins to every player's wallet (server side, idempotent). */
    private void creditLeaderboardCoins() {
        String lossMessage = lossNoticeField == null ? "" : lossNoticeField.getText().toString().trim();
        WithdrawalApiClient.settleTournament(tournamentId, "KILL", null, null, null, null,
                lossMessage, "", new WithdrawalApiClient.SimpleCallback() {
            @Override public void onSuccess(org.json.JSONObject result) {
                if (isFinishing() || isDestroyed()) return;
                int credited = result.optInt("credited", 0), adjusted = result.optInt("adjusted", 0);
                int failed = result.optInt("failed", 0);
                if (failed > 0) {
                    showMessage("Coins: " + (credited + adjusted) + " players ko gaye, " + failed + " fail hue. Update Public Leaderboard dobara dabao.");
                } else if (credited + adjusted > 0) {
                    showMessage("Coins wallet me chale gaye \u2014 " + (credited + adjusted) + " players. WIN/LOSS notices queued.");
                }
            }
            @Override public void onError(String message) {
                if (isFinishing() || isDestroyed()) return;
                showMessage("Leaderboard public hai, par coins nahi gaye: " + message
                        + " \u2014 Update Public Leaderboard dobara dabao.");
            }
        });
    }

    // ---------------------------------------------------------------- Leaderboard view
    private static final class LbRow {
        String name; int kills; int coins; int rank;
    }

    private void drawLeaderboardView(LinearLayout body) {
        List<LbRow> rows = new ArrayList<>();
        for (DataSnapshot child : rankPlayers()) {
            Integer place = rankPrefillPlace.get(child.getKey());
            Integer k = rankPrefillKills.get(child.getKey());
            if ((place == null || place <= 0) && k == null) continue; // nothing saved for this player yet
            LbRow r = new LbRow();
            r.name = text(child.child("gameName").getValue(), "Player");
            r.kills = k == null ? 0 : k;
            Integer sc = rankPrefillCoins.get(child.getKey());
            r.coins = sc != null ? sc : coinsFor(r.kills);
            rows.add(r);
        }
        // App builds the leaderboard itself: most kills first (coins follow kills).
        java.util.Collections.sort(rows, (a, b) -> a.kills != b.kills ? b.kills - a.kills : a.name.compareToIgnoreCase(b.name));
        for (LbRow r : rows) {
            int better = 0;
            for (LbRow o : rows) if (o.kills > r.kills) better++;
            r.rank = better + 1;
        }

        LinearLayout head = new LinearLayout(this);
        head.setGravity(Gravity.CENTER_VERTICAL);
        head.addView(label(rankHasPublishedResults ? "Visible to players" : "Draft \u2014 only you can see this", 11,
                Color.rgb(92, 108, 128), false), new LinearLayout.LayoutParams(0, -2, 1f));
        head.addView(rankHasPublishedResults
                ? chip("\u25CF Public", Color.rgb(21, 128, 61), Color.rgb(230, 248, 238))
                : chip("\u25CF Draft", Color.rgb(146, 84, 6), Color.rgb(255, 244, 219)));
        LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(-1, -2);
        hp.bottomMargin = dp(6);
        body.addView(head, hp);

        if (rows.isEmpty()) {
            body.addView(stateView("No leaderboard yet", "Enter kills in Rank Manage and save a draft."));
            return;
        }
        LinearLayout header = new LinearLayout(this);
        header.setBackground(sq(Color.rgb(20, 40, 70), 0));
        header.setPadding(dp(8), dp(5), dp(8), dp(5));
        header.addView(rankHeaderCellLight("#", 0.5f));
        header.addView(rankHeaderCellLight("Player", 2.6f));
        header.addView(rankHeaderCellLight("Kills", 0.9f));
        header.addView(rankHeaderCellLight("Coins", 0.9f));
        LinearLayout.LayoutParams hdrParams = new LinearLayout.LayoutParams(-1, -2);
        hdrParams.bottomMargin = dp(3);
        body.addView(header, hdrParams);

        String[] medals = {"\uD83E\uDD47", "\uD83E\uDD48", "\uD83E\uDD49"};
        for (int i = 0; i < rows.size(); i++) {
            LbRow r = rows.get(i);
            boolean top = r.rank <= 3 && r.kills > 0;
            LinearLayout row = new LinearLayout(this);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setBackground(sq(top ? Color.rgb(255, 250, 235) : Color.WHITE, Color.rgb(226, 232, 242)));
            row.setPadding(dp(8), dp(6), dp(8), dp(6));
            LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(-1, -2);
            rp.bottomMargin = dp(3);
            row.setLayoutParams(rp);
            row.addView(label(top ? medals[r.rank - 1] : String.valueOf(r.rank), 12, Color.rgb(20, 40, 70), true),
                    new LinearLayout.LayoutParams(0, -2, 0.5f));
            TextView nm = label(r.name, 12, Color.rgb(20, 40, 70), true);
            nm.setSingleLine(true);
            nm.setEllipsize(TextUtils.TruncateAt.END);
            row.addView(nm, new LinearLayout.LayoutParams(0, -2, 2.6f));
            row.addView(label(String.valueOf(r.kills), 12, Color.rgb(92, 108, 128), false), new LinearLayout.LayoutParams(0, -2, 0.9f));
            row.addView(label(String.valueOf(r.coins), 12, Color.rgb(38, 116, 236), true), new LinearLayout.LayoutParams(0, -2, 0.9f));
            body.addView(row);
        }
    }

    private TextView rankHeaderCellLight(String text, float weight) {
        TextView v = label(text, 10, Color.WHITE, true);
        v.setLayoutParams(new LinearLayout.LayoutParams(0, -2, weight));
        return v;
    }

    // ---------------------------------------------------------------- Edit Logs view
    private void drawLogsView(LinearLayout body) {
        FirebaseRepository.editLogs(tournamentId).get().addOnCompleteListener(task -> {
            if (body.getParent() == null || body != rankBody) return;
            body.removeAllViews();
            if (!task.isSuccessful() || task.getResult() == null || !task.getResult().exists()) {
                body.addView(stateView("No edits yet", "Every draft save, publish and edit is listed here."));
                return;
            }
            List<DataSnapshot> logs = new ArrayList<>();
            for (DataSnapshot d : task.getResult().getChildren()) logs.add(d);
            java.util.Collections.sort(logs, (a, b) -> Long.compare(longValue(b.child("timestamp").getValue()),
                    longValue(a.child("timestamp").getValue())));
            int shown = 0;
            for (DataSnapshot d : logs) {
                if (shown++ >= 40) break;
                String action = text(d.child("action").getValue(), "EDIT");
                String admin = text(d.child("admin").getValue(), "admin");
                int at = admin.indexOf('@');
                if (at > 0) admin = admin.substring(0, at);
                long ts = longValue(d.child("timestamp").getValue());
                LinearLayout card = box();
                LinearLayout top = new LinearLayout(this);
                top.setGravity(Gravity.CENTER_VERTICAL);
                boolean pub = action.startsWith("PUBLISH") || action.startsWith("PUBLIC");
                top.addView(chip(action.replace('_', ' '), pub ? Color.rgb(21, 128, 61) : Color.rgb(146, 84, 6),
                        pub ? Color.rgb(230, 248, 238) : Color.rgb(255, 244, 219)));
                TextView who = label("  " + admin, 11, Color.rgb(20, 40, 70), true);
                top.addView(who, new LinearLayout.LayoutParams(0, -2, 1f));
                if (ts > 0) top.addView(label(new SimpleDateFormat("dd MMM, hh:mm a", Locale.ENGLISH).format(new java.util.Date(ts)),
                        9, Color.rgb(140, 155, 175), false));
                card.addView(top);
                TextView det = label(text(d.child("details").getValue(), ""), 10, Color.rgb(92, 108, 128), false);
                det.setPadding(0, dp(3), 0, 0);
                card.addView(det);
                body.addView(card);
            }
        });
    }

    private void renderTeams() {
        ValueEventListener listener = new ValueEventListener() {
            @Override public void onDataChange(DataSnapshot snapshot) {
                content.removeAllViews();
                content.addView(sectionHeader("Teams"));
                if (!snapshot.exists()) { content.addView(stateView("No teams found", "Teams will appear when the teams node is populated.")); return; }
                for (DataSnapshot child : snapshot.getChildren()) {
                    Team team = Team.fromMap(child.getKey(), castMap(child.getValue()));
                    if (team == null) continue;
                    content.addView(row(team.getName(), "Members: " + team.getMemberCount(), team.getStatus()));
                }
            }
            @Override public void onCancelled(DatabaseError error) { content.addView(stateView("Error", error.getMessage())); }
        };
        listeners.put("teams", listener);
        FirebaseRepository.teams().addValueEventListener(listener);
        content.addView(stateView("Loading", "Reading teams from Firebase…"));
    }

    private void renderMatches(boolean schedule) {
        ValueEventListener listener = new ValueEventListener() {
            @Override public void onDataChange(DataSnapshot snapshot) {
                content.removeAllViews();
                content.addView(sectionHeader(schedule ? "Schedule" : "Matches"));
                if (!snapshot.exists()) { content.addView(stateView("No matches", "No match nodes found for this tournament.")); return; }
                int live = 0, waiting = 0, completed = 0;
                for (DataSnapshot child : snapshot.getChildren()) {
                    Match match = Match.fromMap(child.getKey(), castMap(child.getValue()));
                    if (match == null || !tournamentId.equals(match.getTournamentId())) continue;
                    String st = match.getEffectiveStatus();
                    if (Match.LIVE.equals(st) || Match.ROOM_RELEASED.equals(st)) live++;
                    else if (Match.COMPLETED.equals(st)) completed++;
                    else waiting++;
                    content.addView(row(match.getName(), match.getMap() + " • " + match.getMode(), st));
                }
                content.addView(metricRow("Status counts", "Live " + live + ", Waiting " + waiting, "Completed " + completed));
            }
            @Override public void onCancelled(DatabaseError error) { content.addView(stateView("Error", error.getMessage())); }
        };
        listeners.put("matches", listener);
        FirebaseRepository.matches().addValueEventListener(listener);
        content.addView(stateView("Loading", "Fetching tournament matches…"));
    }

    private void renderLeaderboard() {
        ValueEventListener listener = new ValueEventListener() {
            @Override public void onDataChange(DataSnapshot snapshot) {
                content.removeAllViews();
                content.addView(sectionHeader("Leaderboard"));
                DataSnapshot allTime = snapshot.child("allTime");
                if (!allTime.exists()) { content.addView(stateView("No leaderboard data", "Leaderboard entries are not available yet.")); return; }
                for (DataSnapshot child : allTime.getChildren()) {
                    content.addView(row(text(child.child("username").getValue(), child.getKey()),
                            "Matches " + text(child.child("matches").getValue(), "0"),
                            text(child.child("winning").getValue(), "0 PTS")));
                }
            }
            @Override public void onCancelled(DatabaseError error) { content.addView(stateView("Error", error.getMessage())); }
        };
        listeners.put("leaderboard", listener);
        FirebaseRepository.leaderboard().addValueEventListener(listener);
        content.addView(stateView("Loading", "Fetching leaderboard data…"));
    }

    private void renderResults() {
        ValueEventListener listener = new ValueEventListener() {
            @Override public void onDataChange(DataSnapshot snapshot) {
                content.removeAllViews();
                content.addView(sectionHeader("Results"));
                boolean any = false;
                for (DataSnapshot child : snapshot.getChildren()) {
                    if (!tournamentId.equals(text(child.child("tournamentId").getValue(), ""))) continue;
                    any = true;
                    content.addView(row(text(child.child("username").getValue(), child.getKey()),
                            "Kills " + text(child.child("kills").getValue(), "0"),
                            text(child.child("points").getValue(), "0") + " pts"));
                }
                if (!any) content.addView(stateView("No results", "Published results for this tournament will show here."));
            }
            @Override public void onCancelled(DatabaseError error) { content.addView(stateView("Error", error.getMessage())); }
        };
        listeners.put("results", listener);
        FirebaseRepository.results().addValueEventListener(listener);
        content.addView(stateView("Loading", "Fetching tournament results…"));
    }

    private void renderRules() {
        content.addView(card("Rules", tournament.getRules()));
        content.addView(card("Safe admin controls", "Use settings to manage room visibility, status and match operations without changing restricted account data."));
    }

    private void renderReports() { renderSimpleNode("reports", "Reports", FirebaseRepository.reports()); }
    private void renderSupportIssues() { renderSimpleNode("support", "Support Issues", FirebaseRepository.support()); }
    private void renderActivity() { renderSimpleNode("activity", "Activity", FirebaseRepository.activityLogs()); }

    private void renderSettings() {
        content.addView(card("Tournament settings", "Status: " + tournament.getStatus() + "\nRegistration: " + tournament.getRegistrationStatus() + "\nRoom: " + (tournament.isRoomReleased() ? "Released" : "Hidden")));
        MaterialButton refresh = actionButton("Reload tournament", v -> loadTournament());
        content.addView(refresh);
    }

    private void renderSimpleNode(String key, String sectionLabel, com.google.firebase.database.DatabaseReference ref) {
        content.addView(sectionHeader(sectionLabel));
        ValueEventListener listener = new ValueEventListener() {
            @Override public void onDataChange(DataSnapshot snapshot) {
                content.removeAllViews();
                content.addView(sectionHeader(sectionLabel));
                if (!snapshot.exists()) { content.addView(stateView("No data", "No Firebase records available in /" + ref.getKey() + ".")); return; }
                int shown = 0;
                for (DataSnapshot child : snapshot.getChildren()) {
                    if (shown++ >= 8) break;
                    content.addView(row(child.getKey(), text(child.child("title").getValue(), text(child.child("subject").getValue(), sectionLabel)), text(child.child("status").getValue(), "ACTIVE")));
                }
            }
            @Override public void onCancelled(DatabaseError error) { content.addView(stateView("Error", error.getMessage())); }
        };
        listeners.put(key, listener);
        ref.addValueEventListener(listener);
        content.addView(stateView("Loading", "Reading " + sectionLabel.toLowerCase(Locale.ROOT) + "…"));
    }

    private void removeListeners() {
        for (Map.Entry<String, ValueEventListener> e : listeners.entrySet()) {
            String key = e.getKey();
            ValueEventListener listener = e.getValue();
            if ("participants".equals(key)) FirebaseRepository.tournamentParticipants(tournamentId).removeEventListener(listener);
            else if ("teams".equals(key)) FirebaseRepository.teams().removeEventListener(listener);
            else if ("matches".equals(key)) FirebaseRepository.matches().removeEventListener(listener);
            else if ("leaderboard".equals(key)) FirebaseRepository.leaderboard().removeEventListener(listener);
            else if ("results".equals(key)) FirebaseRepository.results().removeEventListener(listener);
            else if ("reports".equals(key)) FirebaseRepository.reports().removeEventListener(listener);
            else if ("support".equals(key)) FirebaseRepository.support().removeEventListener(listener);
            else if ("activity".equals(key)) FirebaseRepository.activityLogs().removeEventListener(listener);
        }
        listeners.clear();
    }

    private LinearLayout card(String heading, String body) {
        LinearLayout box = box();
        box.addView(label(heading, 16, Color.rgb(20, 40, 70), true));
        if (body != null && !body.trim().isEmpty()) box.addView(label(body, 13, Color.rgb(92, 108, 128), false));
        return box;
    }

    private LinearLayout metricRow(String left, String center, String right) {
        LinearLayout row = box();
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.addView(metric(left, 1f));
        row.addView(metric(center, 1f));
        row.addView(metric(right, 1f));
        return row;
    }

    private LinearLayout metric(String text, float weight) {
        LinearLayout wrap = new LinearLayout(this);
        wrap.setOrientation(LinearLayout.VERTICAL);
        wrap.setBackgroundColor(Color.rgb(243, 247, 252));
        wrap.setPadding(dp(12), dp(12), dp(12), dp(12));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, -2, weight);
        p.rightMargin = dp(8);
        wrap.setLayoutParams(p);
        wrap.addView(label(text, 13, Color.rgb(20, 40, 70), true));
        return wrap;
    }

    private LinearLayout row(String title, String subtitle, String statusText) {
        LinearLayout row = box();
        row.addView(label(title, 15, Color.rgb(20, 40, 70), true));
        row.addView(label(subtitle, 12, Color.rgb(92, 108, 128), false));
        row.addView(label(statusText, 11, Color.rgb(38, 116, 236), true));
        return row;
    }

    private LinearLayout stateView(String heading, String body) {
        LinearLayout box = box();
        box.addView(label(heading, 15, Color.rgb(20, 40, 70), true));
        box.addView(label(body, 13, Color.rgb(92, 108, 128), false));
        return box;
    }

    private LinearLayout box() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setBackground(sq(Color.WHITE, Color.rgb(226, 232, 242)));
        box.setPadding(dp(8), dp(7), dp(8), dp(7));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.bottomMargin = dp(6);
        box.setLayoutParams(p);
        return box;
    }

    private TextView sectionHeader(String text) { return label(text, 17, Color.rgb(20, 40, 70), true); }
    private TextView label(String text, int size, int color, boolean bold) {
        TextView v = new TextView(this);
        v.setText(text);
        v.setTextSize(size);
        v.setTextColor(color);
        v.setTypeface(null, bold ? Typeface.BOLD : Typeface.NORMAL);
        return v;
    }
    private MaterialButton actionButton(String text, View.OnClickListener click) {
        MaterialButton b = smallButton(text, true, click);
        b.setLayoutParams(new LinearLayout.LayoutParams(-1, dp(34)));
        return b;
    }
    @SuppressWarnings("unchecked")
    private Map<String, Object> castMap(Object value) { return value instanceof Map ? (Map<String, Object>) value : new HashMap<>(); }
    private String text(Object value, String fallback) { return value == null ? fallback : String.valueOf(value); }
    private void showMessage(String msg) { FancyText.toast(this, msg, Toast.LENGTH_LONG).show(); }
    private int dp(int value) { return Math.round(value * getResources().getDisplayMetrics().density); }

    @Override protected void onDestroy() {
        removeListeners();
        super.onDestroy();
    }
}
