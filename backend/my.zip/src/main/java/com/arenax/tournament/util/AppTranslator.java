package com.arenax.tournament.util;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Handler;
import android.os.Looper;
import android.text.Spanned;
import android.util.Log;
import android.widget.TextView;

import com.arenax.tournament.BuildConfig;
import com.google.android.gms.tasks.Tasks;
import com.google.mlkit.common.model.DownloadConditions;
import com.google.mlkit.nl.translate.TranslateLanguage;
import com.google.mlkit.nl.translate.Translation;
import com.google.mlkit.nl.translate.Translator;
import com.google.mlkit.nl.translate.TranslatorOptions;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.lang.ref.WeakReference;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.WeakHashMap;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.regex.Pattern;

import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

/**
 * Runtime translation of everything the player sees (labels, buttons, hints, toasts, dialogs).
 *
 * The app's texts are English. When a non-English language is chosen, {@link FancyText#apply}
 * hands every TextView to this class. Results are cached on disk per language, so each sentence
 * is translated only once.
 *
 * Engines:
 *  1. ML Kit on-device translation (free, offline after a one-time ~30 MB model download) for
 *     the languages ML Kit supports.
 *  2. Google Cloud Translation (REST) for the remaining Indian languages, used only when
 *     translate.api.key is set in local.properties.
 */
public final class AppTranslator {

    public interface Done { void done(boolean ok); }

    private static final String TAG = "AppTranslator";
    private static final Handler MAIN = new Handler(Looper.getMainLooper());
    private static final ExecutorService IO = Executors.newSingleThreadExecutor();
    private static final Pattern CLOCK = Pattern.compile("\\d{1,2}:\\d{2}");
    private static final int MAX_CACHE = 4000;
    private static final int BATCH = 40;

    private static final Map<String, String> cache = new ConcurrentHashMap<>();
    // Main thread only:
    private static final Map<TextView, String[]> appliedText = new WeakHashMap<>();
    private static final Map<TextView, String[]> appliedHint = new WeakHashMap<>();
    private static final Map<String, List<Slot>> waiting = new LinkedHashMap<>();
    private static final Set<String> inflight = new HashSet<>();
    // IO thread only:
    private static final Map<String, Translator> translators = new HashMap<>();
    private static final OkHttpClient HTTP = new OkHttpClient();

    private static Context app;
    private static String cacheLang;
    private static boolean flushScheduled;
    private static long failUntil;

    private static final class Slot {
        final WeakReference<TextView> ref;
        final boolean hint;
        Slot(TextView tv, boolean hint) { this.ref = new WeakReference<>(tv); this.hint = hint; }
    }

    private AppTranslator() {}

    public static void init(Context ctx) {
        app = ctx.getApplicationContext() == null ? ctx : ctx.getApplicationContext();
        LanguageManager.init(app);
    }

    // ------------------------------------------------------------------ support / prepare

    public static boolean isSupported(String code) {
        if ("en".equals(code)) return true;
        if (mlTag(code) != null) return true;
        return cloudKey().length() > 0;
    }

    /** True when the language works fully on-device (ML Kit), i.e. needs no API key. */
    public static boolean worksWithoutApiKey(String code) {
        return "en".equals(code) || mlTag(code) != null;
    }

    private static String mlTag(String code) {
        try {
            return TranslateLanguage.fromLanguageTag(code);
        } catch (RuntimeException e) {
            return null;
        }
    }

    private static String cloudKey() {
        String k = BuildConfig.TRANSLATE_API_KEY;
        return k == null ? "" : k.trim();
    }

    /** Downloads the language pack (ML Kit) or checks the cloud key; result on the main thread. */
    public static void prepare(final String code, final Done done) {
        IO.execute(() -> {
            boolean ok = false;
            try {
                String tag = mlTag(code);
                if (tag != null) {
                    Translator t = mlTranslator(tag);
                    Tasks.await(t.downloadModelIfNeeded(new DownloadConditions.Builder().build()),
                            5, TimeUnit.MINUTES);
                    ok = true;
                } else if (cloudKey().length() > 0) {
                    List<String> probe = new ArrayList<>();
                    probe.add("Hello");
                    Map<String, String> r = cloudTranslate(code, probe);
                    ok = r.containsKey("Hello");
                }
            } catch (Exception e) {
                Log.w(TAG, "prepare failed for " + code, e);
            }
            final boolean result = ok;
            MAIN.post(() -> done.done(result));
        });
    }

    public static void onLanguageChanged() {
        cacheLang = null;
        waiting.clear();
        inflight.clear();
        appliedText.clear();
        appliedHint.clear();
        failUntil = 0;
        IO.execute(() -> {
            for (Translator t : translators.values()) {
                try { t.close(); } catch (RuntimeException ignored) { }
            }
            translators.clear();
        });
    }

    // ------------------------------------------------------------------ view hooks

    public static void translate(TextView tv) { handle(tv, false); }

    public static void translateHint(TextView tv) { handle(tv, true); }

    /** For toasts: returns the cached translation, otherwise the original and queues it. */
    public static CharSequence cached(CharSequence in) {
        if (in == null || app == null || !LanguageManager.isTranslating()) return in;
        ensureCache();
        String src = FancyText.plain(in).trim();
        if (!worthTranslating(src)) return in;
        String t = cache.get(src);
        if (t != null) return t;
        queue(src, null, false);
        return in;
    }

    private static void handle(TextView tv, boolean hint) {
        if (app == null) return;
        ensureCache();
        CharSequence cur = hint ? tv.getHint() : tv.getText();
        if (cur == null || cur.length() == 0) return;
        Map<TextView, String[]> applied = hint ? appliedHint : appliedText;
        String curStr = cur.toString();
        String[] rec = applied.get(tv);
        if (rec != null && rec[1].equals(curStr)) return; // already our translation
        if (cur instanceof Spanned
                && ((Spanned) cur).getSpans(0, cur.length(), Object.class).length > 0) return;
        String src = FancyText.plain(cur).trim();
        if (!worthTranslating(src)) return;
        String t = cache.get(src);
        if (t != null) {
            put(tv, hint, src, t);
            return;
        }
        if (System.currentTimeMillis() < failUntil) return;
        queue(src, tv, hint);
    }

    private static void put(TextView tv, boolean hint, String src, String translated) {
        (hint ? appliedHint : appliedText).put(tv, new String[]{src, translated});
        if (hint) tv.setHint(translated); else tv.setText(translated);
    }

    private static void queue(String src, TextView tv, boolean hint) {
        List<Slot> list = waiting.get(src);
        if (list == null) {
            list = new ArrayList<>();
            waiting.put(src, list);
        }
        if (tv != null) {
            for (Slot s : list) if (s.ref.get() == tv && s.hint == hint) { scheduleFlush(); return; }
            list.add(new Slot(tv, hint));
        }
        scheduleFlush();
    }

    private static boolean worthTranslating(String s) {
        int n = s.length();
        if (n < 2 || n > 600) return false;
        int latin = 0, other = 0;
        boolean space = false, data = false;
        for (int i = 0; i < n; i++) {
            char c = s.charAt(i);
            if (Character.isWhitespace(c)) space = true;
            else if ((c >= '0' && c <= '9') || c == '@' || c == '/' || c == '_' || c == '#') data = true;
            if (Character.isLetter(c)) {
                if (c < 0x250) latin++; else other++;
            }
        }
        if (latin < 2 || other > latin) return false;
        if (!space && data) return false;       // IDs, e-mails, links
        if (s.contains("://")) return false;
        return !CLOCK.matcher(s).find();         // live timers / clocks change every second
    }

    // ------------------------------------------------------------------ batching

    private static void scheduleFlush() {
        if (flushScheduled) return;
        flushScheduled = true;
        MAIN.postDelayed(AppTranslator::flush, 120);
    }

    private static void flush() {
        flushScheduled = false;
        final String code = LanguageManager.code();
        final List<String> batch = new ArrayList<>();
        for (String key : waiting.keySet()) {
            if (inflight.contains(key)) continue;
            batch.add(key);
            if (batch.size() >= BATCH) break;
        }
        if (batch.isEmpty()) return;
        inflight.addAll(batch);
        IO.execute(() -> {
            final Map<String, String> out = translateBatch(code, batch);
            MAIN.post(() -> onResult(code, batch, out));
        });
        if (waiting.size() > inflight.size()) scheduleFlush();
    }

    private static void onResult(String code, List<String> batch, Map<String, String> out) {
        inflight.removeAll(batch);
        if (!code.equals(LanguageManager.code())) return; // language changed meanwhile
        if (out.isEmpty()) failUntil = System.currentTimeMillis() + 30_000; // offline: back off
        for (String src : batch) {
            List<Slot> slots = waiting.remove(src);
            String t = out.get(src);
            if (t == null || t.isEmpty()) continue;
            if (cache.size() < MAX_CACHE) cache.put(src, t);
            if (slots == null) continue;
            for (Slot s : slots) {
                TextView v = s.ref.get();
                if (v == null) continue;
                CharSequence now = s.hint ? v.getHint() : v.getText();
                if (now == null || !FancyText.plain(now).trim().equals(src)) continue;
                put(v, s.hint, src, t);
            }
        }
        persistCache(code);
    }

    // ------------------------------------------------------------------ engines (IO thread)

    private static Map<String, String> translateBatch(String code, List<String> batch) {
        Map<String, String> out = new HashMap<>();
        try {
            String tag = mlTag(code);
            if (tag != null) {
                Translator t = mlTranslator(tag);
                Tasks.await(t.downloadModelIfNeeded(new DownloadConditions.Builder().build()),
                        5, TimeUnit.MINUTES);
                for (String s : batch) {
                    out.put(s, Tasks.await(t.translate(s), 30, TimeUnit.SECONDS));
                }
            } else if (cloudKey().length() > 0) {
                out.putAll(cloudTranslate(code, batch));
            }
        } catch (Exception e) {
            Log.w(TAG, "translate failed for " + code, e);
        }
        return out;
    }

    private static Translator mlTranslator(String tag) {
        Translator t = translators.get(tag);
        if (t == null) {
            t = Translation.getClient(new TranslatorOptions.Builder()
                    .setSourceLanguage(TranslateLanguage.ENGLISH)
                    .setTargetLanguage(tag)
                    .build());
            translators.put(tag, t);
        }
        return t;
    }

    private static Map<String, String> cloudTranslate(String code, List<String> batch) throws Exception {
        Map<String, String> out = new HashMap<>();
        FormBody.Builder form = new FormBody.Builder(StandardCharsets.UTF_8);
        for (String s : batch) form.add("q", s);
        form.add("source", "en");
        form.add("target", "zh".equals(code) ? "zh-CN" : code);
        form.add("format", "text");
        Request.Builder rb = new Request.Builder()
                .url("https://translation.googleapis.com/language/translate/v2?key=" + cloudKey())
                .post(form.build());
        // Lets the key be restricted to this app in Google Cloud Console.
        rb.header("X-Android-Package", app.getPackageName());
        String sha1 = certSha1();
        if (!sha1.isEmpty()) rb.header("X-Android-Cert", sha1);
        try (Response r = HTTP.newCall(rb.build()).execute()) {
            if (!r.isSuccessful() || r.body() == null) {
                Log.w(TAG, "cloud translate http " + r.code());
                return out;
            }
            JSONArray arr = new JSONObject(r.body().string())
                    .getJSONObject("data").getJSONArray("translations");
            for (int i = 0; i < arr.length() && i < batch.size(); i++) {
                out.put(batch.get(i), arr.getJSONObject(i).getString("translatedText"));
            }
        }
        return out;
    }

    @SuppressWarnings("deprecation")
    private static String certSha1() {
        try {
            PackageInfo pi = app.getPackageManager()
                    .getPackageInfo(app.getPackageName(), PackageManager.GET_SIGNATURES);
            byte[] d = MessageDigest.getInstance("SHA1").digest(pi.signatures[0].toByteArray());
            StringBuilder sb = new StringBuilder();
            for (byte b : d) sb.append(String.format("%02X", b));
            return sb.toString();
        } catch (Exception e) {
            return "";
        }
    }

    // ------------------------------------------------------------------ disk cache

    private static File cacheFile(String code) {
        return new File(app.getFilesDir(), "i18n_" + code.replaceAll("[^A-Za-z0-9-]", "_") + ".json");
    }

    private static void ensureCache() {
        String code = LanguageManager.code();
        if (code.equals(cacheLang)) return;
        cache.clear();
        cacheLang = code;
        File f = cacheFile(code);
        if (!f.exists()) return;
        try (FileInputStream in = new FileInputStream(f)) {
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) bos.write(buf, 0, n);
            JSONObject o = new JSONObject(new String(bos.toByteArray(), StandardCharsets.UTF_8));
            Iterator<String> it = o.keys();
            while (it.hasNext()) {
                String k = it.next();
                cache.put(k, o.getString(k));
            }
        } catch (Exception e) {
            Log.w(TAG, "cache load failed", e);
        }
    }

    private static void persistCache(final String code) {
        final Map<String, String> snap = new HashMap<>(cache);
        IO.execute(() -> {
            try (FileOutputStream out = new FileOutputStream(cacheFile(code))) {
                out.write(new JSONObject(snap).toString().getBytes(StandardCharsets.UTF_8));
            } catch (Exception e) {
                Log.w(TAG, "cache save failed", e);
            }
        });
    }
}
