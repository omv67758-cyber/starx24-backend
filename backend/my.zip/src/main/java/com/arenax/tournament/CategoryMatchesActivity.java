package com.arenax.tournament;


import com.arenax.tournament.util.FancyText;
import com.arenax.tournament.util.FullScreenDialog;
import android.app.Dialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.text.InputType;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.WindowInsetsControllerCompat;
import androidx.core.widget.TextViewCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.arenax.tournament.adapter.TournamentAdapter;
import com.arenax.tournament.data.FirebaseRepository;
import com.arenax.tournament.model.Tournament;
import com.bumptech.glide.Glide;
import com.google.android.material.button.MaterialButton;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class CategoryMatchesActivity extends BaseActivity {
    private final List<Tournament> matches = new ArrayList<>();
    private final List<Tournament> allMatches = new ArrayList<>();
    private ValueEventListener listener;
    private ValueEventListener showTimeListener;
    /** Re-filters the player list the moment a match's "show schedule" time arrives. */
    private final android.os.Handler showScheduleHandler = new android.os.Handler(android.os.Looper.getMainLooper());
    private DataSnapshot lastSnapshot;
    private String categoryId;
    private boolean adminMode;
    private TournamentAdapter adapter;
    private TextView empty;
    private String activeFilter = "UPCOMING";
    private ImageView matchPreview;
    private EditText matchImageUrlField;
    private Uri selectedMatchImage;
    private static final int REQ_MATCH_IMAGE = 8001;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        categoryId = getIntent().getStringExtra("categoryId");
        if (categoryId == null) categoryId = "";
        String categoryTitle = getIntent().getStringExtra("categoryTitle");
        if (categoryTitle == null || categoryTitle.trim().isEmpty()) categoryTitle = "CATEGORY MATCHES";
        adminMode = getIntent().getBooleanExtra("adminMode", false);
        buildScreen(categoryTitle);
        listenForMatches();
    }

    private void buildScreen(String categoryTitle) {
        final int canvas = getColor(R.color.home_bg);
        final int ink = getColor(R.color.text_primary);
        getWindow().setStatusBarColor(canvas);
        getWindow().setNavigationBarColor(canvas);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(canvas);
        // Works on every Android version: on Android 15+ (targetSdk 35, edge-to-edge) the
        // system-bar insets are real and keep the header out from under the status bar;
        // on older versions the insets are already consumed and this adds nothing.
        ViewCompat.setOnApplyWindowInsetsListener(root, (view, insets) -> {
            Insets bars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            view.setPadding(bars.left, bars.top, bars.right, bars.bottom);
            return insets;
        });

        // Full-screen category workspace: back, Ongoing/Upcoming/Completed filter tabs, Add Match action.
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(12), dp(12), dp(12), dp(10));
        TextView back = label("‹", 28, ink, true);
        back.setGravity(Gravity.CENTER); back.setContentDescription("Back");
        back.setBackgroundResource(R.drawable.bg_category_back); back.setOnClickListener(v -> finish());
        bar.addView(back, new LinearLayout.LayoutParams(dp(36), dp(36)));
        LinearLayout heading = new LinearLayout(this); heading.setOrientation(LinearLayout.HORIZONTAL);
        heading.setGravity(Gravity.CENTER_VERTICAL);
        TextView upcomingTab = matchTab("UPCOMING");
        TextView ongoingTab = matchTab("ONGOING");
        TextView completedTab = matchTab("COMPLETED");
        LinearLayout.LayoutParams upcomingParams = new LinearLayout.LayoutParams(0, dp(30), 1f);
        upcomingParams.rightMargin = dp(5);
        LinearLayout.LayoutParams ongoingParams = new LinearLayout.LayoutParams(0, dp(30), 1f);
        ongoingParams.rightMargin = dp(5);
        LinearLayout.LayoutParams completedParams = new LinearLayout.LayoutParams(0, dp(30), 1f);
        upcomingTab.setLayoutParams(upcomingParams);
        ongoingTab.setLayoutParams(ongoingParams);
        completedTab.setLayoutParams(completedParams);
        heading.addView(upcomingTab); heading.addView(ongoingTab); heading.addView(completedTab);
        styleMatchTabs(ongoingTab, upcomingTab, completedTab);
        upcomingTab.setOnClickListener(v -> { activeFilter = "UPCOMING"; styleMatchTabs(ongoingTab, upcomingTab, completedTab); refreshFilteredMatches(); });
        ongoingTab.setOnClickListener(v -> { activeFilter = "ONGOING"; styleMatchTabs(ongoingTab, upcomingTab, completedTab); refreshFilteredMatches(); });
        completedTab.setOnClickListener(v -> { activeFilter = "COMPLETED"; styleMatchTabs(ongoingTab, upcomingTab, completedTab); refreshFilteredMatches(); });
        LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(0, -2, 1f); hp.leftMargin = dp(8); hp.rightMargin = dp(6); bar.addView(heading, hp);
        if (adminMode) {
            MaterialButton add = new MaterialButton(this); add.setText("+ Add Match"); add.setAllCaps(false);
            add.setTextSize(10); add.setTextColor(getColor(R.color.admin_blue)); add.setInsetTop(0); add.setInsetBottom(0);
            add.setMinWidth(0); add.setMinHeight(0); add.setPadding(dp(8), 0, dp(8), 0);
            add.setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xFFE8F1FF));
            add.setStrokeColor(android.content.res.ColorStateList.valueOf(0xFF9CC5F5)); add.setStrokeWidth(dp(1)); add.setCornerRadius(dp(2));
            String categoryTitleForForm = categoryTitle;
            add.setOnClickListener(v -> showMatchTypeChooser(categoryTitleForForm));
            bar.addView(add, new LinearLayout.LayoutParams(-2, dp(36)));
        }
        root.addView(bar, new LinearLayout.LayoutParams(-1, -2));
        if (adminMode) {
            autoDeleteBtn = label("AUTO DELETE ALL COMPLETED", 12, 0xFFD92D20, true);
            autoDeleteBtn.setGravity(Gravity.CENTER);
            autoDeleteBtn.setPadding(dp(12), dp(11), dp(12), dp(11));
            android.graphics.drawable.GradientDrawable adBg = new android.graphics.drawable.GradientDrawable();
            adBg.setColor(0xFFFFF1F0); adBg.setCornerRadius(dp(10)); adBg.setStroke(dp(1), 0xFFD92D20);
            autoDeleteBtn.setBackground(adBg);
            autoDeleteBtn.setVisibility(View.GONE);
            autoDeleteBtn.setOnClickListener(v -> confirmAutoDeleteCompleted());
            LinearLayout.LayoutParams adp = new LinearLayout.LayoutParams(-1, -2);
            adp.setMargins(dp(12), dp(0), dp(12), dp(6));
            root.addView(autoDeleteBtn, adp);
        }
        empty = label(emptyMessage(), 15, getColor(R.color.text_secondary), false);
        empty.setGravity(Gravity.CENTER);
        empty.setPadding(dp(32), 0, dp(32), 0);
        RecyclerView list = new RecyclerView(this);
        list.setLayoutManager(new LinearLayoutManager(this));
        list.setClipToPadding(false);
        list.setPadding(0, dp(4), 0, dp(12));
        adapter = new TournamentAdapter(matches, tournament -> {
            if (adminMode) {
                // Admin is for match-MAKING only. Opening the player-facing
                // TournamentDetailActivity here (with its entry-fee "JOIN" flow) was the bug —
                // admin now goes straight to the match control center instead.
                Intent page = new Intent(this, TournamentControlCenterActivity.class);
                page.putExtra("tournamentId", tournament.getId());
                page.putExtra("title", tournament.getTitle());
                startActivity(page);
            } else if (Tournament.COMPLETED.equals(tournament.getEffectiveStatus())) {
                Intent intent = new Intent(this, MatchResultActivity.class);
                intent.putExtra("tournamentId", tournament.getId());
                startActivity(intent);
            } else {
                Intent intent = new Intent(this, TournamentDetailActivity.class);
                intent.putExtra("tournament", tournament);
                startActivity(intent);
            }
        });
        if (adminMode) {
            adapter.setJoinButtonText("MANAGE MATCH");
            adapter.setOnDeleteClick(this::confirmDeleteMatch);
        }
        adapter.setShowLiveStrip(false);
        list.setAdapter(adapter);

        // The empty message is centered over the list area (it used to sit under the
        // empty list, at the very bottom of the screen).
        FrameLayout body = new FrameLayout(this);
        body.addView(list, new FrameLayout.LayoutParams(-1, -1));
        body.addView(empty, new FrameLayout.LayoutParams(-2, -2, Gravity.CENTER));
        root.addView(body, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(root);

        // Dark status/navigation bar icons on the light canvas.
        WindowInsetsControllerCompat controller = WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView());
        controller.setAppearanceLightStatusBars(true);
        controller.setAppearanceLightNavigationBars(true);
    }

    private String emptyMessage() {
        if ("ONGOING".equals(activeFilter)) return "No ongoing matches right now.";
        if ("COMPLETED".equals(activeFilter)) return "No results published yet.";
        if ("UPCOMING".equals(activeFilter)) return "No upcoming matches yet. Tap Add Match to create one.";
        return "No matches in this category yet. Tap Add Match to create one.";
    }

    private void listenForMatches() {
        if (!FirebaseRepository.isReady(this)) { toast("Live match data is unavailable right now."); return; }
        listener = new ValueEventListener() {
            @Override public void onDataChange(DataSnapshot snapshot) {
                lastSnapshot = snapshot;
                matches.clear();
                allMatches.clear();
                long nextShowAt = 0L;
                for (DataSnapshot child : snapshot.getChildren()) {
                    try {
                        Tournament match = Tournament.fromMap(child.getKey(), (Map<String, Object>) child.getValue());
                        // DRAFT matches are admin-only — a player's category list must never show
                        // a match the admin hasn't finished setting up yet.
                        boolean visible = match != null && categoryId.equals(match.getCategoryId()) && match.isActive()
                                && (adminMode || (!match.isDraft()
                                        && match.isVisibleBySchedule()
                                        && !com.arenax.tournament.util.MatchShowTime.isHidden(match)));
                        // Players: a match waiting for its "show schedule" time -> remember the earliest one.
                        if (!adminMode && match != null && categoryId.equals(match.getCategoryId()) && match.isActive()
                                && !match.isDraft() && !match.isVisibleBySchedule()
                                && (nextShowAt == 0L || match.getShowAt() < nextShowAt)) nextShowAt = match.getShowAt();
                        if (visible) allMatches.add(match);
                        // Daily mode backup: make sure tomorrow's copy exists (server worker does the same).
                        if (visible && adminMode && match.isDailyMode()) FirebaseRepository.ensureDailyNext(match);
                    } catch (RuntimeException ignored) { }
                }
                refreshFilteredMatches();
                scheduleShowTick(nextShowAt);
            }
            @Override public void onCancelled(DatabaseError error) { toast("Could not load matches: " + error.getMessage()); }
        };
        FirebaseRepository.tournaments().addValueEventListener(listener);
        // Admin "Match showing time" changed -> re-filter with the last snapshot (players only).
        if (!adminMode) {
            showTimeListener = com.arenax.tournament.util.MatchShowTime.listen(() -> {
                if (lastSnapshot != null && listener != null) listener.onDataChange(lastSnapshot);
            });
        }
    }

    private void scheduleShowTick(long at) {
        showScheduleHandler.removeCallbacksAndMessages(null);
        if (at <= 0L || adminMode) return;
        long delay = Math.max(500L, at - System.currentTimeMillis() + 300L);
        showScheduleHandler.postDelayed(() -> {
            if (lastSnapshot != null && listener != null) listener.onDataChange(lastSnapshot);
        }, delay);
    }

    private TextView matchTab(String text) {
        TextView tab = label(text, 10, getColor(R.color.text_secondary), true);
        tab.setGravity(Gravity.CENTER);
        tab.setSingleLine(true);
        tab.setMaxLines(1);
        tab.setEllipsize(null);
        tab.setIncludeFontPadding(false);
        tab.setPadding(dp(4), 0, dp(4), 0);
        // Always stays on ONE line: text shrinks (7sp..10sp) instead of wrapping.
        TextViewCompat.setAutoSizeTextTypeUniformWithConfiguration(tab, 7, 10, 1, android.util.TypedValue.COMPLEX_UNIT_SP);
        return tab;
    }

    private void styleMatchTabs(TextView ongoing, TextView upcoming, TextView resulted) {
        styleTab(upcoming, "UPCOMING".equals(activeFilter), 0xFFF59E0B, 0xFFFFF4DB, 0xFFB45309); // amber
        styleTab(ongoing, "ONGOING".equals(activeFilter), 0xFF10B981, 0xFFDCFCE7, 0xFF047857);   // green
        styleTab(resulted, "COMPLETED".equals(activeFilter), 0xFF6366F1, 0xFFE8E9FF, 0xFF4338CA); // indigo
    }

    /** Colourful pill: solid colour + white text when active, soft tint + coloured text when idle. */
    private void styleTab(TextView tab, boolean active, int solid, int tint, int darkText) {
        GradientDrawable bg = new GradientDrawable();
        bg.setCornerRadius(dp(2));
        if (active) {
            bg.setColor(solid);
            bg.setStroke(dp(1), solid);
            tab.setTextColor(Color.WHITE);
        } else {
            bg.setColor(tint);
            bg.setStroke(dp(1), (solid & 0x00FFFFFF) | 0x66000000);
            tab.setTextColor(darkText);
        }
        tab.setBackground(bg);
        tab.setElevation(active ? dp(2) : 0);
        tab.setTypeface(null, Typeface.BOLD);
    }

    private TextView autoDeleteBtn;

    private void refreshFilteredMatches() {
        matches.clear();
        for (Tournament item : allMatches) {
            // Admin only ever sets UPCOMING/COMPLETED/CANCELLED by hand; the "expired but no
            // result yet" case is computed live here so a match never gets stuck showing
            // "Upcoming" forever after its schedule time has passed.
            String status = item.getEffectiveStatus();
            boolean include = "ALL".equals(activeFilter) || ("COMPLETED".equals(activeFilter)
                    ? "COMPLETED".equals(status) : activeFilter.equals(status));
            if (include) matches.add(item);
        }
        // Sooner start time on top, later ones below. COMPLETED: latest finished match on top.
        final boolean completedTab = "COMPLETED".equals(activeFilter);
        java.util.Collections.sort(matches, (a, b) -> {
            long x = a.getEffectiveStartAt();
            long y = b.getEffectiveStartAt();
            if (x <= 0L && y <= 0L) return 0;
            if (x <= 0L) return 1;            // matches without a time go to the bottom
            if (y <= 0L) return -1;
            return completedTab ? Long.compare(y, x) : Long.compare(x, y);
        });
        if (autoDeleteBtn != null) {
            autoDeleteBtn.setVisibility(adminMode && "COMPLETED".equals(activeFilter) && !matches.isEmpty() ? View.VISIBLE : View.GONE);
        }
        if (adapter != null) adapter.notifyDataSetChanged();
        if (empty != null) {
            empty.setText(emptyMessage());
            empty.setVisibility(matches.isEmpty() ? View.VISIBLE : View.GONE);
        }
    }

    private void showAddMatchDialog(String categoryTitle) {
        selectedMatchImage = null;
        LinearLayout form = new LinearLayout(this);
        form.setOrientation(LinearLayout.VERTICAL);
        form.setPadding(dp(22), dp(4), dp(22), dp(8));

        form.addView(sectionLabel("MATCH IMAGE"));
        MaterialButton chooseImage = new MaterialButton(this);
        chooseImage.setText("SELECT PNG/JPG FROM DEVICE");
        chooseImage.setTextColor(Color.WHITE);
        chooseImage.setAllCaps(false);
        chooseImage.setTypeface(null, Typeface.BOLD);
        chooseImage.setBackgroundTintList(android.content.res.ColorStateList.valueOf(getColor(R.color.text_primary)));
        chooseImage.setCornerRadius(dp(14));
        chooseImage.setElevation(0f);
        chooseImage.setInsetTop(0);
        chooseImage.setInsetBottom(0);
        LinearLayout.LayoutParams chooseParams = new LinearLayout.LayoutParams(-1, dp(48));
        chooseParams.topMargin = dp(6);
        chooseParams.bottomMargin = dp(10);
        chooseImage.setLayoutParams(chooseParams);
        chooseImage.setOnClickListener(v -> chooseMatchImage());
        form.addView(chooseImage);

        matchPreview = new ImageView(this);
        matchPreview.setLayoutParams(new LinearLayout.LayoutParams(-1, dp(140)));
        matchPreview.setScaleType(ImageView.ScaleType.CENTER_CROP);
        matchPreview.setBackgroundResource(R.drawable.bg_card);
        form.addView(matchPreview);

        matchImageUrlField = premiumField("Or paste image URL instead");
        form.addView(matchImageUrlField);

        form.addView(sectionLabel("MATCH NAME"));
        EditText title = premiumField("Match name");
        form.addView(title);

        form.addView(sectionLabel("SCHEDULE"));
        EditText date = premiumField("Tap to pick date");
        EditText time = premiumField("Tap to pick time");
        date.setFocusable(false);
        date.setClickable(true);
        time.setFocusable(false);
        time.setClickable(true);
        date.setOnClickListener(v -> showDatePicker(date));
        time.setOnClickListener(v -> showTimePicker(time));
        form.addView(row(date, time));

        form.addView(sectionLabel("PRIZE & SLOTS"));
        EditText prize = premiumField("Prize information (e.g. Diamonds / Bundle)");
        form.addView(prize);
        EditText prizePool = premiumNumberField("Prize pool coins");
        EditText entryFee = premiumNumberField("Entry coins (demo)");
        form.addView(row(prizePool, entryFee));
        EditText perKill = premiumNumberField("Per kill coins");
        EditText gameType = premiumField("Game type (BATTLE ROYALE / CLASH SQUAD)");
        form.addView(row(perKill, gameType));
        EditText slots = premiumNumberField("Total slots");
        EditText teamSize = premiumNumberField("Team size");
        form.addView(row(slots, teamSize));

        form.addView(sectionLabel("MATCH TYPE & MAP"));
        EditText matchType = premiumField("Match type (SOLO / DUO / SQUAD)");
        EditText map = premiumField("Map name");
        form.addView(row(matchType, map));

        form.addView(sectionLabel("DESCRIPTION & RULES"));
        EditText description = premiumField("Match description (optional)");
        form.addView(description);
        EditText rules = premiumField("Rules (optional)");
        form.addView(rules);

        form.addView(sectionLabel("ROOM (OPTIONAL)"));
        EditText room = premiumField("Room ID (optional)");
        form.addView(room);

        ScrollView scroll = new ScrollView(this);
        scroll.setOverScrollMode(View.OVER_SCROLL_IF_CONTENT_SCROLLS);
        scroll.addView(form);

        Dialog dialog = buildStickyFormDialog(
                "Add match",
                "Publish a new match live to Firebase for " + categoryTitle + ". Add a banner image, then save.",
                scroll,
                "SAVE MATCH",
                () -> {
                    String name = value(title);
                    if (name.isEmpty()) { title.setError("Enter match name"); return; }
                    String prizeValue = value(prize).isEmpty() ? "Free entry" : value(prize);
                    int slotsValue = integer(slots, 48);
                    int teamValue = Math.max(1, integer(teamSize, 1));
                    String dateValue = value(date).isEmpty() ? "TBA" : value(date).toUpperCase(java.util.Locale.ROOT);
                    String timeValue = value(time).isEmpty() ? "TBA" : value(time).toUpperCase(java.util.Locale.ROOT);
                    long startAt = parseDateTime(dateValue, timeValue);
                    String matchTypeValue = value(matchType).isEmpty() ? "SOLO" : value(matchType).toUpperCase(java.util.Locale.ROOT);
                    String mapValue = value(map).isEmpty() ? "TBA" : value(map);
                    String descriptionValue = value(description).isEmpty()
                            ? "Live match in " + categoryTitle : value(description);

                    if (selectedMatchImage != null) {
                        FancyText.toast(this, "Uploading image securely…", Toast.LENGTH_SHORT).show();
                        com.arenax.tournament.data.ImgBbUploader.uploadImage(this, selectedMatchImage,
                                new com.arenax.tournament.data.StorageUploader.Callback() {
                                    @Override public void onSuccess(String fileUrl) {
                                        saveMatch(categoryTitle, name, fileUrl, descriptionValue, dateValue, timeValue,
                                                startAt, prizeValue, slotsValue, teamValue, mapValue, matchTypeValue,
                                                value(rules), value(room), integer(entryFee, 0), integer(prizePool, 0), integer(perKill, 0), value(gameType));
                                    }
                                    @Override public void onFailure(String message) {
                                        toast("Image upload failed: " + message);
                                    }
                                });
                    } else {
                        saveMatch(categoryTitle, name, value(matchImageUrlField), descriptionValue, dateValue, timeValue,
                                startAt, prizeValue, slotsValue, teamValue, mapValue, matchTypeValue,
                                value(rules), value(room), integer(entryFee, 0), integer(prizePool, 0), integer(perKill, 0), value(gameType));
                    }
                });
        activeMatchDialog = dialog;
        dialog.show();
    }

    private Dialog activeMatchDialog;

    private void saveMatch(String categoryTitle, String name, String bannerUrl, String descriptionValue,
                            String dateValue, String timeValue, long startAt, String prizeValue, int slotsValue,
                            int teamValue, String mapValue, String matchTypeValue, String rulesValue, String roomValue,
                            int entryFeeCoins, int prizePoolCoins, int perKillCoins, String gameTypeValue) {
        Tournament match = new Tournament(null, name, categoryTitle, categoryId, bannerUrl, descriptionValue,
                dateValue, timeValue, startAt, 0L, 0L, prizeValue, slotsValue, 0,
                teamValue, mapValue, matchTypeValue, rulesValue, "", roomValue, "",
                false, "", "UPCOMING", "OPEN", true, Color.rgb(226, 46, 60));
        match.setCoinDetails(entryFeeCoins, prizePoolCoins, perKillCoins, gameTypeValue);
        FirebaseRepository.saveTournament(match)
                .addOnSuccessListener(done -> {
                    mirrorToMessengerApp(match, categoryTitle, startAt, roomValue);
                    FirebaseRepository.logActivity("MATCH_CREATED", name,
                            categoryTitle + " • " + dateValue + " " + timeValue);
                    toast("Match saved in " + categoryTitle);
                    if (activeMatchDialog != null) activeMatchDialog.dismiss();
                })
                .addOnFailureListener(error -> toast("Save failed: " + error.getMessage()));
    }

    /**
     * Bridges this "Add match" form (which actually saves a Tournament, see
     * FirebaseRepository.saveTournament above) into the /matches node so the
     * android-messenger-app's "Manage Matches" screen (its Match.java model)
     * picks it up immediately without a separate admin step. Field names below
     * match android-messenger-app/app/src/main/java/com/tournament/messanger/Match.java
     * exactly: tournamentTitle, name, category, imageUrl, scheduledAt, roomId,
     * roomPassword, roomReleased, status, participants.
     */
    private void mirrorToMessengerApp(Tournament match, String categoryTitle, long startAt, String roomValue) {
        java.util.Map<String, Object> mirror = new java.util.HashMap<>();
        mirror.put("tournamentTitle", match.getTitle());
        mirror.put("name", match.getTitle());
        mirror.put("category", categoryTitle);
        mirror.put("imageUrl", match.getBannerUrl());
        mirror.put("scheduledAt", startAt);
        mirror.put("roomId", roomValue == null ? "" : roomValue);
        mirror.put("roomPassword", "");
        mirror.put("roomReleased", false);
        mirror.put("status", "UPCOMING");
        mirror.put("participants", new java.util.HashMap<String, Object>());
        FirebaseRepository.matches().push().setValue(mirror);
    }

    /** Real Android calendar picker — writes the chosen date into the field as "dd MMM yyyy" (matches parseDateTime's format). */
    private void showDatePicker(EditText target) {
        java.util.Calendar now = java.util.Calendar.getInstance();
        DatePickerDialog dialog = new DatePickerDialog(this, android.R.style.Theme_Holo_Dialog_MinWidth,
                (view, year, month, dayOfMonth) -> {
                    java.util.Calendar picked = java.util.Calendar.getInstance();
                    picked.set(year, month, dayOfMonth);
                    String formatted = new java.text.SimpleDateFormat("dd MMM yyyy", java.util.Locale.ENGLISH).format(picked.getTime());
                    target.setText(formatted.toUpperCase(java.util.Locale.ROOT));
                },
                now.get(java.util.Calendar.YEAR), now.get(java.util.Calendar.MONTH), now.get(java.util.Calendar.DAY_OF_MONTH));
        dialog.getDatePicker().setMinDate(System.currentTimeMillis() - 1000);
        dialog.show();
    }

    /** Real Android clock picker — writes the chosen time into the field as "hh:mm a" (matches parseDateTime's format). */
    private void showTimePicker(EditText target) {
        java.util.Calendar now = java.util.Calendar.getInstance();
        TimePickerDialog dialog = new TimePickerDialog(this,
                (view, hourOfDay, minute) -> {
                    java.util.Calendar picked = java.util.Calendar.getInstance();
                    picked.set(java.util.Calendar.HOUR_OF_DAY, hourOfDay);
                    picked.set(java.util.Calendar.MINUTE, minute);
                    String formatted = new java.text.SimpleDateFormat("hh:mm a", java.util.Locale.ENGLISH).format(picked.getTime());
                    target.setText(formatted.toUpperCase(java.util.Locale.ROOT));
                },
                now.get(java.util.Calendar.HOUR_OF_DAY), now.get(java.util.Calendar.MINUTE), false);
        dialog.show();
    }

    private void chooseMatchImage() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("image/*");
        startActivityForResult(intent, REQ_MATCH_IMAGE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_MATCH_IMAGE && resultCode == RESULT_OK && data != null && data.getData() != null) {
            selectedMatchImage = data.getData();
            if (matchPreview != null) matchPreview.setImageURI(selectedMatchImage);
        }
    }

    /** Two fields side by side — matches the reference form's Date/Time, Slots/Type rows. */
    private LinearLayout row(View left, View right) {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        lp.rightMargin = dp(6);
        left.setLayoutParams(lp);
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        rp.leftMargin = dp(6);
        right.setLayoutParams(rp);
        r.addView(left);
        r.addView(right);
        return r;
    }

    private TextView sectionLabel(String text) {
        TextView label = new TextView(this);
        label.setText(text);
        label.setTextColor(getColor(R.color.text_secondary));
        label.setTextSize(11f);
        label.setTypeface(null, Typeface.BOLD);
        label.setLetterSpacing(0.02f);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, -2);
        params.topMargin = dp(12);
        params.bottomMargin = dp(4);
        label.setLayoutParams(params);
        return label;
    }

    /**
     * Dialog with a fixed header, a height-capped scrollable form, and a footer with
     * CANCEL / positive buttons that always stay visible — no more Save button
     * disappearing off-screen on long forms. Styled in the app's white theme.
     */
    private Dialog buildStickyFormDialog(String title, String subtitle, View scrollableForm,
                                          String positiveLabel, Runnable onPositive) {
        // Full-screen page (back arrow + title on top, big Cancel / action buttons pinned at the
        // bottom) instead of a small floating card. The action button does not auto-close;
        // callers dismiss the dialog themselves once saving succeeds.
        return FullScreenDialog.form(this, title, subtitle, scrollableForm, positiveLabel, onPositive);
    }

    private View matchDialogDivider() {
        View divider = new View(this);
        divider.setBackgroundColor(getColor(R.color.stroke));
        divider.setLayoutParams(new LinearLayout.LayoutParams(-1, dp(1)));
        return divider;
    }

    /** Deletes every match currently shown in the COMPLETED tab of this category. */
    private void confirmAutoDeleteCompleted() {
        final java.util.List<Tournament> done = new java.util.ArrayList<>(matches);
        if (done.isEmpty()) { toast("Koi completed match nahi hai."); return; }
        new FullScreenDialog.Builder(this)
                .setTitle("Delete " + done.size() + " completed matches?")
                .setMessage("Is tab ke saare completed matches Firebase se permanently hat jayenge.")
                .setNegativeButton("CANCEL", null)
                .setPositiveButton("DELETE ALL", (dialog, which) -> {
                    final int[] ok = {0};
                    final int[] fail = {0};
                    for (Tournament t : done) {
                        FirebaseRepository.deleteTournament(t.getId())
                                .addOnSuccessListener(x -> {
                                    ok[0]++;
                                    FirebaseRepository.logActivity("TOURNAMENT_DELETED", t.getTitle(), "auto delete completed");
                                    if (ok[0] + fail[0] == done.size()) toast(ok[0] + " deleted, " + fail[0] + " failed.");
                                })
                                .addOnFailureListener(e -> {
                                    fail[0]++;
                                    if (ok[0] + fail[0] == done.size()) toast(ok[0] + " deleted, " + fail[0] + " failed.");
                                });
                    }
                })
                .show();
    }

    /** Admin-only: confirm before permanently removing a match from this category. */
    private void confirmDeleteMatch(Tournament tournament) {
        new FullScreenDialog.Builder(this)
                .setTitle("Delete " + tournament.getTitle() + "?")
                .setMessage("This permanently removes the match from Firebase. Players will no longer see it.")
                .setNegativeButton("CANCEL", null)
                .setPositiveButton("DELETE", (dialog, which) ->
                        FirebaseRepository.deleteTournament(tournament.getId())
                                .addOnSuccessListener(done -> {
                                    toast("Match deleted.");
                                    FirebaseRepository.logActivity("TOURNAMENT_DELETED", tournament.getTitle(), "");
                                })
                                .addOnFailureListener(error -> toast("Delete failed: " + error.getMessage())))
                .show();
    }

    private EditText premiumField(String hint) {
        EditText input = new EditText(this);
        input.setHint(hint);
        input.setTextColor(getColor(R.color.text_primary));
        input.setHintTextColor(getColor(R.color.text_muted));
        input.setSingleLine(true);
        input.setBackgroundResource(R.drawable.bg_input);
        int hPad = dp(16), vPad = dp(14);
        input.setPadding(hPad, vPad, hPad, vPad);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                android.view.ViewGroup.LayoutParams.MATCH_PARENT, android.view.ViewGroup.LayoutParams.WRAP_CONTENT);
        params.topMargin = dp(6);
        params.bottomMargin = dp(6);
        input.setLayoutParams(params);
        return input;
    }

    private EditText premiumNumberField(String hint) {
        EditText input = premiumField(hint);
        input.setInputType(InputType.TYPE_CLASS_NUMBER);
        return input;
    }

    private Button button(String text) { Button b = new Button(this); b.setText(text); b.setTextColor(Color.WHITE); return b; }
    private TextView label(String text, int size, int color, boolean bold) { TextView v = new TextView(this); v.setText(text); v.setTextSize(size); v.setTextColor(color); v.setTypeface(null, bold ? 1 : 0); return v; }
    private LinearLayout.LayoutParams margin(int width, int top) { LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(width, dp(50)); p.topMargin = top; return p; }
    private String value(EditText e) { return e.getText() == null ? "" : e.getText().toString().trim(); }
    private int integer(EditText e, int fallback) { try { return Integer.parseInt(value(e)); } catch (NumberFormatException ignored) { return fallback; } }
    private void toast(String message) { FancyText.toast(this, message, Toast.LENGTH_LONG).show(); }
    /** Add Match -> first pick which kind of match this is; the form + result/payout system follow from it.
     *  Each option is a numbered row: [number] | [title + description], with a dark outline per row. */
    private void showMatchTypeChooser(String categoryTitleForForm) {
        final String[] systems = {"BATTLE_1V1", "KILL", "TEAM", "SURVIVAL"};
        final String[] titles = {"1 vs 1", "Full Map", "Team Match", "Survival Match"};
        final String[] descs = {
                "Dono players ko kitne coins dene hain wo khud daalo.",
                "Sabhi players, kill ke hisaab se coins.",
                "Team rank (1st, 2nd, 3rd...) ke hisaab se coins.",
                "Last tak survive: top 10 team ko coins."};
        final int[] colors = {0xFF2563EB, 0xFFDC2626, 0xFF7C3AED, 0xFF059669};

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(16), dp(16), dp(16), dp(12));

        TextView heading = new TextView(this);
        heading.setText("Select match type");
        heading.setTextSize(19);
        heading.setTypeface(null, Typeface.BOLD);
        heading.setTextColor(Color.rgb(18, 31, 55));
        heading.setPadding(dp(2), 0, 0, dp(10));
        box.addView(heading);

        final androidx.appcompat.app.AlertDialog[] holder = new androidx.appcompat.app.AlertDialog[1];
        for (int i = 0; i < systems.length; i++) {
            final int index = i;
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setBackgroundResource(R.drawable.bg_card_dark_outline);
            row.setPadding(dp(12), dp(12), dp(12), dp(12));
            row.setClickable(true);

            // column 1: number badge
            TextView number = new TextView(this);
            number.setText(String.valueOf(i + 1));
            number.setGravity(Gravity.CENTER);
            number.setTextSize(18);
            number.setTypeface(null, Typeface.BOLD);
            number.setTextColor(Color.WHITE);
            GradientDrawable badge = new GradientDrawable();
            badge.setShape(GradientDrawable.RECTANGLE);
            badge.setCornerRadius(dp(8));
            badge.setColor(colors[i]);
            number.setBackground(badge);
            row.addView(number, new LinearLayout.LayoutParams(dp(40), dp(40)));

            // thin vertical divider between the two columns
            View divider = new View(this);
            divider.setBackgroundColor(Color.rgb(209, 213, 219));
            LinearLayout.LayoutParams dv = new LinearLayout.LayoutParams(dp(1), dp(40));
            dv.leftMargin = dp(12); dv.rightMargin = dp(12);
            row.addView(divider, dv);

            // column 2: title + description
            LinearLayout col = new LinearLayout(this);
            col.setOrientation(LinearLayout.VERTICAL);
            TextView title = new TextView(this);
            title.setText(titles[i]);
            title.setTextSize(16);
            title.setTypeface(null, Typeface.BOLD);
            title.setTextColor(Color.rgb(18, 31, 55));
            col.addView(title);
            TextView desc = new TextView(this);
            desc.setText(descs[i]);
            desc.setTextSize(12);
            desc.setTextColor(Color.rgb(75, 85, 99));
            col.addView(desc);
            row.addView(col, new LinearLayout.LayoutParams(0, -2, 1f));

            row.setOnClickListener(v -> {
                if (holder[0] != null) holder[0].dismiss();
                Intent form = new Intent(this, MatchScheduleActivity.class);
                form.putExtra("categoryId", categoryId);
                form.putExtra("categoryTitle", categoryTitleForForm);
                form.putExtra("matchSystem", systems[index]);
                startActivity(form);
            });
            LinearLayout.LayoutParams rowLp = new LinearLayout.LayoutParams(-1, -2);
            rowLp.topMargin = dp(8);
            box.addView(row, rowLp);
        }

        com.google.android.material.button.MaterialButton cancel = new com.google.android.material.button.MaterialButton(this);
        cancel.setText("Cancel");
        cancel.setAllCaps(false);
        cancel.setTextColor(Color.rgb(55, 65, 81));
        cancel.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.WHITE));
        cancel.setStrokeColor(android.content.res.ColorStateList.valueOf(Color.rgb(55, 65, 81)));
        cancel.setStrokeWidth(dp(1));
        cancel.setCornerRadius(dp(8));
        cancel.setOnClickListener(v -> { if (holder[0] != null) holder[0].dismiss(); });
        LinearLayout.LayoutParams cl = new LinearLayout.LayoutParams(-1, dp(46));
        cl.topMargin = dp(14);
        box.addView(cancel, cl);

        android.widget.ScrollView scroll = new android.widget.ScrollView(this);
        scroll.addView(box);
        holder[0] = new androidx.appcompat.app.AlertDialog.Builder(this).setView(scroll).create();
        holder[0].show();
    }

    private int dp(int value) { return Math.round(value * getResources().getDisplayMetrics().density); }

    private long parseDateTime(String date, String time) {
        if (date == null || time == null || date.trim().isEmpty() || time.trim().isEmpty()
                || "TBA".equalsIgnoreCase(date) || "TBA".equalsIgnoreCase(time)) return 0L;
        String combined = date.trim() + " " + time.trim();
        String[] formats = {"dd MMM yyyy hh:mm a", "dd MMM yyyy HH:mm"};
        for (String format : formats) {
            try {
                java.util.Date parsed = new java.text.SimpleDateFormat(format, java.util.Locale.ENGLISH).parse(combined);
                if (parsed != null) return parsed.getTime();
            } catch (java.text.ParseException ignored) {
                // Keep the record publishable even if the optional date can't be parsed.
            }
        }
        return 0L;
    }

    @Override protected void onDestroy() {
        if (listener != null) FirebaseRepository.tournaments().removeEventListener(listener);
        com.arenax.tournament.util.MatchShowTime.unlisten(showTimeListener);
        showScheduleHandler.removeCallbacksAndMessages(null);
        super.onDestroy();
    }
}
