package com.arenax.tournament;


import com.arenax.tournament.util.FancyText;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.arenax.tournament.data.FirebaseRepository;
import com.arenax.tournament.model.Match;
import com.arenax.tournament.model.Tournament;
import com.arenax.tournament.util.FcmSender;
import com.arenax.tournament.util.RoomReleaseScheduler;
import com.google.android.material.button.MaterialButton;
import com.google.firebase.database.DatabaseReference;

/**
 * F1 — full-screen replacement for the old floating room-control dialogs
 * (showRoomControlDialog / showMatchRoomDialog in AdminActivity).
 *
 * One page handles BOTH flows:
 *  - TOURNAMENT mode (extra "tournament"): room ID/password/delay + waitlist promote
 *  - MATCH mode      (extra "match"):      room ID/password/delay per scheduled match
 *
 * Every save path is the exact port of the dialog logic:
 *  - updateRoom()       -> saveTournament + publish notification + targeted FCM push
 *  - match release/hide -> releaseMatchRoom/hideMatchRoom + RoomReleaseScheduler.cancel
 *  - match delay        -> setMatchDelay / clearMatchDelay
 */
public class RoomControlActivity extends BaseActivity {

    public static final String EXTRA_TOURNAMENT = "tournament";
    public static final String EXTRA_MATCH = "match";

    private Tournament tournament;
    private Match match;
    private boolean matchMode;

    private EditText roomIdField;
    private EditText roomPassField;
    private EditText delayField;
    private TextView statusText;
    private MaterialButton releaseToggle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (!FirebaseRepository.isReady(this)) {
            FancyText.toast(this, "Live services are unavailable. Please try again later.", Toast.LENGTH_LONG).show();
            finish();
            return;
        }
        if (android.os.Build.VERSION.SDK_INT >= 33) {
            tournament = getIntent().getSerializableExtra(EXTRA_TOURNAMENT, Tournament.class);
            match = getIntent().getSerializableExtra(EXTRA_MATCH, Match.class);
        } else {
            tournament = (Tournament) getIntent().getSerializableExtra(EXTRA_TOURNAMENT);
            match = (Match) getIntent().getSerializableExtra(EXTRA_MATCH);
        }
        matchMode = match != null;
        if (tournament == null && match == null) {
            finish();
            return;
        }
        buildUi();
    }

    // ------------------------------------------------------------------
    // Theme helpers (match the JoinMatch navy full-screen look)
    // ------------------------------------------------------------------

    private int dp(float v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private TextView navyText(String text, float sizeSp, boolean bold, String hex) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextSize(sizeSp);
        tv.setTypeface(null, bold ? Typeface.BOLD : Typeface.NORMAL);
        tv.setTextColor(Color.parseColor(hex));
        return tv;
    }

    private TextView sectionLabel(String text) {
        TextView label = navyText(text, 11.5f, true, "#68686D");
        label.setLetterSpacing(0.04f);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.topMargin = dp(18);
        p.bottomMargin = dp(6);
        label.setLayoutParams(p);
        return label;
    }

    private EditText navyField(String hint) {
        EditText input = new EditText(this);
        input.setHint(hint);
        input.setTextColor(Color.parseColor("#1C1C1E"));
        input.setHintTextColor(Color.parseColor("#68686D"));
        input.setBackgroundResource(R.drawable.bg_input_navy);
        int hPad = dp(16), vPad = dp(14);
        input.setPadding(hPad, vPad, hPad, vPad);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.topMargin = dp(6);
        p.bottomMargin = dp(6);
        input.setLayoutParams(p);
        input.setTextSize(13.5f);
        return input;
    }

    private MaterialButton gradientButton(String label) {
        MaterialButton b = new MaterialButton(this);
        b.setText(label);
        b.setTextColor(Color.WHITE);
        b.setAllCaps(false);
        b.setTextSize(13f);
        b.setTypeface(null, Typeface.BOLD);
        b.setBackgroundResource(R.drawable.bg_button_gradient);
        b.setElevation(0f);
        b.setInsetTop(0);
        b.setInsetBottom(0);
        b.setCornerRadius(dp(14));
        return b;
    }

    private MaterialButton outlineButton(String label, String strokeHex) {
        MaterialButton b = new MaterialButton(this);
        b.setText(label);
        b.setTextColor(Color.parseColor(strokeHex));
        b.setAllCaps(false);
        b.setTextSize(13f);
        b.setTypeface(null, Typeface.BOLD);
        b.setBackgroundResource(R.drawable.bg_dialog_button_outline);
        b.setStrokeColor(android.content.res.ColorStateList.valueOf(Color.parseColor(strokeHex)));
        b.setStrokeWidth(dp(1));
        b.setElevation(0f);
        b.setInsetTop(0);
        b.setInsetBottom(0);
        b.setCornerRadius(dp(14));
        return b;
    }

    // ------------------------------------------------------------------
    // Page
    // ------------------------------------------------------------------

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundResource(R.drawable.bg_page_navy);

        // ---- Top bar ----
        LinearLayout topBar = new LinearLayout(this);
        topBar.setOrientation(LinearLayout.HORIZONTAL);
        topBar.setGravity(Gravity.CENTER_VERTICAL);
        topBar.setPadding(dp(14), dp(12), dp(14), dp(12));
        topBar.setBackgroundResource(R.drawable.bg_card_navy);

        TextView back = new TextView(this);
        back.setBackgroundResource(R.drawable.bg_section_pill_navy);
        back.setCompoundDrawablesWithIntrinsicBounds(R.drawable.ic_arrow_back, 0, 0, 0);
        back.setCompoundDrawablePadding(dp(6));
        back.setPadding(dp(12), dp(10), dp(12), dp(10));
        back.setOnClickListener(v -> finish());
        topBar.addView(back, new LinearLayout.LayoutParams(-2, -2));

        LinearLayout titleBlock = new LinearLayout(this);
        titleBlock.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams tbParams = new LinearLayout.LayoutParams(0, -2, 1f);
        tbParams.leftMargin = dp(12);
        titleBlock.setLayoutParams(tbParams);
        titleBlock.addView(navyText("ROOM CONTROL", 18f, true, "#1C1C1E"));
        TextView sub = navyText(matchMode ? match.getName() : tournament.getTitle(), 12f, false, "#68686D");
        LinearLayout.LayoutParams subParams = new LinearLayout.LayoutParams(-1, -2);
        subParams.topMargin = dp(2);
        sub.setLayoutParams(subParams);
        titleBlock.addView(sub);
        topBar.addView(titleBlock);
        root.addView(topBar);

        // ---- Body ----
        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(dp(18), dp(12), dp(18), dp(18));

        // Current status card
        LinearLayout statusCard = new LinearLayout(this);
        statusCard.setOrientation(LinearLayout.VERTICAL);
        statusCard.setBackgroundResource(R.drawable.bg_card_navy);
        statusCard.setPadding(dp(14), dp(12), dp(14), dp(12));
        statusCard.addView(navyText("CURRENT STATE", 10.5f, true, "#B8860B"));
        statusText = navyText(releasedFlag() ? "●  ROOM CURRENTLY RELEASED TO PLAYERS" : "●  ROOM CURRENTLY HIDDEN",
                12.5f, true, releasedFlag() ? "#2ECC8F" : "#68686D");
        LinearLayout.LayoutParams statusParams = new LinearLayout.LayoutParams(-1, -2);
        statusParams.topMargin = dp(6);
        statusText.setLayoutParams(statusParams);
        statusCard.addView(statusText);
        TextView hint = navyText(matchMode
                        ? "Release sends Room ID + Password live to this match's participants instantly. A delay reason shows \"MATCH DELAYED — WAIT FOR ROOM ID & PASSWORD\" on the User App."
                        : "Release sends Room ID + Password live to every registered participant instantly.",
                11.5f, false, "#68686D");
        LinearLayout.LayoutParams hintParams = new LinearLayout.LayoutParams(-1, -2);
        hintParams.topMargin = dp(6);
        hint.setLayoutParams(hintParams);
        statusCard.addView(hint);
        body.addView(statusCard);

        // Fields
        body.addView(sectionLabel("ROOM DETAILS"));
        roomIdField = navyField("Room ID");
        String currentRoomId = matchMode ? match.getRoomId() : tournament.getRoomId();
        if (currentRoomId != null && !currentRoomId.isEmpty()) roomIdField.setText(currentRoomId);
        body.addView(roomIdField);
        roomPassField = navyField("Room Password");
        String currentPass = matchMode ? match.getRoomPassword() : tournament.getRoomPassword();
        if (currentPass != null && !currentPass.isEmpty()) roomPassField.setText(currentPass);
        body.addView(roomPassField);
        delayField = navyField("Delay reason (leave empty if not delayed)");
        String currentDelay = matchMode ? match.getDelayReason() : tournament.getDelayReason();
        if (currentDelay != null && !currentDelay.isEmpty()) delayField.setText(currentDelay);
        body.addView(delayField);

        // ---- Tournament mode only: waitlist card ----
        if (!matchMode) {
            body.addView(sectionLabel("WAITLIST CONTROL"));
            LinearLayout waitCard = new LinearLayout(this);
            waitCard.setOrientation(LinearLayout.VERTICAL);
            waitCard.setBackgroundResource(R.drawable.bg_card_navy);
            waitCard.setPadding(dp(14), dp(12), dp(14), dp(12));
            final TextView waitlistStatus = navyText("Checking waitlist…", 12f, false, "#68686D");
            waitCard.addView(waitlistStatus);
            final MaterialButton promote = outlineButton("PROMOTE NEXT FROM WAITLIST", "#B8860B");
            promote.setTextSize(12f);
            promote.setEnabled(false);
            LinearLayout.LayoutParams promoteParams = new LinearLayout.LayoutParams(-1, dp(44));
            promoteParams.topMargin = dp(10);
            waitCard.addView(promote, promoteParams);
            refreshWaitlistStatus(waitlistStatus, promote);
            promote.setOnClickListener(v -> FirebaseRepository.promoteNextFromWaitlist(tournament.getId())
                    .addOnSuccessListener(done -> {
                        FancyText.toast(this, "Promoted the next waitlisted player into the match.",
                                Toast.LENGTH_SHORT).show();
                        FirebaseRepository.logActivity("WAITLIST_PROMOTED", tournament.getTitle(), "");
                        refreshWaitlistStatus(waitlistStatus, promote);
                    })
                    .addOnFailureListener(error ->
                            FancyText.toast(this, error.getMessage(), Toast.LENGTH_SHORT).show()));
            body.addView(waitCard);
        }

        ScrollView scroll = new ScrollView(this);
        scroll.addView(body);
        scroll.setLayoutParams(new LinearLayout.LayoutParams(-1, 0, 1f));
        root.addView(scroll);

        // ---- Pinned action bar ----
        LinearLayout bottomBar = new LinearLayout(this);
        bottomBar.setOrientation(LinearLayout.HORIZONTAL);
        bottomBar.setGravity(Gravity.CENTER_VERTICAL);
        bottomBar.setPadding(dp(16), dp(12), dp(16), dp(14));
        bottomBar.setBackgroundResource(R.drawable.bg_card_navy);

        LinearLayout.LayoutParams actionParams = new LinearLayout.LayoutParams(0, dp(48), 1f);
        actionParams.rightMargin = dp(8);

        MaterialButton cancelButton = outlineButton("CANCEL", "#68686D");
        cancelButton.setOnClickListener(v -> finish());
        bottomBar.addView(cancelButton, actionParams);

        releaseToggle = gradientButton(releasedFlag() ? "HIDE ROOM" : "RELEASE ROOM");
        releaseToggle.setOnClickListener(v -> save(true));
        bottomBar.addView(releaseToggle, actionParams);

        MaterialButton saveButton = gradientButton("SAVE");
        saveButton.setOnClickListener(v -> save(false));
        bottomBar.addView(saveButton, new LinearLayout.LayoutParams(0, dp(48), 1f));
        root.addView(bottomBar);

        setContentView(root);
    }

    private boolean releasedFlag() {
        return matchMode ? match.isRoomReleased() : tournament.isRoomReleased();
    }

    // ------------------------------------------------------------------
    // Save — exact port of updateRoom() / showMatchRoomDialog button logic
    // ------------------------------------------------------------------

    private void save(boolean toggleRelease) {
        final String roomId = roomIdField.getText().toString().trim();
        final String roomPass = roomPassField.getText().toString().trim();
        final String delayReason = delayField.getText().toString().trim();

        if (matchMode) {
            // ---- Match room control (port of showMatchRoomDialog) ----
            if (!delayReason.isEmpty()) {
                FirebaseRepository.setMatchDelay(match.getId(), delayReason, 0L);
                FirebaseRepository.publishNotification("Match Delayed",
                        match.getName() + " delayed: " + delayReason);
                FirebaseRepository.logActivity("MATCH_DELAYED", match.getName(), delayReason);
            } else {
                FirebaseRepository.clearMatchDelay(match.getId());
            }
            if (toggleRelease) {
                // Manual action wins over any pending exact-time auto-release
                // (see RoomReleaseScheduler) so it can never double-fire later.
                RoomReleaseScheduler.cancel(this, match.getId());
                if (match.isRoomReleased()) {
                    FirebaseRepository.hideMatchRoom(match.getId());
                    FirebaseRepository.logActivity("MATCH_ROOM_HIDDEN", match.getName(), "");
                    FancyText.toast(this, "Room hidden from players.", Toast.LENGTH_SHORT).show();
                } else {
                    FirebaseRepository.releaseMatchRoom(match.getId(), roomId, roomPass);
                    FirebaseRepository.logActivity("MATCH_ROOM_RELEASED", match.getName(), "Room " + roomId);
                    FirebaseRepository.publishNotification("Room Released",
                            match.getName() + " room ID & password are now live.");
                    sendRoomReleasePush(FirebaseRepository.matchParticipants(match.getId()),
                            match.getName() + " — Room Released!",
                            "Room ID: " + roomId + " | Password: " + roomPass);
                    FancyText.toast(this, "Room released live to players.", Toast.LENGTH_SHORT).show();
                }
            } else {
                FancyText.toast(this, "Room details saved.", Toast.LENGTH_SHORT).show();
            }
            finish();
            return;
        }

        // ---- Tournament room control (port of updateRoom) ----
        RoomReleaseScheduler.cancel(this, tournament.getId());
        boolean released = toggleRelease ? !tournament.isRoomReleased() : tournament.isRoomReleased();
        Tournament updated = new Tournament(
                tournament.getId(), tournament.getTitle(), tournament.getMode(), tournament.getCategoryId(),
                tournament.getBannerUrl(), tournament.getDescription(), tournament.getDate(), tournament.getTime(),
                tournament.getStartAt(), tournament.getRegistrationCloseAt(), tournament.getRoomReleaseAt(),
                tournament.getPrizeInfo(), tournament.getTotalSlots(), tournament.getJoinedSlots(),
                tournament.getTeamSize(), tournament.getMap(), tournament.getMatchType(), tournament.getRules(),
                tournament.getPrizeDistribution(), roomId, roomPass, released, delayReason,
                tournament.getStatus(), tournament.getRegistrationStatus(), tournament.isActive(),
                tournament.getAccentColor());
        updated.setCoinDetails(tournament.getEntryFeeCoins(), tournament.getPrizePoolCoins(), tournament.getPerKillCoins(), tournament.getGameType());
        updated.setResultSystem(tournament.getResultSystem());
        FirebaseRepository.saveTournament(updated)
                .addOnSuccessListener(unused -> {
                    FancyText.toast(this, released ? "Room released live to players." : "Room hidden from players.",
                            Toast.LENGTH_SHORT).show();
                    FirebaseRepository.logActivity(released ? "ROOM_RELEASED" : "ROOM_HIDDEN",
                            tournament.getTitle(), delayReason);
                    FirebaseRepository.publishNotification(
                            released ? "Room Released" : "Room Update",
                            released ? tournament.getTitle() + " room ID & password are now live."
                                    : (delayReason.isEmpty() ? tournament.getTitle() + " room hidden."
                                    : tournament.getTitle() + " delayed: " + delayReason));
                    if (released) {
                        sendRoomReleasePush(FirebaseRepository.tournamentParticipants(tournament.getId()),
                                tournament.getTitle() + " — Room Released!",
                                "Room ID: " + roomId + " | Password: " + roomPass);
                    }
                    finish();
                })
                .addOnFailureListener(error ->
                        FancyText.toast(this, error.getMessage(), Toast.LENGTH_LONG).show());
    }

    /** A19 — targeted room-release push (copied verbatim from AdminActivity). */
    private void sendRoomReleasePush(DatabaseReference participantsRef, String title, String body) {
        FirebaseRepository.collectParticipantFcmTokens(participantsRef, tokens -> {
            if (tokens.isEmpty()) return;
            new Thread(() -> {
                try {
                    FcmSender.sendToAllTokens(null, tokens, title, body, "",
                            (successCount, total, errorLog) -> runOnUiThread(() ->
                                    FancyText.toast(this, "Notified " + successCount + "/" + total
                                            + " joined player(s).", Toast.LENGTH_SHORT).show()));
                } catch (Exception e) {
                    runOnUiThread(() ->
                            FancyText.toast(this, "Push notify failed: " + e.getMessage(),
                                    Toast.LENGTH_SHORT).show());
                }
            }).start();
        });
    }

    /** A8 — current free-waitlist count; "Promote" only enabled when someone is waiting. */
    private void refreshWaitlistStatus(final TextView status, final MaterialButton promote) {
        FirebaseRepository.tournamentWaitlist(tournament.getId()).get()
                .addOnSuccessListener(snapshot -> {
                    long count = snapshot.getChildrenCount();
                    status.setText(count == 0
                            ? "Waitlist is empty."
                            : count + " player(s) waiting for a free slot.");
                    promote.setEnabled(count > 0);
                })
                .addOnFailureListener(error ->
                        status.setText("Waitlist unavailable: " + error.getMessage()));
    }
}
