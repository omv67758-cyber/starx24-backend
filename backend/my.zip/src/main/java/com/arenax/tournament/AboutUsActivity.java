package com.arenax.tournament;

import android.os.Bundle;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.arenax.tournament.data.FirebaseRepository;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.ValueEventListener;

/** About Us — brand/info screen for STARX24. Texts shown here are the built-in defaults
 *  unless the admin has edited them (Admin Panel -> About Us), stored at appContent/about. */
public class AboutUsActivity extends BaseActivity {

    /** {firebase key, admin label, default text}. Order = order shown in the admin editor. */
    public static final String[][] FIELDS = {
            {"hero", "Hero tagline", "Your Ultimate\nEsports Arena"},
            {"t1", "Heading 1", "Premier Esports Platform"},
            {"b1", "Text 1", "STARX24 is a premier esports platform built for players, bringing organised tournaments, live leaderboards and real cash rewards to every player in the arena."},
            {"t2", "Heading 2", "For Every Skill Level"},
            {"b2", "Text 2", "Join STARX24 to compete in professionally managed tournaments \u2014 solo, duo or full squad \u2014 and earn real rewards based on your in-game performance. Casual or pro, there's a bracket for you here."},
            {"t3", "Heading 3", "Fast & Secure Wallet"},
            {"b3", "Text 3", "Add cash, join matches and withdraw your winnings instantly. Every transaction is protected end-to-end, so you can focus on the game while we handle the payouts."},
            {"t4", "Heading 4", "More Than Just Tournaments"},
            {"b4", "Text 4", "We're building a community where gamers connect, compete and grow together \u2014 match after match, season after season."},
            {"tag", "Bottom line", "Play Together. Win Together."},
    };

    private int viewId(String key) {
        return getResources().getIdentifier("about_" + key, "id", getPackageName());
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about_us);

        findViewById(R.id.about_back).setOnClickListener(v -> finish());
        // Customer Support always opens Telegram, using the support link the admin has
        // configured under Platform Links.
        findViewById(R.id.about_contact_support)
                .setOnClickListener(v -> SupportLinks.openTelegramSupport(this));

        findViewById(R.id.about_social_telegram)
                .setOnClickListener(v -> SupportLinks.openConfiguredLink(this, "telegramUrl", "Telegram"));
        findViewById(R.id.about_social_youtube)
                .setOnClickListener(v -> SupportLinks.openConfiguredLink(this, "youtubeUrl", "YouTube"));
        findViewById(R.id.about_social_instagram)
                .setOnClickListener(v -> SupportLinks.openConfiguredLink(this, "instagramUrl", "Instagram"));

        applyAdminText();
    }

    /** Overrides the default texts with whatever the admin saved (empty/missing = keep default). */
    private void applyAdminText() {
        try {
            FirebaseRepository.appContent().child("about").addListenerForSingleValueEvent(new ValueEventListener() {
                @Override public void onDataChange(@NonNull DataSnapshot snapshot) {
                    if (isFinishing() || isDestroyed()) return;
                    for (String[] f : FIELDS) {
                        String value = snapshot.child(f[0]).getValue(String.class);
                        if (value == null || value.trim().isEmpty()) continue;
                        TextView view = findViewById(viewId(f[0]));
                        if (view != null) view.setText(value);
                    }
                }
                @Override public void onCancelled(@NonNull DatabaseError error) { /* keep defaults */ }
            });
        } catch (RuntimeException ignored) { /* keep defaults */ }
    }
}
