package com.arenax.tournament;


import com.arenax.tournament.util.FancyText;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.widget.NestedScrollView;

import com.arenax.tournament.data.FirebaseRepository;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.ValueEventListener;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/**
 * B40 — Notification inbox. Shows global announcements and notices targeted at this user
 * (room releases, delays, results, support replies), newest first, with local read tracking.
 *
 * Light/white theme with a real (XML vector, never emoji) colored icon per notification
 * type. Opened from the Profile page it shows everything; opened from the Wallet page
 * (EXTRA_WALLET_ONLY) it shows only wallet-related notices — withdrawal updates and coin
 * approvals — so the wallet bell never mixes in match/announcement noise.
 */
public class NotificationsActivity extends BaseActivity {

    /** Pass true to only show wallet-related notifications (withdrawals, coin credits). */
    public static final String EXTRA_WALLET_ONLY = "wallet_only";

    /** Notification "type" values (see FirebaseRepository) that belong to the wallet. */
    private static final Set<String> WALLET_TYPES = new HashSet<>(Arrays.asList(
            "WITHDRAWAL_NOTICE", "COINS_APPROVED", "WALLET", "WALLET_CREDIT", "WALLET_DEBIT"));

    private LinearLayout list;
    private TextView empty;
    private ValueEventListener listener;
    private SharedPreferences prefs;
    private boolean walletOnly;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        walletOnly = getIntent().getBooleanExtra(EXTRA_WALLET_ONLY, false);
        getWindow().setStatusBarColor(Color.WHITE);
        getWindow().setNavigationBarColor(Color.WHITE);
        prefs = getSharedPreferences("notification_read_state", MODE_PRIVATE);
        buildScreen();
        loadNotifications();
    }

    // ---------------------------------------------------------------------------------
    // Screen construction — light theme to match the app's reference notification UI.
    // ---------------------------------------------------------------------------------

    private void buildScreen() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(getColor(R.color.home_bg));
        // Base visual padding, kept even on devices with no cutout/status-bar inset.
        final int basePad = dp(18);
        root.setPadding(basePad, basePad, basePad, basePad);
        // On Android 15+ (targetSdk 35, edge-to-edge) the system draws behind the status
        // bar/nav bar by default, so without this the header sits under the clock,
        // battery and notification icons. Add the real inset on top of the base padding
        // (matches the pattern already used in CategoryMatchesActivity etc.); on older
        // versions the inset is already consumed and this adds nothing.
        ViewCompat.setOnApplyWindowInsetsListener(root, (view, insets) -> {
            Insets bars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            view.setPadding(basePad + bars.left, basePad + bars.top, basePad + bars.right, basePad + bars.bottom);
            return insets;
        });

        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);

        ImageView back = new ImageView(this);
        back.setImageResource(R.drawable.ic_arrow_back);
        back.setColorFilter(getColor(R.color.text_primary));
        back.setBackgroundResource(R.drawable.bg_profile_back);
        back.setPadding(dp(10), dp(10), dp(10), dp(10));
        back.setOnClickListener(v -> finish());
        LinearLayout.LayoutParams backLp = new LinearLayout.LayoutParams(dp(42), dp(42));
        backLp.rightMargin = dp(8);
        top.addView(back, backLp);

        // Envelope badge, mirrors the reference design's inbox icon with an unread dot.
        top.addView(envelopeBadge(), new LinearLayout.LayoutParams(dp(36), dp(36)));

        LinearLayout heading = new LinearLayout(this);
        heading.setOrientation(LinearLayout.VERTICAL);
        heading.setPadding(dp(8), 0, dp(6), 0);
        // Red "INBOX"/"WALLET" eyebrow label removed per request.
        // Single line + ellipsize: at narrow widths (squeezed by the back button, envelope
        // and "MARK ALL READ" pill) a bold, space-less word like "Notifications" would
        // otherwise get force-broken mid-word ("Notification" / "s") instead of wrapping
        // cleanly — ellipsizing keeps it on one legible line instead.
        TextView title = label(walletOnly ? "Wallet Notifications" : "Notifications", 18, getColor(R.color.text_primary), true);
        title.setSingleLine(true);
        title.setEllipsize(TextUtils.TruncateAt.END);
        heading.addView(title);
        top.addView(heading, new LinearLayout.LayoutParams(0, -2, 1));

        TextView markAll = label("MARK ALL READ", 9, getColor(R.color.profile_indigo), true);
        markAll.setSingleLine(true);
        markAll.setPadding(dp(10), dp(9), dp(10), dp(9));
        GradientDrawable markAllBg = new GradientDrawable();
        markAllBg.setShape(GradientDrawable.RECTANGLE);
        markAllBg.setCornerRadius(dp(18));
        markAllBg.setColor(getColor(R.color.profile_indigo_tint));
        markAll.setBackground(markAllBg);
        markAll.setOnClickListener(v -> markAllRead());
        top.addView(markAll, new LinearLayout.LayoutParams(-2, -2));
        root.addView(top, new LinearLayout.LayoutParams(-1, -2));

        empty = label(walletOnly ? "No wallet notifications yet." : "No notifications yet.", 15, getColor(R.color.text_muted), false);
        empty.setGravity(Gravity.CENTER);
        empty.setPadding(0, dp(60), 0, 0);

        list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(0, dp(16), 0, 0);
        NestedScrollView scroll = new NestedScrollView(this);
        LinearLayout container = new LinearLayout(this);
        container.setOrientation(LinearLayout.VERTICAL);
        container.addView(list);
        container.addView(empty);
        scroll.addView(container);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(root);
    }

    private View envelopeBadge() {
        FrameLayout wrap = new FrameLayout(this);
        GradientDrawable bg = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{getColor(R.color.profile_indigo), getColor(R.color.profile_purple)});
        bg.setShape(GradientDrawable.RECTANGLE);
        bg.setCornerRadius(dp(12));
        wrap.setBackground(bg);
        ImageView envelope = new ImageView(this);
        envelope.setImageResource(R.drawable.ic_email);
        envelope.setColorFilter(Color.WHITE);
        FrameLayout.LayoutParams elp = new FrameLayout.LayoutParams(dp(20), dp(20));
        elp.gravity = Gravity.CENTER;
        wrap.addView(envelope, elp);

        View dot = new View(this);
        GradientDrawable dotBg = new GradientDrawable();
        dotBg.setShape(GradientDrawable.OVAL);
        dotBg.setColor(getColor(R.color.profile_red));
        dotBg.setStroke(dp(2), Color.WHITE);
        dot.setBackground(dotBg);
        FrameLayout.LayoutParams dlp = new FrameLayout.LayoutParams(dp(11), dp(11));
        dlp.gravity = Gravity.TOP | Gravity.END;
        wrap.addView(dot, dlp);
        return wrap;
    }

    // ---------------------------------------------------------------------------------
    // Data
    // ---------------------------------------------------------------------------------

    private void loadNotifications() {
        if (!FirebaseRepository.isReady(this)) {
            toast("Live notifications are unavailable right now.");
            return;
        }
        String uid = FirebaseAuth.getInstance().getUid();
        listener = new ValueEventListener() {
            @Override public void onDataChange(@NonNull DataSnapshot snapshot) {
                List<DataSnapshot> items = new ArrayList<>();
                for (DataSnapshot child : snapshot.getChildren()) {
                    String targetUid = child.child("userId").getValue(String.class);
                    if (targetUid != null && !targetUid.equals(uid)) continue;
                    if (walletOnly && !isWalletItem(child)) continue;
                    items.add(child);
                }
                Collections.sort(items, (a, b) -> {
                    long ta = a.child("createdAt").getValue(Long.class) == null ? 0L : a.child("createdAt").getValue(Long.class);
                    long tb = b.child("createdAt").getValue(Long.class) == null ? 0L : b.child("createdAt").getValue(Long.class);
                    return Long.compare(tb, ta);
                });
                list.removeAllViews();
                if (walletOnly) {
                    // Wallet bell: skip global/tournament announcements entirely — only
                    // wallet-typed rows from /notifications belong here.
                    for (DataSnapshot item : items) list.addView(buildRow(item));
                    empty.setVisibility(items.isEmpty() ? View.VISIBLE : View.GONE);
                    return;
                }
                // A17/B29 — pinned announcements relevant to this user surface above the regular inbox.
                FirebaseRepository.announcements().addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override public void onDataChange(@NonNull DataSnapshot announcementSnapshot) {
                        filterAnnouncementsForUser(announcementSnapshot, uid, relevant -> {
                            List<DataSnapshot> pinned = new ArrayList<>();
                            List<DataSnapshot> regularAnnouncements = new ArrayList<>();
                            for (DataSnapshot a : relevant) {
                                if (Boolean.TRUE.equals(a.child("pinned").getValue())) pinned.add(a);
                                else regularAnnouncements.add(a);
                            }
                            for (DataSnapshot a : pinned) list.addView(buildAnnouncementRow(a));
                            for (DataSnapshot a : regularAnnouncements) list.addView(buildAnnouncementRow(a));
                            for (DataSnapshot item : items) list.addView(buildRow(item));
                            empty.setVisibility(items.isEmpty() && relevant.isEmpty() ? View.VISIBLE : View.GONE);
                        });
                    }
                    @Override public void onCancelled(@NonNull DatabaseError error) {
                        for (DataSnapshot item : items) list.addView(buildRow(item));
                        empty.setVisibility(items.isEmpty() ? View.VISIBLE : View.GONE);
                    }
                });
            }
            @Override public void onCancelled(@NonNull DatabaseError error) { toast(error.getMessage()); }
        };
        FirebaseRepository.notifications().addValueEventListener(listener);
    }

    /** Wallet relevance: an explicit wallet "type", or (fallback, for older rows with no
     *  type set) a title/message that clearly talks about coins, payment or withdrawal. */
    private boolean isWalletItem(DataSnapshot item) {
        String type = item.child("type").getValue(String.class);
        if (type != null && WALLET_TYPES.contains(type)) return true;
        String title = String.valueOf(item.child("title").getValue()).toLowerCase(Locale.ENGLISH);
        String message = String.valueOf(item.child("message").getValue()).toLowerCase(Locale.ENGLISH);
        String combined = title + " " + message;
        return combined.contains("wallet") || combined.contains("withdraw") || combined.contains("payment")
                || combined.contains("coin") || combined.contains("deposit") || combined.contains("refund");
    }

    private interface AnnouncementFilterCallback { void onFiltered(List<DataSnapshot> relevant); }

    /**
     * A17 targeting follow-up — an ALL announcement is relevant to everyone. A TOURNAMENT
     * announcement is only relevant to a user registered as a participant of that tournament,
     * and a TEAM announcement only to that team's captain/members. Resolves each targeted
     * announcement against Firebase before handing back the filtered list, so a Tournament
     * Manager's per-tournament notice no longer reaches every player.
     */
    private void filterAnnouncementsForUser(DataSnapshot announcementSnapshot, String uid, AnnouncementFilterCallback callback) {
        List<DataSnapshot> all = new ArrayList<>();
        long now = System.currentTimeMillis();
        for (DataSnapshot a : announcementSnapshot.getChildren()) {
            Long scheduledAt = a.child("scheduledAt").getValue(Long.class);
            Long expiresAt = a.child("expiresAt").getValue(Long.class);
            if (scheduledAt != null && scheduledAt > 0L && scheduledAt > now) continue;
            if (expiresAt != null && expiresAt > 0L && expiresAt <= now) continue;
            all.add(a);
        }
        if (all.isEmpty()) { callback.onFiltered(all); return; }
        List<DataSnapshot> relevant = Collections.synchronizedList(new ArrayList<>());
        int[] pending = {all.size()};
        for (DataSnapshot a : all) {
            String targetType = String.valueOf(a.child("targetType").getValue());
            String targetId = a.child("targetId").getValue(String.class);
            if (uid == null || !("TOURNAMENT".equals(targetType) || "TEAM".equals(targetType)) || targetId == null || targetId.isEmpty()) {
                relevant.add(a);
                if (--pending[0] == 0) callback.onFiltered(sortedByOriginalOrder(relevant, all));
                continue;
            }
            if ("TOURNAMENT".equals(targetType)) {
                FirebaseRepository.tournamentParticipants(targetId).child(uid).addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override public void onDataChange(@NonNull DataSnapshot snap) {
                        if (snap.exists()) relevant.add(a);
                        if (--pending[0] == 0) callback.onFiltered(sortedByOriginalOrder(relevant, all));
                    }
                    @Override public void onCancelled(@NonNull DatabaseError error) {
                        if (--pending[0] == 0) callback.onFiltered(sortedByOriginalOrder(relevant, all));
                    }
                });
            } else {
                FirebaseRepository.teams().child(targetId).addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override public void onDataChange(@NonNull DataSnapshot snap) {
                        boolean isCaptain = uid.equals(snap.child("captainId").getValue(String.class));
                        boolean isMember = snap.child("members").child(uid).exists();
                        if (isCaptain || isMember) relevant.add(a);
                        if (--pending[0] == 0) callback.onFiltered(sortedByOriginalOrder(relevant, all));
                    }
                    @Override public void onCancelled(@NonNull DatabaseError error) {
                        if (--pending[0] == 0) callback.onFiltered(sortedByOriginalOrder(relevant, all));
                    }
                });
            }
        }
    }

    /** Async per-item resolution above can finish out of order; restore the original snapshot order. */
    private List<DataSnapshot> sortedByOriginalOrder(List<DataSnapshot> relevant, List<DataSnapshot> original) {
        List<DataSnapshot> ordered = new ArrayList<>();
        synchronized (relevant) {
            for (DataSnapshot a : original) if (relevant.contains(a)) ordered.add(a);
        }
        return ordered;
    }

    // ---------------------------------------------------------------------------------
    // Row icon styling — a real XML vector icon + solid color circle per notification
    // type (never an emoji glyph), so the inbox reads as colorful the way the reference
    // design does.
    // ---------------------------------------------------------------------------------

    private static final class IconStyle {
        final int iconRes; final int color;
        IconStyle(int iconRes, int color) { this.iconRes = iconRes; this.color = color; }
    }

    private IconStyle iconStyleFor(String type, boolean isAnnouncement) {
        if (isAnnouncement) return new IconStyle(R.drawable.ic_megaphone, getColor(R.color.profile_purple));
        if (type == null) return new IconStyle(R.drawable.ic_chat_bubble, getColor(R.color.profile_pink));
        switch (type) {
            case "WITHDRAWAL_NOTICE":
                return new IconStyle(R.drawable.ic_withdraw, getColor(R.color.profile_green));
            case "COINS_APPROVED":
            case "WALLET_CREDIT":
                return new IconStyle(R.drawable.ic_coin, getColor(R.color.profile_orange));
            case "MATCH_ROOM_RELEASED":
                return new IconStyle(R.drawable.ic_calendar, getColor(R.color.profile_indigo));
            case "ADMIN_NOTICE":
                return new IconStyle(R.drawable.ic_profile, getColor(R.color.profile_blue));
            case "GLOBAL":
                return new IconStyle(R.drawable.ic_megaphone, getColor(R.color.profile_purple));
            default:
                return new IconStyle(R.drawable.ic_chat_bubble, getColor(R.color.profile_pink));
        }
    }

    /** Solid colored circle with a white vector glyph centered in it — built in code so
     *  every notification type gets its own real icon instead of reusing one drawable. */
    private View iconCircle(IconStyle style) {
        FrameLayout box = new FrameLayout(this);
        GradientDrawable bg = new GradientDrawable();
        bg.setShape(GradientDrawable.OVAL);
        bg.setColor(style.color);
        box.setBackground(bg);
        ImageView icon = new ImageView(this);
        icon.setImageResource(style.iconRes);
        icon.setColorFilter(Color.WHITE);
        FrameLayout.LayoutParams ilp = new FrameLayout.LayoutParams(dp(22), dp(22));
        ilp.gravity = Gravity.CENTER;
        box.addView(icon, ilp);
        return box;
    }

    // ---------------------------------------------------------------------------------
    // Rows
    // ---------------------------------------------------------------------------------

    private View buildAnnouncementRow(DataSnapshot item) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setBackgroundResource(R.drawable.bg_card_white);
        row.setPadding(dp(14), dp(14), dp(14), dp(14));
        LinearLayout.LayoutParams rowParams = new LinearLayout.LayoutParams(-1, -2);
        rowParams.bottomMargin = dp(12);
        row.setLayoutParams(rowParams);

        row.addView(iconCircle(iconStyleFor(null, true)), new LinearLayout.LayoutParams(dp(46), dp(46)));

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(14), 0, dp(6), 0);
        String title = String.valueOf(item.child("title").getValue());
        String message = String.valueOf(item.child("message").getValue());
        col.addView(dotLabel("Notice:  " + title, getColor(R.color.text_primary), true));
        TextView messageView = label(message, 13, getColor(R.color.text_secondary), false);
        messageView.setPadding(0, dp(4), 0, dp(4));
        col.addView(messageView);
        col.addView(timeRow(item.child("createdAt").getValue(Long.class)));
        row.addView(col, new LinearLayout.LayoutParams(0, -2, 1));
        row.addView(chevron());
        final com.arenax.tournament.util.NotificationRedirect.Target redirect =
                com.arenax.tournament.util.NotificationRedirect.fromSnapshot(item);
        if (!redirect.isNone()) {
            row.setOnClickListener(v -> com.arenax.tournament.util.NotificationRedirect.open(this, redirect));
        }
        return row;
    }

    private View buildRow(DataSnapshot item) {
        boolean read = prefs.getBoolean(item.getKey(), false);
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setBackgroundResource(read ? R.drawable.bg_card_white : R.drawable.bg_card_notif_unread);
        row.setPadding(dp(14), dp(14), dp(14), dp(14));
        LinearLayout.LayoutParams rowParams = new LinearLayout.LayoutParams(-1, -2);
        rowParams.bottomMargin = dp(12);
        row.setLayoutParams(rowParams);

        String type = item.child("type").getValue(String.class);
        row.addView(iconCircle(iconStyleFor(type, false)), new LinearLayout.LayoutParams(dp(46), dp(46)));

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(14), 0, dp(6), 0);
        String title = String.valueOf(item.child("title").getValue());
        String message = String.valueOf(item.child("message").getValue());
        col.addView(dotLabel(title, getColor(R.color.text_primary), !read));
        TextView messageView = label(message, 13, getColor(R.color.text_secondary), false);
        messageView.setPadding(0, dp(4), 0, dp(4));
        col.addView(messageView);
        col.addView(timeRow(item.child("createdAt").getValue(Long.class)));
        row.addView(col, new LinearLayout.LayoutParams(0, -2, 1));
        row.addView(chevron());

        final com.arenax.tournament.util.NotificationRedirect.Target redirect =
                com.arenax.tournament.util.NotificationRedirect.fromSnapshot(item);
        row.setOnClickListener(v -> {
            prefs.edit().putBoolean(item.getKey(), true).apply();
            loadNotifications();
            // Admin chose a redirect for this notification: go straight to that content.
            if (!redirect.isNone()) com.arenax.tournament.util.NotificationRedirect.open(this, redirect);
        });
        return row;
    }

    /** Title with a small colored unread dot in front, real title text always in place
     *  (no emoji bullet). */
    private LinearLayout dotLabel(String text, int textColor, boolean showDot) {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        if (showDot) {
            View dot = new View(this);
            GradientDrawable dotBg = new GradientDrawable();
            dotBg.setShape(GradientDrawable.OVAL);
            dotBg.setColor(getColor(R.color.profile_indigo));
            dot.setBackground(dotBg);
            LinearLayout.LayoutParams dlp = new LinearLayout.LayoutParams(dp(7), dp(7));
            dlp.rightMargin = dp(8);
            row.addView(dot, dlp);
        }
        row.addView(label(text, 15, textColor, true));
        return row;
    }

    private LinearLayout timeRow(Long createdAt) {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        if (createdAt != null) {
            ImageView clock = new ImageView(this);
            clock.setImageResource(R.drawable.ic_clock);
            clock.setColorFilter(getColor(R.color.text_muted));
            LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(dp(12), dp(12));
            clp.rightMargin = dp(4);
            row.addView(clock, clp);
            String time = new SimpleDateFormat("dd MMM, hh:mm a", Locale.ENGLISH).format(new java.util.Date(createdAt));
            row.addView(label(time, 11, getColor(R.color.text_muted), false));
        }
        return row;
    }

    private ImageView chevron() {
        ImageView chevron = new ImageView(this);
        chevron.setImageResource(R.drawable.ic_chevron_right);
        chevron.setColorFilter(getColor(R.color.text_muted));
        chevron.setLayoutParams(new LinearLayout.LayoutParams(dp(16), dp(16)));
        return chevron;
    }

    private void markAllRead() {
        SharedPreferences.Editor editor = prefs.edit();
        FirebaseRepository.notifications().get().addOnSuccessListener(snapshot -> {
            for (DataSnapshot child : snapshot.getChildren()) editor.putBoolean(child.getKey(), true);
            editor.apply();
            loadNotifications();
            toast("All marked as read.");
        });
    }

    private TextView label(String text, int size, int color, boolean bold) {
        TextView v = new TextView(this);
        v.setText(text);
        v.setTextSize(size);
        v.setTextColor(color);
        v.setTypeface(null, bold ? Typeface.BOLD : Typeface.NORMAL);
        return v;
    }

    private void toast(String message) { FancyText.toast(this, message, Toast.LENGTH_LONG).show(); }
    private int dp(int value) { return Math.round(value * getResources().getDisplayMetrics().density); }

    /** Opens the full (Profile page) notification inbox. */
    public static void openAll(Context context) {
        context.startActivity(new Intent(context, NotificationsActivity.class));
    }

    /** Opens the inbox filtered to wallet-related notifications only (Wallet page bell). */
    public static void openWalletOnly(Context context) {
        Intent intent = new Intent(context, NotificationsActivity.class);
        intent.putExtra(EXTRA_WALLET_ONLY, true);
        context.startActivity(intent);
    }

    @Override
    protected void onDestroy() {
        if (listener != null) FirebaseRepository.notifications().removeEventListener(listener);
        super.onDestroy();
    }
}
