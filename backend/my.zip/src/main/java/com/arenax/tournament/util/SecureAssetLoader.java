package com.arenax.tournament.util;

import android.content.Context;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.bumptech.glide.Priority;
import com.bumptech.glide.load.DataSource;
import com.bumptech.glide.load.Options;
import com.bumptech.glide.load.data.DataFetcher;
import com.bumptech.glide.load.model.GlideUrl;
import com.bumptech.glide.load.model.ModelLoader;
import com.bumptech.glide.load.model.ModelLoaderFactory;
import com.bumptech.glide.load.model.MultiModelLoaderFactory;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.SequenceInputStream;

/**
 * Sits in front of Glide's network loader for EVERY Glide.with(...).load(url) in the app:
 *  1. URL already in the encrypted zip (AssetStore) -> served from it, no network at all.
 *  2. Otherwise -> normal download, and the bytes are written into the encrypted zip for next time.
 */
public final class SecureAssetLoader implements ModelLoader<GlideUrl, InputStream> {

    public static final class Factory implements ModelLoaderFactory<GlideUrl, InputStream> {
        private final Context context;
        private final ModelLoaderFactory<GlideUrl, InputStream> network;

        public Factory(Context context, ModelLoaderFactory<GlideUrl, InputStream> network) {
            this.context = context.getApplicationContext();
            this.network = network;
        }

        @NonNull @Override
        public ModelLoader<GlideUrl, InputStream> build(@NonNull MultiModelLoaderFactory factory) {
            return new SecureAssetLoader(AssetStore.get(context), network.build(factory));
        }

        @Override public void teardown() { network.teardown(); }
    }

    private final AssetStore store;
    private final ModelLoader<GlideUrl, InputStream> network;

    private SecureAssetLoader(AssetStore store, ModelLoader<GlideUrl, InputStream> network) {
        this.store = store;
        this.network = network;
    }

    @Override public boolean handles(@NonNull GlideUrl model) { return network.handles(model); }

    @Nullable @Override
    public LoadData<InputStream> buildLoadData(@NonNull GlideUrl model, int width, int height, @NonNull Options options) {
        LoadData<InputStream> net = network.buildLoadData(model, width, height, options);
        if (net == null) return null;
        return new LoadData<>(net.sourceKey, new Fetcher(store, model.toStringUrl(), net.fetcher));
    }

    private static final class Fetcher implements DataFetcher<InputStream> {
        private final AssetStore store;
        private final String url;
        private final DataFetcher<InputStream> network;
        private volatile boolean fromPack;

        Fetcher(AssetStore store, String url, DataFetcher<InputStream> network) {
            this.store = store;
            this.url = url;
            this.network = network;
        }

        @Override
        public void loadData(@NonNull Priority priority, @NonNull final DataCallback<? super InputStream> callback) {
            byte[] local = store.read(url);
            if (local != null) {
                fromPack = true;
                callback.onDataReady(new ByteArrayInputStream(local));
                return;
            }
            fromPack = false;
            network.loadData(priority, new DataCallback<InputStream>() {
                @Override public void onDataReady(@Nullable InputStream data) {
                    if (data == null) { callback.onDataReady(null); return; }
                    try {
                        ByteArrayOutputStream out = new ByteArrayOutputStream();
                        byte[] buf = new byte[16 * 1024];
                        int n;
                        while ((n = data.read(buf)) > 0) {
                            out.write(buf, 0, n);
                            if (out.size() > AssetStore.MAX_ENTRY_BYTES) {
                                // Too big to keep: hand Glide everything read so far + the rest, don't store.
                                callback.onDataReady(new SequenceInputStream(
                                        new ByteArrayInputStream(out.toByteArray()), data));
                                return;
                            }
                        }
                        byte[] bytes = out.toByteArray();
                        try { data.close(); } catch (Exception ignored) { }
                        if (url.startsWith("http")) store.putAsync(url, bytes);
                        callback.onDataReady(new ByteArrayInputStream(bytes));
                    } catch (Exception e) {
                        callback.onLoadFailed(e);
                    }
                }

                @Override public void onLoadFailed(@NonNull Exception e) { callback.onLoadFailed(e); }
            });
        }

        @Override public void cleanup() { network.cleanup(); }
        @Override public void cancel() { network.cancel(); }
        @NonNull @Override public Class<InputStream> getDataClass() { return InputStream.class; }
        @NonNull @Override public DataSource getDataSource() { return fromPack ? DataSource.LOCAL : DataSource.REMOTE; }
    }
}
