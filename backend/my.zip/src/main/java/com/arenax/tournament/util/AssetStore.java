package com.arenax.tournament.util;

import android.content.Context;
import android.content.SharedPreferences;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;

import net.lingala.zip4j.ZipFile;
import net.lingala.zip4j.model.FileHeader;
import net.lingala.zip4j.model.ZipParameters;
import net.lingala.zip4j.model.enums.AesKeyStrength;
import net.lingala.zip4j.model.enums.CompressionMethod;
import net.lingala.zip4j.model.enums.EncryptionMethod;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.locks.ReentrantReadWriteLock;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

/**
 * Every downloaded image lives inside ONE password-protected (AES-256) zip in the app's private
 * storage. The zip password is random, generated on first use and kept only as an Android
 * Keystore-encrypted blob, so it is never in the APK, never in plain text, and the zip cannot be
 * opened outside this app. Entry names are SHA-256 hashes of the URL (no file names / extensions).
 */
public final class AssetStore {
    private static final String KEYSTORE = "AndroidKeyStore";
    private static final String ALIAS = "arenax_asset_pack_key";
    private static final String PREFS = "arenax_asset_pack";
    private static final String K_PW = "pw_ct";
    private static final String K_IV = "pw_iv";

    public static final long MAX_ENTRY_BYTES = 8L * 1024 * 1024;
    private static final long MAX_PACK_BYTES = 200L * 1024 * 1024;
    private static final char[] HEX = "0123456789abcdef".toCharArray();

    private static AssetStore instance;

    private final Context app;
    private final File packFile;
    // Reads run in parallel (read lock); writes / reset are exclusive (write lock).
    private final ReentrantReadWriteLock rw = new ReentrantReadWriteLock();
    private final ExecutorService writer = Executors.newSingleThreadExecutor();
    private char[] password; // null => store disabled (Keystore unusable) -> plain network loading

    // FAST PATH: one shared ZipFile (central directory parsed ONCE) + an in-memory set of the
    // entry names. Before this, every has()/read() created a new ZipFile and re-parsed the whole
    // central directory (slower the more images were stored, and has() ran on the UI thread).
    private ZipFile zip;                         // guarded by rw
    private Set<String> keys;                    // guarded by rw (null => not loaded yet)

    public static synchronized AssetStore get(Context context) {
        if (instance == null) instance = new AssetStore(context.getApplicationContext());
        return instance;
    }

    private AssetStore(Context app) {
        this.app = app;
        File dir = new File(app.getFilesDir(), "assets_pack");
        //noinspection ResultOfMethodCallIgnored
        dir.mkdirs();
        this.packFile = new File(dir, "arenax_assets.zip");
        this.password = loadOrCreatePassword();
    }

    public boolean isEnabled() { return password != null; }

    public static String keyFor(String url) {
        try {
            byte[] d = MessageDigest.getInstance("SHA-256").digest(url.trim().getBytes(StandardCharsets.UTF_8));
            char[] out = new char[d.length * 2];
            for (int i = 0; i < d.length; i++) {
                out[i * 2] = HEX[(d[i] >> 4) & 0xF];
                out[i * 2 + 1] = HEX[d[i] & 0xF];
            }
            return new String(out);
        } catch (Exception e) {
            return Integer.toHexString(url.hashCode());
        }
    }

    /** Loads the zip + entry-name set once. Caller must NOT hold any lock. */
    private void ensureLoaded() {
        rw.readLock().lock();
        try { if (keys != null) return; } finally { rw.readLock().unlock(); }
        rw.writeLock().lock();
        try {
            if (keys != null) return;
            Set<String> names = new HashSet<>();
            if (packFile.exists()) {
                try {
                    ZipFile z = new ZipFile(packFile, password);
                    List<FileHeader> headers = z.getFileHeaders();
                    if (headers != null) for (FileHeader h : headers) names.add(h.getFileName());
                    zip = z;
                } catch (Exception e) {
                    resetPackLocked();
                    names.clear();
                }
            }
            keys = names;
        } finally {
            rw.writeLock().unlock();
        }
    }

    /** O(1), no disk access after the first call. */
    public boolean has(String url) {
        if (!isEnabled() || url == null) return false;
        ensureLoaded();
        String name = keyFor(url);
        rw.readLock().lock();
        try { return keys != null && keys.contains(name); } finally { rw.readLock().unlock(); }
    }

    /** Decrypted image bytes, or null if this URL is not in the pack. */
    public byte[] read(String url) {
        if (!isEnabled() || url == null) return null;
        ensureLoaded();
        String name = keyFor(url);
        boolean corrupt = false;
        rw.readLock().lock();
        try {
            if (zip == null || keys == null || !keys.contains(name)) return null;
            FileHeader header = zip.getFileHeader(name);
            if (header == null) return null;
            try (InputStream in = zip.getInputStream(header)) {
                ByteArrayOutputStream out = new ByteArrayOutputStream(
                        (int) Math.min(Math.max(header.getUncompressedSize(), 1024), MAX_ENTRY_BYTES));
                byte[] buf = new byte[64 * 1024];
                int n;
                while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
                return out.toByteArray();
            }
        } catch (Exception e) {
            corrupt = true;
            return null;
        } finally {
            rw.readLock().unlock();
            if (corrupt) {
                rw.writeLock().lock();
                try { resetPackLocked(); } finally { rw.writeLock().unlock(); } // images re-download
            }
        }
    }

    /** Saves in the background (single writer thread, so zip writes never overlap). */
    public void putAsync(final String url, final byte[] data) {
        if (!isEnabled() || url == null || data == null || data.length == 0) return;
        writer.execute(() -> put(url, data));
    }

    public void put(String url, byte[] data) {
        if (!isEnabled() || url == null || data == null || data.length == 0 || data.length > MAX_ENTRY_BYTES) return;
        ensureLoaded();
        String name = keyFor(url);
        rw.writeLock().lock();
        try {
            if (packFile.exists() && packFile.length() > MAX_PACK_BYTES) resetPackLocked();
            if (keys == null) keys = new HashSet<>();
            if (keys.contains(name)) return;
            if (zip == null) zip = new ZipFile(packFile, password);
            ZipParameters p = new ZipParameters();
            p.setFileNameInZip(name);
            p.setCompressionMethod(CompressionMethod.STORE); // images are already compressed
            p.setEncryptFiles(true);
            p.setEncryptionMethod(EncryptionMethod.AES);
            p.setAesKeyStrength(AesKeyStrength.KEY_STRENGTH_256);
            zip.addStream(new ByteArrayInputStream(data), p);
            keys.add(name);
        } catch (Exception e) {
            resetPackLocked();
        } finally {
            rw.writeLock().unlock();
        }
    }

    public void clear() {
        rw.writeLock().lock();
        try { resetPackLocked(); } finally { rw.writeLock().unlock(); }
    }

    /** Caller holds the write lock (or is the constructor path). */
    private void resetPackLocked() {
        zip = null;
        keys = new HashSet<>();
        //noinspection ResultOfMethodCallIgnored
        packFile.delete();
    }

    // ---- zip password: random, Keystore-encrypted ---------------------------------------------

    private char[] loadOrCreatePassword() {
        try {
            SharedPreferences prefs = app.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
            String ct = prefs.getString(K_PW, null);
            String iv = prefs.getString(K_IV, null);
            if (ct != null && iv != null) {
                try {
                    Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
                    c.init(Cipher.DECRYPT_MODE, keystoreKey(), new GCMParameterSpec(128, Base64.decode(iv, Base64.NO_WRAP)));
                    return new String(c.doFinal(Base64.decode(ct, Base64.NO_WRAP)), StandardCharsets.UTF_8).toCharArray();
                } catch (Exception keyLostOrChanged) {
                    packFile.delete(); // old pack can't be opened without the old password
                }
            }
            byte[] raw = new byte[32];
            new SecureRandom().nextBytes(raw);
            String fresh = Base64.encodeToString(raw, Base64.NO_WRAP);
            Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
            c.init(Cipher.ENCRYPT_MODE, keystoreKey());
            byte[] enc = c.doFinal(fresh.getBytes(StandardCharsets.UTF_8));
            prefs.edit()
                    .putString(K_PW, Base64.encodeToString(enc, Base64.NO_WRAP))
                    .putString(K_IV, Base64.encodeToString(c.getIV(), Base64.NO_WRAP))
                    .apply();
            return fresh.toCharArray();
        } catch (Exception e) {
            return null; // no usable Keystore: images still load normally from the network
        }
    }

    private static SecretKey keystoreKey() throws Exception {
        KeyStore ks = KeyStore.getInstance(KEYSTORE);
        ks.load(null);
        if (ks.containsAlias(ALIAS)) return ((KeyStore.SecretKeyEntry) ks.getEntry(ALIAS, null)).getSecretKey();
        KeyGenerator g = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, KEYSTORE);
        g.init(new KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .build());
        return g.generateKey();
    }
}
