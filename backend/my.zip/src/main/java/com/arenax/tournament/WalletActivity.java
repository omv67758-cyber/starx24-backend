package com.arenax.tournament;


import com.arenax.tournament.util.FancyText;
import android.content.ComponentName;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.browser.customtabs.CustomTabColorSchemeParams;
import androidx.browser.customtabs.CustomTabsClient;
import androidx.browser.customtabs.CustomTabsIntent;
import androidx.browser.customtabs.CustomTabsServiceConnection;
import androidx.browser.customtabs.CustomTabsSession;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.arenax.tournament.adapter.TransactionAdapter;
import com.arenax.tournament.data.FirebaseRepository;
import com.arenax.tournament.model.Transaction;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Wallet screen. Everything lives on this one page now: check balance (hero card),
 * add coin (inline amount chips + custom amount + UPI pay), withdrawal, and history —
 * the Coin Balance card no longer routes to a separate Add Money screen.
 */
public class WalletActivity extends BaseActivity {

    public static final int MIN_AMOUNT = 10;
    public static final int MAX_AMOUNT = 10000;
    private static final int[] AMOUNTS = {10, 20, 50, 100, 200, 500};

    private static final String WALLET_PREFS = "wallet";
    private static final String PREF_PENDING_ORDER_ID = "pending_order_id";

    private long balance;
    private long withdrawableBalance;
    private int selectedAmount = AMOUNTS[0];

    private TextView total;
    private TextView withdrawBalance;
    private View emptyState;
    private RecyclerView historyRecycler;
    private final List<Transaction> transactions = new ArrayList<>();
    private TransactionAdapter transactionAdapter;

    private final List<View> amountChips = new ArrayList<>();
    private TextView amountError, proceedText;
    private EditText customAmount;
    private View inputBox;
    private View proceedButton;

    private ScrollView scrollView;
    private View addCoinAnchor, withdrawAnchor, historyAnchor;

    private ValueEventListener balanceListener;
    private ValueEventListener historyListener;
    private CustomTabsSession customTabsSession;
    private CustomTabsServiceConnection customTabsConnection;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        setContentView(R.layout.activity_wallet);

        // Wake the backend + Firebase token early; "Proceed to pay" is one tap away.
        ZapUpiClient.warmUp();
        warmUpCustomTabs();

        bindViews();
        setupHistoryList();
        buildAmountChips();
        setupCustomAmount();

        render();
        loadWalletBalance();
        loadTransactionHistory();

        findViewById(R.id.wallet_back).setOnClickListener(v -> finish());

        // Bell in the header had no action at all — admin notices (e.g. withdrawal
        // updates) were written to the inbox but there was no way to open it from here.
        // Opens the wallet-only inbox (withdrawal updates / coin approvals), not the
        // full notification list, so this bell never shows match or announcement noise.
        View bell = findViewById(R.id.wallet_topbar_coin);
        if (bell != null) {
            bell.setOnClickListener(v -> NotificationsActivity.openWalletOnly(this));
        }

        findViewById(R.id.wallet_withdraw).setOnClickListener(v -> WithdrawDialog.show(this, withdrawableBalance));
        proceedButton.setOnClickListener(v -> onProceed());

        // Quick-action row jumps straight to the matching section on this same page.
        findViewById(R.id.wallet_qa_addcoin).setOnClickListener(v -> scrollTo(addCoinAnchor));
        findViewById(R.id.wallet_qa_withdraw).setOnClickListener(v -> scrollTo(withdrawAnchor));
        findViewById(R.id.wallet_qa_history).setOnClickListener(v -> scrollTo(historyAnchor));

        // Wallet is a separate activity. Route its bottom navigation back through
        // MainActivity instead of leaving the selected tab visually stuck here.
        com.google.android.material.bottomnavigation.BottomNavigationView nav =
                findViewById(R.id.wallet_bottom_nav);
        nav.setSelectedItemId(com.arenax.tournament.R.id.nav_wallet);
        nav.setOnItemSelectedListener(item -> {
            int id = item.getItemId();
            if (id == R.id.nav_wallet) return true;
            android.content.Intent intent = new android.content.Intent(this, MainActivity.class);
            intent.putExtra("open_tab", id);
            intent.addFlags(android.content.Intent.FLAG_ACTIVITY_CLEAR_TOP | android.content.Intent.FLAG_ACTIVITY_SINGLE_TOP);
            startActivity(intent);
            finish();
            return true;
        });
    }

    private void bindViews() {
        total = findViewById(R.id.wallet_total);
        withdrawBalance = findViewById(R.id.wallet_withdraw_balance);
        emptyState = findViewById(R.id.wallet_history_empty);
        historyRecycler = findViewById(R.id.wallet_history_recycler);

        amountError = findViewById(R.id.wallet_amount_error);
        proceedText = findViewById(R.id.wallet_proceed_text);
        customAmount = findViewById(R.id.wallet_custom_amount);
        inputBox = findViewById(R.id.wallet_input_box);
        proceedButton = findViewById(R.id.wallet_proceed);

        scrollView = findViewById(R.id.wallet_scroll);
        addCoinAnchor = findViewById(R.id.wallet_addcoin_anchor);
        withdrawAnchor = findViewById(R.id.wallet_withdraw_anchor);
        historyAnchor = findViewById(R.id.wallet_history_anchor);
    }

    private void scrollTo(View anchor) {
        if (scrollView == null || anchor == null) return;
        scrollView.post(() -> scrollView.smoothScrollTo(0, anchor.getTop()));
    }

    private void setupHistoryList() {
        transactionAdapter = new TransactionAdapter(transactions);
        historyRecycler.setLayoutManager(new LinearLayoutManager(this));
        historyRecycler.setAdapter(transactionAdapter);
        historyRecycler.setNestedScrollingEnabled(false);
        renderHistoryVisibility();
    }

    private void renderHistoryVisibility() {
        boolean hasTransactions = !transactions.isEmpty();
        emptyState.setVisibility(hasTransactions ? View.GONE : View.VISIBLE);
        historyRecycler.setVisibility(hasTransactions ? View.VISIBLE : View.GONE);
    }

    // ---------------------------------------------------------------- add coin (amounts)

    private void buildAmountChips() {
        LinearLayout row1 = findViewById(R.id.wallet_amount_row_1);
        LinearLayout row2 = findViewById(R.id.wallet_amount_row_2);
        LayoutInflater inflater = LayoutInflater.from(this);
        int margin = dp(4);

        for (int i = 0; i < AMOUNTS.length; i++) {
            LinearLayout row = i < 3 ? row1 : row2;
            View chip = inflater.inflate(R.layout.item_wallet_amount_chip, row, false);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(76), 1f);
            lp.setMargins(margin, margin, margin, margin);
            chip.setLayoutParams(lp);

            final int amount = AMOUNTS[i];
            ((TextView) chip.findViewById(R.id.wallet_chip_text)).setText("₹" + amount);
            // FIX: was amount * 10 — showed "100 Coins" under a ₹10 chip even though
            // the backend credits exactly 1 coin per ₹1 paid (see creditWalletOnce in
            // backend/index.js, which adds order.amount as-is). That extra ×10 was a
            // display-only bug — real credited coins were always correct (₹10 paid = 10
            // coins), only this label under the chip lied about the ratio.
            ((TextView) chip.findViewById(R.id.wallet_chip_coins_text)).setText(amount + " Coins");
            chip.setOnClickListener(v -> {
                // Picking a chip replaces whatever was typed in the custom field.
                customAmount.setText("");
                customAmount.clearFocus();
                hideKeyboard();
                selectAmount(amount);
            });
            row.addView(chip);
            amountChips.add(chip);
        }
        selectAmount(AMOUNTS[0]); // ₹10 is pre-selected
    }

    /** amount <= 0 clears the chip selection (used while a custom amount is typed). */
    private void selectAmount(int amount) {
        selectedAmount = amount;
        for (int i = 0; i < amountChips.size(); i++) {
            View chip = amountChips.get(i);
            boolean on = AMOUNTS[i] == amount;
            chip.setSelected(on);
            chip.findViewById(R.id.wallet_chip_check).setVisibility(on ? View.VISIBLE : View.GONE);
        }
        hideAmountError();
        updateProceedLabel();
    }

    private void setupCustomAmount() {
        customAmount.setOnFocusChangeListener((v, hasFocus) -> inputBox.setSelected(hasFocus));
        customAmount.setOnEditorActionListener((v, actionId, event) -> {
            hideKeyboard();
            customAmount.clearFocus();
            return true;
        });
        customAmount.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (s.length() > 0) selectAmount(0); // typing overrides the chips
                else if (selectedAmount <= 0) selectAmount(AMOUNTS[0]);
                hideAmountError();
                updateProceedLabel();
            }
            @Override public void afterTextChanged(Editable s) { }
        });
    }

    /** Amount currently chosen (custom field wins over chips), or -1 if the custom field isn't a number. */
    private int currentAmount() {
        String raw = customAmount.getText().toString().trim();
        if (raw.isEmpty()) return selectedAmount;
        try {
            return Integer.parseInt(raw);
        } catch (NumberFormatException e) {
            return -1;
        }
    }

    private boolean isValidAmount(int amount) {
        return amount >= MIN_AMOUNT && amount <= MAX_AMOUNT;
    }

    private void updateProceedLabel() {
        int amount = currentAmount();
        proceedText.setText(isValidAmount(amount) ? "PROCEED TO PAY  ₹" + amount : "PROCEED TO PAY");
    }

    private void showAmountError(String message) {
        amountError.setText(message);
        amountError.setVisibility(View.VISIBLE);
    }

    private void hideAmountError() {
        amountError.setVisibility(View.GONE);
    }

    private void hideKeyboard() {
        InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
        if (imm != null) imm.hideSoftInputFromWindow(customAmount.getWindowToken(), 0);
    }

    private void onProceed() {
        int amount = currentAmount();
        if (amount < MIN_AMOUNT) {
            showAmountError("Minimum amount is ₹" + MIN_AMOUNT);
            return;
        }
        if (amount > MAX_AMOUNT) {
            showAmountError("Maximum amount is ₹" + MAX_AMOUNT);
            return;
        }
        hideKeyboard();
        startPayment(amount);
    }

    // ---------------------------------------------------------------- payment

    private void startPayment(int amount) {
        if (!isValidAmount(amount)) {
            showAmountError("Enter an amount between ₹" + MIN_AMOUNT + " and ₹" + MAX_AMOUNT);
            return;
        }
        // Block duplicate taps while the backend/provider wakes up.
        setProceedEnabled(false);
        toast(getString(R.string.wallet_creating_order));
        String mobile = getSharedPreferences("profile", MODE_PRIVATE).getString("phone", "");
        ZapUpiClient.createOrder(amount, mobile, new ZapUpiClient.Callback() {
            @Override public void onSuccess(String paymentUrl, String orderId) {
                // Survives the app being killed while the Custom Tab is in front,
                // so it can be verified + credited the moment the user is back.
                getSharedPreferences(WALLET_PREFS, MODE_PRIVATE).edit()
                        .putString(PREF_PENDING_ORDER_ID, orderId).apply();
                openInCustomTab(paymentUrl);
            }
            @Override public void onError(String message) {
                setProceedEnabled(true);
                new FancyText.AppCompatBuilder(WalletActivity.this)
                        .setTitle("Could not open payment page")
                        .setMessage(message == null ? "Something went wrong. Please try again." : message)
                        .setPositiveButton("OK", null)
                        .show();
            }
        });
    }

    private void setProceedEnabled(boolean enabled) {
        proceedButton.setEnabled(enabled);
        proceedButton.setAlpha(enabled ? 1f : 0.6f);
    }

    private void warmUpCustomTabs() {
        try {
            String packageName = CustomTabsClient.getPackageName(this, null);
            if (packageName == null) return;
            customTabsConnection = new CustomTabsServiceConnection() {
                @Override public void onCustomTabsServiceConnected(ComponentName name, CustomTabsClient client) {
                    client.warmup(0L);
                    customTabsSession = client.newSession(null);
                }
                @Override public void onServiceDisconnected(ComponentName name) {
                    customTabsSession = null;
                }
            };
            CustomTabsClient.bindCustomTabsService(this, packageName, customTabsConnection);
        } catch (Exception ignored) {
            // Best effort only; openInCustomTab() falls back to a plain launch.
        }
    }

    private void openInCustomTab(String url) {
        try {
            if (customTabsSession != null) {
                customTabsSession.mayLaunchUrl(Uri.parse(url), null, null);
            }
            CustomTabColorSchemeParams colorParams = new CustomTabColorSchemeParams.Builder()
                    .setToolbarColor(0xFF2563EB)
                    .build();
            CustomTabsIntent.Builder builder = customTabsSession != null
                    ? new CustomTabsIntent.Builder(customTabsSession)
                    : new CustomTabsIntent.Builder();
            CustomTabsIntent intent = builder
                    .setDefaultColorSchemeParams(colorParams)
                    .setShowTitle(true)
                    .build();
            intent.launchUrl(this, Uri.parse(url));
        } catch (Exception e) {
            try {
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
            } catch (Exception e2) {
                setProceedEnabled(true);
                toast("Could not open payment page");
            }
        }
    }

    @Override protected void onResume() {
        super.onResume();
        setProceedEnabled(true);
        verifyPendingOrderIfAny();
    }

    /** Safety net: if the app was killed while the payment Custom Tab was in front, the
     *  pending order is still remembered. Re-check it with ZapUPI as soon as the wallet
     *  is visible again and credit it immediately instead of waiting on the webhook. */
    private void verifyPendingOrderIfAny() {
        SharedPreferences prefs = getSharedPreferences(WALLET_PREFS, MODE_PRIVATE);
        String orderId = prefs.getString(PREF_PENDING_ORDER_ID, null);
        if (orderId == null) return;

        ZapUpiClient.verifyOrder(orderId, new ZapUpiClient.VerifyCallback() {
            @Override public void onResult(String status) {
                if ("credited".equals(status) || "failed".equals(status)) {
                    prefs.edit().remove(PREF_PENDING_ORDER_ID).apply();
                    if ("credited".equals(status)) toast(getString(R.string.wallet_add_success));
                }
                // "pending" is left in prefs — the next onResume (or app reopen) retries it.
            }
            @Override public void onError(String message) {
                // Silent: webhook may still credit it independently, and the next
                // onResume will retry the check.
            }
        });
    }

    // ---------------------------------------------------------------- balance + history

    private void loadWalletBalance() {
        com.google.firebase.auth.FirebaseUser user = FirebaseRepository.currentUser();
        if (user == null) return;

        balanceListener = new ValueEventListener() {
            @Override public void onDataChange(DataSnapshot snapshot) {
                Long value = snapshot.getValue(Long.class);
                balance = value == null ? 0L : value;
                render();
            }

            @Override public void onCancelled(DatabaseError error) {
                toast("Could not load wallet balance.");
            }
        };
        FirebaseRepository.users().child(user.getUid()).child("wallet").child("balance")
                .addValueEventListener(balanceListener);
        FirebaseRepository.users().child(user.getUid()).child("wallet").child("withdrawableBalance")
                .addValueEventListener(new ValueEventListener() {
                    @Override public void onDataChange(DataSnapshot snapshot) {
                        Long value = snapshot.getValue(Long.class);
                        withdrawableBalance = value == null ? 0L : Math.max(0L, value);
                        render();
                    }
                    @Override public void onCancelled(DatabaseError error) { }
                });
    }

    /** Reads transactions from wallet/transactions/{uid}; adjust the path to match your backend
     *  schema once payment/withdrawal history is being written server-side. Safe no-op (keeps the
     *  empty state) if the node doesn't exist yet. */
    private void loadTransactionHistory() {
        com.google.firebase.auth.FirebaseUser user = FirebaseRepository.currentUser();
        if (user == null) return;

        historyListener = new ValueEventListener() {
            @Override public void onDataChange(DataSnapshot snapshot) {
                transactions.clear();
                for (DataSnapshot child : snapshot.getChildren()) {
                    Transaction t = transactionFromLedger(child);
                    if (t != null) transactions.add(t);
                }
                transactions.sort((a, b) -> Long.compare(b.getTimestamp(), a.getTimestamp()));
                transactionAdapter.notifyDataSetChanged();
                renderHistoryVisibility();
            }

            @Override public void onCancelled(DatabaseError error) {
                // Keep showing the empty state; history is non-critical to the wallet flow.
            }
        };
        FirebaseRepository.users().child(user.getUid()).child("wallet").child("transactions")
                .addValueEventListener(historyListener);
    }

    private Transaction transactionFromLedger(DataSnapshot child) {
        String rawType = child.child("type").getValue(String.class);
        String rawStatus = child.child("status").getValue(String.class);
        if (rawType == null || rawStatus == null) return null;
        Transaction.Type type;
        Transaction.Status status;
        try {
            type = Transaction.Type.valueOf(rawType);
            status = Transaction.Status.valueOf(rawStatus);
        } catch (IllegalArgumentException ignored) {
            return null;
        }
        Long amount = child.child("amount").getValue(Long.class);
        Long timestamp = child.child("timestamp").getValue(Long.class);
        String title = child.child("title").getValue(String.class);
        if (amount == null || timestamp == null) return null;
        return new Transaction(child.getKey(), type, title == null ? rawType : title,
                amount, timestamp, status);
    }

    @Override protected void onDestroy() {
        com.google.firebase.auth.FirebaseUser user = FirebaseRepository.currentUser();
        if (user != null) {
            if (balanceListener != null) {
                FirebaseRepository.users().child(user.getUid()).child("wallet").child("balance")
                        .removeEventListener(balanceListener);
            }
            if (historyListener != null) {
                FirebaseRepository.users().child(user.getUid()).child("wallet").child("transactions")
                        .removeEventListener(historyListener);
            }
        }
        if (customTabsConnection != null) {
            try { unbindService(customTabsConnection); } catch (Exception ignored) { }
            customTabsConnection = null;
            customTabsSession = null;
        }
        super.onDestroy();
    }

    private void render() {
        total.setText("₹" + balance);
        withdrawBalance.setText("₹" + withdrawableBalance);
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density);
    }

    private void toast(String message) {
        FancyText.toast(this, message, Toast.LENGTH_LONG).show();
    }
}
