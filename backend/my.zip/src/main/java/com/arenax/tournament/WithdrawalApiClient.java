package com.arenax.tournament;

import android.os.Handler;
import android.os.Looper;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

import org.json.JSONObject;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import okhttp3.Call;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

/**
 * Calls the Render backend's withdrawal + leave-match endpoints. Mirrors
 * ZapUpiClient's shape on purpose: same base URL, same Firebase ID token
 * auth, same timeout tuning for Render's free-tier cold starts.
 *
 * Why these went to the backend instead of a direct Firebase write:
 * database.rules.json sets users/$uid/wallet/locked and withdrawals/$id
 * writes to admin-SDK-only, so wallet.balance/wallet.locked can no longer
 * drift out of sync with what a withdrawal request actually holds.
 */
public final class WithdrawalApiClient {
    public interface SimpleCallback {
        void onSuccess(JSONObject result);
        void onError(String message);
    }

    private static final MediaType JSON = MediaType.get("application/json; charset=utf-8");
    private static final OkHttpClient HTTP = new OkHttpClient.Builder()
            .connectTimeout(30, TimeUnit.SECONDS)
            .readTimeout(90, TimeUnit.SECONDS)
            .writeTimeout(30, TimeUnit.SECONDS)
            .callTimeout(120, TimeUnit.SECONDS)
            .retryOnConnectionFailure(true)
            .build();
    private static final Handler MAIN = new Handler(Looper.getMainLooper());

    private WithdrawalApiClient() {}

    /** User-facing: request a payout of `amount` coins to `upiId`. */
    public static void requestWithdrawal(int amount, String upiId, SimpleCallback callback) {
        JSONObject payload = new JSONObject();
        try {
            payload.put("amount", amount);
            payload.put("upiId", upiId);
            // Used only for the admin-side "same device, many accounts" check.
            try {
                android.content.Context ctx = com.google.firebase.FirebaseApp.getInstance().getApplicationContext();
                String device = android.provider.Settings.Secure.getString(ctx.getContentResolver(),
                        android.provider.Settings.Secure.ANDROID_ID);
                if (device != null) payload.put("deviceId", device);
            } catch (Exception ignored) { }
        } catch (Exception e) {
            callback.onError("Could not build request");
            return;
        }
        post("/requestWithdrawal", payload, callback);
    }

    /** Admin-facing: resolve a pending withdrawal. action is "PAID" or "REJECTED". */
    public static void approveWithdrawal(String withdrawalId, String action, SimpleCallback callback) {
        JSONObject payload = new JSONObject();
        try {
            payload.put("withdrawalId", withdrawalId);
            payload.put("action", action);
        } catch (Exception e) {
            callback.onError("Could not build request");
            return;
        }
        post("/admin/approveWithdrawal", payload, callback);
    }

    /** Admin-facing: permanently delete an already-resolved (PAID/REJECTED)
     *  withdrawal from history. A still-PENDING request is rejected by the
     *  backend — resolve it first with approveWithdrawal(). */
    public static void deleteWithdrawal(String withdrawalId, SimpleCallback callback) {
        JSONObject payload = new JSONObject();
        try {
            payload.put("withdrawalId", withdrawalId);
        } catch (Exception e) {
            callback.onError("Could not build request");
            return;
        }
        post("/admin/deleteWithdrawal", payload, callback);
    }

    /** Admin-facing: delete a withdrawal even if it is still PENDING. A pending request holds the
     *  player's coins in wallet.locked, so it is first REJECTED (coins are refunded to the wallet by
     *  the backend) and only then deleted. Already-resolved records are just deleted. */
    public static void deleteWithdrawalAnyStatus(String withdrawalId, SimpleCallback callback) {
        deleteWithdrawal(withdrawalId, new SimpleCallback() {
            @Override public void onSuccess(JSONObject result) { callback.onSuccess(result); }
            @Override public void onError(String message) {
                String m = message == null ? "" : message.toLowerCase(java.util.Locale.ENGLISH);
                if (!m.contains("resolve this request")) { callback.onError(message); return; }
                approveWithdrawal(withdrawalId, "REJECTED", new SimpleCallback() {
                    @Override public void onSuccess(JSONObject r) { deleteWithdrawal(withdrawalId, callback); }
                    @Override public void onError(String msg2) {
                        String m2 = msg2 == null ? "" : msg2.toLowerCase(java.util.Locale.ENGLISH);
                        // someone resolved it in the meantime -> just delete it now
                        if (m2.contains("already resolved")) deleteWithdrawal(withdrawalId, callback);
                        else callback.onError(msg2);
                    }
                });
            }
        });
    }

    /** Admin-facing: permanently delete every already-resolved (PAID/REJECTED)
     *  withdrawal from history in one call. Any still-PENDING request is left
     *  alone by the backend since it still holds locked coins. */
    public static void deleteAllWithdrawals(SimpleCallback callback) {
        post("/admin/deleteAllWithdrawals", new JSONObject(), callback);
    }

    /** Admin-facing: manually add or remove coins. action is "ADD" or "REMOVE"; the backend
     *  updates the wallet and writes the manual_coin_log entry. */
    public static void adjustCoins(String uid, String action, int amount, String reason, SimpleCallback callback) {
        JSONObject payload = new JSONObject();
        try {
            payload.put("uid", uid);
            payload.put("action", action);
            payload.put("amount", amount);
            payload.put("reason", reason);
        } catch (Exception e) {
            callback.onError("Could not build request");
            return;
        }
        post("/admin/adjustCoins", payload, callback);
    }

    /** Admin-facing: after the leaderboard is public, credit every player's leaderboard coins to their
     *  wallet. Safe to call again after an edit - the backend only moves the difference. */
    public static void creditMatchCoins(String tournamentId, SimpleCallback callback) {
        JSONObject payload = new JSONObject();
        try {
            payload.put("tournamentId", tournamentId);
        } catch (Exception e) {
            callback.onError("Could not build request");
            return;
        }
        post("/admin/creditMatchCoins", payload, callback);
    }

    /** Admin-facing settlement for KILL, SURVIVAL and 1VS1 result systems. */
    public static void settleTournament(String tournamentId, String resultSystem,
                                        java.util.List<String> winnerUids, String winnerUid,
                                        String joinedUid, String payoutOption,
                                        String lossMessage, String refundMessage,
                                        SimpleCallback callback) {
        settleTournament(tournamentId, resultSystem, winnerUids, winnerUid, joinedUid, payoutOption,
                lossMessage, refundMessage, null, callback);
    }

    /** TEAM system: teamRanks maps a representative player uid of each team -> team rank (1 = first). */
    public static void settleTournament(String tournamentId, String resultSystem,
                                        java.util.List<String> winnerUids, String winnerUid,
                                        String joinedUid, String payoutOption,
                                        String lossMessage, String refundMessage,
                                        java.util.Map<String, Integer> teamRanks,
                                        SimpleCallback callback) {
        JSONObject payload = new JSONObject();
        try {
            if (teamRanks != null) {
                JSONObject ranks = new JSONObject();
                for (java.util.Map.Entry<String, Integer> e : teamRanks.entrySet()) ranks.put(e.getKey(), e.getValue());
                payload.put("teamRanks", ranks);
            }
            payload.put("tournamentId", tournamentId);
            if (resultSystem != null) payload.put("resultSystem", resultSystem);
            org.json.JSONArray winners = new org.json.JSONArray();
            if (winnerUids != null) for (String uid : winnerUids) winners.put(uid);
            payload.put("winnerUids", winners);
            if (winnerUid != null) payload.put("winnerUid", winnerUid);
            if (joinedUid != null) payload.put("joinedUid", joinedUid);
            if (payoutOption != null) payload.put("payoutOption", payoutOption);
            payload.put("lossMessage", lossMessage == null ? "" : lossMessage);
            payload.put("refundMessage", refundMessage == null ? "" : refundMessage);
        } catch (Exception e) {
            callback.onError("Could not build settlement request");
            return;
        }
        post("/admin/settleTournament", payload, callback);
    }

    /** 1VS1: admin types the exact coins for each of the two players; playerCoins maps uid -> coins. */
    public static void settleBattleManual(String tournamentId, java.util.Map<String, Integer> playerCoins,
                                          String lossMessage, SimpleCallback callback) {
        settleBattleManual(tournamentId, playerCoins, lossMessage, false, callback);
    }

    /** Same as above; refund=true marks every payout as an entry-fee REFUND (works with a single registered player). */
    public static void settleBattleManual(String tournamentId, java.util.Map<String, Integer> playerCoins,
                                          String lossMessage, boolean refund, SimpleCallback callback) {
        settleBattleManual(tournamentId, playerCoins, lossMessage, refund, null, callback);
    }

    /** playerMessages: optional per-player admin message (uid -> text), delivered as that player's notice. */
    public static void settleBattleManual(String tournamentId, java.util.Map<String, Integer> playerCoins,
                                          String lossMessage, boolean refund,
                                          java.util.Map<String, String> playerMessages, SimpleCallback callback) {
        JSONObject payload = new JSONObject();
        try {
            if (playerMessages != null) {
                JSONObject msgs = new JSONObject();
                for (java.util.Map.Entry<String, String> e : playerMessages.entrySet())
                    if (e.getValue() != null && !e.getValue().trim().isEmpty()) msgs.put(e.getKey(), e.getValue().trim());
                payload.put("playerMessages", msgs);
            }
            payload.put("battleRefund", refund);
            JSONObject coins = new JSONObject();
            for (java.util.Map.Entry<String, Integer> e : playerCoins.entrySet()) coins.put(e.getKey(), e.getValue());
            payload.put("tournamentId", tournamentId);
            payload.put("resultSystem", "BATTLE_1V1");
            payload.put("battleCoins", coins);
            payload.put("lossMessage", lossMessage == null ? "" : lossMessage);
            payload.put("refundMessage", "");
        } catch (Exception e) {
            callback.onError("Could not build settlement request");
            return;
        }
        post("/admin/settleTournament", payload, callback);
    }

    /** User-facing: leave a match before it starts, refunding the entry fee. */
    public static void leaveMatch(String tournamentId, SimpleCallback callback) {
        JSONObject payload = new JSONObject();
        try {
            payload.put("tournamentId", tournamentId);
        } catch (Exception e) {
            callback.onError("Could not build request");
            return;
        }
        post("/leaveMatch", payload, callback);
    }

    /** User-facing: AI support chat. `messages` is an array of {role: "user"|"assistant", content}.
     *  Result JSON: {reply: String, escalate: boolean}. */
    public static void supportChat(org.json.JSONArray messages, SimpleCallback callback) {
        JSONObject payload = new JSONObject();
        try {
            payload.put("messages", messages);
        } catch (Exception e) {
            callback.onError("Could not build request");
            return;
        }
        post("/support/chat", payload, callback);
    }

    private static void post(String path, JSONObject payload, SimpleCallback callback) {
        String baseUrl = BuildConfig.STARX_API_BASE_URL == null ? "" : BuildConfig.STARX_API_BASE_URL.trim();
        if (baseUrl.isEmpty() || baseUrl.contains("YOUR-SERVICE")) {
            callback.onError("Backend is not configured. Add backend.base.url before building.");
            return;
        }
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        if (user == null) {
            callback.onError("Please sign in first.");
            return;
        }
        user.getIdToken(false)
                .addOnSuccessListener(result -> {
                    String token = result == null ? null : result.getToken();
                    if (token == null || token.trim().isEmpty()) {
                        MAIN.post(() -> callback.onError("Could not verify your Firebase session."));
                        return;
                    }
                    send(baseUrl, path, token, payload, callback);
                })
                .addOnFailureListener(error ->
                        MAIN.post(() -> callback.onError("Could not verify your Firebase session.")));
    }

    private static void send(String baseUrl, String path, String idToken, JSONObject payload, SimpleCallback callback) {
        String normalizedBaseUrl = baseUrl.endsWith("/") ? baseUrl.substring(0, baseUrl.length() - 1) : baseUrl;
        Request request = new Request.Builder()
                .url(normalizedBaseUrl + path)
                .post(RequestBody.create(payload.toString(), JSON))
                .addHeader("Authorization", "Bearer " + idToken)
                .build();

        HTTP.newCall(request).enqueue(new okhttp3.Callback() {
            @Override public void onFailure(Call call, IOException error) {
                boolean timeout = error instanceof java.net.SocketTimeoutException;
                String message = timeout
                        ? "Server is waking up. Please try again in a few seconds."
                        : "Could not connect to the server. Please check your internet and try again.";
                MAIN.post(() -> callback.onError(message));
            }

            @Override public void onResponse(Call call, Response response) {
                try (Response bodyResponse = response) {
                    String body = bodyResponse.body() == null ? "" : bodyResponse.body().string();
                    JSONObject result = body.isEmpty() ? new JSONObject() : new JSONObject(body);
                    if (!response.isSuccessful()) {
                        String message = result.optString("error", "Request failed (" + response.code() + ")");
                        MAIN.post(() -> callback.onError(message));
                        return;
                    }
                    MAIN.post(() -> callback.onSuccess(result));
                } catch (Exception error) {
                    MAIN.post(() -> callback.onError("Invalid response from server."));
                }
            }
        });
    }
}
