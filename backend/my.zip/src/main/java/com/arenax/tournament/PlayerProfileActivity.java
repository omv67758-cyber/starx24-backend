package com.arenax.tournament;

import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.WindowInsetsControllerCompat;

import com.arenax.tournament.data.FirebaseRepository;
import com.arenax.tournament.util.FancyText;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.resource.bitmap.CircleCrop;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.ValueEventListener;

/**
 * Public view of another player: logo (photo), name and bio ONLY.
 * Reads publicProfiles/{uid} - email, phone and wallet are never loaded here.
 */
public class PlayerProfileActivity extends BaseActivity {
    public static final String EXTRA_UID = "uid";
    public static final String EXTRA_NAME = "name";
    public static final String EXTRA_BIO = "bio";
    public static final String EXTRA_PHOTO = "photo";

    private static final int INK = 0xFF101936, MUTED = 0xFF5B6784, BLUE = 0xFF2F6FED, VIOLET = 0xFF7C5CE8, PINK = 0xFFEC4899;

    private ImageView avatar;
    private TextView nameView, bioView;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        build();
        show(getIntent().getStringExtra(EXTRA_NAME), getIntent().getStringExtra(EXTRA_BIO), getIntent().getStringExtra(EXTRA_PHOTO));
        String uid = getIntent().getStringExtra(EXTRA_UID);
        if (uid != null && !uid.isEmpty() && FirebaseRepository.isReady(this)) {
            FirebaseRepository.publicProfiles().child(uid).addListenerForSingleValueEvent(new ValueEventListener() {
                @Override public void onDataChange(DataSnapshot s) {
                    if (isFinishing() || isDestroyed() || !s.exists()) return;
                    show(str(s.child("name").getValue()), str(s.child("bio").getValue()), str(s.child("photoUrl").getValue()));
                }
                @Override public void onCancelled(DatabaseError e) { }
            });
        }
    }

    private void build() {
        final int canvas = getColor(R.color.home_bg);
        getWindow().setStatusBarColor(canvas);
        getWindow().setNavigationBarColor(canvas);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(canvas);
        ViewCompat.setOnApplyWindowInsetsListener(root, (v, insets) -> {
            Insets b = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(b.left, b.top, b.right, b.bottom);
            return insets;
        });

        LinearLayout bar = new LinearLayout(this);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(12), dp(12), dp(12), dp(8));
        TextView back = text("\u2039", 28, INK, true);
        back.setGravity(Gravity.CENTER);
        back.setBackgroundResource(R.drawable.bg_category_back);
        back.setOnClickListener(v -> finish());
        bar.addView(back, new LinearLayout.LayoutParams(dp(36), dp(36)));
        TextView title = text("Player Profile", 18, INK, true);
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(0, -2, 1f);
        tp.leftMargin = dp(12);
        bar.addView(title, tp);
        root.addView(bar, new LinearLayout.LayoutParams(-1, -2));

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setGravity(Gravity.CENTER_HORIZONTAL);
        card.setPadding(dp(20), dp(28), dp(20), dp(28));
        GradientDrawable bg = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{0xFFFFFFFF, 0xFFFFFFFF, 0xFFEEF3FF});
        bg.setCornerRadius(dp(24));
        bg.setStroke(dp(1), 0xFFC9D8FB);
        card.setBackground(bg);

        LinearLayout ring = new LinearLayout(this);
        ring.setGravity(Gravity.CENTER);
        ring.setPadding(dp(4), dp(4), dp(4), dp(4));
        GradientDrawable rb = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{0xFF38BDF8, VIOLET, PINK});
        rb.setShape(GradientDrawable.OVAL);
        ring.setBackground(rb);
        avatar = new ImageView(this);
        GradientDrawable dot = new GradientDrawable();
        dot.setShape(GradientDrawable.OVAL);
        dot.setColor(Color.WHITE);
        avatar.setBackground(dot);
        avatar.setScaleType(ImageView.ScaleType.CENTER_CROP);
        ring.addView(avatar, new LinearLayout.LayoutParams(dp(112), dp(112)));
        card.addView(ring, new LinearLayout.LayoutParams(dp(120), dp(120)));

        nameView = text("", 21, INK, true);
        nameView.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams np = new LinearLayout.LayoutParams(-2, -2);
        np.topMargin = dp(16);
        card.addView(nameView, np);

        TextView bioLabel = text("BIO", 11.5f, BLUE, true);
        bioLabel.setLetterSpacing(0.08f);
        LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(-2, -2);
        blp.topMargin = dp(20);
        card.addView(bioLabel, blp);
        bioView = text("", 14.5f, MUTED, false);
        bioView.setGravity(Gravity.CENTER);
        bioView.setLineSpacing(dp(2), 1f);
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-2, -2);
        bp.topMargin = dp(6);
        card.addView(bioView, bp);

        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(dp(14), dp(8), dp(14), dp(16));
        body.addView(card, new LinearLayout.LayoutParams(-1, -2));
        ScrollView scroll = new ScrollView(this);
        scroll.addView(body, new android.widget.FrameLayout.LayoutParams(-1, -2));
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1f));
        setContentView(root);

        WindowInsetsControllerCompat c = WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView());
        c.setAppearanceLightStatusBars(true);
        c.setAppearanceLightNavigationBars(true);
    }

    private void show(String name, String bio, String photo) {
        name = name == null ? "" : name.trim();
        bio = bio == null ? "" : bio.trim();
        nameView.setText(name.isEmpty() ? "STARX24 Player" : name);
        boolean has = !bio.isEmpty();
        bioView.setText(has ? FancyText.plain(bio) : "No bio yet");
        bioView.setTextColor(has ? MUTED : 0xFF9AA5BD);
        bioView.setTypeface(null, has ? Typeface.NORMAL : Typeface.ITALIC);
        if (photo != null && !photo.isEmpty()) {
            avatar.setPadding(dp(3), dp(3), dp(3), dp(3));
            try { Glide.with(this).load(photo).transform(new CircleCrop()).into(avatar); }
            catch (RuntimeException e) { placeholder(); }
        } else {
            placeholder();
        }
    }

    private void placeholder() {
        avatar.setPadding(dp(28), dp(28), dp(28), dp(28));
        avatar.setImageResource(R.drawable.ic_profile);
    }

    private static String str(Object o) { return o == null ? "" : String.valueOf(o); }

    private TextView text(String s, float size, int color, boolean bold) {
        TextView v = new TextView(this);
        v.setText(s);
        v.setTextSize(size);
        v.setTextColor(color);
        v.setTypeface(null, bold ? Typeface.BOLD : Typeface.NORMAL);
        return v;
    }

    private int dp(int value) { return Math.round(value * getResources().getDisplayMetrics().density); }
}
