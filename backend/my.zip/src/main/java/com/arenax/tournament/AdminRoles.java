package com.arenax.tournament;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/** Canonical role names for the four-role STARX24 admin system. */
public final class AdminRoles {
    public static final String MATCH_OPERATIONS = "MATCH_OPERATIONS_ADMIN";
    public static final String RESULTS_COINS = "RESULTS_COINS_ADMIN";
    public static final String CUSTOMER_SUPPORT = "CUSTOMER_SUPPORT_ADMIN";
    public static final String MASTER = "MASTER_ADMIN";

    // ---- Work roles (owner-defined work groups). A key of one of these roles carries a
    // `perms` map in admin_keys/{key}; the admin only ever sees the functions listed there. ----
    public static final String WITHDRAWAL_MANAGER = "WITHDRAWAL_MANAGER";
    public static final String MATCH_BANNER_MANAGER = "MATCH_BANNER_MANAGER";
    public static final String PROFILE_SYSTEM_MANAGER = "PROFILE_SYSTEM_MANAGER";
    public static final String CUSTOM_MANAGER = "CUSTOM_MANAGER";

    /** One assignable function: id stored in perms, label shown to the owner, workspace pages it unlocks. */
    public static final class Fn {
        public final String id, label, hint;
        public final String[] pages;
        Fn(String id, String label, String hint, String... pages) {
            this.id = id; this.label = label; this.hint = hint; this.pages = pages;
        }
    }

    /** Every function the owner can hand out. Add a line here to create a new assignable option. */
    public static final Map<String, Fn> FUNCTIONS = new LinkedHashMap<>();
    static {
        add(new Fn("payments", "Payment Requests", "Deposits & withdrawal requests", "payments"));
        add(new Fn("coin_requests", "Coin Handling", "Edit user coins"));
        add(new Fn("categories", "Category Manager", "Add / edit game categories", "category", "esports"));
        // Creating / deleting matches stays OWNER-ONLY (not assignable). Admins get Match Detail Handle instead.
        add(new Fn("match_detail", "Match Detail Handle", "Room / key release, edit match, leaderboard", "matches", "tournaments", "results"));
        add(new Fn("banners", "Banner Control", "Home banners add / delete"));
        add(new Fn("profile_text", "Profile Text Control", "FAQ, Terms, Privacy, About text", "faq", "terms", "privacy", "about"));
        add(new Fn("notice", "Notice Handle", "Notices & notifications", "notice"));
        add(new Fn("platform_links", "Platform Links", "Platform name, Customer Support link, Telegram, YouTube..."));
        add(new Fn("results", "Results & Leaderboard", "Post results", "results"));
        add(new Fn("users", "User Management", "View / ban players", "users"));
        add(new Fn("reports", "Reports & Disputes", "Moderation", "reports", "disputes"));
        add(new Fn("analytics", "Analytics", "Stats overview", "analytics"));
        add(new Fn("activity", "Activity Log", "Who did what", "activity"));
    }
    private static void add(Fn fn) { FUNCTIONS.put(fn.id, fn); }

    /** The 4 work cards shown on the Admin Panel. Last one is the owner-picks-anything card. */
    public static final String[] WORK_ROLES = {
            WITHDRAWAL_MANAGER, MATCH_BANNER_MANAGER, PROFILE_SYSTEM_MANAGER, CUSTOM_MANAGER};

    public static boolean isWorkRole(String role) {
        for (String r : WORK_ROLES) if (r.equals(role)) return true;
        return false;
    }

    /** Functions pre-ticked when the owner picks this work. Custom starts empty. */
    public static List<String> defaultFunctions(String role) {
        switch (role == null ? "" : role) {
            case WITHDRAWAL_MANAGER: return Arrays.asList("payments", "coin_requests");
            case MATCH_BANNER_MANAGER: return Arrays.asList("categories", "match_detail", "banners");
            case PROFILE_SYSTEM_MANAGER: return Arrays.asList("profile_text", "notice", "platform_links");
            default: return new ArrayList<>();
        }
    }

    public static String workTitle(String role) {
        switch (role == null ? "" : role) {
            case WITHDRAWAL_MANAGER: return "Withdrawal Manager";
            case MATCH_BANNER_MANAGER: return "Match & Banner Manager";
            case PROFILE_SYSTEM_MANAGER: return "Profile & System Manager";
            case CUSTOM_MANAGER: return "Custom / Extra Manager";
            default: return label(role);
        }
    }

    public static String workSubtitle(String role) {
        switch (role == null ? "" : role) {
            case WITHDRAWAL_MANAGER: return "Payment Manager + Coin Request";
            case MATCH_BANNER_MANAGER: return "Category + Match + Banner";
            case PROFILE_SYSTEM_MANAGER: return "Profile Text + Notice + Platform Links";
            case CUSTOM_MANAGER: return "Your Own Assigned Functions";
            default: return "";
        }
    }

    /** Workspace pages unlocked by a set of function ids ("dashboard" is always included). */
    public static Set<String> pagesFor(Set<String> perms) {
        Set<String> pages = new LinkedHashSet<>();
        pages.add("dashboard");
        if (perms == null) return pages;
        for (String id : perms) {
            Fn fn = FUNCTIONS.get(id);
            if (fn != null) pages.addAll(Arrays.asList(fn.pages));
        }
        return pages;
    }

    /** First page worth opening for a set of functions, or "dashboard" when the work lives on the dashboard. */
    public static String landingPage(Set<String> perms) {
        if (perms != null) {
            for (String id : FUNCTIONS.keySet()) {
                if (!perms.contains(id)) continue;
                Fn fn = FUNCTIONS.get(id);
                if (fn.pages.length > 0) return fn.pages[0];
            }
        }
        return "dashboard";
    }

    private AdminRoles() {}

    public static boolean isRestructured(String role) {
        if (role == null) return false;
        return MATCH_OPERATIONS.equals(role)
                || RESULTS_COINS.equals(role)
                || CUSTOMER_SUPPORT.equals(role)
                || MASTER.equals(role)
                || "SUPER_ADMIN".equals(role);
    }

    /** Allows old keys to keep working while new keys use the four explicit roles. */
    public static String normalize(String role) {
        if (role == null) return CUSTOMER_SUPPORT;
        switch (role.toUpperCase(Locale.ROOT)) {
            case "SUPER_ADMIN":
                return MASTER;
            case "TOURNAMENT_MANAGER":
            case "MATCH_ADMIN":
                return MATCH_OPERATIONS;
            case "SUPPORT_AGENT":
                return CUSTOMER_SUPPORT;
            case "PAYMENT_ADMIN":
                return MASTER;
            default:
                return role.toUpperCase(Locale.ROOT);
        }
    }

    public static String label(String role) {
        switch (normalize(role)) {
            case MATCH_OPERATIONS:
                return "Match Operations";
            case RESULTS_COINS:
                return "Results & Coins";
            case CUSTOMER_SUPPORT:
                return "Customer Support";
            case MASTER:
                return "Master Admin";
            case WITHDRAWAL_MANAGER:
                return "Withdrawal Manager";
            case MATCH_BANNER_MANAGER:
                return "Match & Banner Manager";
            case PROFILE_SYSTEM_MANAGER:
                return "Profile & System Manager";
            case CUSTOM_MANAGER:
                return "Custom Manager";
            default:
                return "Admin";
        }
    }
}