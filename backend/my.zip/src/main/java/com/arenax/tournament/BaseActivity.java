package com.arenax.tournament;

import android.content.Context;
import android.content.res.Configuration;

import androidx.appcompat.app.AppCompatActivity;

import com.arenax.tournament.util.ScreenFit;

/**
 * Common parent for every screen (user + admin). Makes sure a page fills the whole screen
 * on high-DPI / large display-size phones — see {@link ScreenFit}.
 */
public abstract class BaseActivity extends AppCompatActivity {
    @Override
    protected void attachBaseContext(Context newBase) {
        super.attachBaseContext(com.arenax.tournament.util.LanguageManager.wrap(ScreenFit.wrap(newBase)));
    }

    // ---- Keep every heading clear of the status bar / notifications --------------------------
    private boolean topInsetInstalled;

    @Override public void setContentView(int layoutResID) { super.setContentView(layoutResID); installTopInset(); }
    @Override public void setContentView(android.view.View view) { super.setContentView(view); installTopInset(); }
    @Override public void setContentView(android.view.View view, android.view.ViewGroup.LayoutParams params) {
        super.setContentView(view, params);
        installTopInset();
    }

    /**
     * Pads the whole page below the status bar (+4dp breathing room) and hands the screen's own
     * insets listeners a zero top inset, so nothing is padded twice and no heading is ever hidden
     * under the clock / notification icons.
     */
    private void installTopInset() {
        if (topInsetInstalled) return;
        final android.view.View content = findViewById(android.R.id.content);
        if (content == null) return;
        topInsetInstalled = true;
        final int extra = Math.round(4 * getResources().getDisplayMetrics().density);
        if (content instanceof android.view.ViewGroup) {
            android.view.View first = ((android.view.ViewGroup) content).getChildAt(0);
            if (first != null && first.getBackground() instanceof android.graphics.drawable.ColorDrawable) {
                content.setBackgroundColor(((android.graphics.drawable.ColorDrawable) first.getBackground()).getColor());
            }
        }
        androidx.core.view.ViewCompat.setOnApplyWindowInsetsListener(content, (v, insets) -> {
            androidx.core.graphics.Insets sb = insets.getInsets(androidx.core.view.WindowInsetsCompat.Type.statusBars());
            androidx.core.graphics.Insets cut = insets.getInsets(androidx.core.view.WindowInsetsCompat.Type.displayCutout());
            v.setPadding(0, Math.max(sb.top, cut.top) + extra, 0, 0);
            return new androidx.core.view.WindowInsetsCompat.Builder(insets)
                    .setInsets(androidx.core.view.WindowInsetsCompat.Type.statusBars(),
                            androidx.core.graphics.Insets.of(sb.left, 0, sb.right, sb.bottom))
                    .setInsets(androidx.core.view.WindowInsetsCompat.Type.displayCutout(),
                            androidx.core.graphics.Insets.of(cut.left, 0, cut.right, cut.bottom))
                    .build();
        });
        androidx.core.view.ViewCompat.requestApplyInsets(content);
    }

    /** Every screen (user + admin) gets the app-wide design font, even if built in code after onCreate. */
    @Override
    protected void onPostCreate(android.os.Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
        com.arenax.tournament.util.FancyText.attach(getWindow());
    }

    private final int langVersion = com.arenax.tournament.util.LanguageManager.version();

    /** A language picked on another screen: rebuild this one so it picks it up. */
    @Override
    protected void onResume() {
        super.onResume();
        if (langVersion != com.arenax.tournament.util.LanguageManager.version()) { recreate(); return; }
        // Maintenance mode / update notice set by the admin (fail-open if offline).
        try { com.arenax.tournament.util.AppStatus.gate(this); } catch (RuntimeException ignored) { }
    }

    @Override
    protected void onPause() {
        super.onPause();
        try { com.arenax.tournament.util.AppStatus.paused(this); } catch (RuntimeException ignored) { }
    }

    /** AppCompat re-applies its own override config (night mode etc.); keep our density fix on it. */
    @Override
    public void applyOverrideConfiguration(Configuration overrideConfiguration) {
        if (overrideConfiguration != null) {
            Configuration merged = new Configuration(getBaseContext().getResources().getConfiguration());
            merged.updateFrom(overrideConfiguration);
            if (ScreenFit.adjust(merged)) {
                overrideConfiguration = merged;
            }
        }
        super.applyOverrideConfiguration(overrideConfiguration);
    }
}
