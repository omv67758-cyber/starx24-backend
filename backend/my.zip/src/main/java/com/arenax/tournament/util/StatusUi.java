package com.arenax.tournament.util;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/** Small programmatic-UI helpers shared by the maintenance screen, update dialog and admin form. */
public final class StatusUi {

    private StatusUi() { }

    public static final int BLUE = 0xFF2563EB, BLUE_TINT = 0xFFEFF6FF;
    public static final int AMBER = 0xFFD97706, AMBER_TINT = 0xFFFFF7E6;
    public static final int INK = 0xFF111827, MUTED = 0xFF6B7280, LINE = 0xFFE5E7EB, CANVAS = 0xFFF6F7FB;

    public static int dp(Context c, int v) {
        return Math.round(v * c.getResources().getDisplayMetrics().density);
    }

    public static GradientDrawable box(int fill, int radiusDp, int stroke, Context c) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(dp(c, radiusDp));
        if (stroke != 0) g.setStroke(dp(c, 1), stroke);
        return g;
    }

    public static TextView text(Context c, CharSequence t, int sp, int color, boolean bold) {
        TextView v = new TextView(c);
        v.setText(t);
        v.setTextSize(sp);
        v.setTextColor(color);
        if (bold) v.setTypeface(null, Typeface.BOLD);
        return v;
    }

    /** Round icon badge: tinted disc, solid inner disc, white icon. */
    public static View badge(Context c, int iconRes, int accent, int tint, int sizeDp) {
        FrameLayout outer = new FrameLayout(c);
        GradientDrawable ring = new GradientDrawable();
        ring.setShape(GradientDrawable.OVAL);
        ring.setColor(tint);
        outer.setBackground(ring);
        int inner = Math.round(sizeDp * 0.68f);
        FrameLayout disc = new FrameLayout(c);
        GradientDrawable d = new GradientDrawable();
        d.setShape(GradientDrawable.OVAL);
        d.setColor(accent);
        disc.setBackground(d);
        ImageView icon = new ImageView(c);
        icon.setImageResource(iconRes);
        int pad = dp(c, Math.round(inner * 0.24f));
        icon.setPadding(pad, pad, pad, pad);
        disc.addView(icon, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        FrameLayout.LayoutParams dl = new FrameLayout.LayoutParams(dp(c, inner), dp(c, inner), Gravity.CENTER);
        outer.addView(disc, dl);
        outer.setLayoutParams(new LinearLayout.LayoutParams(dp(c, sizeDp), dp(c, sizeDp)));
        return outer;
    }

    public static TextView button(Context c, String label, int fill, int textColor, int stroke) {
        TextView b = text(c, label, 15, textColor, true);
        b.setGravity(Gravity.CENTER);
        b.setClickable(true);
        b.setFocusable(true);
        GradientDrawable bg = box(fill, 10, stroke, c);
        b.setBackground(new RippleDrawable(ColorStateList.valueOf(0x22000000), bg, null));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(c, 50));
        b.setLayoutParams(lp);
        return b;
    }

    public static TextView pill(Context c, String label, int color, int tint) {
        TextView p = text(c, label, 12, color, true);
        p.setPadding(dp(c, 10), dp(c, 4), dp(c, 10), dp(c, 4));
        p.setBackground(box(tint, 20, 0, c));
        return p;
    }

    // ------------------------------------------------------------------------------------------

    public static Dialog showUpdateDialog(Activity a, AppStatus.State s, String link) {
        final boolean force = s.uForce;
        final Dialog dialog = new Dialog(a);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setCancelable(!force);
        dialog.setCanceledOnTouchOutside(false);

        LinearLayout card = new LinearLayout(a);
        card.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable cardBg = box(Color.WHITE, 26, 0, a);
        card.setBackground(cardBg);
        card.setClipToOutline(true);

        // ---- hero header: blue gradient, glowing download badge, status pill ----
        LinearLayout hero = new LinearLayout(a);
        hero.setOrientation(LinearLayout.VERTICAL);
        hero.setGravity(Gravity.CENTER_HORIZONTAL);
        hero.setPadding(dp(a, 20), dp(a, 28), dp(a, 20), dp(a, 24));
        GradientDrawable heroBg = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{0xFF3B82F6, 0xFF1D4ED8});
        heroBg.setCornerRadii(new float[]{dp(a, 26), dp(a, 26), dp(a, 26), dp(a, 26), 0, 0, 0, 0});
        hero.setBackground(heroBg);

        FrameLayout halo = new FrameLayout(a);
        GradientDrawable haloBg = new GradientDrawable();
        haloBg.setShape(GradientDrawable.OVAL);
        haloBg.setColor(0x26FFFFFF);
        halo.setBackground(haloBg);
        FrameLayout disc = new FrameLayout(a);
        GradientDrawable discBg = new GradientDrawable();
        discBg.setShape(GradientDrawable.OVAL);
        discBg.setColor(Color.WHITE);
        disc.setBackground(discBg);
        disc.setElevation(dp(a, 6));
        ImageView icon = new ImageView(a);
        icon.setImageResource(com.arenax.tournament.R.drawable.ic_status_update);
        icon.setColorFilter(BLUE);
        int ip = dp(a, 15);
        icon.setPadding(ip, ip, ip, ip);
        disc.addView(icon, new FrameLayout.LayoutParams(-1, -1));
        halo.addView(disc, new FrameLayout.LayoutParams(dp(a, 62), dp(a, 62), Gravity.CENTER));
        hero.addView(halo, new LinearLayout.LayoutParams(dp(a, 88), dp(a, 88)));

        TextView pill = text(a, force ? "REQUIRED UPDATE" : "NEW UPDATE", 11, Color.WHITE, true);
        pill.setLetterSpacing(0.12f);
        pill.setPadding(dp(a, 12), dp(a, 5), dp(a, 12), dp(a, 5));
        pill.setBackground(box(0x33FFFFFF, 20, 0, a));
        LinearLayout.LayoutParams pl = new LinearLayout.LayoutParams(-2, -2);
        pl.topMargin = dp(a, 16);
        hero.addView(pill, pl);

        TextView title = text(a, s.uTitle.isEmpty() ? "A new version is ready" : s.uTitle, 21, Color.WHITE, true);
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, dp(a, 10), 0, 0);
        hero.addView(title);
        card.addView(hero);

        // ---- body ----
        LinearLayout body = new LinearLayout(a);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(dp(a, 22), dp(a, 18), dp(a, 22), dp(a, 18));
        card.addView(body);

        String installed = AppStatus.installedName(a);
        if (!installed.isEmpty() || !s.uName.isEmpty()) {
            LinearLayout row = new LinearLayout(a);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER);
            if (!installed.isEmpty()) row.addView(versionBox(a, "YOUR VERSION", installed, false), new LinearLayout.LayoutParams(0, -2, 1f));
            if (!installed.isEmpty() && !s.uName.isEmpty()) {
                TextView arrow = text(a, "\u279C", 18, BLUE, true);
                arrow.setPadding(dp(a, 10), 0, dp(a, 10), 0);
                row.addView(arrow);
            }
            if (!s.uName.isEmpty()) row.addView(versionBox(a, "LATEST", s.uName, true), new LinearLayout.LayoutParams(0, -2, 1f));
            body.addView(row);
        }

        if (!s.uDesc.isEmpty()) {
            TextView label = text(a, "WHAT'S NEW", 11, MUTED, true);
            label.setLetterSpacing(0.1f);
            label.setPadding(0, dp(a, 18), 0, dp(a, 8));
            body.addView(label);
            final int maxPx = dp(a, 170);
            ScrollView sv = new ScrollView(a) {
                @Override protected void onMeasure(int w, int h) {
                    super.onMeasure(w, View.MeasureSpec.makeMeasureSpec(maxPx, View.MeasureSpec.AT_MOST));
                }
            };
            sv.setVerticalScrollBarEnabled(false);
            LinearLayout list = new LinearLayout(a);
            list.setOrientation(LinearLayout.VERTICAL);
            for (String raw : s.uDesc.split("\\r?\\n")) {
                String line = raw.trim().replaceFirst("^[-\u2022*\u00B7]+\\s*", "");
                if (line.isEmpty()) continue;
                LinearLayout item = new LinearLayout(a);
                item.setOrientation(LinearLayout.HORIZONTAL);
                View dot = new View(a);
                GradientDrawable dg = new GradientDrawable();
                dg.setShape(GradientDrawable.OVAL);
                dg.setColor(BLUE);
                dot.setBackground(dg);
                LinearLayout.LayoutParams dl = new LinearLayout.LayoutParams(dp(a, 7), dp(a, 7));
                dl.topMargin = dp(a, 7);
                dl.rightMargin = dp(a, 10);
                item.addView(dot, dl);
                TextView t = text(a, line, 14, 0xFF374151, false);
                t.setLineSpacing(0, 1.2f);
                item.addView(t, new LinearLayout.LayoutParams(0, -2, 1f));
                LinearLayout.LayoutParams il = new LinearLayout.LayoutParams(-1, -2);
                il.bottomMargin = dp(a, 7);
                list.addView(item, il);
            }
            sv.addView(list);
            body.addView(sv, new LinearLayout.LayoutParams(-1, -2));
        }

        TextView update = button(a, "Update now", BLUE, Color.WHITE, 0);
        update.setTextSize(16);
        update.setElevation(dp(a, 3));
        LinearLayout.LayoutParams ul = (LinearLayout.LayoutParams) update.getLayoutParams();
        ul.height = dp(a, 54);
        ul.topMargin = dp(a, 20);
        update.setOnClickListener(v -> AppStatus.openLink(a, link));
        body.addView(update);

        if (force) {
            TextView note = text(a, "This update is required to keep using the app.", 12, MUTED, false);
            note.setGravity(Gravity.CENTER);
            note.setPadding(0, dp(a, 12), 0, 0);
            body.addView(note);
        } else {
            TextView later = button(a, "Maybe later", Color.TRANSPARENT, MUTED, 0);
            ((LinearLayout.LayoutParams) later.getLayoutParams()).topMargin = dp(a, 6);
            later.setOnClickListener(v -> dialog.dismiss());
            body.addView(later);
        }

        dialog.setContentView(card);
        Window w = dialog.getWindow();
        if (w != null) {
            w.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            int width = Math.min(a.getResources().getDisplayMetrics().widthPixels - dp(a, 36), dp(a, 400));
            w.setLayout(width, ViewGroup.LayoutParams.WRAP_CONTENT);
            w.setGravity(Gravity.CENTER);
            w.setDimAmount(0.65f);
        }
        card.setAlpha(0f);
        card.setScaleX(0.92f);
        card.setScaleY(0.92f);
        try {
            dialog.show();
            card.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(220).start();
        } catch (RuntimeException ignored) { }
        return dialog;
    }

    private static View versionBox(Context c, String label, String value, boolean highlight) {
        LinearLayout b = new LinearLayout(c);
        b.setOrientation(LinearLayout.VERTICAL);
        b.setGravity(Gravity.CENTER);
        b.setPadding(dp(c, 8), dp(c, 10), dp(c, 8), dp(c, 10));
        b.setBackground(box(highlight ? BLUE_TINT : 0xFFF3F4F6, 12, highlight ? 0xFFBFDBFE : 0, c));
        TextView l = text(c, label, 10, highlight ? BLUE : MUTED, true);
        l.setLetterSpacing(0.1f);
        b.addView(l);
        TextView v = text(c, value, 16, highlight ? BLUE : INK, true);
        v.setPadding(0, dp(c, 2), 0, 0);
        b.addView(v);
        return b;
    }
}
