package com.arenax.tournament.util;

import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import com.google.android.material.button.MaterialButton;

/**
 * Full-screen replacement for floating AlertDialogs.
 *
 * Same builder API as MaterialAlertDialogBuilder (setTitle / setMessage / setView /
 * setPositiveButton / setNegativeButton / setNeutralButton / setCancelable / create / show),
 * so existing call sites only need the class name swapped. Layout: top bar with a back arrow
 * and title, scrollable body (message and/or custom view), and a sticky bottom bar with big
 * rounded buttons that stays above the keyboard.
 *
 * getButton(which) returns the real Button, so code that overrides a button's click after
 * show (to keep the page open on validation errors) keeps working.
 */
public class FullScreenDialog extends Dialog {

    private static final int PAGE_BG = 0xFFF6F5F2;
    private static final int INK = 0xFF1C1C1E;
    private static final int MUTED = 0xFF68686D;
    private static final int STROKE = 0xFFE5E3DE;
    private static final int GREEN = 0xFF059669;
    private static final int RED = 0xFFDC2626;
    private static final int BLUE = 0xFF2563EB;

    private final Context ctx;
    private Button positive, negative, neutral;

    private FullScreenDialog(Context context) {
        super(context, android.R.style.Theme_Material_Light_NoActionBar);
        this.ctx = context;
    }

    @Override
    protected void onStart() {
        super.onStart();
        FancyText.attach(getWindow());
    }

    private int dp(float v) {
        return Math.round(v * ctx.getResources().getDisplayMetrics().density);
    }

    /** Real button for DialogInterface.BUTTON_POSITIVE / NEGATIVE / NEUTRAL (null if not set). */
    public Button getButton(int which) {
        if (which == DialogInterface.BUTTON_POSITIVE) return positive;
        if (which == DialogInterface.BUTTON_NEGATIVE) return negative;
        return neutral;
    }

    private static boolean isDestructive(CharSequence label) {
        if (label == null) return false;
        String t = label.toString().toUpperCase(java.util.Locale.ENGLISH);
        return t.contains("DELETE") || t.contains("REMOVE") || t.contains("BAN")
                || t.contains("REJECT") || t.contains("REVOKE") || t.contains("RESET")
                || t.contains("CANCEL MATCH") || t.contains("CLEAR");
    }

    private GradientDrawable round(int fill, int radiusDp, int strokeColor, int strokeDp) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(fill);
        d.setCornerRadius(dp(radiusDp));
        if (strokeDp > 0) d.setStroke(dp(strokeDp), strokeColor);
        return d;
    }

    private MaterialButton makeButton(CharSequence label, int color, boolean filled) {
        MaterialButton b = new MaterialButton(ctx);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextSize(14);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setInsetTop(0);
        b.setInsetBottom(0);
        b.setElevation(0f);
        b.setCornerRadius(dp(14));
        b.setTextColor(filled ? Color.WHITE : color);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(filled ? color : Color.WHITE));
        b.setStrokeColor(android.content.res.ColorStateList.valueOf(filled ? color : (color == MUTED ? STROKE : color)));
        b.setStrokeWidth(filled ? 0 : dp(1));
        return b;
    }

    private void build(CharSequence title, CharSequence message, View customView,
                       CharSequence posLabel, DialogInterface.OnClickListener posL,
                       CharSequence negLabel, DialogInterface.OnClickListener negL,
                       CharSequence neuLabel, DialogInterface.OnClickListener neuL) {
        LinearLayout root = new LinearLayout(ctx);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(PAGE_BG);
        root.setFitsSystemWindows(true);

        // ---- top bar ----
        LinearLayout bar = new LinearLayout(ctx);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setBackgroundColor(Color.WHITE);
        bar.setPadding(dp(14), dp(10), dp(14), dp(10));
        bar.setElevation(dp(2));
        TextView back = new TextView(ctx);
        back.setText("\u2039");
        back.setTextSize(28);
        back.setTextColor(INK);
        back.setGravity(Gravity.CENTER);
        back.setBackground(round(Color.WHITE, 20, STROKE, 1));
        back.setOnClickListener(v -> cancel());
        bar.addView(back, new LinearLayout.LayoutParams(dp(40), dp(40)));
        TextView titleView = new TextView(ctx);
        titleView.setText(title == null || title.length() == 0 ? "" : title);
        titleView.setTextColor(INK);
        titleView.setTextSize(19);
        titleView.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        titleView.setMaxLines(2);
        LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        tlp.setMarginStart(dp(12));
        bar.addView(titleView, tlp);
        root.addView(bar, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        // ---- scrollable body ----
        ScrollView scroll = new ScrollView(ctx);
        scroll.setFillViewport(false);
        scroll.setClipToPadding(false);
        LinearLayout body = new LinearLayout(ctx);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(dp(18), dp(16), dp(18), dp(24));
        if (message != null && message.length() > 0) {
            TextView msg = new TextView(ctx);
            msg.setText(message);
            msg.setTextColor(0xFF3A3A3F);
            msg.setTextSize(15);
            msg.setLineSpacing(dp(4), 1f);
            msg.setBackground(round(Color.WHITE, 16, STROKE, 1));
            msg.setPadding(dp(16), dp(16), dp(16), dp(16));
            LinearLayout.LayoutParams mlp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            if (customView != null) mlp.bottomMargin = dp(12);
            body.addView(msg, mlp);
        }
        if (customView != null) {
            if (customView.getParent() instanceof ViewGroup) {
                ((ViewGroup) customView.getParent()).removeView(customView);
            }
            // forms were sized for a floating card (fixed heights) — let them flow naturally here
            customView.setLayoutParams(new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            body.addView(customView);
        }
        scroll.addView(body, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        root.addView(scroll, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        // ---- sticky bottom bar ----
        boolean hasPos = posLabel != null, hasNeg = negLabel != null, hasNeu = neuLabel != null;
        if (hasPos || hasNeg || hasNeu) {
            LinearLayout footer = new LinearLayout(ctx);
            footer.setOrientation(LinearLayout.VERTICAL);
            footer.setBackgroundColor(Color.WHITE);
            footer.setPadding(dp(16), dp(12), dp(16), dp(14));
            footer.setElevation(dp(6));

            if (hasNeu) {
                neutral = makeButton(neuLabel, isDestructive(neuLabel) ? RED : BLUE, false);
                neutral.setOnClickListener(v -> { if (neuL != null) neuL.onClick(this, BUTTON_NEUTRAL); dismiss(); });
                LinearLayout.LayoutParams nlp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(50));
                nlp.bottomMargin = dp(10);
                footer.addView(neutral, nlp);
            }
            LinearLayout row = new LinearLayout(ctx);
            row.setOrientation(LinearLayout.HORIZONTAL);
            if (hasNeg) {
                negative = makeButton(negLabel, MUTED, false);
                negative.setOnClickListener(v -> { if (negL != null) negL.onClick(this, BUTTON_NEGATIVE); dismiss(); });
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(50), 1f);
                if (hasPos) lp.rightMargin = dp(10);
                row.addView(negative, lp);
            }
            if (hasPos) {
                positive = makeButton(posLabel, isDestructive(posLabel) ? RED : GREEN, true);
                positive.setOnClickListener(v -> { if (posL != null) posL.onClick(this, BUTTON_POSITIVE); dismiss(); });
                row.addView(positive, new LinearLayout.LayoutParams(0, dp(50), hasNeg ? 1.4f : 1f));
            }
            if (row.getChildCount() > 0) {
                footer.addView(row, new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            }
            root.addView(footer, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        } else {
            // no buttons supplied: still give the user an obvious way out
            neutral = makeButton("CLOSE", MUTED, false);
            neutral.setOnClickListener(v -> dismiss());
            LinearLayout footer = new LinearLayout(ctx);
            footer.setBackgroundColor(Color.WHITE);
            footer.setPadding(dp(16), dp(12), dp(16), dp(14));
            footer.addView(neutral, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(50)));
            root.addView(footer, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        }

        setContentView(root);
        Window w = getWindow();
        if (w != null) {
            w.setBackgroundDrawable(new ColorDrawable(PAGE_BG));
            w.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
            w.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
            w.getAttributes().windowAnimations = android.R.style.Animation_Activity;
        }
    }

    /** Drop-in replacement for MaterialAlertDialogBuilder. */
    public static class Builder {
        private final Context ctx;
        private CharSequence title, message;
        private View view;
        private CharSequence posLabel, negLabel, neuLabel;
        private DialogInterface.OnClickListener posL, negL, neuL;
        private boolean cancelable = true;

        public Builder(Context context) { this.ctx = context; }

        public Builder setTitle(CharSequence t) { this.title = t; return this; }
        public Builder setTitle(int res) { this.title = ctx.getString(res); return this; }
        public Builder setMessage(CharSequence m) { this.message = m; return this; }
        public Builder setMessage(int res) { this.message = ctx.getString(res); return this; }
        public Builder setView(View v) { this.view = v; return this; }
        public Builder setCancelable(boolean c) { this.cancelable = c; return this; }

        public Builder setPositiveButton(CharSequence label, DialogInterface.OnClickListener l) {
            this.posLabel = label; this.posL = l; return this;
        }
        public Builder setPositiveButton(int res, DialogInterface.OnClickListener l) {
            return setPositiveButton(ctx.getString(res), l);
        }
        public Builder setNegativeButton(CharSequence label, DialogInterface.OnClickListener l) {
            this.negLabel = label; this.negL = l; return this;
        }
        public Builder setNegativeButton(int res, DialogInterface.OnClickListener l) {
            return setNegativeButton(ctx.getString(res), l);
        }
        public Builder setNeutralButton(CharSequence label, DialogInterface.OnClickListener l) {
            this.neuLabel = label; this.neuL = l; return this;
        }
        public Builder setNeutralButton(int res, DialogInterface.OnClickListener l) {
            return setNeutralButton(ctx.getString(res), l);
        }

        public FullScreenDialog create() {
            FullScreenDialog d = new FullScreenDialog(ctx);
            d.build(title, message, view, posLabel, posL, negLabel, negL, neuLabel, neuL);
            d.setCancelable(cancelable);
            return d;
        }

        public FullScreenDialog show() {
            FullScreenDialog d = create();
            d.show();
            return d;
        }
    }

    /** Full-screen form page used by the "sticky form" dialogs (heading, optional subtitle, form,
     *  one primary button). The primary button does NOT auto-close; the caller dismisses on success. */
    public static FullScreenDialog form(Context context, String title, String subtitle, View form,
                                        String positiveLabel, Runnable onPositive) {
        FullScreenDialog d = new Builder(context)
                .setTitle(title)
                .setMessage((CharSequence) null) // no text under the heading
                .setView(form)
                .setNegativeButton("CANCEL", null)
                .setPositiveButton(positiveLabel, null)
                .create();
        Button p = d.getButton(BUTTON_POSITIVE);
        if (p != null) p.setOnClickListener(v -> onPositive.run());
        return d;
    }
}
