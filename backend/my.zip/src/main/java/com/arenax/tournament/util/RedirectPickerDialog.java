package com.arenax.tournament.util;

import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import com.arenax.tournament.data.FirebaseRepository;
import com.google.android.material.button.MaterialButton;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Admin "Redirect content" picker.
 *
 * Shows the whole user panel as phone previews (Home, Leaderboard, Wallet, Profile, Add Money,
 * Notifications, My Matches, Support, FAQ ...) plus the live categories and matches from
 * Firebase. The admin taps one, sees a big preview of exactly what the player will land on,
 * and confirms. The chosen {@link NotificationRedirect.Target} is handed back to the caller,
 * which stores it on the notification so a tap opens that content directly.
 */
public class RedirectPickerDialog extends Dialog {

    public interface Callback {
        void onPicked(NotificationRedirect.Target target);
    }

    private static final int PAGE_BG = 0xFFF6F5F2;
    private static final int INK = 0xFF1C1C1E;
    private static final int MUTED = 0xFF68686D;
    private static final int BLUE = 0xFF2563EB;
    private static final int BLUE_SOFT = 0xFFDBEAFE;

    private static final String[][] SCREENS = {
            {NotificationRedirect.TYPE_HOME, "Home"},
            {NotificationRedirect.TYPE_LEADERBOARD, "Leaderboard"},
            {NotificationRedirect.TYPE_WALLET, "Wallet"},
            {NotificationRedirect.TYPE_ADD_MONEY, "Add Money"},
            {NotificationRedirect.TYPE_PROFILE, "Profile"},
            {NotificationRedirect.TYPE_NOTIFICATIONS, "Notifications"},
            {NotificationRedirect.TYPE_MY_UPCOMING, "My Upcoming"},
            {NotificationRedirect.TYPE_MY_ONGOING, "My Ongoing"},
            {NotificationRedirect.TYPE_MY_COMPLETED, "My Completed"},
            {NotificationRedirect.TYPE_MATCH_HISTORY, "Match History"},
            {NotificationRedirect.TYPE_GALLERY, "Esports Games"},
            {NotificationRedirect.TYPE_SUPPORT, "Support"},
            {NotificationRedirect.TYPE_SUPPORT_CHAT, "Support Chat"},
            {NotificationRedirect.TYPE_FAQ, "FAQ"},
            {NotificationRedirect.TYPE_ABOUT, "About Us"},
    };

    private static final class Item {
        final String id; final String title; final String status;
        Item(String id, String title, String status) { this.id = id; this.title = title; this.status = status; }
    }

    private final Context ctx;
    private final Callback callback;
    private NotificationRedirect.Target current;

    private ScreenPreviewView bigPreview;
    private TextView selectedLabel;
    private TextView selectedHint;
    private final List<View> stripCards = new ArrayList<>();
    private final List<String> stripTypes = new ArrayList<>();
    private LinearLayout categoryList;
    private LinearLayout matchList;
    private final List<Item> categories = new ArrayList<>();
    private final List<Item> matches = new ArrayList<>();
    private String matchQuery = "";

    public RedirectPickerDialog(Context context, NotificationRedirect.Target initial, Callback callback) {
        super(context, android.R.style.Theme_Material_Light_NoActionBar);
        this.ctx = context;
        this.callback = callback;
        this.current = initial == null ? NotificationRedirect.none() : initial;
        build();
        loadCategories();
        loadMatches();
        refreshSelection();
    }

    @Override
    protected void onStart() {
        super.onStart();
        FancyText.attach(getWindow());
    }

    // ---------------------------------------------------------------------------------
    // UI
    // ---------------------------------------------------------------------------------

    private void build() {
        LinearLayout root = new LinearLayout(ctx);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(PAGE_BG);
        root.setFitsSystemWindows(true);

        // top bar
        LinearLayout bar = new LinearLayout(ctx);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setBackgroundColor(Color.WHITE);
        bar.setPadding(dp(14), dp(10), dp(14), dp(10));
        bar.setElevation(dp(2));
        TextView back = new TextView(ctx);
        back.setText("\u2039");
        back.setTextSize(28);
        back.setTextColor(INK);
        back.setGravity(Gravity.CENTER);
        back.setBackground(round(Color.WHITE, 20));
        back.setElevation(dp(3));
        back.setOnClickListener(v -> cancel());
        bar.addView(back, new LinearLayout.LayoutParams(dp(40), dp(40)));
        LinearLayout titles = new LinearLayout(ctx);
        titles.setOrientation(LinearLayout.VERTICAL);
        titles.setPadding(dp(12), 0, 0, 0);
        titles.addView(text("Redirect content", 19, INK, true));
        titles.addView(text("Player will land here when the notification is tapped", 11, MUTED, false));
        bar.addView(titles, new LinearLayout.LayoutParams(0, -2, 1));
        root.addView(bar, new LinearLayout.LayoutParams(-1, -2));

        // scrollable body
        ScrollView scroll = new ScrollView(ctx);
        scroll.setFillViewport(false);
        LinearLayout body = new LinearLayout(ctx);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(dp(16), dp(14), dp(16), dp(20));
        scroll.addView(body, new ViewGroup.LayoutParams(-1, -2));
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));

        // selected preview card
        LinearLayout selectedCard = new LinearLayout(ctx);
        selectedCard.setOrientation(LinearLayout.HORIZONTAL);
        selectedCard.setGravity(Gravity.CENTER_VERTICAL);
        selectedCard.setBackground(round(Color.WHITE, 18));
        selectedCard.setElevation(dp(5));
        selectedCard.setPadding(dp(12), dp(12), dp(14), dp(12));
        bigPreview = new ScreenPreviewView(ctx);
        selectedCard.addView(bigPreview, new LinearLayout.LayoutParams(dp(116), dp(232)));
        LinearLayout info = new LinearLayout(ctx);
        info.setOrientation(LinearLayout.VERTICAL);
        info.setPadding(dp(14), 0, 0, 0);
        info.addView(text("PLAYER WILL SEE", 10, MUTED, true));
        selectedLabel = text("", 18, INK, true);
        selectedLabel.setPadding(0, dp(4), 0, dp(4));
        info.addView(selectedLabel);
        selectedHint = text("", 12, MUTED, false);
        info.addView(selectedHint);
        MaterialButton clear = pill("NO REDIRECT", false);
        clear.setOnClickListener(v -> select(NotificationRedirect.none()));
        LinearLayout.LayoutParams clearLp = new LinearLayout.LayoutParams(-2, dp(38));
        clearLp.topMargin = dp(14);
        info.addView(clear, clearLp);
        selectedCard.addView(info, new LinearLayout.LayoutParams(0, -2, 1));
        body.addView(selectedCard, new LinearLayout.LayoutParams(-1, -2));

        // user panel screens strip
        body.addView(section("USER PANEL - TAP A SCREEN"));
        HorizontalScrollView hs = new HorizontalScrollView(ctx);
        hs.setHorizontalScrollBarEnabled(false);
        hs.setClipToPadding(false);
        LinearLayout strip = new LinearLayout(ctx);
        strip.setOrientation(LinearLayout.HORIZONTAL);
        strip.setPadding(dp(2), dp(6), dp(2), dp(14));
        for (String[] screenDef : SCREENS) {
            final String type = screenDef[0];
            final String label = screenDef[1];
            LinearLayout card = new LinearLayout(ctx);
            card.setOrientation(LinearLayout.VERTICAL);
            card.setGravity(Gravity.CENTER_HORIZONTAL);
            card.setPadding(dp(6), dp(8), dp(6), dp(8));
            ScreenPreviewView preview = new ScreenPreviewView(ctx);
            preview.setScreen(type, label);
            card.addView(preview, new LinearLayout.LayoutParams(dp(84), dp(168)));
            TextView name = text(label, 11, INK, true);
            name.setGravity(Gravity.CENTER);
            name.setSingleLine(true);
            name.setPadding(0, dp(4), 0, 0);
            card.addView(name, new LinearLayout.LayoutParams(dp(84), -2));
            card.setOnClickListener(v -> select(new NotificationRedirect.Target(type, "", label)));
            LinearLayout.LayoutParams cardLp = new LinearLayout.LayoutParams(-2, -2);
            cardLp.rightMargin = dp(10);
            strip.addView(card, cardLp);
            stripCards.add(card);
            stripTypes.add(type);
        }
        hs.addView(strip);
        body.addView(hs, new LinearLayout.LayoutParams(-1, -2));

        // categories
        body.addView(section("GAME CATEGORIES"));
        categoryList = new LinearLayout(ctx);
        categoryList.setOrientation(LinearLayout.VERTICAL);
        body.addView(categoryList, new LinearLayout.LayoutParams(-1, -2));

        // matches
        body.addView(section("MATCHES / TOURNAMENTS"));
        EditText search = new EditText(ctx);
        search.setHint("Search match title");
        search.setSingleLine(true);
        search.setTextSize(14);
        search.setTextColor(INK);
        search.setHintTextColor(MUTED);
        search.setBackground(round(Color.WHITE, 14));
        search.setElevation(dp(2));
        search.setPadding(dp(14), dp(12), dp(14), dp(12));
        search.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void afterTextChanged(Editable s) {
                matchQuery = s == null ? "" : s.toString().trim().toLowerCase(Locale.ROOT);
                renderMatches();
            }
        });
        LinearLayout.LayoutParams searchLp = new LinearLayout.LayoutParams(-1, -2);
        searchLp.bottomMargin = dp(8);
        body.addView(search, searchLp);
        matchList = new LinearLayout(ctx);
        matchList.setOrientation(LinearLayout.VERTICAL);
        body.addView(matchList, new LinearLayout.LayoutParams(-1, -2));

        // bottom bar
        LinearLayout bottom = new LinearLayout(ctx);
        bottom.setGravity(Gravity.CENTER_VERTICAL);
        bottom.setBackgroundColor(Color.WHITE);
        bottom.setElevation(dp(8));
        bottom.setPadding(dp(16), dp(12), dp(16), dp(12));
        MaterialButton cancel = pill("CANCEL", false);
        cancel.setOnClickListener(v -> cancel());
        LinearLayout.LayoutParams cLp = new LinearLayout.LayoutParams(0, dp(50), 1);
        cLp.rightMargin = dp(10);
        bottom.addView(cancel, cLp);
        MaterialButton confirm = pill("SELECT THIS", true);
        confirm.setOnClickListener(v -> {
            if (callback != null) callback.onPicked(current);
            dismiss();
        });
        bottom.addView(confirm, new LinearLayout.LayoutParams(0, dp(50), 1.4f));
        root.addView(bottom, new LinearLayout.LayoutParams(-1, -2));

        setContentView(root);
    }

    private void select(NotificationRedirect.Target target) {
        current = target == null ? NotificationRedirect.none() : target;
        refreshSelection();
    }

    private void refreshSelection() {
        bigPreview.setScreen(current.type, NotificationRedirect.label(current));
        selectedLabel.setText(NotificationRedirect.label(current));
        selectedHint.setText(hintFor(current));
        for (int i = 0; i < stripCards.size(); i++) {
            boolean on = stripTypes.get(i).equals(current.type);
            stripCards.get(i).setBackground(round(on ? BLUE_SOFT : Color.WHITE, 16));
            stripCards.get(i).setElevation(dp(on ? 8 : 3));
        }
        renderCategories();
        renderMatches();
    }

    private String hintFor(NotificationRedirect.Target t) {
        if (t.isNone()) return "Tapping the notification only opens the app.";
        switch (t.type) {
            case NotificationRedirect.TYPE_CATEGORY: return "Opens this game's Ongoing / Upcoming / Resulted match list.";
            case NotificationRedirect.TYPE_MATCH: return "Opens the match page (join / room details). Completed matches open the result.";
            case NotificationRedirect.TYPE_RESULT: return "Opens the published result and leaderboard.";
            default: return "Opens this screen directly in the user app.";
        }
    }

    // ---------------------------------------------------------------------------------
    // Live data
    // ---------------------------------------------------------------------------------

    private void loadCategories() {
        if (!FirebaseRepository.isFirebaseAvailable(ctx)) return;
        FirebaseRepository.gameModes().addListenerForSingleValueEvent(new ValueEventListener() {
            @Override public void onDataChange(DataSnapshot snapshot) {
                categories.clear();
                for (DataSnapshot child : snapshot.getChildren()) {
                    String title = child.child("title").getValue(String.class);
                    Boolean active = child.child("active").getValue(Boolean.class);
                    if (title == null || title.trim().isEmpty() || Boolean.FALSE.equals(active)) continue;
                    categories.add(new Item(child.getKey(), title.trim(), ""));
                }
                renderCategories();
            }
            @Override public void onCancelled(DatabaseError error) { renderCategories(); }
        });
    }

    private void loadMatches() {
        if (!FirebaseRepository.isFirebaseAvailable(ctx)) return;
        FirebaseRepository.tournaments().orderByChild("startAt").limitToLast(80)
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override public void onDataChange(DataSnapshot snapshot) {
                        matches.clear();
                        List<Item> found = new ArrayList<>();
                        for (DataSnapshot child : snapshot.getChildren()) {
                            String title = child.child("title").getValue(String.class);
                            String status = child.child("status").getValue(String.class);
                            if (title == null || title.trim().isEmpty()) continue;
                            found.add(new Item(child.getKey(), title.trim(), status == null ? "" : status));
                        }
                        // newest first
                        for (int i = found.size() - 1; i >= 0; i--) matches.add(found.get(i));
                        renderMatches();
                    }
                    @Override public void onCancelled(DatabaseError error) { renderMatches(); }
                });
    }

    private void renderCategories() {
        if (categoryList == null) return;
        categoryList.removeAllViews();
        if (categories.isEmpty()) {
            categoryList.addView(text("No categories found.", 13, MUTED, false));
            return;
        }
        for (Item item : categories) {
            boolean on = NotificationRedirect.TYPE_CATEGORY.equals(current.type) && item.id.equals(current.id);
            categoryList.addView(row(item.title, "Category", on, v ->
                    select(new NotificationRedirect.Target(NotificationRedirect.TYPE_CATEGORY, item.id, item.title))));
        }
    }

    private void renderMatches() {
        if (matchList == null) return;
        matchList.removeAllViews();
        int shown = 0;
        for (Item item : matches) {
            if (!matchQuery.isEmpty() && !item.title.toLowerCase(Locale.ROOT).contains(matchQuery)) continue;
            boolean on = (NotificationRedirect.TYPE_MATCH.equals(current.type)
                    || NotificationRedirect.TYPE_RESULT.equals(current.type)) && item.id.equals(current.id);
            String sub = item.status.isEmpty() ? "Match" : item.status.toUpperCase(Locale.ROOT);
            matchList.addView(row(item.title, sub, on, v ->
                    select(new NotificationRedirect.Target(NotificationRedirect.TYPE_MATCH, item.id, item.title))));
            if (++shown >= 60) break;
        }
        if (shown == 0) matchList.addView(text(matches.isEmpty() ? "No matches yet." : "No match found.", 13, MUTED, false));
    }

    private View row(String title, String sub, boolean selected, View.OnClickListener click) {
        LinearLayout row = new LinearLayout(ctx);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setBackground(round(selected ? BLUE_SOFT : Color.WHITE, 14));
        row.setElevation(dp(selected ? 5 : 2));
        row.setPadding(dp(14), dp(12), dp(14), dp(12));
        LinearLayout col = new LinearLayout(ctx);
        col.setOrientation(LinearLayout.VERTICAL);
        TextView t = text(title, 14, INK, true);
        t.setSingleLine(true);
        t.setEllipsize(android.text.TextUtils.TruncateAt.END);
        col.addView(t);
        col.addView(text(sub, 11, MUTED, false));
        row.addView(col, new LinearLayout.LayoutParams(0, -2, 1));
        if (selected) row.addView(text("SELECTED", 10, BLUE, true));
        row.setOnClickListener(click);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.bottomMargin = dp(8);
        row.setLayoutParams(lp);
        return row;
    }

    // ---------------------------------------------------------------------------------
    // Small view helpers
    // ---------------------------------------------------------------------------------

    private View section(String label) {
        TextView v = text(label, 11, MUTED, true);
        v.setLetterSpacing(0.08f);
        v.setPadding(dp(2), dp(18), 0, dp(4));
        return v;
    }

    private TextView text(String value, int sp, int color, boolean bold) {
        TextView v = new TextView(ctx);
        v.setText(value);
        v.setTextSize(sp);
        v.setTextColor(color);
        v.setTypeface(null, bold ? Typeface.BOLD : Typeface.NORMAL);
        return v;
    }

    private MaterialButton pill(String label, boolean filled) {
        MaterialButton b = new MaterialButton(ctx);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextSize(13);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setInsetTop(0);
        b.setInsetBottom(0);
        b.setCornerRadius(dp(14));
        b.setElevation(dp(filled ? 4 : 2));
        b.setTextColor(filled ? Color.WHITE : INK);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(filled ? BLUE : Color.WHITE));
        b.setStrokeWidth(0);
        return b;
    }

    private GradientDrawable round(int fill, int radiusDp) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(fill);
        d.setCornerRadius(dp(radiusDp));
        return d;
    }

    private int dp(float v) {
        return Math.round(v * ctx.getResources().getDisplayMetrics().density);
    }

    // ---------------------------------------------------------------------------------
    // Form field: drop-in "Redirect content" selector for any admin notification form.
    // ---------------------------------------------------------------------------------

    /** Holds the redirect the admin picked inside a form. */
    public static final class Field {
        private NotificationRedirect.Target target = NotificationRedirect.none();
        public NotificationRedirect.Target get() { return target; }
    }

    /**
     * Adds a "Redirect content" caption + SELECT button to {@code form} and returns the holder
     * to read the chosen target from when the form is submitted.
     */
    public static Field addField(final Context context, LinearLayout form) {
        final Field field = new Field();
        final float d = context.getResources().getDisplayMetrics().density;

        TextView caption = new TextView(context);
        caption.setText("REDIRECT CONTENT (opens on tap)");
        caption.setTextSize(11);
        caption.setTextColor(MUTED);
        caption.setTypeface(null, Typeface.BOLD);
        caption.setLetterSpacing(0.06f);
        caption.setPadding(0, Math.round(12 * d), 0, Math.round(4 * d));
        form.addView(caption);

        final LinearLayout row = new LinearLayout(context);
        row.setGravity(Gravity.CENTER_VERTICAL);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.WHITE);
        bg.setCornerRadius(14 * d);
        row.setBackground(bg);
        row.setElevation(4 * d);
        row.setPadding(Math.round(14 * d), Math.round(12 * d), Math.round(14 * d), Math.round(12 * d));

        final TextView value = new TextView(context);
        value.setText(NotificationRedirect.label(field.target));
        value.setTextSize(14);
        value.setTextColor(INK);
        value.setTypeface(null, Typeface.BOLD);
        value.setSingleLine(true);
        value.setEllipsize(android.text.TextUtils.TruncateAt.END);
        row.addView(value, new LinearLayout.LayoutParams(0, -2, 1));

        TextView select = new TextView(context);
        select.setText("SELECT");
        select.setTextSize(12);
        select.setTextColor(Color.WHITE);
        select.setTypeface(null, Typeface.BOLD);
        select.setGravity(Gravity.CENTER);
        GradientDrawable selectBg = new GradientDrawable();
        selectBg.setColor(BLUE);
        selectBg.setCornerRadius(12 * d);
        select.setBackground(selectBg);
        select.setPadding(Math.round(14 * d), Math.round(8 * d), Math.round(14 * d), Math.round(8 * d));
        row.addView(select, new LinearLayout.LayoutParams(-2, -2));

        row.setOnClickListener(v -> new RedirectPickerDialog(context, field.target, picked -> {
            field.target = picked == null ? NotificationRedirect.none() : picked;
            value.setText(NotificationRedirect.label(field.target));
        }).show());

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = Math.round(2 * d);
        lp.bottomMargin = Math.round(6 * d);
        form.addView(row, lp);
        return field;
    }
}
