package com.arenax.tournament.util;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.bumptech.glide.Glide;
import com.bumptech.glide.Priority;
import com.bumptech.glide.RequestBuilder;
import com.bumptech.glide.load.DataSource;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.load.engine.GlideException;
import com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.target.Target;

import java.io.File;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * One place for every remote image in the app.
 *
 *  - While an image is loading (or fails / has no URL) the view shows a plain BLACK
 *    placeholder, never the app logo.
 *  - Uses the shared Glide setup in AppGlideConfig (OkHttp + memory + disk cache).
 *  - preload() warms the disk cache in the background (low priority, no decoding) so
 *    the image is ready by the time the user scrolls to it or opens the next screen.
 *  - Remembers the last branding logo URL locally so the Home logo appears instantly
 *    on the next launch instead of waiting for Firebase.
 */
public final class ImageLoader {
    private static final int PLACEHOLDER_COLOR = Color.BLACK;
    private static final int MAX_PRELOAD_PER_CALL = 40;
    private static final int MAX_TRACKED_URLS = 400;
    private static final Set<String> PRELOADED = Collections.synchronizedSet(new HashSet<String>());

    private static final String PREFS = "arenax_image_prefs";
    private static final String KEY_LOGO_URL = "branding_logo_url";

    private ImageLoader() {}

    /** A fresh black drawable (fills the whole view, no intrinsic size). */
    public static Drawable placeholder() {
        return new ColorDrawable(PLACEHOLDER_COLOR);
    }

    public static boolean isValid(@Nullable String url) {
        return url != null && !url.trim().isEmpty();
    }

    /** centerCrop load with black placeholder/error/fallback. Empty URL -> black. */
    public static void load(@Nullable ImageView view, @Nullable String url) {
        load(view, url, false);
    }

    /** Same as load() but fitCenter (used for the tournament detail banner). */
    public static void loadFit(@Nullable ImageView view, @Nullable String url) {
        load(view, url, true);
    }

    private static void load(@Nullable ImageView view, @Nullable String url, boolean fit) {
        if (view == null) return;
        if (!isValid(url)) {
            showEmpty(view);
            return;
        }
        try {
            RequestBuilder<Drawable> request = Glide.with(view)
                    .load(url.trim())
                    .placeholder(placeholder())
                    .error(placeholder())
                    .fallback(placeholder())
                    .diskCacheStrategy(DiskCacheStrategy.NONE)
                    .transition(DrawableTransitionOptions.withCrossFade(120));
            if (fit) request = request.fitCenter(); else request = request.centerCrop();
            request.into(view);
        } catch (RuntimeException destroyedOrDetached) {
            // Glide.with(view) throws if the view's Activity is already finished (e.g. a late
            // Firebase callback after the admin pressed Back). Never let that crash the app.
        }
    }

    /** Cancels any pending load on this view (important for recycled rows) and shows black. */
    public static void showEmpty(@Nullable ImageView view) {
        if (view == null) return;
        clear(view);
        view.setImageDrawable(placeholder());
    }

    /** Cancels any pending Glide request for this view. */
    public static void clear(@Nullable ImageView view) {
        if (view == null) return;
        try {
            Glide.with(view).clear(view);
        } catch (RuntimeException ignored) {
            // View's Activity already destroyed -> nothing to cancel.
        }
    }

    /**
     * Downloads the original files into Glide's disk cache in the background.
     * Low priority so it never competes with images the user is looking at.
     * Safe to call on every Firebase snapshot: URLs already preloaded are skipped.
     */
    public static void preload(@Nullable Context context, @Nullable Collection<String> urls) {
        // Encrypted zip me download (already-saved URLs skip ho jaate hain).
        AssetSync.prefetch(context, urls);
    }

    // ---- Home logo: remembered locally so it shows instantly next launch ----------------

    @NonNull
    public static String getCachedLogoUrl(@Nullable Context context) {
        if (context == null) return "";
        String v = prefs(context).getString(KEY_LOGO_URL, "");
        return v == null ? "" : v;
    }

    public static void setCachedLogoUrl(@Nullable Context context, @Nullable String url) {
        if (context == null) return;
        prefs(context).edit().putString(KEY_LOGO_URL, url == null ? "" : url.trim()).apply();
    }

    private static SharedPreferences prefs(Context context) {
        return context.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }
}
