package com.arenax.tournament;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import androidx.annotation.NonNull;

import com.arenax.tournament.data.FirebaseRepository;
import com.arenax.tournament.util.RoomReleaseScheduler;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.ValueEventListener;

/**
 * AlarmManager alarms are wiped on every reboot. This re-schedules an exact alarm for every
 * match that has a pending room-release schedule (matches/{id}/roomRelease) which hasn't fired
 * yet and whose releaseAt is still in the future — so a scheduled "auto-notify at room time"
 * survives a phone restart on the admin's device.
 */
public class BootRescheduleReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        if (!Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction())) return;

        final Context appContext = context.getApplicationContext();
        final PendingResult pendingResult = goAsync();

        FirebaseRepository.matches().addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for (DataSnapshot match : snapshot.getChildren()) {
                    String matchId = match.getKey();
                    if (matchId == null) continue;

                    Boolean released = match.child("roomReleased").getValue(Boolean.class);
                    if (Boolean.TRUE.equals(released)) continue;

                    DataSnapshot schedule = match.child("roomRelease");
                    Boolean scheduleSent = schedule.child("released").getValue(Boolean.class);
                    Long releaseAt = schedule.child("releaseAt").getValue(Long.class);
                    String roomId = schedule.child("roomId").getValue(String.class);

                    boolean pending = !Boolean.TRUE.equals(scheduleSent)
                            && roomId != null && !roomId.trim().isEmpty()
                            && releaseAt != null && releaseAt > System.currentTimeMillis();

                    if (pending) {
                        RoomReleaseScheduler.schedule(appContext, matchId, releaseAt);
                    }
                }
                pendingResult.finish();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                pendingResult.finish();
            }
        });
    }
}
