package com.arenax.tournament;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.View;

import java.util.Random;

/**
 * Lightweight celebration layer: confetti cannons from both bottom corners plus a
 * confetti rain from the top. No assets, pure canvas, auto-stops and calls onDone.
 */
public class ConfettiView extends View {
    private static final int COUNT = 140;
    private static final int[] COLORS = {
            0xFFFFD700, 0xFFFFFFFF, 0xFFFF4D6D, 0xFF38BDF8, 0xFF34D399, 0xFFA78BFA, 0xFFFFB347
    };

    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Random rnd = new Random();
    private final Piece[] pieces = new Piece[COUNT];
    private long last;
    private float elapsed;
    private float duration = 4.2f;
    private boolean running;
    private Runnable onDone;

    private static final class Piece {
        float x, y, vx, vy, rot, vr, w, h, delay;
        int color;
        boolean circle;
    }

    public ConfettiView(Context c) { super(c); }
    public ConfettiView(Context c, AttributeSet a) { super(c, a); }

    public void start(Runnable done) {
        this.onDone = done;
        post(() -> {
            float w = getWidth(), h = getHeight(), d = getResources().getDisplayMetrics().density;
            for (int i = 0; i < COUNT; i++) {
                Piece p = new Piece();
                p.color = COLORS[rnd.nextInt(COLORS.length)];
                p.w = (5 + rnd.nextFloat() * 6) * d;
                p.h = p.w * (0.5f + rnd.nextFloat() * 0.8f);
                p.circle = rnd.nextInt(5) == 0;
                p.rot = rnd.nextFloat() * 360f;
                p.vr = (rnd.nextFloat() - 0.5f) * 720f;
                if (i < 70) {            // cannons: left (0..34) and right (35..69) corners
                    boolean left = i < 35;
                    p.x = left ? 0 : w;
                    p.y = h * 0.92f;
                    float ang = (float) Math.toRadians(left ? 55 + rnd.nextFloat() * 25 : 125 - rnd.nextFloat() * 25);
                    float speed = (650 + rnd.nextFloat() * 650) * d;
                    p.vx = (float) Math.cos(ang) * speed;
                    p.vy = -(float) Math.sin(ang) * speed;
                    p.delay = rnd.nextFloat() * 0.25f;
                } else {                  // rain from the top
                    p.x = rnd.nextFloat() * w;
                    p.y = -rnd.nextFloat() * h * 0.3f;
                    p.vx = (rnd.nextFloat() - 0.5f) * 120 * d;
                    p.vy = (120 + rnd.nextFloat() * 200) * d;
                    p.delay = 0.3f + rnd.nextFloat() * 1.6f;
                }
                pieces[i] = p;
            }
            elapsed = 0;
            last = 0;
            running = true;
            postInvalidateOnAnimation();
        });
    }

    @Override
    protected void onDraw(Canvas canvas) {
        if (!running) return;
        long now = System.nanoTime();
        float dt = last == 0 ? 0.016f : Math.min(0.05f, (now - last) / 1e9f);
        last = now;
        elapsed += dt;
        float d = getResources().getDisplayMetrics().density;
        float g = 900f * d, drag = 0.992f;
        int h = getHeight();
        boolean any = false;
        float fade = elapsed > duration - 0.8f ? Math.max(0f, (duration - elapsed) / 0.8f) : 1f;
        for (Piece p : pieces) {
            if (p == null) continue;
            if (elapsed < p.delay) { any = true; continue; }
            p.vx *= drag;
            p.vy = p.vy * drag + g * dt * (p.vy < 0 ? 1f : 0.35f);
            if (p.vy > 330 * d) p.vy = 330 * d;      // terminal velocity → floaty flutter
            p.x += p.vx * dt;
            p.y += p.vy * dt;
            p.rot += p.vr * dt;
            if (p.y > h + 40 * d) continue;
            any = true;
            paint.setColor(p.color);
            paint.setAlpha((int) (255 * fade));
            canvas.save();
            canvas.translate(p.x, p.y);
            canvas.rotate(p.rot);
            if (p.circle) canvas.drawCircle(0, 0, p.w / 2f, paint);
            else canvas.drawRect(-p.w / 2f, -p.h / 2f, p.w / 2f, p.h / 2f, paint);
            canvas.restore();
        }
        if (any && elapsed < duration) {
            postInvalidateOnAnimation();
        } else {
            running = false;
            if (onDone != null) onDone.run();
        }
    }
}
