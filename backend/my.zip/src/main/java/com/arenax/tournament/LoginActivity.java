package com.arenax.tournament;


import com.arenax.tournament.util.FancyText;
import android.animation.ValueAnimator;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Shader;
import android.net.Uri;
import android.os.Bundle;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.style.ForegroundColorSpan;
import android.view.View;
import android.view.animation.LinearInterpolator;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import com.arenax.tournament.data.FirebaseRepository;
import com.arenax.tournament.data.StorageUploader;
import com.arenax.tournament.util.InputValidation;
import com.arenax.tournament.util.SecureCredentialStore;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.resource.bitmap.CircleCrop;
import com.google.firebase.auth.FirebaseAuth;

public class LoginActivity extends BaseActivity {
    /** Accounts created after this moment must verify their Gmail before they can log in.
     *  Older accounts are not locked out. (2026-10-10 03:25 UTC) */
    private static final long EMAIL_VERIFY_REQUIRED_AFTER_MS = 1791602700000L;
    private FirebaseAuth auth;
    private EditText nameInput, emailInput, phoneInput, passwordInput, usernameInput;
    private CheckBox rememberInput;
    private TextView title, subtitle, tabLogin, tabRegister, forgot, avatarHint;
    private Button primaryButton;
    private FrameLayout avatarPicker;
    private ImageView avatarPreview;
    private Uri selectedAvatarUri;
    private boolean registrationMode;
    private ValueAnimator subtitleRgbAnimator;
    private ValueAnimator verifyPulse;
    private boolean verifyDone;
    private final android.os.Handler verifyHandler = new android.os.Handler(android.os.Looper.getMainLooper());

    private final ActivityResultLauncher<String> pickAvatarLauncher =
            registerForActivityResult(new ActivityResultContracts.GetContent(), uri -> {
                if (uri == null || avatarPreview == null) return;
                selectedAvatarUri = uri;
                avatarPreview.setPadding(0, 0, 0, 0);
                Glide.with(this).load(uri).transform(new CircleCrop()).into(avatarPreview);
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // This activity is now the launcher (the old splash screen was removed
        // because it was crashing on some devices). Do the routing it used to
        // do first, but keep it wrapped so a Firebase/config problem can never
        // take down the launcher boundary again.
        // Update notice comes FIRST - before any login, auto-login or flavor routing.
        try { showLaunchSplash(); } catch (Throwable ignored) { }
        com.arenax.tournament.util.AppStatus.launchGate(this, this::continueLaunch);
    }

    /** Plain logo screen shown for the split second the pre-login update check runs. */
    private void showLaunchSplash() {
        float d = getResources().getDisplayMetrics().density;
        android.widget.FrameLayout root = new android.widget.FrameLayout(this);
        root.setBackgroundColor(Color.parseColor("#FBFBFA"));
        ImageView logo = new ImageView(this);
        logo.setImageResource(R.mipmap.ic_launcher);
        logo.setScaleType(ImageView.ScaleType.CENTER_CROP);
        logo.setClipToOutline(true);
        android.graphics.drawable.GradientDrawable clip = new android.graphics.drawable.GradientDrawable();
        clip.setCornerRadius(24 * d);
        logo.setBackground(clip);
        root.addView(logo, new android.widget.FrameLayout.LayoutParams(Math.round(96 * d), Math.round(96 * d), android.view.Gravity.CENTER));
        setContentView(root);
    }

    private void continueLaunch() {
        if ("admin".equals(BuildConfig.FLAVOR)) {
            startActivity(new Intent(this, AdminLoginActivity.class));
            finish();
            return;
        }
        if ("messenger".equals(BuildConfig.FLAVOR)) {
            startActivity(new Intent(this, MessageLoginActivity.class));
            finish();
            return;
        }
        // Firebase Auth restores a successful user session across app restarts. This
        // activity is the user-flavor launcher, so do not show the login form again
        // when a valid session already exists. Explicit logout clears that session.
        if (routeExistingUser()) return;
        try {
            buildPremiumLoginScreen();
        } catch (Throwable error) {
            // Never let a decorative resource or theme issue close the app.
            buildFallbackLoginScreen();
        }
    }

    /** Minimal, dependency-free screen used only if the styled layout fails to inflate. */
    private void buildFallbackLoginScreen() {
        android.widget.LinearLayout root = new android.widget.LinearLayout(this);
        root.setOrientation(android.widget.LinearLayout.VERTICAL);
        root.setGravity(android.view.Gravity.CENTER_HORIZONTAL);
        int pad = Math.round(24 * getResources().getDisplayMetrics().density);
        root.setPadding(pad, pad, pad, pad);
        root.setBackgroundColor(Color.parseColor("#F0F2F7"));

        TextView titleView = new TextView(this);
        titleView.setText("STARX24 LOGIN");
        titleView.setTextColor(Color.parseColor("#14161D"));
        titleView.setTextSize(22);
        titleView.setGravity(android.view.Gravity.CENTER);
        root.addView(titleView);

        emailInput = new EditText(this);
        emailInput.setHint("Email, mobile number or username");
        emailInput.setTextColor(Color.parseColor("#14161D"));
        emailInput.setHintTextColor(Color.parseColor("#9AA3B2"));
        root.addView(emailInput);

        passwordInput = new EditText(this);
        passwordInput.setHint("Password");
        passwordInput.setInputType(android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD);
        passwordInput.setTextColor(Color.parseColor("#14161D"));
        passwordInput.setHintTextColor(Color.parseColor("#9AA3B2"));
        root.addView(passwordInput);

        Button login = new Button(this);
        login.setText("SIGN IN");
        login.setOnClickListener(v -> signIn(login));
        root.addView(login);

        setContentView(root);
    }

    /** Keeps the login card at a comfortable width on tablets / large screens; phones keep 6dp side padding so the card is nearly full width. */
    private void capLoginWidth() {
        View content = findViewById(R.id.login_content);
        if (content == null) return;
        float d = getResources().getDisplayMetrics().density;
        int screenDp = getResources().getConfiguration().screenWidthDp;
        int sideDp = screenDp > 500 ? (screenDp - 480) / 2 : (screenDp < 340 ? 4 : 6);
        int side = Math.round(sideDp * d);
        content.setPadding(side, content.getPaddingTop(), side, content.getPaddingBottom());
    }

    private void buildPremiumLoginScreen() {
        setContentView(R.layout.activity_login);
        capLoginWidth();

        title = findViewById(R.id.login_title);
        subtitle = findViewById(R.id.login_subtitle);
        tabLogin = findViewById(R.id.tab_login);
        tabRegister = findViewById(R.id.tab_register);
        nameInput = findViewById(R.id.input_name);
        emailInput = findViewById(R.id.input_email);
        phoneInput = findViewById(R.id.input_phone);
        usernameInput = findViewById(R.id.input_username);
        passwordInput = findViewById(R.id.input_password);
        rememberInput = findViewById(R.id.check_remember);
        forgot = findViewById(R.id.text_forgot);
        primaryButton = findViewById(R.id.btn_primary);
        avatarPicker = findViewById(R.id.avatar_picker);
        avatarPreview = findViewById(R.id.avatar_preview);
        avatarHint = findViewById(R.id.avatar_hint);

        avatarPicker.setOnClickListener(v -> pickAvatarLauncher.launch("image/*"));

        emailInput.setText(getSharedPreferences("arenax_auth", MODE_PRIVATE).getString("email", ""));
        passwordInput.setText(SecureCredentialStore.loadPassword(this));

        tabLogin.setOnClickListener(v -> { if (registrationMode) toggleMode(); });
        tabRegister.setOnClickListener(v -> { if (!registrationMode) toggleMode(); });

        primaryButton.setOnClickListener(v -> {
            if (registrationMode) register(primaryButton);
            else signIn(primaryButton);
        });
        forgot.setOnClickListener(v -> resetPassword());

        setStyledTitle(title, "welcome back");
        startSubtitleRgbAnimation(subtitle);
        styleBrandWordmark();
    }

    /** STARX wordmark: "STAR" in an ice-white gradient, "X" in a gold -> orange -> pink gradient. */
    private void styleBrandWordmark() {
        gradientText(findViewById(R.id.login_brand_star), 0xFFFFFFFF, 0xFFEAF0FF, 0xFFA9C2FF);
        gradientText(findViewById(R.id.login_brand_x), 0xFFFFF176, 0xFFFFA726, 0xFFFF4F8B);
    }

    private void gradientText(TextView tv, int... colors) {
        if (tv == null) return;
        tv.post(() -> {
            float h = Math.max(tv.getHeight(), tv.getTextSize());
            tv.getPaint().setShader(new LinearGradient(0, 0, 0, h, colors, null, Shader.TileMode.CLAMP));
            tv.invalidate();
        });
    }

    /** Routes a previously authenticated user directly to the user panel. */
    private boolean routeExistingUser() {
        if (!ensureFirebase() || auth.getCurrentUser() == null) return false;
        // Show a "verifying" screen right away (no blank page) while the ban check runs.
        try { showVerifyScreen(); } catch (Throwable ignored) { }
        // Never wait long: MainActivity runs the same BanGuard check itself, so if the check
        // is slow (cold start / weak network) we open the app after 1.5s anyway.
        verifyHandler.postDelayed(this::proceedToApp, 1500L);
        com.arenax.tournament.util.BanGuard.check(this, banned -> {
            if (banned) { verifyDone = true; verifyHandler.removeCallbacksAndMessages(null); return; }
            proceedToApp();
        });
        return true;
    }

    private void proceedToApp() {
        if (verifyDone) return;
        verifyDone = true;
        verifyHandler.removeCallbacksAndMessages(null);
        openApp();
    }

    /** Scan/verify style loading page shown to an already logged-in player instead of a blank screen. */
    private void showVerifyScreen() {
        float d = getResources().getDisplayMetrics().density;
        android.widget.LinearLayout root = new android.widget.LinearLayout(this);
        root.setOrientation(android.widget.LinearLayout.VERTICAL);
        root.setGravity(android.view.Gravity.CENTER);
        root.setBackgroundColor(Color.parseColor("#FBFBFA"));
        root.setPadding(Math.round(32 * d), 0, Math.round(32 * d), 0);

        ImageView logo = new ImageView(this);
        logo.setImageResource(R.mipmap.ic_launcher);
        logo.setScaleType(ImageView.ScaleType.CENTER_CROP);
        logo.setClipToOutline(true);
        android.graphics.drawable.GradientDrawable clip = new android.graphics.drawable.GradientDrawable();
        clip.setCornerRadius(24 * d);
        logo.setBackground(clip);
        root.addView(logo, new android.widget.LinearLayout.LayoutParams(Math.round(96 * d), Math.round(96 * d)));

        TextView name = new TextView(this);
        name.setText("STARX24");
        name.setTextColor(Color.parseColor("#1C1C1E"));
        name.setTextSize(22f);
        name.setTypeface(null, android.graphics.Typeface.BOLD);
        name.setLetterSpacing(0.12f);
        android.widget.LinearLayout.LayoutParams np = new android.widget.LinearLayout.LayoutParams(-2, -2);
        np.topMargin = Math.round(16 * d);
        root.addView(name, np);

        android.widget.ProgressBar bar = new android.widget.ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        bar.setIndeterminate(true);
        bar.setIndeterminateTintList(android.content.res.ColorStateList.valueOf(Color.parseColor("#1C1C1E")));
        android.widget.LinearLayout.LayoutParams bp = new android.widget.LinearLayout.LayoutParams(Math.round(180 * d), Math.round(4 * d));
        bp.topMargin = Math.round(28 * d);
        root.addView(bar, bp);

        TextView status = new TextView(this);
        status.setText("Verifying your account\u2026");
        status.setTextColor(Color.parseColor("#5A6472"));
        status.setTextSize(13.5f);
        android.widget.LinearLayout.LayoutParams sp = new android.widget.LinearLayout.LayoutParams(-2, -2);
        sp.topMargin = Math.round(12 * d);
        root.addView(status, sp);

        setContentView(root);

        // soft pulse on the logo while verifying
        verifyPulse = ValueAnimator.ofFloat(1f, 1.07f);
        verifyPulse.setDuration(700L);
        verifyPulse.setRepeatMode(ValueAnimator.REVERSE);
        verifyPulse.setRepeatCount(ValueAnimator.INFINITE);
        verifyPulse.addUpdateListener(a -> {
            float v = (float) a.getAnimatedValue();
            logo.setScaleX(v);
            logo.setScaleY(v);
        });
        verifyPulse.start();
    }

    /** Lowercases the title and colors its last word blood red, rest stays default. */
    private void setStyledTitle(TextView target, String lowerCaseText) {
        SpannableString styled = new SpannableString(lowerCaseText);
        int lastWordStart = lowerCaseText.lastIndexOf(' ') + 1;
        styled.setSpan(new ForegroundColorSpan(getResources().getColor(R.color.login_ink)),
                lastWordStart, lowerCaseText.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        target.setText(styled);
    }

    /** Animates a moving white -> red -> orange gradient across the subtitle text. */
    private void startSubtitleRgbAnimation(TextView target) {
        target.post(() -> {
            int width = target.getWidth();
            if (width <= 0) return;
            int[] colors = {Color.parseColor("#B9C0CC"), Color.parseColor("#14161D"), Color.parseColor("#5A6472"), Color.parseColor("#B9C0CC")};
            LinearGradient gradient = new LinearGradient(
                    0, 0, width * 2f, 0, colors, null, Shader.TileMode.MIRROR);
            target.getPaint().setShader(gradient);

            if (subtitleRgbAnimator != null) subtitleRgbAnimator.cancel();
            subtitleRgbAnimator = ValueAnimator.ofFloat(0f, width * 2f);
            subtitleRgbAnimator.setDuration(2400);
            subtitleRgbAnimator.setRepeatCount(ValueAnimator.INFINITE);
            subtitleRgbAnimator.setInterpolator(new LinearInterpolator());
            subtitleRgbAnimator.addUpdateListener(animation -> {
                float translate = (float) animation.getAnimatedValue();
                android.graphics.Matrix matrix = new android.graphics.Matrix();
                matrix.setTranslate(translate, 0);
                gradient.setLocalMatrix(matrix);
                target.invalidate();
            });
            subtitleRgbAnimator.start();
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (subtitleRgbAnimator != null) subtitleRgbAnimator.cancel();
        if (verifyPulse != null) verifyPulse.cancel();
        verifyHandler.removeCallbacksAndMessages(null);
    }

    private void toggleMode() {
        registrationMode = !registrationMode;
        if (registrationMode) {
            setStyledTitle(title, "create account");
            subtitle.setText("Join the arena and start competing");
            nameInput.setVisibility(View.VISIBLE);
            phoneInput.setVisibility(View.VISIBLE);
            usernameInput.setVisibility(View.VISIBLE);
            emailInput.setHint("Email address");
            avatarPicker.setVisibility(View.VISIBLE);
            avatarHint.setVisibility(View.VISIBLE);
            primaryButton.setText("CREATE ACCOUNT   →");
            forgot.setVisibility(View.GONE);
            tabLogin.setBackgroundResource(R.drawable.bg_login_tab_inactive);
            tabLogin.setTextColor(getResources().getColor(R.color.text_secondary));
            tabRegister.setBackgroundResource(R.drawable.bg_login_tab_active);
            tabRegister.setTextColor(Color.WHITE);
        } else {
            setStyledTitle(title, "welcome back");
            subtitle.setText("Sign in to continue your tournament run");
            nameInput.setVisibility(View.GONE);
            phoneInput.setVisibility(View.GONE);
            usernameInput.setVisibility(View.GONE);
            emailInput.setHint("Email, mobile number or username");
            avatarPicker.setVisibility(View.GONE);
            avatarHint.setVisibility(View.GONE);
            primaryButton.setText("LOGIN   →");
            forgot.setVisibility(View.VISIBLE);
            tabRegister.setBackgroundResource(R.drawable.bg_login_tab_inactive);
            tabRegister.setTextColor(getResources().getColor(R.color.text_secondary));
            tabLogin.setBackgroundResource(R.drawable.bg_login_tab_active);
            tabLogin.setTextColor(Color.WHITE);
        }
    }

    private void signIn(Button button) {
        if (registrationMode) return;
        if (!ensureFirebase()) return;
        final String identifier = value(emailInput), pass = value(passwordInput);
        if (identifier.isEmpty()) { emailInput.setError("Enter email, mobile number or username"); emailInput.requestFocus(); return; }
        if (!InputValidation.password(passwordInput)) { toast("Check your password"); return; }
        button.setEnabled(false);
        if (identifier.contains("@")) {
            if (!android.util.Patterns.EMAIL_ADDRESS.matcher(identifier).matches()) {
                button.setEnabled(true);
                emailInput.setError("Enter a valid email address");
                emailInput.requestFocus();
                return;
            }
            signInWithEmail(button, identifier, identifier, pass);
            return;
        }
        // Mobile number or username: look up the email it belongs to, then sign in with it.
        FirebaseRepository.resolveLoginEmail(identifier, (found, failed) -> {
            if (found == null) {
                button.setEnabled(true);
                toast(failed ? "Could not look up your account. Check your connection."
                        : "No account found for this mobile number / username. Login with your email once, or create an account.");
                return;
            }
            signInWithEmail(button, found, identifier, pass);
        });
    }

    private void signInWithEmail(Button button, String email, String typedIdentifier, String pass) {
        auth.signInWithEmailAndPassword(email, pass).addOnSuccessListener(result -> {
            com.google.firebase.auth.FirebaseUser fu = result.getUser();
            if (fu != null && !fu.isEmailVerified() && fu.getMetadata() != null
                    && fu.getMetadata().getCreationTimestamp() > EMAIL_VERIFY_REQUIRED_AFTER_MS) {
                try { fu.sendEmailVerification(); } catch (Throwable ignored) { }
                auth.signOut();
                button.setEnabled(true);
                toast("Email not verified. A new verification link was sent to " + email + ". Open it, then login again.");
                return;
            }
            // Banned players never get into the app: BanGuard signs them out and shows the ban notice.
            com.arenax.tournament.util.BanGuard.check(this, banned -> {
                if (banned) return;
                if (result.getUser() != null) FirebaseRepository.backfillLoginKeys(result.getUser().getUid(), email);
                boolean remember = rememberInput == null || rememberInput.isChecked();
                getSharedPreferences("arenax_auth", MODE_PRIVATE).edit().putString("email", remember ? typedIdentifier : "").apply();
                if (remember) SecureCredentialStore.savePassword(this, pass);
                else SecureCredentialStore.clear(this);
                openApp();
            });
        }).addOnFailureListener(error -> { button.setEnabled(true); toast(message(error)); });
    }

    private void register(Button button) {
        if (!ensureFirebase()) return;
        String name = value(nameInput), email = value(emailInput), phone = value(phoneInput).replaceAll("\\D", ""), pass = value(passwordInput);
        String username = value(usernameInput).toLowerCase(java.util.Locale.ROOT);
        if (!InputValidation.length(nameInput, 2, 60, "Enter your name")
                || !InputValidation.email(emailInput)
                || !InputValidation.phone(phoneInput)
                || !InputValidation.password(passwordInput)) {
            toast("Please correct the highlighted fields");
            return;
        }
        if (!email.toLowerCase(java.util.Locale.ROOT).endsWith("@gmail.com")) {
            emailInput.setError("Use a real Gmail address (example@gmail.com)");
            emailInput.requestFocus();
            return;
        }
        if (!username.matches("[a-z0-9_.]{3,20}")) {
            usernameInput.setError("3-20 characters: letters, numbers, _ or .");
            usernameInput.requestFocus();
            return;
        }
        button.setEnabled(false);
        FirebaseRepository.usernameAvailable(username, free -> {
            if (!free) {
                button.setEnabled(true);
                usernameInput.setError("This username is already taken");
                usernameInput.requestFocus();
                return;
            }
            createAccount(button, name, email, phone, pass, username);
        });
    }

    private void createAccount(Button button, String name, String email, String phone, String pass, String username) {
        auth.createUserWithEmailAndPassword(email, pass).addOnSuccessListener(result -> {
            if (result.getUser() == null) { button.setEnabled(true); return; }
            String uid = result.getUser().getUid();
            try { result.getUser().sendEmailVerification(); } catch (Throwable ignored) { }
            FirebaseRepository.reservePhone(phone, uid)
                    .addOnSuccessListener(v -> {
                        FirebaseRepository.saveLoginKeys(uid, email, phone, username);
                        finishRegistration(uid, email, name, phone, button);
                    })
                    .addOnFailureListener(error -> {
                        button.setEnabled(true);
                        auth.signOut();
                        toast("This mobile number is already registered.");
                    });
        }).addOnFailureListener(error -> { button.setEnabled(true); toast(message(error)); });
    }

    /** Uploads the picked profile picture (if any) before writing the user record, so
     *  photoUrl is already known when saveUserProfile does its one-time users/{uid} write. */
    private void finishRegistration(String uid, String email, String name, String phone, Button button) {
        if (selectedAvatarUri == null) {
            saveProfileAndOpenApp(uid, email, name, phone, null, button);
            return;
        }
        StorageUploader.uploadAvatar(this, selectedAvatarUri, uid, new StorageUploader.Callback() {
            @Override public void onSuccess(String fileUrl) {
                saveProfileAndOpenApp(uid, email, name, phone, fileUrl, button);
            }
            @Override public void onFailure(String message) {
                // Don't block account creation over a picture upload hiccup — the account
                // still gets created, just without a photo for now.
                toast("Profile picture upload failed, continuing without it");
                saveProfileAndOpenApp(uid, email, name, phone, null, button);
            }
        });
    }

    private void saveProfileAndOpenApp(String uid, String email, String name, String phone, String photoUrl, Button button) {
        FirebaseRepository.saveUserProfile(uid, email, name, phone, photoUrl)
                .addOnSuccessListener(done -> verifyEmailThenLogin(email, button))
                .addOnFailureListener(error -> { button.setEnabled(true); auth.signOut(); toast(message(error)); });
    }

    /** New accounts cannot enter the app until the Gmail link is opened, so a fake address can never log in. */
    private void verifyEmailThenLogin(String email, Button button) {
        auth.signOut();
        button.setEnabled(true);
        passwordInput.setText("");
        toast("Verification link sent to " + email + ". Open it (check Spam too), then login.");
        if (registrationMode) toggleMode();
    }

    private void resetPassword() {
        if (!ensureFirebase()) return;
        String email = value(emailInput);
        if (email.isEmpty()) { toast("Enter your email, mobile number or username first"); return; }
        if (!email.contains("@")) {
            FirebaseRepository.resolveLoginEmail(email, (found, failed) -> {
                if (found == null) { toast("No account found for that mobile number / username"); return; }
                auth.sendPasswordResetEmail(found).addOnSuccessListener(v -> toast("Password reset email sent")).addOnFailureListener(e -> toast(message(e)));
            });
            return;
        }
        auth.sendPasswordResetEmail(email).addOnSuccessListener(v -> toast("Password reset email sent")).addOnFailureListener(e -> toast(message(e)));
    }

    private boolean ensureFirebase() {
        try {
            if (auth == null && FirebaseRepository.isFirebaseAvailable(this)) auth = FirebaseAuth.getInstance();
        } catch (Throwable ignored) { auth = null; }
        if (auth != null) return true;
        toast("Login service is unavailable. Please check Firebase setup.");
        return false;
    }

    /** First login after registration: MainActivity plays the welcome celebration. */
    private void openAppAsNewUser(String name) {
        Intent i = new Intent(this, MainActivity.class);
        i.putExtra("celebrate_new_user", true);
        i.putExtra("celebrate_name", name);
        startActivity(i);
        finish();
    }

    private void openApp() {
        Intent i = new Intent(this, MainActivity.class);
        // A notification tapped while the app was closed lands here first (launcher screen);
        // hand its redirect on so MainActivity can open the exact content.
        com.arenax.tournament.util.NotificationRedirect.copyExtras(getIntent(), i);
        startActivity(i);
        finish();
    }
    private String value(EditText input) { return input.getText() == null ? "" : input.getText().toString().trim(); }
    private String message(Exception error) { return error.getMessage() == null ? "Please try again" : error.getMessage(); }
    private void toast(String message) { FancyText.toast(this, message, Toast.LENGTH_LONG).show(); }
}
