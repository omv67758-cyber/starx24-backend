package com.arenax.tournament.util;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.provider.Settings;
import android.widget.Toast;

import com.arenax.tournament.RoomReleaseAlarmReceiver;

/**
 * Schedules/cancels the exact-time alarm that auto-releases a match's room ID + password
 * (and notifies only its joined participants) at matches/{matchId}/roomRelease/releaseAt,
 * even if the app is completely closed. This is what finally makes good on the promise
 * already shown to admins in {@code RoleAdminActivity#showRoomReleaseForm} ("The backend
 * releases it even if the app is closed.") — previously nothing actually watched
 * roomReleaseAt/releaseAt.
 *
 * Used by RoleAdminActivity (right after FirebaseRepository.saveRoomRelease) and by
 * BootRescheduleReceiver (to survive a phone restart, since AlarmManager alarms are wiped
 * on reboot).
 */
public final class RoomReleaseScheduler {
    private RoomReleaseScheduler() {}

    /** Om's measured delivery lag: from the moment RoomReleaseAlarmReceiver actually fires
     *  and calls FcmSender, the push notification takes ~10s to actually land on a player's
     *  device (FCM handoff + system tray delivery, not something this app controls). Firing
     *  the alarm exactly AT releaseAt therefore means every "Room Released!" notification
     *  shows up 10s late relative to the schedule the admin picked. Compensating here — the
     *  one place every caller (RoleAdminActivity, TournamentControlCenterActivity,
     *  BootRescheduleReceiver) goes through to arm the alarm — fires it 10s earlier so the
     *  notification actually reaches the player at the advertised time. */
    private static final long NOTIFICATION_DELIVERY_LEAD_MS = 10_000L;

    /** Schedules an exact alarm for releaseAt (fired NOTIFICATION_DELIVERY_LEAD_MS early to
     *  offset real-world push delivery lag). No-op if that time has already passed —
     *  callers should release immediately instead in that case. */
    public static void schedule(Context context, String matchId, long releaseAt) {
        long now = System.currentTimeMillis();
        if (matchId == null || matchId.trim().isEmpty() || releaseAt <= now) {
            return;
        }

        AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (alarmManager == null) return;

        PendingIntent pendingIntent = buildPendingIntent(context, matchId);

        if (Build.VERSION.SDK_INT >= 31 && !alarmManager.canScheduleExactAlarms()) {
            FancyText.toast(context,
                    "Enable \"Alarms & reminders\" for this app in Settings, otherwise auto room-release may fire late.",
                    Toast.LENGTH_LONG).show();
            Intent settingsIntent = new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM);
            settingsIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(settingsIntent);
        }

        // Fire 10s early so the notification (which itself takes ~10s to actually reach the
        // device) lands right on time. If releaseAt is less than 10s away, fire as soon as
        // possible instead of scheduling something in the past.
        long fireAt = Math.max(now + 100L, releaseAt - NOTIFICATION_DELIVERY_LEAD_MS);
        alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, fireAt, pendingIntent);
    }


    /** Cancels a previously scheduled alarm for this match, e.g. after a manual release/hide. */
    public static void cancel(Context context, String matchId) {
        if (matchId == null || matchId.trim().isEmpty()) return;
        AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (alarmManager == null) return;
        alarmManager.cancel(buildPendingIntent(context, matchId));
    }

    private static PendingIntent buildPendingIntent(Context context, String matchId) {
        Intent intent = new Intent(context, RoomReleaseAlarmReceiver.class);
        intent.putExtra(RoomReleaseAlarmReceiver.EXTRA_MATCH_ID, matchId);
        int requestCode = matchId.hashCode();
        int flags = PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE;
        return PendingIntent.getBroadcast(context, requestCode, intent, flags);
    }
}
