package com.arenax.tournament;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.WindowInsetsControllerCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.arenax.tournament.adapter.TournamentAdapter;
import com.arenax.tournament.data.FirebaseRepository;
import com.arenax.tournament.model.Tournament;
import com.arenax.tournament.util.FancyText;
import com.arenax.tournament.util.FullScreenDialog;
import com.arenax.tournament.util.MatchNumber;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/**
 * Admin "Search Match": type a match #hash code (e.g. #482913 or just 482913) and every match
 * with that code is listed, no matter which category it belongs to. Typing part of a match name
 * works too. Tapping a result opens its Control Center, same as the category pages.
 */
public class MatchSearchActivity extends BaseActivity {
    private final List<Tournament> everything = new ArrayList<>();
    private final List<Tournament> results = new ArrayList<>();
    private TournamentAdapter adapter;
    private EditText input;
    private TextView summary, empty;
    private ValueEventListener listener;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        buildScreen();
        listen();
    }

    private void buildScreen() {
        final int canvas = getColor(R.color.home_bg);
        final int ink = getColor(R.color.text_primary);
        getWindow().setStatusBarColor(canvas);
        getWindow().setNavigationBarColor(canvas);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(canvas);
        ViewCompat.setOnApplyWindowInsetsListener(root, (view, insets) -> {
            Insets bars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            view.setPadding(bars.left, bars.top, bars.right, bars.bottom);
            return insets;
        });

        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(12), dp(12), dp(12), dp(8));
        TextView back = text("‹", 28, ink, true);
        back.setGravity(Gravity.CENTER);
        back.setContentDescription("Back");
        back.setBackgroundResource(R.drawable.bg_category_back);
        back.setOnClickListener(v -> finish());
        bar.addView(back, new LinearLayout.LayoutParams(dp(36), dp(36)));
        TextView title = text("Search Match", 18, ink, true);
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(0, -2, 1f);
        tp.leftMargin = dp(12);
        bar.addView(title, tp);
        root.addView(bar, new LinearLayout.LayoutParams(-1, -2));

        input = new EditText(this);
        input.setHint("Search #hash, match name or category");
        input.setHintTextColor(Color.rgb(120, 130, 145));
        input.setTextColor(ink);
        input.setTextSize(14.5f);
        input.setSingleLine(true);
        input.setInputType(InputType.TYPE_CLASS_TEXT);
        input.setImeOptions(EditorInfo.IME_ACTION_SEARCH);
        input.setPadding(dp(14), dp(12), dp(14), dp(12));
        GradientDrawable field = new GradientDrawable();
        field.setColor(Color.WHITE);
        field.setCornerRadius(dp(10));
        field.setStroke(dp(1), 0xFF9CC5F5);
        input.setBackground(field);
        input.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void afterTextChanged(Editable s) { applyFilter(); }
        });
        input.setOnEditorActionListener((v, actionId, event) -> { applyFilter(); return false; });
        LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(-1, -2);
        ip.setMargins(dp(12), dp(4), dp(12), dp(4));
        root.addView(input, ip);

        TextView autoDelete = text("AUTO DELETE COMPLETED (listed matches)", 12.5f, 0xFFD92D20, true);
        autoDelete.setGravity(Gravity.CENTER);
        autoDelete.setPadding(dp(12), dp(11), dp(12), dp(11));
        GradientDrawable adBg = new GradientDrawable();
        adBg.setColor(0xFFFFF1F0);
        adBg.setCornerRadius(dp(10));
        adBg.setStroke(dp(1), 0xFFD92D20);
        autoDelete.setBackground(adBg);
        autoDelete.setOnClickListener(v -> confirmAutoDeleteCompleted());
        LinearLayout.LayoutParams adp = new LinearLayout.LayoutParams(-1, -2);
        adp.setMargins(dp(12), dp(2), dp(12), dp(4));
        root.addView(autoDelete, adp);

        summary = text("", 11.5f, getColor(R.color.text_secondary), false);
        summary.setPadding(dp(14), dp(2), dp(14), dp(4));
        root.addView(summary, new LinearLayout.LayoutParams(-1, -2));

        empty = text("", 14, getColor(R.color.text_secondary), false);
        empty.setGravity(Gravity.CENTER);
        empty.setPadding(dp(32), 0, dp(32), 0);
        RecyclerView list = new RecyclerView(this);
        list.setLayoutManager(new LinearLayoutManager(this));
        list.setClipToPadding(false);
        list.setPadding(0, dp(4), 0, dp(12));
        adapter = new TournamentAdapter(results, t -> {
            Intent page = new Intent(this, TournamentControlCenterActivity.class);
            page.putExtra("tournamentId", t.getId());
            page.putExtra("title", t.getTitle());
            startActivity(page);
        });
        adapter.setJoinButtonText("MANAGE MATCH");
        adapter.setOnDeleteClick(this::confirmDelete);
        adapter.setShowLiveStrip(false);
        list.setAdapter(adapter);

        FrameLayout body = new FrameLayout(this);
        body.addView(list, new FrameLayout.LayoutParams(-1, -1));
        body.addView(empty, new FrameLayout.LayoutParams(-2, -2, Gravity.CENTER));
        root.addView(body, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(root);

        WindowInsetsControllerCompat c = WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView());
        c.setAppearanceLightStatusBars(true);
        c.setAppearanceLightNavigationBars(true);
    }

    @SuppressWarnings("unchecked")
    private void listen() {
        if (!FirebaseRepository.isReady(this)) {
            toast("Live match data is unavailable right now.");
            return;
        }
        listener = new ValueEventListener() {
            @Override public void onDataChange(DataSnapshot snapshot) {
                everything.clear();
                for (DataSnapshot child : snapshot.getChildren()) {
                    try {
                        Tournament t = Tournament.fromMap(child.getKey(), (Map<String, Object>) child.getValue());
                        if (t != null) everything.add(t);   // every category, every status
                    } catch (RuntimeException ignored) { }
                }
                applyFilter();
            }
            @Override public void onCancelled(DatabaseError error) {
                toast("Could not load matches: " + error.getMessage());
            }
        };
        FirebaseRepository.tournaments().addValueEventListener(listener);
    }

    private void applyFilter() {
        results.clear();
        String raw = input == null ? "" : input.getText().toString().trim();
        String digits = raw.replaceAll("[^0-9]", "");
        boolean codeSearch = !digits.isEmpty() && raw.replaceAll("[#0-9\\s]", "").isEmpty();
        String needle = raw.toLowerCase(Locale.ROOT);
        Set<String> categories = new LinkedHashSet<>();
        for (Tournament t : everything) {
            boolean hit;
            if (raw.isEmpty()) {
                hit = true;   // nothing typed: list every match, all categories and statuses
            } else if (codeSearch) {
                hit = MatchNumber.fromId(t.getId()).contains(digits);
            } else {
                hit = (t.getTitle() != null && t.getTitle().toLowerCase(Locale.ROOT).contains(needle))
                        || (t.getMode() != null && t.getMode().toLowerCase(Locale.ROOT).contains(needle))
                        || (t.getId() != null && t.getId().toLowerCase(Locale.ROOT).equals(needle));
            }
            if (hit) {
                results.add(t);
                if (t.getMode() != null && !t.getMode().trim().isEmpty()) categories.add(t.getMode().trim());
            }
        }
        // Sooner start time on top, later ones below.
        java.util.Collections.sort(results, (a, b) -> {
            long x = a.getEffectiveStartAt();
            long y = b.getEffectiveStartAt();
            if (x <= 0L && y <= 0L) return 0;
            if (x <= 0L) return 1;
            if (y <= 0L) return -1;
            return Long.compare(x, y);
        });
        if (results.isEmpty()) {
            summary.setText("");
            empty.setText(raw.isEmpty() ? "Abhi koi match nahi hai." : "Is search ka koi match nahi mila.");
        } else {
            summary.setText(results.size() + " match mile  •  " + android.text.TextUtils.join(", ", categories));
        }
        empty.setVisibility(results.isEmpty() ? View.VISIBLE : View.GONE);
        adapter.notifyDataSetChanged();
    }

    /** Deletes every FINISHED match (completed / result published / cancelled) in the current search list. */
    private void confirmAutoDeleteCompleted() {
        final java.util.List<Tournament> done = new java.util.ArrayList<>();
        for (Tournament t : results) {
            String st = t.getEffectiveStatus();
            if (Tournament.COMPLETED.equals(st) || Tournament.CANCELLED.equals(st)) done.add(t);
        }
        if (done.isEmpty()) { toast("Is list me koi completed match nahi hai."); return; }
        new FullScreenDialog.Builder(this)
                .setTitle("Delete " + done.size() + " completed matches?")
                .setMessage("Is list ke saare completed/cancelled matches Firebase se permanently hat jayenge.")
                .setNegativeButton("CANCEL", null)
                .setPositiveButton("DELETE ALL", (dialog, which) -> {
                    final int[] ok = {0};
                    final int[] fail = {0};
                    for (Tournament t : done) {
                        FirebaseRepository.deleteTournament(t.getId())
                                .addOnSuccessListener(x -> {
                                    ok[0]++;
                                    FirebaseRepository.logActivity("TOURNAMENT_DELETED", t.getTitle(), "auto delete completed");
                                    if (ok[0] + fail[0] == done.size()) toast(ok[0] + " deleted, " + fail[0] + " failed.");
                                })
                                .addOnFailureListener(e -> {
                                    fail[0]++;
                                    if (ok[0] + fail[0] == done.size()) toast(ok[0] + " deleted, " + fail[0] + " failed.");
                                });
                    }
                })
                .show();
    }

    private void confirmDelete(Tournament tournament) {
        new FullScreenDialog.Builder(this)
                .setTitle("Delete " + tournament.getTitle() + "?")
                .setMessage("This permanently removes the match from Firebase. Players will no longer see it.")
                .setNegativeButton("CANCEL", null)
                .setPositiveButton("DELETE", (dialog, which) ->
                        FirebaseRepository.deleteTournament(tournament.getId())
                                .addOnSuccessListener(done -> {
                                    toast("Match deleted.");
                                    FirebaseRepository.logActivity("TOURNAMENT_DELETED", tournament.getTitle(), "");
                                })
                                .addOnFailureListener(error -> toast("Delete failed: " + error.getMessage())))
                .show();
    }

    @Override protected void onDestroy() {
        super.onDestroy();
        if (listener != null) FirebaseRepository.tournaments().removeEventListener(listener);
    }

    private TextView text(String s, float size, int color, boolean bold) {
        TextView v = new TextView(this);
        v.setText(s);
        v.setTextSize(size);
        v.setTextColor(color);
        v.setTypeface(null, bold ? Typeface.BOLD : Typeface.NORMAL);
        return v;
    }

    private int dp(int value) { return Math.round(value * getResources().getDisplayMetrics().density); }

    private void toast(String message) { FancyText.toast(this, message, Toast.LENGTH_LONG).show(); }
}
