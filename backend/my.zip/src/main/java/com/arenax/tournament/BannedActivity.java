package com.arenax.tournament;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Shown instead of the app when a banned player tries to log in. */
public class BannedActivity extends BaseActivity {
    public static final String EXTRA_REASON = "banReason";

    private int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        String reason = getIntent().getStringExtra(EXTRA_REASON);
        if (reason == null || reason.trim().isEmpty()) reason = "Violation of app rules";

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setBackgroundColor(Color.WHITE);
        root.setPadding(dp(24), dp(24), dp(24), dp(24));

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setGravity(Gravity.CENTER_HORIZONTAL);
        card.setPadding(dp(22), dp(28), dp(22), dp(22));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xFFFEF2F2);
        bg.setCornerRadius(dp(18));
        bg.setStroke(dp(2), 0xFFDC2626);
        card.setBackground(bg);

        TextView icon = new TextView(this);
        icon.setText("⛔");
        icon.setTextSize(48);
        icon.setGravity(Gravity.CENTER);
        card.addView(icon);

        TextView title = new TextView(this);
        title.setText("You're banned");
        title.setTextSize(26);
        title.setTypeface(null, Typeface.BOLD);
        title.setTextColor(0xFFDC2626);
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, dp(8), 0, dp(10));
        card.addView(title);

        TextView sub = new TextView(this);
        sub.setText("Your account has been banned, so you can't log in. Reason:");
        sub.setTextSize(14);
        sub.setTextColor(0xFF68686D);
        sub.setGravity(Gravity.CENTER);
        card.addView(sub);

        TextView why = new TextView(this);
        why.setText(reason);
        why.setTextSize(17);
        why.setTypeface(null, Typeface.BOLD);
        why.setTextColor(0xFF1C1C1E);
        why.setGravity(Gravity.CENTER);
        why.setPadding(0, dp(12), 0, dp(6));
        card.addView(why);

        LinearLayout.LayoutParams cardLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        root.addView(card, cardLp);

        Button back = new Button(this);
        back.setText("OK");
        back.setAllCaps(true);
        back.setOnClickListener(v -> {
            Intent i = new Intent(this, LoginActivity.class);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(i);
            finish();
        });
        LinearLayout.LayoutParams btnLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(52));
        btnLp.topMargin = dp(20);
        root.addView(back, btnLp);

        setContentView(root);
    }

    @Override
    public void onBackPressed() {
        finishAffinity();
    }
}
