package com.arenax.tournament;


import com.arenax.tournament.util.FancyText;
import com.arenax.tournament.util.FullScreenDialog;
import com.arenax.tournament.util.ImageLoader;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputType;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;
import android.widget.TextView;
import android.widget.Button;
import android.widget.Spinner;

import androidx.appcompat.app.AppCompatActivity;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.arenax.tournament.adapter.BannerAdapter;
import com.arenax.tournament.adapter.GameModeAdapter;
import com.arenax.tournament.adapter.TournamentAdapter;
import com.arenax.tournament.data.FirebaseRepository;
import com.arenax.tournament.model.Banner;
import com.arenax.tournament.model.GameMode;
import com.arenax.tournament.model.Tournament;
import com.arenax.tournament.util.RoomReleaseScheduler;
import com.bumptech.glide.Glide;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.switchmaterial.SwitchMaterial;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class AdminActivity extends BaseActivity {
    private RecyclerView.Adapter<AdminMatchHolder> adapter;
    private final List<Tournament> tournaments = new ArrayList<>();
    private final List<Tournament> recentMatches = new ArrayList<>();
    private final List<GameMode> gameModes = new ArrayList<>();
    private com.arenax.tournament.adapter.CategoryImageAdapter categoryImageAdapter;
    private ValueEventListener tournamentListener;
    private ValueEventListener gameModeListener;
    private ValueEventListener configListener;
    private boolean applyingConfig;
    private Dialog categoryDialog;
    private ImageView categoryPreview;
    private EditText categoryImageUrl;
    private Uri selectedCategoryImage;
    private final List<Banner> banners = new ArrayList<>();
    private ValueEventListener bannerListener;
    private BannerAdapter homeBannerAdapter;
    private final List<Banner> homeBanners = new ArrayList<>();
    private final Map<String, TextView> homeStatValues = new HashMap<>();
    private FullScreenDialog bannerDialog;
    private ImageView bannerPreview;
    private EditText bannerImageUrlField;
    private Uri selectedBannerImage;
    private FullScreenDialog logoDialog;
    private ImageView logoPreview;
    private Uri selectedLogoImage;
    private ImageView tournamentPreview;
    private EditText tournamentImageUrlField;
    private Uri selectedTournamentImage;
    private android.widget.ScrollView dashboardScroll;
    private android.widget.ScrollView workspaceScroll;
    private LinearLayout workspaceContent;
    /** Pull-down-to-refresh wrapper around the workspace pages (replaces every "REFRESH ..." button). */
    private com.arenax.tournament.util.PullRefreshLayout workspaceRefreshLayout;
    /** Re-renders the workspace page currently on screen; run when the admin pulls down. */
    private Runnable workspaceRefresh;
    private DatabaseReference coinEditRef;
    private ValueEventListener coinEditListener;

    private void detachCoinEditListener() {
        if (coinEditRef != null && coinEditListener != null) coinEditRef.removeEventListener(coinEditListener);
        coinEditRef = null;
        coinEditListener = null;
    }
    /** Top-bar slot for the current page's own actions (＋ create, export, ⋮ more). */
    private LinearLayout headerActions;
    /** Top-right bell = Coin Requests inbox, with a live pending-count badge. */
    private View bellWrap;
    private TextView bellBadge;
    private final android.os.Handler uiHandler = new android.os.Handler(android.os.Looper.getMainLooper());
    /** The tournament whose matches page is currently open in the workspace, so the full-screen
     *  MatchEditor / RoomControl pages can tell us exactly what to re-render when they return. */
    private Tournament activeTournament;
    /** A-TXN — one row of the unified Transaction History table on the Payments page
     *  (merges withdrawals + deposits, newest first). */
    private static final class TxnRow {
        final String id, type, userId, amount, status, upiId;
        final long ts;
        final boolean withdrawal;
        boolean flagged;
        TxnRow(String id, String type, String userId, String amount, String status, long ts, boolean withdrawal, String upiId) {
            this.id = id; this.type = type; this.userId = userId; this.amount = amount;
            this.status = status; this.ts = ts; this.withdrawal = withdrawal; this.upiId = upiId == null ? "" : upiId;
        }
    }
    /** uid -> {name, email, phone, upiId}; filled from users/{uid} so the payments list shows people, not IDs. */
    private final Map<String, String[]> txnUserCache = new HashMap<>();
    private final List<TxnRow> paymentsTxnCache = new ArrayList<>();
    private String paymentsFilter = "ALL";
    private LinearLayout paymentsTableBody;
    /** A1 RBAC — never default to full access. If the intent's role is missing/unrecognized
     *  (stale session, corrupted key record, etc.) this now falls back to the MOST restrictive
     *  role instead of silently granting every nav item. */
    private String adminRole = "SUPPORT_AGENT";

    /** Work-role keys (Withdrawal / Match & Banner / Profile & System / Custom) run as this synthetic
     *  role; what they may actually do comes only from the owner-assigned functions in adminPerms. */
    private static final String WORK_KEY = "WORK_KEY";
    private final java.util.Set<String> adminPerms = new java.util.HashSet<>();

    /** Pages this session may open: owner/legacy roles via ROLE_PAGES, work keys via their perms. */
    private java.util.Set<String> rolePages() {
        if (WORK_KEY.equals(adminRole)) return AdminRoles.pagesFor(adminPerms);
        java.util.Set<String> pages = ROLE_PAGES.get(adminRole);
        return pages != null ? pages : ROLE_PAGES.get("SUPPORT_AGENT");
    }

    /** Match creation is available to the owner, legacy match roles, and a work key
     * explicitly granted the match-detail function. Firebase rules enforce the same gate. */
    private boolean canCreateMatch() {
        return "SUPER_ADMIN".equals(adminRole)
                || DASHBOARD_MATCH_CONTROL_ROLES.contains(adminRole)
                || hasPerm("match_detail");
    }

    /** True for the owner and for work keys that were handed this function. Legacy roles never match. */
    private boolean hasPerm(String function) {
        return "SUPER_ADMIN".equals(adminRole) || (WORK_KEY.equals(adminRole) && adminPerms.contains(function));
    }

    /** A1 RBAC — which workspace pages each role may open. Dashboard is always visible to every role. */
    private static final Map<String, java.util.Set<String>> ROLE_PAGES = new HashMap<>();
    static {
        java.util.Set<String> superAdmin = new java.util.HashSet<>(java.util.Arrays.asList(
                "dashboard", "users", "battles", "tournaments", "esports", "category", "teams", "matches",
                "results", "disputes", "reports", "faq", "notice", "analytics", "activity", "settings", "roles",
                "payments", "terms", "privacy", "about"));
        java.util.Set<String> manager = new java.util.HashSet<>(java.util.Arrays.asList(
                "dashboard", "battles", "tournaments", "esports", "category", "teams", "matches", "results", "activity"));
        java.util.Set<String> support = new java.util.HashSet<>(java.util.Arrays.asList(
                "dashboard", "faq", "notice", "battles", "tournaments", "terms", "privacy", "about"));
        // RESULTS_COINS_ADMIN keys land here (dashboardRole() maps that canonical role to
        // "MODERATOR" for this legacy permission table). A Results & Coins admin's whole job
        // is approving coin top-up requests and posting match results, so without "payments"
        // and "results" here, that entire role saw "permission denied" on the two sections it
        // exists for — moderation (reports/disputes/users) was never the fit for this key.
        java.util.Set<String> moderator = new java.util.HashSet<>(java.util.Arrays.asList(
                "dashboard", "reports", "disputes", "users", "activity", "payments", "results"));
        // A25 — split-key roles: a PAYMENT_ADMIN key only ever unlocks the Payments workspace,
        // a MATCH_ADMIN key only ever unlocks match/tournament workspaces. Neither role sees the
        // other's nav rows at all (see applyRolePermissions), so a payment key can't touch matches
        // and a match key can't touch payments.
        java.util.Set<String> paymentAdmin = new java.util.HashSet<>(java.util.Arrays.asList(
                "dashboard", "payments"));
        java.util.Set<String> matchAdmin = new java.util.HashSet<>(java.util.Arrays.asList(
                "dashboard", "battles", "tournaments", "esports", "category", "teams", "matches", "results"));
        ROLE_PAGES.put("SUPER_ADMIN", superAdmin);
        ROLE_PAGES.put("TOURNAMENT_MANAGER", manager);
        ROLE_PAGES.put("SUPPORT_AGENT", support);
        ROLE_PAGES.put("MODERATOR", moderator);
        ROLE_PAGES.put("PAYMENT_ADMIN", paymentAdmin);
        ROLE_PAGES.put("MATCH_ADMIN", matchAdmin);
    }

    /** A1 RBAC — the Dashboard's quick actions (Add Category, New Battle, Send Notice, the home
     *  banners/profile settings and the tournament list) are match-control tools and
     *  used to render unconditionally for EVERY role, regardless of ROLE_PAGES above. That meant a
     *  Customer Support or Results & Coins key landed on a screen with full Add Category/Add Match
     *  controls even though their nav rows correctly hid those workspace pages. Only the owner and
     *  the two match-operations roles get those Dashboard widgets now; every other role sees the
     *  bare welcome card and works entirely from their own role-gated nav pages instead. */
    private static final java.util.Set<String> DASHBOARD_MATCH_CONTROL_ROLES = new java.util.HashSet<>(
            java.util.Arrays.asList("SUPER_ADMIN", "TOURNAMENT_MANAGER", "MATCH_ADMIN"));

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin);
        String roleExtra = getIntent().getStringExtra("adminRole");
        if (AdminRoles.isWorkRole(roleExtra)) {
            adminRole = WORK_KEY;
            java.util.ArrayList<String> grantedPerms = getIntent().getStringArrayListExtra("adminPerms");
            if (grantedPerms != null) adminPerms.addAll(grantedPerms);
        } else if (roleExtra != null && ROLE_PAGES.containsKey(roleExtra)) {
            adminRole = roleExtra;
        } else if (roleExtra != null) {
            // Defensive: an unrecognized role string must never fall through to full access.
            FancyText.toast(this, "Unrecognized admin role \"" + roleExtra + "\" — showing minimum access.", Toast.LENGTH_LONG).show();
        }
        dashboardScroll = findViewById(R.id.admin_dashboard_scroll);
        workspaceScroll = findViewById(R.id.admin_workspace_scroll);
        workspaceContent = findViewById(R.id.admin_workspace_content);
        workspaceRefreshLayout = findViewById(R.id.admin_workspace_refresh);
        headerActions = findViewById(R.id.admin_header_actions);
        // BACK FIX: system back on an open workspace page returns to the dashboard instead of
        // tearing the whole activity down; from the dashboard it closes normally.
        getOnBackPressedDispatcher().addCallback(this, new androidx.activity.OnBackPressedCallback(true) {
            @Override public void handleOnBackPressed() {
                if (workspaceScroll != null && workspaceScroll.getVisibility() == View.VISIBLE) {
                    showDashboard();
                } else {
                    setEnabled(false);
                    getOnBackPressedDispatcher().onBackPressed();
                }
            }
        });
        bellWrap = findViewById(R.id.admin_bell_wrap);
        bellBadge = findViewById(R.id.admin_bell_badge);
        setupResponsiveDesktopLayout();
        setupNavigation();
        applyRolePermissions();
        applyDashboardRolePermissions();
        populateHomeStats();
        populateHomeActions();
        populateWorkspaceShortcuts();
        setupBottomNavigation();
        setupPullToRefresh();
        setupCoinBell();
        setupHeaderSearch();
        String openWorkspaceExtra = getIntent().getStringExtra("openWorkspace");
        if (openWorkspaceExtra != null) showWorkspacePage(openWorkspaceExtra);

        RecyclerView list = findViewById(R.id.admin_tournament_list);
        list.setLayoutManager(new LinearLayoutManager(this));
        adapter = new RecyclerView.Adapter<AdminMatchHolder>() {
            @NonNull
            @Override public AdminMatchHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
                return createHomeMatchRow(parent);
            }
            @Override public void onBindViewHolder(@NonNull AdminMatchHolder holder, int position) {
                Tournament match = recentMatches.get(position);
                holder.title.setText(match.getTitle());
                holder.detail.setText(match.getMatchType() + "  •  " + match.getDate() + "  •  " + match.getTime());
                String status = match.getEffectiveStatus();
                holder.status.setText(status);
                int tint = Tournament.ONGOING.equals(status) ? R.color.admin_green
                        : Tournament.COMPLETED.equals(status) ? R.color.text_secondary : R.color.admin_blue;
                holder.status.setTextColor(getColor(tint));
                holder.itemView.setOnClickListener(v -> showTournamentActions(match));
                String imageUrl = match.getBannerUrl();
                ImageLoader.load(holder.image, imageUrl);
            }
            @Override public int getItemCount() { return recentMatches.size(); }
        };
        list.setAdapter(adapter);

        RecyclerView categoryList = findViewById(R.id.admin_game_mode_list);
        categoryList.setLayoutManager(new GridLayoutManager(this, 2));
        GameModeAdapter categoryAdapter = new GameModeAdapter(gameModes, true, this::confirmDeleteGameMode,
                this::showCategoryMatches);
        categoryAdapter.setOnEditClick(this::openEditCategoryPage);
        categoryList.setAdapter(categoryAdapter);

        RecyclerView bannerList = findViewById(R.id.admin_banner_list);
        bannerList.setLayoutManager(new LinearLayoutManager(this));
        bannerList.setAdapter(new BannerAdapter(banners, true, this::confirmDeleteBanner));

        RecyclerView homeBannerList = findViewById(R.id.admin_home_banner_list);
        homeBannerList.setLayoutManager(new LinearLayoutManager(this, RecyclerView.HORIZONTAL, false));
        homeBannerAdapter = new BannerAdapter(homeBanners, true, this::confirmDeleteBanner);
        homeBannerList.setAdapter(homeBannerAdapter);

        findViewById(R.id.admin_back).setOnClickListener(v -> openAdminMore());
        findViewById(R.id.admin_add_tournament).setOnClickListener(v -> showAddTournamentDialog("", ""));
        if (!canCreateMatch()) findViewById(R.id.admin_add_tournament).setVisibility(View.GONE);
        findViewById(R.id.admin_add_category).setOnClickListener(v -> openAddCategoryPage());
        findViewById(R.id.admin_add_banner).setOnClickListener(v -> showAddBannerDialog());
        findViewById(R.id.admin_send_notice).setOnClickListener(v -> publishNotice());
        findViewById(R.id.admin_home_notice_publish).setOnClickListener(v -> publishHomeNotice());
        findViewById(R.id.admin_profile_publish).setOnClickListener(v -> saveProfileControls());
        findViewById(R.id.admin_open_app_control).setOnClickListener(v -> startActivity(new Intent(this, AdminAppControlActivity.class)));
        findViewById(R.id.admin_home_manage_banners).setOnClickListener(v -> {
            if (hasPerm("banners")) {
                dashboardScroll.smoothScrollTo(0, findViewById(R.id.admin_banner_header_row).getTop());
            } else {
                FancyText.toast(this, "Banner controls are available to the owner admin.", Toast.LENGTH_SHORT).show();
            }
        });
        findViewById(R.id.admin_home_matches_view_all).setOnClickListener(v -> showWorkspacePage(matchesPageForRole()));

        // Admin Panel hub: open the tapped work's page right away.
        String openPage = getIntent().getStringExtra("openPage");
        if (openPage != null && !"dashboard".equals(openPage)) showWorkspacePage(openPage);

    }

    /** Hides every nav row the signed-in admin's role isn't allowed to open. Read-only "battles/tournaments"
     *  access for Support Agent is enforced by keeping create/delete actions role-gated where those live too. */
    private void applyRolePermissions() {
        java.util.Set<String> allowed = rolePages();
        Map<Integer, String> idToPage = new HashMap<>();
        idToPage.put(R.id.admin_nav_users, "users");
        idToPage.put(R.id.admin_nav_battles, "battles");
        idToPage.put(R.id.admin_nav_tournaments, "tournaments");
        idToPage.put(R.id.admin_nav_esports, "esports");
        idToPage.put(R.id.admin_nav_category, "category");
        idToPage.put(R.id.admin_nav_teams, "teams");
        idToPage.put(R.id.admin_nav_matches, "matches");
        idToPage.put(R.id.admin_nav_payments, "payments");
        idToPage.put(R.id.admin_nav_results, "results");
        idToPage.put(R.id.admin_nav_disputes, "disputes");
        idToPage.put(R.id.admin_nav_reports, "reports");
        idToPage.put(R.id.admin_nav_faq, "faq");
        idToPage.put(R.id.admin_nav_notice, "notice");
        idToPage.put(R.id.admin_nav_analytics, "analytics");
        idToPage.put(R.id.admin_nav_activity, "activity");
        idToPage.put(R.id.admin_nav_settings, "settings");
        for (Map.Entry<Integer, String> entry : idToPage.entrySet()) {
            View row = findViewById(entry.getKey());
            if (row != null) row.setVisibility(allowed.contains(entry.getValue()) ? View.VISIBLE : View.GONE);
        }
        View rolesRow = findViewById(R.id.admin_nav_roles);
        if (rolesRow != null) rolesRow.setVisibility("SUPER_ADMIN".equals(adminRole) ? View.VISIBLE : View.GONE);
    }

    /** A1 RBAC — gates the Dashboard's own widgets (see DASHBOARD_MATCH_CONTROL_ROLES above), the
     *  same way applyRolePermissions() already gates the sidebar. A Match Operations / Match Admin
     *  key sees Add Category, New Battle, the tournament list and the notification (Send Notice /
     *  Home notice) controls — nothing else. Home Banners and the Profile settings stay
     *  owner-only. Every other role (Customer Support, Results & Coins, Payments) sees none of it. */
    private void applyDashboardRolePermissions() {
        boolean legacyMatch = DASHBOARD_MATCH_CONTROL_ROLES.contains(adminRole);
        boolean matchControl = legacyMatch || hasPerm("categories") || hasPerm("matches");
        boolean noticeControl = legacyMatch || hasPerm("notice");
        boolean owner = "SUPER_ADMIN".equals(adminRole);
        boolean bannerControl = hasPerm("banners");
        boolean platformControl = hasPerm("platform_links");

        setDashboardViewVisible(R.id.admin_quick_actions_row, false);
        setDashboardViewVisible(R.id.admin_category_header_row, matchControl);
        setDashboardViewVisible(R.id.admin_game_mode_list, matchControl);
        // Recent Matches is intentionally not shown on the admin home dashboard.
        setDashboardViewVisible(R.id.admin_tournaments_header, false);
        setDashboardViewVisible(R.id.admin_tournament_list, false);
        setDashboardViewVisible(R.id.admin_notice_controls_group, noticeControl);

        setDashboardViewVisible(R.id.admin_banner_header_row, bannerControl);
        setDashboardViewVisible(R.id.admin_banner_list, bannerControl);
        setDashboardViewVisible(R.id.admin_home_manage_banners, bannerControl);
        setDashboardViewVisible(R.id.admin_profile_controls_group, platformControl);

        boolean anyPlatformControl = legacyMatch || owner || platformControl || hasPerm("profile_text");
        setDashboardViewVisible(R.id.admin_platform_controls_header, anyPlatformControl);
        setDashboardViewVisible(R.id.admin_platform_controls_card, anyPlatformControl);
        View recentMatchesHeader = findViewById(R.id.admin_tournaments_header);
        if (recentMatchesHeader != null) recentMatchesHeader.setVisibility(View.GONE);
        View recentMatchesLink = findViewById(R.id.admin_home_matches_view_all);
        if (recentMatchesLink != null) recentMatchesLink.setVisibility(View.GONE);
    }

    /**
     * On tablets, Chromebooks and desktop-sized Android windows, replace the
     * horizontally scrolling mobile nav strip with a persistent vertical menu.
     * Every page allowed for the signed-in role stays directly visible without
     * opening search. Compact phones keep the existing mobile navigation.
     */
    private void setupResponsiveDesktopLayout() {
        if (getResources().getConfiguration().screenWidthDp < 720) return;

        ViewGroup contentRoot = findViewById(android.R.id.content);
        if (contentRoot == null || contentRoot.getChildCount() == 0) return;
        View rootView = contentRoot.getChildAt(0);
        if (!(rootView instanceof LinearLayout)) return;
        LinearLayout root = (LinearLayout) rootView;
        if (root.getChildCount() < 4
                || !(root.getChildAt(1) instanceof android.widget.HorizontalScrollView)) return;

        android.widget.HorizontalScrollView mobileNav =
                (android.widget.HorizontalScrollView) root.getChildAt(1);
        if (mobileNav.getChildCount() == 0 || !(mobileNav.getChildAt(0) instanceof LinearLayout)) return;
        LinearLayout navItems = (LinearLayout) mobileNav.getChildAt(0);
        View divider = root.getChildAt(2);
        View pageArea = root.getChildAt(3);

        mobileNav.removeView(navItems);
        root.removeView(mobileNav);
        root.removeView(divider);
        root.removeView(pageArea);

        navItems.setOrientation(LinearLayout.VERTICAL);
        navItems.setPadding(dp(10), dp(4), dp(10), dp(12));
        for (int i = 0; i < navItems.getChildCount(); i++) {
            View item = navItems.getChildAt(i);
            if (item instanceof TextView) {
                ((TextView) item).setGravity(Gravity.CENTER_VERTICAL | Gravity.START);
            }
            item.setPadding(dp(14), 0, dp(10), 0);
            LinearLayout.LayoutParams itemParams = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, dp(32));
            itemParams.bottomMargin = dp(2);
            item.setLayoutParams(itemParams);
        }

        LinearLayout sidebar = new LinearLayout(this);
        sidebar.setOrientation(LinearLayout.VERTICAL);
        sidebar.setBackgroundColor(getColor(R.color.surface));

        TextView menuHeading = new TextView(this);
        menuHeading.setText("ADMIN MENU");
        menuHeading.setTextColor(getColor(R.color.blood_red_bright));
        menuHeading.setTextSize(11);
        menuHeading.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        menuHeading.setLetterSpacing(0.08f);
        menuHeading.setGravity(Gravity.CENTER_VERTICAL);
        menuHeading.setPadding(dp(16), 0, dp(12), 0);
        sidebar.addView(menuHeading, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(44)));

        View menuDivider = new View(this);
        menuDivider.setBackgroundColor(getColor(R.color.stroke));
        sidebar.addView(menuDivider, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(1)));

        android.widget.ScrollView menuScroll = new android.widget.ScrollView(this);
        menuScroll.setFillViewport(false);
        menuScroll.setVerticalScrollBarEnabled(true);
        menuScroll.addView(navItems, new android.widget.ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        sidebar.addView(menuScroll, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        LinearLayout desktopRow = new LinearLayout(this);
        desktopRow.setOrientation(LinearLayout.HORIZONTAL);
        desktopRow.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        desktopRow.addView(sidebar, new LinearLayout.LayoutParams(dp(208),
                ViewGroup.LayoutParams.MATCH_PARENT));

        View verticalDivider = new View(this);
        verticalDivider.setBackgroundColor(getColor(R.color.stroke));
        desktopRow.addView(verticalDivider, new LinearLayout.LayoutParams(dp(1),
                ViewGroup.LayoutParams.MATCH_PARENT));
        desktopRow.addView(pageArea, new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.MATCH_PARENT, 1f));
        View bottomNav = findViewById(R.id.admin_bottom_nav);
        if (bottomNav != null) {
            root.removeView(bottomNav);
            bottomNav.setVisibility(View.GONE);
        }
        root.addView(desktopRow, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
    }

    private void setDashboardViewVisible(int viewId, boolean visible) {
        View view = findViewById(viewId);
        if (view != null) view.setVisibility(visible ? View.VISIBLE : View.GONE);
    }

    /** Builds the editable-content cards (FAQ, Terms, Privacy, About Us) for roles allowed to use them. */
    private void populateWorkspaceShortcuts() {
        android.widget.GridLayout grid = findViewById(R.id.admin_workspace_shortcut_grid);
        if (grid == null) return;
        grid.removeAllViews();
        int widthDp = getResources().getConfiguration().screenWidthDp;
        int columns = widthDp >= 1200 ? 4 : (widthDp >= 600 ? 3 : 2);
        grid.setColumnCount(columns);

        // Colourful cards = the editable "Profile" pages of the user app. Tap a card to edit
        // its text; everything else is reachable from the bottom navigation / More page.
        String[] pages = {"faq", "terms", "privacy", "about"};
        String[] labels = {"FAQ", "Terms & Conditions", "Privacy Policy", "About Us"};
        java.util.Set<String> allowed = rolePages();
        for (int i = 0; i < pages.length; i++) {
            final String page = pages[i];
            boolean canOpen = "bannerlinks".equals(page) ? hasPerm("banners") : allowed.contains(page);
            if (!canOpen || ("roles".equals(page) && !"SUPER_ADMIN".equals(adminRole))) continue;

            LinearLayout shortcut = new LinearLayout(this);
            shortcut.setOrientation(LinearLayout.VERTICAL);
            shortcut.setGravity(Gravity.CENTER_VERTICAL);
            shortcut.setPadding(dp(12), dp(8), dp(8), dp(8));
            int[] fills = {0xFFE8F1FF, 0xFFF1EAFF, 0xFFE8FAF2, 0xFFFFF2DD, 0xFFFFE9EE, 0xFFE7F8FA};
            int fill = fills[i % fills.length];
            android.graphics.drawable.GradientDrawable cardBg = new android.graphics.drawable.GradientDrawable();
            cardBg.setColor(fill); cardBg.setCornerRadius(dp(4));
            cardBg.setStroke(dp(1), 0xFFD9E0E8); shortcut.setBackground(cardBg);
            ImageView icon = new ImageView(this);
            icon.setImageResource(workspaceIcon(page));
            icon.setColorFilter(0xFF203B62, android.graphics.PorterDuff.Mode.SRC_IN);
            android.graphics.drawable.GradientDrawable iconBg = new android.graphics.drawable.GradientDrawable();
            iconBg.setColor(0xFFFFFFFF); iconBg.setShape(android.graphics.drawable.GradientDrawable.OVAL);
            icon.setBackground(iconBg); icon.setPadding(dp(7), dp(7), dp(7), dp(7));
            shortcut.addView(icon, new LinearLayout.LayoutParams(dp(30), dp(30)));
            TextView label = new TextView(this);
            label.setText(labels[i]); label.setTextColor(getColor(R.color.text_primary)); label.setTextSize(11.5f);
            label.setTypeface(Typeface.DEFAULT, Typeface.BOLD); label.setSingleLine(true);
            label.setEllipsize(android.text.TextUtils.TruncateAt.END);
            LinearLayout.LayoutParams labelParams = new LinearLayout.LayoutParams(-1, -2); labelParams.topMargin = dp(5);
            shortcut.addView(label, labelParams);
            shortcut.setOnClickListener(v -> showWorkspacePage(page));
            android.widget.GridLayout.LayoutParams params = new android.widget.GridLayout.LayoutParams(
                    android.widget.GridLayout.spec(android.widget.GridLayout.UNDEFINED, 1f),
                    android.widget.GridLayout.spec(android.widget.GridLayout.UNDEFINED, 1f));
            params.width = 0; params.height = dp(78); params.setMargins(dp(4), dp(4), dp(4), dp(4));
            grid.addView(shortcut, params);
        }
    }

    private int workspaceIcon(String page) {
        if ("users".equals(page)) return android.R.drawable.ic_menu_myplaces;
        if ("battles".equals(page) || "matches".equals(page)) return android.R.drawable.ic_menu_compass;
        if ("tournaments".equals(page) || "esports".equals(page)) return android.R.drawable.ic_menu_gallery;
        if ("category".equals(page) || "teams".equals(page)) return android.R.drawable.ic_menu_manage;
        if ("payments".equals(page)) return android.R.drawable.ic_menu_save;
        if ("results".equals(page) || "analytics".equals(page)) return android.R.drawable.ic_menu_sort_by_size;
        if ("disputes".equals(page) || "reports".equals(page)) return android.R.drawable.ic_menu_report_image;
        if ("faq".equals(page) || "notice".equals(page) || "about".equals(page)) return android.R.drawable.ic_menu_info_details;
        if ("terms".equals(page) || "privacy".equals(page)) return android.R.drawable.ic_menu_agenda;
        if ("activity".equals(page)) return android.R.drawable.ic_menu_recent_history;
        if ("roles".equals(page)) return android.R.drawable.ic_menu_myplaces;
        return android.R.drawable.ic_menu_preferences;
    }

    private void populateHomeStats() {
        android.widget.GridLayout grid = findViewById(R.id.admin_home_stats_grid);
        if (grid == null) return;
        int widthDp = getResources().getConfiguration().screenWidthDp;
        grid.setColumnCount(widthDp >= 400 ? 4 : 2);
        java.util.Set<String> allowed = rolePages();
        if (allowed.contains("users")) {
            addHomeStat(grid, "users", "TOTAL USERS", R.drawable.ic_profile, R.color.admin_blue, R.color.admin_blue_tint);
        }
        if (allowed.contains("payments")) {
            addHomeStat(grid, "pending_deposits", "PENDING DEPOSITS", R.drawable.ic_wallet_outline,
                    R.color.admin_red, R.color.admin_red_tint);
            addHomeStat(grid, "pending_withdrawals", "PENDING WITHDRAWALS", R.drawable.ic_withdraw,
                    R.color.admin_orange, R.color.admin_orange_tint);
        }
        if (allowed.contains("category") || allowed.contains("esports")) {
            addHomeStat(grid, "categories", "CATEGORIES", R.drawable.ic_gamepad,
                    R.color.admin_blue, R.color.admin_blue_tint);
        }
        if (hasPerm("banners")) {
            addHomeStat(grid, "banners", "ACTIVE BANNERS", R.drawable.ic_rewards,
                    R.color.admin_purple, R.color.admin_purple_tint);
        }
    }

    private void addHomeStat(android.widget.GridLayout grid, String key, String label, int iconRes,
                             int iconTintRes, int iconBoxRes) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setBackgroundResource(R.drawable.bg_admin_stat_card);
        card.setPadding(dp(10), dp(9), dp(8), dp(8));

        ImageView icon = new ImageView(this);
        icon.setImageResource(iconRes);
        icon.setImageTintList(android.content.res.ColorStateList.valueOf(getColor(iconTintRes)));
        icon.setBackgroundTintList(android.content.res.ColorStateList.valueOf(getColor(iconBoxRes)));
        icon.setBackgroundResource(R.drawable.bg_admin_stat_icon_ring);
        icon.setPadding(dp(6), dp(6), dp(6), dp(6));
        LinearLayout.LayoutParams iconParams = new LinearLayout.LayoutParams(dp(30), dp(30));
        card.addView(icon, iconParams);

        TextView title = new TextView(this);
        title.setText(label);
        title.setTextColor(getColor(R.color.text_secondary));
        title.setTextSize(9);
        title.setSingleLine(true);
        title.setEllipsize(android.text.TextUtils.TruncateAt.END);
        LinearLayout.LayoutParams titleParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        titleParams.topMargin = dp(7);
        card.addView(title, titleParams);

        TextView value = new TextView(this);
        value.setText("—");
        value.setTextColor(getColor(R.color.text_primary));
        value.setTextSize(14);
        value.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        LinearLayout.LayoutParams valueParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        valueParams.topMargin = dp(3);
        card.addView(value, valueParams);
        homeStatValues.put(key, value);

        android.widget.GridLayout.LayoutParams params = new android.widget.GridLayout.LayoutParams(
                android.widget.GridLayout.spec(android.widget.GridLayout.UNDEFINED, 1f),
                android.widget.GridLayout.spec(android.widget.GridLayout.UNDEFINED, 1f));
        params.width = 0;
        params.height = dp(88);
        params.setMargins(dp(3), dp(3), dp(3), dp(3));
        grid.addView(card, params);
    }

    private void setHomeStat(String key, String value) {
        TextView view = homeStatValues.get(key);
        if (view != null) view.setText(value == null ? "—" : value);
    }

    private void populateHomeActions() {
        android.widget.GridLayout grid = findViewById(R.id.admin_home_actions_grid);
        if (grid == null) return;
        int widthDp = getResources().getConfiguration().screenWidthDp;
        grid.setColumnCount(widthDp >= 400 ? 4 : 2);
        java.util.Set<String> allowed = rolePages();

        if (hasPerm("banners")) {
            addHomeAction(grid, "Add Banner", R.drawable.ic_rewards, R.color.admin_purple,
                    R.color.admin_purple_tint, this::showAddBannerDialog);
        }
        boolean legacyMatchActions = DASHBOARD_MATCH_CONTROL_ROLES.contains(adminRole);
        if (legacyMatchActions || hasPerm("categories")) {
            addHomeAction(grid, "Add Category", R.drawable.ic_gamepad, R.color.admin_blue,
                    R.color.admin_blue_tint, this::openAddCategoryPage);
        }
        if (canCreateMatch()) {
            addHomeAction(grid, "Add Match", R.drawable.ic_bolt, R.color.admin_green,
                    R.color.admin_green_tint, () -> showAddTournamentDialog("", ""));
        }
        if (canCreateMatch() || legacyMatchActions || hasPerm("categories") || hasPerm("match_detail")) {
            addHomeAction(grid, "Search Match", R.drawable.ic_bolt, R.color.admin_orange,
                    R.color.admin_orange_tint, () -> startActivity(new Intent(this, MatchSearchActivity.class)));
        }
        if (allowed.contains("users")) {
            addHomeAction(grid, "Manage Users", R.drawable.ic_profile, R.color.admin_blue,
                    R.color.admin_blue_tint, () -> showWorkspacePage("users"));
        }
        if (allowed.contains("payments")) {
            addHomeAction(grid, "Payments", R.drawable.ic_wallet_outline, R.color.admin_red,
                    R.color.admin_red_tint, () -> showWorkspacePage("payments"));
        }
        if (allowed.contains("results")) {
            addHomeAction(grid, "Post Results", R.drawable.ic_trophy, R.color.admin_orange,
                    R.color.admin_orange_tint, () -> showWorkspacePage("results"));
        }
        if (allowed.contains("notice")) {
            addHomeAction(grid, "Notices", R.drawable.ic_megaphone, R.color.admin_purple,
                    R.color.admin_purple_tint, () -> showWorkspacePage("notice"));
        } else if (DASHBOARD_MATCH_CONTROL_ROLES.contains(adminRole) || hasPerm("notice")) {
            addHomeAction(grid, "Send Notice", R.drawable.ic_megaphone, R.color.admin_purple,
                    R.color.admin_purple_tint, this::publishNotice);
        }
        addHomeAction(grid, "More", R.drawable.ic_menu_dots_gold, R.color.text_primary,
                R.color.surface_2, this::openAdminMore);
    }

    private void addHomeAction(android.widget.GridLayout grid, String label, int iconRes,
                               int iconTintRes, int iconBoxRes, Runnable action) {
        LinearLayout tile = new LinearLayout(this);
        tile.setOrientation(LinearLayout.VERTICAL);
        tile.setGravity(Gravity.CENTER);
        tile.setBackgroundResource(R.drawable.bg_admin_stat_card);
        tile.setPadding(dp(4), dp(6), dp(4), dp(6));
        tile.setClickable(true);
        tile.setFocusable(true);
        tile.setOnClickListener(v -> action.run());

        ImageView icon = new ImageView(this);
        icon.setImageResource(iconRes);
        icon.setImageTintList(android.content.res.ColorStateList.valueOf(getColor(iconTintRes)));
        icon.setBackgroundTintList(android.content.res.ColorStateList.valueOf(getColor(iconBoxRes)));
        icon.setBackgroundResource(R.drawable.bg_admin_stat_icon_ring);
        icon.setPadding(dp(6), dp(6), dp(6), dp(6));
        tile.addView(icon, new LinearLayout.LayoutParams(dp(30), dp(30)));

        TextView text = new TextView(this);
        text.setText(label);
        text.setTextColor(getColor(R.color.text_primary));
        text.setTextSize(9);
        text.setGravity(Gravity.CENTER);
        text.setMaxLines(2);
        LinearLayout.LayoutParams textParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        textParams.topMargin = dp(4);
        tile.addView(text, textParams);

        android.widget.GridLayout.LayoutParams params = new android.widget.GridLayout.LayoutParams(
                android.widget.GridLayout.spec(android.widget.GridLayout.UNDEFINED, 1f),
                android.widget.GridLayout.spec(android.widget.GridLayout.UNDEFINED, 1f));
        params.width = 0;
        params.height = dp(74);
        params.setMargins(dp(3), dp(3), dp(3), dp(3));
        grid.addView(tile, params);
    }

    private void setupBottomNavigation() {
        LinearLayout nav = findViewById(R.id.admin_bottom_nav);
        if (nav == null || getResources().getConfiguration().screenWidthDp >= 720) return;
        nav.removeAllViews();
        addBottomTab(nav, "Home", R.drawable.ic_home, true, this::showDashboard);
        if (hasPerm("banners")) {
            addBottomTab(nav, "Banners", R.drawable.ic_rewards, true, () ->
                    dashboardScroll.smoothScrollTo(0, findViewById(R.id.admin_banner_header_row).getTop()));
        }
        java.util.Set<String> allowed = rolePages();
        if (allowed.contains("category")) addBottomTab(nav, "Categories", R.drawable.ic_gamepad, true,
                () -> showWorkspacePage("category"));
        if (allowed.contains("users")) addBottomTab(nav, "Users", R.drawable.ic_profile, true,
                () -> showWorkspacePage("users"));
        if (allowed.contains("payments")) addBottomTab(nav, "Payments", R.drawable.ic_wallet_outline, true,
                () -> showWorkspacePage("payments"));
        addBottomTab(nav, "More", R.drawable.ic_menu_dots_gold, false, this::openAdminMore);
    }

    private void addBottomTab(LinearLayout nav, String label, int iconRes, boolean enabled,
                              Runnable action) {
        LinearLayout tab = new LinearLayout(this);
        tab.setGravity(Gravity.CENTER);
        tab.setOrientation(LinearLayout.VERTICAL);
        tab.setClickable(true);
        tab.setFocusable(true);
        tab.setOnClickListener(v -> action.run());
        ImageView icon = new ImageView(this);
        icon.setImageResource(iconRes);
        icon.setImageTintList(android.content.res.ColorStateList.valueOf(
                getColor(enabled ? R.color.admin_blue : R.color.text_secondary)));
        tab.addView(icon, new LinearLayout.LayoutParams(dp(18), dp(18)));
        TextView title = new TextView(this);
        title.setText(label);
        title.setTextColor(getColor(enabled ? R.color.text_primary : R.color.text_secondary));
        title.setTextSize(8);
        LinearLayout.LayoutParams titleParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        titleParams.topMargin = dp(3);
        tab.addView(title, titleParams);
        nav.addView(tab, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f));
    }

    private AdminMatchHolder createHomeMatchRow(ViewGroup parent) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setBackgroundResource(R.drawable.bg_admin_stat_card);
        row.setPadding(dp(8), dp(8), dp(10), dp(8));
        RecyclerView.LayoutParams rowParams = new RecyclerView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        rowParams.bottomMargin = dp(7);
        row.setLayoutParams(rowParams);

        ImageView image = new ImageView(this);
        image.setScaleType(ImageView.ScaleType.CENTER_CROP);
        image.setBackgroundResource(R.drawable.bg_admin_stat_icon_ring);
        image.setPadding(dp(2), dp(2), dp(2), dp(2));
        row.addView(image, new LinearLayout.LayoutParams(dp(54), dp(54)));

        LinearLayout details = new LinearLayout(this);
        details.setOrientation(LinearLayout.VERTICAL);
        details.setPadding(dp(10), 0, dp(4), 0);
        LinearLayout.LayoutParams detailsParams = new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        row.addView(details, detailsParams);

        TextView title = new TextView(this);
        title.setTextColor(getColor(R.color.text_primary));
        title.setTextSize(12);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        title.setMaxLines(1);
        title.setEllipsize(android.text.TextUtils.TruncateAt.END);
        details.addView(title);

        TextView detail = new TextView(this);
        detail.setTextColor(getColor(R.color.text_secondary));
        detail.setTextSize(9);
        detail.setMaxLines(1);
        detail.setEllipsize(android.text.TextUtils.TruncateAt.END);
        LinearLayout.LayoutParams detailParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        detailParams.topMargin = dp(5);
        details.addView(detail, detailParams);

        TextView status = new TextView(this);
        status.setTextSize(9);
        status.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        status.setPadding(dp(8), dp(5), dp(8), dp(5));
        status.setBackgroundResource(R.drawable.bg_admin_stat_icon_ring);
        row.addView(status, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView chevron = new TextView(this);
        chevron.setText("›");
        chevron.setTextSize(23);
        chevron.setTextColor(getColor(R.color.text_secondary));
        LinearLayout.LayoutParams chevronParams = new LinearLayout.LayoutParams(dp(20),
                ViewGroup.LayoutParams.WRAP_CONTENT);
        chevronParams.gravity = Gravity.CENTER_VERTICAL;
        row.addView(chevron, chevronParams);

        return new AdminMatchHolder(row, image, title, detail, status);
    }

    private static class AdminMatchHolder extends RecyclerView.ViewHolder {
        final ImageView image;
        final TextView title;
        final TextView detail;
        final TextView status;
        AdminMatchHolder(View row, ImageView image, TextView title, TextView detail, TextView status) {
            super(row);
            this.image = image;
            this.title = title;
            this.detail = detail;
            this.status = status;
        }
    }

    private void showDashboard() {
        resetWorkspaceChrome(null);
        workspaceScroll.setVisibility(View.GONE);
        dashboardScroll.setVisibility(View.VISIBLE);
    }

    // ================================================================ Page chrome: pull-to-refresh, header actions, bell

    /** Called every time a workspace page is (re)drawn: remembers how to refresh it and clears the
     *  previous page's top-bar actions so they never leak onto the next screen. */
    private void resetWorkspaceChrome(Runnable refresh) {
        detachCoinEditListener();
        workspaceRefresh = refresh;
        clearHeaderActions();
    }

    private void clearHeaderActions() {
        if (headerActions != null) headerActions.removeAllViews();
    }

    /** Pull down from the top of any admin page to reload it - no refresh button needed. */
    private void setupPullToRefresh() {
        if (workspaceRefreshLayout == null) return;
        workspaceRefreshLayout.setOnRefreshListener(() -> {
            Runnable refresh = workspaceRefresh;
            if (refresh != null) refresh.run();
            // Firebase loads are async and have no completion hook, so close the spinner shortly after.
            uiHandler.postDelayed(() -> workspaceRefreshLayout.setRefreshing(false), 900);
        });
    }

    /** One icon button in the top bar (right side, left of the bell). */
    private void addHeaderAction(int iconRes, String description, View.OnClickListener listener) {
        if (headerActions == null) return;
        ImageView icon = new ImageView(this);
        icon.setImageResource(iconRes);
        icon.setImageTintList(android.content.res.ColorStateList.valueOf(getColor(R.color.text_primary)));
        icon.setBackgroundResource(R.drawable.bg_admin_nav_item);
        icon.setPadding(dp(7), dp(7), dp(7), dp(7));
        icon.setContentDescription(description);
        icon.setOnClickListener(listener);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(36), dp(36));
        lp.setMarginStart(dp(6));
        headerActions.addView(icon, lp);
    }

    /** "＋" in the top bar: create something on the current page. */
    private void addHeaderPlus(String description, Runnable action) {
        addHeaderAction(R.drawable.ic_admin_plus, description, v -> action.run());
    }

    /** "⋮" in the top bar: a small popup menu when a page has several secondary actions. */
    private void addHeaderMenu(String[] labels, Runnable[] actions) {
        addHeaderAction(R.drawable.ic_admin_more, "More actions", anchor -> {
            android.widget.PopupMenu menu = new android.widget.PopupMenu(this, anchor);
            for (int i = 0; i < labels.length; i++) menu.getMenu().add(0, i, i, labels[i]);
            menu.setOnMenuItemClickListener(item -> {
                actions[item.getItemId()].run();
                return true;
            });
            menu.show();
        });
    }

    /** Search icon in the top bar: opens the full-screen match search (all matches listed). */
    private void setupHeaderSearch() {
        View wrap = findViewById(R.id.admin_search_wrap);
        if (wrap == null) return;
        boolean allowedToSearch = canCreateMatch() || DASHBOARD_MATCH_CONTROL_ROLES.contains(adminRole)
                || hasPerm("categories") || hasPerm("match_detail");
        wrap.setVisibility(View.VISIBLE);   // global search: every admin function, match and category
        wrap.setOnClickListener(v -> openGlobalSearch());
    }

    private final androidx.activity.result.ActivityResultLauncher<Intent> globalSearchLauncher =
            registerForActivityResult(new androidx.activity.result.contract.ActivityResultContracts.StartActivityForResult(), result -> {
                if (result.getResultCode() != RESULT_OK || result.getData() == null) return;
                String action = result.getData().getStringExtra(GlobalSearchActivity.EXTRA_ACTION);
                if (action != null) runSearchAction(action);
            });

    private void openGlobalSearch() {
        java.util.Set<String> keys = new java.util.HashSet<>(rolePages());
        if (hasPerm("banners")) { keys.add("banners"); keys.add("bannerlinks"); }
        if (hasPerm("categories") || canCreateMatch() || "SUPER_ADMIN".equals(adminRole)) keys.add("categories");
        if (!"SUPER_ADMIN".equals(adminRole)) keys.remove("roles");
        keys.remove("dashboard");
        Intent i = new Intent(this, GlobalSearchActivity.class);
        i.putExtra(GlobalSearchActivity.EXTRA_MODE, GlobalSearchActivity.MODE_ADMIN);
        i.putExtra(GlobalSearchActivity.EXTRA_ALLOWED, keys.toArray(new String[0]));
        globalSearchLauncher.launch(i);
    }

    private void runSearchAction(String action) {
        switch (action) {
            case "act_banners":
                showWorkspacePage("dashboard");
                dashboardScroll.post(() -> {
                    View header = findViewById(R.id.admin_banner_header_row);
                    if (header != null) dashboardScroll.smoothScrollTo(0, header.getTop());
                });
                break;
            case "act_add_banner": showAddBannerDialog(); break;
            case "act_add_category": openAddCategoryPage(); break;
            case "act_search_match": startActivity(new Intent(this, MatchSearchActivity.class)); break;
            case "act_more": openAdminMore(); break;
            default: showWorkspacePage(action); break;
        }
    }

    private void setupCoinBell() {
        if (bellWrap != null) bellWrap.setVisibility(View.GONE);
    }

    @Override
    protected void onDestroy() {
        detachCoinEditListener();
        uiHandler.removeCallbacksAndMessages(null);
        super.onDestroy();
    }

    private String matchesPageForRole() {
        java.util.Set<String> allowed = rolePages();
        if (allowed.contains("matches")) return "matches";
        if (allowed.contains("battles")) return "battles";
        return "tournaments";
    }

    /** Full-screen "More" page listing every admin section this role can open — no dialog/popup. */
    private void openAdminMore() {
        resetWorkspaceChrome(null);
        dashboardScroll.setVisibility(View.GONE);
        workspaceScroll.setVisibility(View.VISIBLE);
        workspaceContent.removeAllViews();
        activeTournament = null;

        TextView title = pageText("More");
        title.setTextSize(21);
        title.setTextColor(getColor(R.color.text_primary));
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        title.setPadding(0, dp(10), 0, dp(2));
        workspaceContent.addView(title);
        

        java.util.Set<String> allowed = rolePages();
        // Battles / Tournaments / Categories / Teams / Matches / Disputes / Settings dropped
        // from this menu on request — kept minimal to what's actually used day to day.
        String[] keys = {"roles", "bannerlinks"};
        String[] names = {"Roles & Permissions", "Banner Customer Support Link"};

        LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setBackgroundResource(R.drawable.bg_admin_surface);
        LinearLayout.LayoutParams listParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        listParams.topMargin = dp(8);
        workspaceContent.addView(list, listParams);

        boolean first = true;
        for (int i = 0; i < keys.length; i++) {
            final String page = keys[i];
            boolean canOpen = "bannerlinks".equals(page) ? hasPerm("banners") : allowed.contains(page);
            if (!canOpen || ("roles".equals(page) && !"SUPER_ADMIN".equals(adminRole))) continue;

            if (!first) {
                View divider = new View(this);
                divider.setBackgroundColor(getColor(R.color.stroke));
                list.addView(divider, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(1)));
            }
            first = false;

            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(dp(14), dp(14), dp(14), dp(14));
            row.setClickable(true);
            row.setFocusable(true);
            row.setOnClickListener(v -> showWorkspacePage(page));

            TextView label = new TextView(this);
            label.setText(names[i]);
            label.setTextColor(getColor(R.color.text_primary));
            label.setTextSize(14.5f);
            LinearLayout.LayoutParams labelParams = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
            row.addView(label, labelParams);

            TextView chevron = new TextView(this);
            chevron.setText("›");
            chevron.setTextColor(getColor(R.color.text_secondary));
            chevron.setTextSize(18);
            row.addView(chevron);

            list.addView(row);
        }

        // Day-to-day tools (shortcuts to features that otherwise sit inside Settings / Analytics / Match Management).
        if (canCreateMatch()) {
            addMoreActionRow(list, "Auto delete completed matches", this::showAutoDeleteCompletedDialog);
            addMoreActionRow(list, "Search Match", () -> startActivity(new Intent(this, MatchSearchActivity.class)));
            addMoreActionRow(list, "Bulk match actions (delete / cancel / shift time)", this::showBulkMatchDialog);
            addMoreActionRow(list, "Match showing time", this::showMatchShowTimeDialog);
        }
        if (allowed.contains("analytics") || allowed.contains("payments")) {
            addMoreActionRow(list, "Revenue Dashboard", () -> showWorkspacePage("revenue"));
        }
        if (allowed.contains("activity")) addMoreActionRow(list, "Activity Log", () -> showWorkspacePage("activity"));
        if (allowed.contains("reports")) addMoreActionRow(list, "Reports & Moderation", () -> showWorkspacePage("reports"));
    }

    private void addMoreActionRow(LinearLayout list, String text, Runnable action) {
        if (list.getChildCount() > 0) {
            View divider = new View(this);
            divider.setBackgroundColor(getColor(R.color.stroke));
            list.addView(divider, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(1)));
        }
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(14), dp(14), dp(14), dp(14));
        row.setClickable(true);
        row.setFocusable(true);
        row.setOnClickListener(v -> action.run());
        TextView label = new TextView(this);
        label.setText(text);
        label.setTextColor(getColor(R.color.text_primary));
        label.setTextSize(14.5f);
        row.addView(label, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        TextView chevron = new TextView(this);
        chevron.setText("›");
        chevron.setTextColor(getColor(R.color.text_secondary));
        chevron.setTextSize(18);
        row.addView(chevron);
        list.addView(row);
    }

    /** More > Auto delete completed matches: hours after result publish when the backend removes a match (0 = off). */
    private void showAutoDeleteCompletedDialog() {
        LinearLayout form = new LinearLayout(this);
        form.setOrientation(LinearLayout.VERTICAL);
        form.setPadding(dp(24), dp(8), dp(24), dp(8));
        final EditText hoursInput = field("Hours (0 = auto delete OFF)");
        hoursInput.setInputType(InputType.TYPE_CLASS_NUMBER);
        hoursInput.setText("0");
        form.addView(hoursInput);

        LinearLayout chips = new LinearLayout(this);
        chips.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        cp.topMargin = dp(10);
        final String[] labels = {"OFF", "6h", "12h", "24h", "48h", "72h"};
        final int[] values = {0, 6, 12, 24, 48, 72};
        for (int i = 0; i < labels.length; i++) {
            final int value = values[i];
            TextView chip = new TextView(this);
            chip.setText(labels[i]);
            chip.setTextSize(12f);
            chip.setTypeface(null, android.graphics.Typeface.BOLD);
            chip.setGravity(Gravity.CENTER);
            chip.setTextColor(getColor(R.color.text_primary));
            chip.setPadding(dp(4), dp(9), dp(4), dp(9));
            android.graphics.drawable.GradientDrawable bg = new android.graphics.drawable.GradientDrawable();
            bg.setColor(0xFFF1F3F6);
            bg.setCornerRadius(dp(8));
            chip.setBackground(bg);
            chip.setOnClickListener(v -> hoursInput.setText(String.valueOf(value)));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
            lp.rightMargin = dp(4);
            chips.addView(chip, lp);
        }
        form.addView(chips, cp);

        FirebaseRepository.appConfig().child("autoDeleteCompletedHours").get().addOnSuccessListener(snap -> {
            Object raw = snap.getValue();
            if (raw instanceof Number) hoursInput.setText(String.valueOf(((Number) raw).intValue()));
        });
        final FullScreenDialog dialog = new FullScreenDialog.Builder(this)
                .setTitle("Auto delete completed matches")
                .setMessage("Result publish hone ke itne ghante baad completed match apne aap delete ho jayega (jaise 24). 0 = band. Backend (Render) chalu hona chahiye.")
                .setView(form)
                .setNegativeButton("CANCEL", null)
                .setPositiveButton("SAVE", null)
                .create();
        dialog.setOnShowListener(ignored -> dialog.getButton(Dialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            int hours;
            try { hours = Integer.parseInt(hoursInput.getText().toString().trim()); } catch (NumberFormatException e) { hours = -1; }
            if (hours < 0 || hours > 8760) {
                toast("0 se 8760 ke beech number daalo.");
                return;
            }
            final int saved = hours;
            FirebaseRepository.appConfig().child("autoDeleteCompletedHours").setValue(saved)
                    .addOnSuccessListener(done -> {
                        toast(saved == 0 ? "Auto delete OFF" : "Auto delete: " + saved + " ghante baad");
                        FirebaseRepository.logActivity("Auto delete completed changed", "platform", saved == 0 ? "OFF" : saved + "h");
                        dialog.dismiss();
                    })
                    .addOnFailureListener(error -> toast("Save failed: " + error.getMessage()));
        }));
        dialog.show();
    }

    private int countPendingPayments(DataSnapshot snapshot, boolean withdrawal) {
        int count = 0;
        for (DataSnapshot child : snapshot.getChildren()) {
            String status = child.child("status").getValue(String.class);
            if (withdrawal) {
                if (!"PAID".equalsIgnoreCase(status) && !"REJECTED".equalsIgnoreCase(status)) count++;
            } else if ("PENDING".equalsIgnoreCase(status)) {
                count++;
            }
        }
        return count;
    }

    private void watchAppConfig() {
        configListener = new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                if (isFinishing() || isDestroyed()) return;
                applyingConfig = true;

                EditText noticeTitleInput = findViewById(R.id.admin_home_notice_title_input);
                EditText noticeInput = findViewById(R.id.admin_home_notice_input);
                SwitchMaterial noticeSwitch = findViewById(R.id.admin_home_notice_switch);
                if (noticeTitleInput != null && !noticeTitleInput.isFocused()) {
                    String noticeTitle = snapshot.child("homeNotice").child("title").getValue(String.class);
                    noticeTitleInput.setText(noticeTitle == null ? "" : noticeTitle);
                }
                if (noticeInput != null && !noticeInput.isFocused()) {
                    String noticeText = snapshot.child("homeNotice").child("text").getValue(String.class);
                    noticeInput.setText(noticeText == null ? "" : noticeText);
                }
                if (noticeSwitch != null) {
                    Boolean noticeEnabled = snapshot.child("homeNotice").child("enabled").getValue(Boolean.class);
                    noticeSwitch.setChecked(Boolean.TRUE.equals(noticeEnabled));
                }
                EditText profileName = findViewById(R.id.admin_profile_name_input);
                EditText profileTerms = findViewById(R.id.admin_profile_terms_input);
                EditText profilePrivacy = findViewById(R.id.admin_profile_privacy_input);
                EditText profileSupport = findViewById(R.id.admin_profile_support_input);
                EditText profileTelegram = findViewById(R.id.admin_profile_telegram_input);
                EditText profileYoutube = findViewById(R.id.admin_profile_youtube_input);
                EditText profileInstagram = findViewById(R.id.admin_profile_instagram_input);
                EditText profileDownload = findViewById(R.id.admin_profile_download_input);
                if (profileName != null && !profileName.isFocused()) profileName.setText(snapshot.child("profile").child("adminName").getValue(String.class));
                if (profileTerms != null && !profileTerms.isFocused()) profileTerms.setText(snapshot.child("profile").child("termsUrl").getValue(String.class));
                if (profilePrivacy != null && !profilePrivacy.isFocused()) profilePrivacy.setText(snapshot.child("profile").child("privacyUrl").getValue(String.class));
                if (profileSupport != null && !profileSupport.isFocused()) profileSupport.setText(snapshot.child("profile").child("supportUrl").getValue(String.class));
                if (profileTelegram != null && !profileTelegram.isFocused()) profileTelegram.setText(snapshot.child("profile").child("telegramUrl").getValue(String.class));
                if (profileYoutube != null && !profileYoutube.isFocused()) profileYoutube.setText(snapshot.child("profile").child("youtubeUrl").getValue(String.class));
                if (profileInstagram != null && !profileInstagram.isFocused()) profileInstagram.setText(snapshot.child("profile").child("instagramUrl").getValue(String.class));
                if (profileDownload != null && !profileDownload.isFocused()) profileDownload.setText(snapshot.child("profile").child("downloadUrl").getValue(String.class));
                applyingConfig = false;
            }

            @Override
            public void onCancelled(DatabaseError error) {
                FancyText.toast(AdminActivity.this, "Could not load app settings: " + error.getMessage(), Toast.LENGTH_LONG).show();
            }
        };
        FirebaseRepository.appConfig().addValueEventListener(configListener);
    }

    @Override
    protected void onStart() {
        super.onStart();
        tournamentListener = new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                if (isFinishing() || isDestroyed()) return;
                tournaments.clear();
                for (DataSnapshot child : snapshot.getChildren()) {
                    Object rawTournament = child.getValue();
                    if (!(rawTournament instanceof Map)) continue;
                    try {
                        Tournament tournament = Tournament.fromMap(child.getKey(),
                                (java.util.Map<String, Object>) rawTournament);
                        if (tournament != null) tournaments.add(tournament);
                    } catch (RuntimeException ignored) { }
                }
                java.util.Collections.sort(tournaments,
                        java.util.Comparator.comparingLong(Tournament::getStartAt).reversed());
                recentMatches.clear();
                int upcoming = 0;
                int completed = 0;
                for (Tournament tournament : tournaments) {
                    if (tournament == null) continue;
                    String status = tournament.getEffectiveStatus();
                    if (Tournament.UPCOMING.equals(status)) upcoming++;
                    if (Tournament.COMPLETED.equals(status)) completed++;
                    if (recentMatches.size() < 3) recentMatches.add(tournament);
                }
                if (adapter != null) adapter.notifyDataSetChanged();
                setHomeStat("matches", String.valueOf(tournaments.size()));
                setHomeStat("upcoming", String.valueOf(upcoming));
                setHomeStat("completed", String.valueOf(completed));
                TextView battleStat = findViewById(R.id.admin_stat_battles);
                TextView liveStat = findViewById(R.id.admin_stat_live);
                TextView prizeStat = findViewById(R.id.admin_stat_prize);
                if (battleStat != null) battleStat.setText(tournaments.size() + "\nBATTLES");
                if (liveStat != null) {
                    int live = 0;
                    for (Tournament t : tournaments) {
                        if (t != null && Tournament.ONGOING.equals(t.getEffectiveStatus())) live++;
                    }
                    liveStat.setText(live + "\nLIVE");
                }
                if (prizeStat != null) prizeStat.setText("FREE\nENTRY");
            }

            @Override
            public void onCancelled(DatabaseError error) {
                FancyText.toast(AdminActivity.this, "Could not load tournaments: " + error.getMessage(), Toast.LENGTH_LONG).show();
            }
        };
        FirebaseRepository.tournaments().addValueEventListener(tournamentListener);
        gameModeListener = new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                if (isFinishing() || isDestroyed()) return;
                gameModes.clear();
                for (DataSnapshot child : snapshot.getChildren()) {
                    Object raw = child.getValue();
                    if (!(raw instanceof Map)) continue;
                    GameMode mode = GameMode.fromMap(child.getKey(), (Map<String, Object>) raw);
                    if (mode != null) gameModes.add(mode);
                }
                RecyclerView categoryList = findViewById(R.id.admin_game_mode_list);
                if (categoryList.getAdapter() != null) categoryList.getAdapter().notifyDataSetChanged();
                if (categoryImageAdapter != null) categoryImageAdapter.notifyDataSetChanged();
                setHomeStat("categories", String.valueOf(gameModes.size()));
            }

            @Override
            public void onCancelled(DatabaseError error) {
                FancyText.toast(AdminActivity.this, "Could not load categories: " + error.getMessage(), Toast.LENGTH_LONG).show();
            }
        };
        FirebaseRepository.gameModes().addValueEventListener(gameModeListener);
        bannerListener = new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                if (isFinishing() || isDestroyed()) return;
                banners.clear();
                for (DataSnapshot child : snapshot.getChildren()) {
                    Object raw = child.getValue();
                    if (!(raw instanceof Map)) continue;
                    Banner banner = Banner.fromMap(child.getKey(), (Map<String, Object>) raw);
                    if (banner != null) banners.add(banner);
                }
                java.util.Collections.sort(banners, java.util.Comparator.comparingInt(Banner::getDisplayOrder));
                RecyclerView bannerList = findViewById(R.id.admin_banner_list);
                if (bannerList.getAdapter() != null) bannerList.getAdapter().notifyDataSetChanged();
                homeBanners.clear();
                for (Banner banner : banners) if (banner.isActive()) homeBanners.add(banner);
                if (homeBannerAdapter != null) homeBannerAdapter.notifyDataSetChanged();
                setHomeStat("banners", String.valueOf(homeBanners.size()));
            }

            @Override
            public void onCancelled(DatabaseError error) {
                FancyText.toast(AdminActivity.this, "Could not load banners: " + error.getMessage(), Toast.LENGTH_LONG).show();
            }
        };
        FirebaseRepository.banners().addValueEventListener(bannerListener);
        FirebaseRepository.users().addListenerForSingleValueEvent(new ValueEventListener() {
            @Override public void onDataChange(DataSnapshot snapshot) {
                TextView stat = findViewById(R.id.admin_stat_users);
                if (stat != null) stat.setText(snapshot.getChildrenCount() + "\nUSERS");
                setHomeStat("users", String.valueOf(snapshot.getChildrenCount()));
            }
            @Override public void onCancelled(DatabaseError error) { }
        });
        java.util.Set<String> allowed = rolePages();
        if (allowed.contains("payments")) {
            FirebaseRepository.deposits().addListenerForSingleValueEvent(new ValueEventListener() {
                @Override public void onDataChange(DataSnapshot snapshot) {
                    setHomeStat("pending_deposits", String.valueOf(countPendingPayments(snapshot, false)));
                }
                @Override public void onCancelled(DatabaseError error) { setHomeStat("pending_deposits", "—"); }
            });
            FirebaseRepository.withdrawals().addListenerForSingleValueEvent(new ValueEventListener() {
                @Override public void onDataChange(DataSnapshot snapshot) {
                    setHomeStat("pending_withdrawals", String.valueOf(countPendingPayments(snapshot, true)));
                }
                @Override public void onCancelled(DatabaseError error) { setHomeStat("pending_withdrawals", "—"); }
            });
        }
        watchAppConfig();
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (tournamentListener != null) FirebaseRepository.tournaments().removeEventListener(tournamentListener);
        if (gameModeListener != null) FirebaseRepository.gameModes().removeEventListener(gameModeListener);
        if (bannerListener != null) FirebaseRepository.banners().removeEventListener(bannerListener);
        if (configListener != null) FirebaseRepository.appConfig().removeEventListener(configListener);
        tournamentListener = null; gameModeListener = null; bannerListener = null; configListener = null;
    }

    private void showCategoryMatches(GameMode mode) {
        Intent page = new Intent(this, CategoryMatchesActivity.class);
        page.putExtra("categoryId", mode.getId());
        page.putExtra("categoryTitle", mode.getTitle());
        page.putExtra("adminMode", true);
        startActivity(page);
        return;
        /*
        FirebaseRepository.tournaments().addListenerForSingleValueEvent(new ValueEventListener() {
            @Override public void onDataChange(DataSnapshot snapshot) {
                StringBuilder matches = new StringBuilder();
                int count = 0;
                for (DataSnapshot child : snapshot.getChildren()) {
                    Tournament tournament = Tournament.fromMap(child.getKey(),
                            (Map<String, Object>) child.getValue());
                    if (tournament != null && mode.getId().equals(tournament.getCategoryId())) {
                        count++;
                        matches.append("• ").append(tournament.getTitle())
                                .append(" | ").append(tournament.getDate()).append(" ")
                                .append(tournament.getTime()).append(" | Prize ")
                                .append(tournament.getPrizeInfo()).append(" | FREE ENTRY").append("\n");
                    }
                }
                if (count == 0) matches.append("No matches published in this category yet.");
                new FullScreenDialog.Builder(AdminActivity.this)
                        .setTitle(mode.getTitle() + " • MATCHES")
                        .setMessage(matches.toString())
                        .setNegativeButton("CLOSE", null)
                        .setPositiveButton("OPEN MATCH FORM", (dialog, which) ->
                                showAddTournamentDialog(mode.getId(), mode.getTitle()))
                        .show();
            }
            @Override public void onCancelled(DatabaseError error) {
                FancyText.toast(AdminActivity.this, "Could not load category matches: " + error.getMessage(), Toast.LENGTH_LONG).show();
            }
        });
        */
    }

    private void showAddTournamentDialog(String categoryId, String categoryTitle) {
        selectedTournamentImage = null;
        LinearLayout form = new LinearLayout(this);
        form.setOrientation(LinearLayout.VERTICAL);
        form.setPadding(dp(24), dp(4), dp(24), dp(8));

        form.addView(fieldLabel("MATCH IMAGE"));
        MaterialButton chooseImage = new MaterialButton(this);
        chooseImage.setText("SELECT PNG/JPG FROM DEVICE");
        chooseImage.setTextColor(getColor(R.color.text_primary));
        chooseImage.setBackgroundResource(R.drawable.bg_button_gradient);
        chooseImage.setMaxLines(1);
        LinearLayout.LayoutParams chooseParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        chooseParams.topMargin = dp(6);
        chooseParams.bottomMargin = dp(10);
        chooseImage.setLayoutParams(chooseParams);
        chooseImage.setOnClickListener(v -> chooseTournamentImage());
        form.addView(chooseImage);

        tournamentPreview = new ImageView(this);
        tournamentPreview.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(140)));
        tournamentPreview.setScaleType(ImageView.ScaleType.CENTER_CROP);
        tournamentPreview.setBackgroundResource(R.drawable.bg_game_card_gold);
        form.addView(tournamentPreview);

        tournamentImageUrlField = field("Or paste image URL instead");
        form.addView(tournamentImageUrlField);

        form.addView(fieldLabel("MATCH NAME"));
        EditText title = field("Tournament name");
        form.addView(title);

        EditText mode = field("Category ID or game mode");
        if (!categoryId.isEmpty()) {
            mode.setText(categoryId);
            mode.setEnabled(false);
        } else {
            form.addView(fieldLabel("CATEGORY / MODE"));
        }
        form.addView(mode);

        form.addView(fieldLabel("SCHEDULE"));
        EditText date = field("Start date (e.g. 20 SEP 2026)");
        date.setFocusable(false);
        date.setClickable(true);
        Spinner time = new Spinner(this);
        Calendar selectedDay = Calendar.getInstance();
        date.setText(new SimpleDateFormat("dd MMM yyyy", Locale.ENGLISH)
                .format(selectedDay.getTime()).toUpperCase(Locale.ENGLISH));
        refreshMatchTimeSlots(time, selectedDay, date);
        date.setOnClickListener(v -> {
            Calendar picker = (Calendar) selectedDay.clone();
            new DatePickerDialog(this, (view, year, month, day) -> {
                selectedDay.set(Calendar.YEAR, year);
                selectedDay.set(Calendar.MONTH, month);
                selectedDay.set(Calendar.DAY_OF_MONTH, day);
                date.setText(new SimpleDateFormat("dd MMM yyyy", Locale.ENGLISH)
                        .format(selectedDay.getTime()).toUpperCase(Locale.ENGLISH));
                refreshMatchTimeSlots(time, selectedDay, date);
            }, picker.get(Calendar.YEAR), picker.get(Calendar.MONTH), picker.get(Calendar.DAY_OF_MONTH)).show();
        });
        form.addView(formRow(date, time));

        form.addView(fieldLabel("PRIZE & SLOTS"));
        EditText prize = field("Prize information (e.g. Diamonds / Bundle)");
        form.addView(prize);
        EditText slots = field("Total slots");
        slots.setInputType(InputType.TYPE_CLASS_NUMBER);
        EditText teamSize = field("Team size (1=Solo, 2=Duo, 4=Squad)");
        teamSize.setInputType(InputType.TYPE_CLASS_NUMBER);
        form.addView(formRow(slots, teamSize));
        form.addView(fieldLabel("ENTRY FEE (COINS)"));
        Spinner entryFee = coinAmountSpinner(0);
        form.addView(fieldLabel("PRIZE POOL (COINS)"));
        Spinner prizePoolCoins = coinAmountSpinner(0);
        form.addView(fieldLabel("REWARD PER KILL (COINS)"));
        Spinner perKill = coinAmountSpinner(0);
        form.addView(formRow(entryFee, prizePoolCoins));
        form.addView(perKill);

        form.addView(fieldLabel("LEADERBOARD & REWARD SYSTEM"));
        Spinner resultSystem = new Spinner(this);
        String[] resultSystemLabels = {"KILL → COIN", "SURVIVAL → COIN", "1VS1 BATTLE", "TEAM → RANK COIN"};
        resultSystem.setAdapter(new android.widget.ArrayAdapter<>(this,
                android.R.layout.simple_spinner_dropdown_item, resultSystemLabels));
        form.addView(resultSystem);

        form.addView(fieldLabel("MATCH TYPE & MAP"));
        Spinner matchType = new Spinner(this);
        matchType.setAdapter(new android.widget.ArrayAdapter<>(this,
                android.R.layout.simple_spinner_dropdown_item,
                new String[]{"SOLO", "DUO", "SQUAD"}));
        EditText map = field("Map name");
        // Admin only types the team size number; SOLO / DUO / SQUAD is selected automatically.
        matchType.setEnabled(false);
        teamSize.addTextChangedListener(new android.text.TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void afterTextChanged(android.text.Editable e) {
                int idx = e.toString().trim().isEmpty() ? 0 : matchTypeIndexForTeamSize(numberOrDefault(e.toString(), 0));
                if (idx >= 0) matchType.setSelection(idx);
            }
        });
        form.addView(formRow(matchType, map));

        form.addView(fieldLabel("MATCH DESCRIPTION"));
        EditText description = field("Match description");
        form.addView(description);

        form.addView(fieldLabel("RULES (OPTIONAL)"));
        EditText rules = field("Rules (optional)");
        form.addView(rules);
        // Per-category saved description / rules (only when this dialog was opened inside a category).
        com.arenax.tournament.util.CategoryPresetUi.attach(this, form, description, rules,
                categoryId, categoryTitle, null);

        form.addView(fieldLabel("ROOM DETAILS (OPTIONAL)"));
        EditText roomId = field("Room ID (optional)");
        form.addView(roomId);
        EditText roomDate = field("Room release date (optional)");
        EditText roomTime = field("Room release time (optional)");
        form.addView(formRow(roomDate, roomTime));

        android.widget.ScrollView scroll = new android.widget.ScrollView(this);
        scroll.setOverScrollMode(View.OVER_SCROLL_IF_CONTENT_SCROLLS);
        scroll.addView(form);

        Dialog dialog = buildStickyFormDialog(
                categoryTitle.isEmpty() ? "Create tournament" : "Add match • " + categoryTitle,
                "Set match time, prize information, slots and rules. Add a banner image, then publish live to Firebase.",
                scroll,
                "SAVE MATCH",
                () -> {
                    String tournamentTitle = title.getText().toString().trim();
                    if (tournamentTitle.isEmpty()) {
                        title.setError("Enter a name");
                        return;
                    }
                    String prizeValue = prize.getText().toString().trim().isEmpty() ? "Free entry" : prize.getText().toString().trim();
                    int slotValue = numberOrDefault(slots.getText().toString(), 48);
                    // F2 \u2014 match type drives team size: SQUAD can never be saved as a 1-player
                    // team by mistake. If the admin left team size blank/1 while picking a
                    // team mode, derive it straight from the match type (SOLO=1, DUO=2,
                    // TRIO=3, SQUAD/CLASH=4). An explicit larger team size still wins.
                    String matchTypeValue = (String) matchType.getSelectedItem();
                    int teamValue = numberOrDefault(teamSize.getText().toString(), 1);
                    int derivedTeamSize = MatchEditorActivity.teamSizeFor(matchTypeValue);
                    if (teamValue < derivedTeamSize) {
                        teamValue = derivedTeamSize;
                    }
                    int entryValue = Math.max(0, numberOrDefault((String) entryFee.getSelectedItem(), 0));
                    int prizePoolValue = Math.max(0, numberOrDefault((String) prizePoolCoins.getSelectedItem(), 0));
                    int perKillValue = Math.max(0, numberOrDefault((String) perKill.getSelectedItem(), 0));
                    int resultSystemIndex = resultSystem.getSelectedItemPosition();
                    String resultSystemValue = resultSystemIndex == 1 ? "SURVIVAL"
                            : (resultSystemIndex == 2 ? "BATTLE_1V1" : (resultSystemIndex == 3 ? "TEAM" : "KILL"));
                    if ("BATTLE_1V1".equals(resultSystemValue)) {
                        slotValue = 2;
                        teamValue = 1;
                        slots.setText("2");
                        teamSize.setText("1");
                    } else if ("KILL".equals(resultSystemValue) || "SURVIVAL".equals(resultSystemValue)) {
                        int typedTeam = numberOrDefault(teamSize.getText().toString(), 1);
                        if (matchTypeIndexForTeamSize(typedTeam) < 0) {
                            teamSize.setError("Team size 1 (SOLO), 2 (DUO) ya 4 (SQUAD) hi ho sakta hai");
                            return;
                        }
                    }
                    String modeValue = mode.getText().toString().trim().isEmpty()
                            ? "CUSTOM MODE" : mode.getText().toString().trim().toUpperCase();
                    String dateValue = date.getText().toString().trim().isEmpty()
                            ? "TBA" : date.getText().toString().trim().toUpperCase();
                    String timeValue = time.getSelectedItem() == null
                            ? "TBA" : ((String) time.getSelectedItem()).toUpperCase(Locale.ENGLISH);
                    long startAt = parseDateTime(dateValue, timeValue);
                    long roomReleaseAt = parseDateTime(
                            roomDate.getText().toString().trim().toUpperCase(),
                            roomTime.getText().toString().trim().toUpperCase());
                    String categoryValue = categoryId.isEmpty() ? modeValue : categoryId;
                    final int finalSlotValue = slotValue;
                    final int finalTeamValue = teamValue;

                    if (selectedTournamentImage != null) {
                        FancyText.toast(this, "Uploading image securely…", Toast.LENGTH_SHORT).show();
                        com.arenax.tournament.data.ImgBbUploader.uploadImage(this, selectedTournamentImage,
                                new com.arenax.tournament.data.StorageUploader.Callback() {
                                    @Override public void onSuccess(String fileUrl) {
                                        saveTournamentEntry(tournamentTitle, modeValue, categoryValue, fileUrl,
                                                description.getText().toString().trim(), dateValue, timeValue, startAt,
                                                roomReleaseAt, prizeValue, finalSlotValue, finalTeamValue,
                                                entryValue, prizePoolValue, perKillValue, resultSystemValue,
                                                map.getText().toString().trim(), matchTypeValue,
                                                rules.getText().toString().trim(), roomId.getText().toString().trim());
                                    }
                                    @Override public void onFailure(String message) {
                                        showUploadErrorDialog("Image upload failed", message);
                                    }
                                });
                    } else {
                        saveTournamentEntry(tournamentTitle, modeValue, categoryValue,
                                tournamentImageUrlField.getText().toString().trim(),
                                description.getText().toString().trim(), dateValue, timeValue, startAt,
                                roomReleaseAt, prizeValue, finalSlotValue, finalTeamValue,
                                entryValue, prizePoolValue, perKillValue, resultSystemValue,
                                map.getText().toString().trim(), matchTypeValue,
                                rules.getText().toString().trim(), roomId.getText().toString().trim());
                    }
                });
        categoryDialog = dialog;
        dialog.show();
    }

    private void saveTournamentEntry(String tournamentTitle, String modeValue, String categoryValue, String bannerUrlValue,
                                      String descriptionValue, String dateValue, String timeValue, long startAt,
                                      long roomReleaseAt, String prizeValue, int slotValue, int teamValue,
                                      int entryFeeValue, int prizePoolValue, int perKillValue, String resultSystemValue,
                                      String mapValue, String matchTypeValue, String rulesValue, String roomIdValue) {
        Tournament tournament = new Tournament(
                null,
                tournamentTitle,
                modeValue,
                categoryValue,
                bannerUrlValue,
                descriptionValue,
                dateValue,
                timeValue,
                startAt,
                0L,
                roomReleaseAt,
                prizeValue, slotValue, 0,
                Math.max(1, teamValue),
                mapValue.isEmpty() ? "TBA" : mapValue,
                matchTypeValue.isEmpty() ? "SOLO" : matchTypeValue.toUpperCase(),
                rulesValue,
                "",
                roomIdValue,
                "",
                false, "",
                "UPCOMING", "OPEN", true, getColor(R.color.blood_red));
        tournament.setCoinDetails(entryFeeValue, prizePoolValue, perKillValue, "BATTLE ROYALE");
        tournament.setResultSystem(resultSystemValue);
        FirebaseRepository.saveTournament(tournament)
                .addOnSuccessListener(unused -> {
                    FancyText.toast(this, "Tournament published. User app updated live.", Toast.LENGTH_SHORT).show();
                    FirebaseRepository.logActivity("TOURNAMENT_SAVED", tournamentTitle, "Slots " + slotValue + ", mode " + modeValue);
                    if (categoryDialog != null) categoryDialog.dismiss();
                })
                .addOnFailureListener(error -> FancyText.toast(this, error.getMessage(), Toast.LENGTH_LONG).show());
    }

    private void chooseTournamentImage() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("image/*");
        startActivityForResult(intent, 7004);
    }

    /** Puts two fields side by side (2-column row), matching the reference form design. */
    private LinearLayout formRow(View left, View right) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams leftParams = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        leftParams.rightMargin = dp(6);
        left.setLayoutParams(leftParams);
        LinearLayout.LayoutParams rightParams = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        rightParams.leftMargin = dp(6);
        right.setLayoutParams(rightParams);
        row.addView(left);
        row.addView(right);
        return row;
    }

    private static final int REQUEST_CATEGORY_EDITOR = 9083;

    /** Opens the full-page "Add category" screen (image + name + OK) instead of a floating card. */
    private void openAddCategoryPage() {
        Intent page = new Intent(this, CategoryEditorActivity.class);
        page.putExtra(CategoryEditorActivity.EXTRA_NEXT_POSITION, gameModes.size() + 1);
        startActivityForResult(page, REQUEST_CATEGORY_EDITOR);
    }

    /** Opens the full-page "Edit category" screen, pre-filled with the existing category. */
    private void openEditCategoryPage(GameMode existing) {
        Intent page = new Intent(this, CategoryEditorActivity.class);
        page.putExtra(CategoryEditorActivity.EXTRA_CATEGORY, existing);
        startActivityForResult(page, REQUEST_CATEGORY_EDITOR);
    }

    private void showAddCategoryDialog() {
        selectedCategoryImage = null;
        LinearLayout form = new LinearLayout(this);
        form.setOrientation(LinearLayout.VERTICAL);
        form.setPadding(dp(24), dp(8), dp(24), dp(8));

        EditText title = field("Game category name");
        categoryImageUrl = field("PNG/JPG image URL (optional)");
        EditText positionField = field("Slot position (1, 2, 3… blank = add to end)");
        positionField.setInputType(InputType.TYPE_CLASS_NUMBER);
        form.addView(title);
        form.addView(categoryImageUrl);
        form.addView(positionField);

        MaterialButton chooseImage = new MaterialButton(this);
        chooseImage.setText("SELECT PNG/JPG FROM DEVICE");
        chooseImage.setTextColor(getColor(R.color.text_primary));
        chooseImage.setMaxLines(1);
        LinearLayout.LayoutParams chooseParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        chooseParams.topMargin = dp(6);
        chooseParams.bottomMargin = dp(10);
        chooseImage.setLayoutParams(chooseParams);
        chooseImage.setOnClickListener(v -> chooseCategoryImage());
        form.addView(chooseImage);

        categoryPreview = new ImageView(this);
        categoryPreview.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(140)));
        categoryPreview.setScaleType(ImageView.ScaleType.CENTER_CROP);
        categoryPreview.setBackgroundResource(R.drawable.bg_game_card_blue);
        form.addView(categoryPreview);

        android.widget.ScrollView formScroll = new android.widget.ScrollView(this);
        formScroll.setOverScrollMode(View.OVER_SCROLL_IF_CONTENT_SCROLLS);
        formScroll.addView(form);

        categoryDialog = buildStickyFormDialog(
                "Create esports category",
                "Publish live to Firebase. Add a public image URL or select a PNG/JPG from this device.",
                formScroll,
                "PUBLISH",
                () -> {
                    String categoryTitle = title.getText().toString().trim();
                    if (categoryTitle.isEmpty()) {
                        title.setError("Enter a category name");
                        return;
                    }
                    int position = parsePosition(positionField.getText().toString().trim(), gameModes.size() + 1);
                    publishCategory(categoryTitle, categoryImageUrl.getText().toString().trim(), position);
                });
        categoryDialog.show();
    }

    /** Home screen shows 2 categories per line, so slot 1 & 2 = line 1, 3 & 4 = line 2, and so on. */
    private int parsePosition(String rawValue, int fallback) {
        if (rawValue.isEmpty()) return fallback;
        try {
            int parsed = Integer.parseInt(rawValue);
            return parsed > 0 ? parsed : fallback;
        } catch (NumberFormatException ignored) {
            return fallback;
        }
    }

    /** Like parsePosition but allows zero (a category can legitimately show 0 users). */
    private int parseNonNegative(String rawValue, int fallback) {
        if (rawValue.isEmpty()) return fallback;
        try {
            int parsed = Integer.parseInt(rawValue);
            return parsed >= 0 ? parsed : fallback;
        } catch (NumberFormatException ignored) {
            return fallback;
        }
    }

    private void showEditCategoryDialog(GameMode existing) {
        selectedCategoryImage = null;
        LinearLayout form = new LinearLayout(this);
        form.setOrientation(LinearLayout.VERTICAL);
        form.setPadding(dp(24), dp(8), dp(24), dp(8));

        EditText title = field("Game category name");
        title.setText(existing.getTitle());
        categoryImageUrl = field("PNG/JPG image URL (leave as-is to keep current image)");
        categoryImageUrl.setText(existing.getImageUrl());
        EditText positionField = field("Slot position (1, 2, 3…)");
        positionField.setInputType(InputType.TYPE_CLASS_NUMBER);
        positionField.setText(String.valueOf(existing.getDisplayOrder()));
        EditText usersField = field("Total users shown (e.g. 32)");
        usersField.setInputType(InputType.TYPE_CLASS_NUMBER);
        usersField.setText(String.valueOf(existing.getTotalUsers()));
        form.addView(fieldLabel("CATEGORY NAME"));
        form.addView(title);
        form.addView(fieldLabel("IMAGE URL"));
        form.addView(categoryImageUrl);
        form.addView(fieldLabel("SLOT POSITION"));
        form.addView(positionField);
        form.addView(fieldLabel("TOTAL USERS SHOWN"));
        form.addView(usersField);

        LinearLayout onlineRow = new LinearLayout(this);
        onlineRow.setOrientation(LinearLayout.HORIZONTAL);
        onlineRow.setGravity(android.view.Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams onlineRowParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        onlineRowParams.topMargin = dp(6);
        onlineRowParams.bottomMargin = dp(6);
        onlineRow.setLayoutParams(onlineRowParams);
        TextView onlineLabel = new TextView(this);
        onlineLabel.setText("Category status: ONLINE (green dot on Home) / OFFLINE (red dot)");
        onlineLabel.setTextColor(getColor(R.color.text_primary));
        onlineLabel.setTextSize(11f);
        onlineLabel.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        com.google.android.material.switchmaterial.SwitchMaterial onlineSwitch =
                new com.google.android.material.switchmaterial.SwitchMaterial(this);
        onlineSwitch.setChecked(existing.isOnline());
        onlineRow.addView(onlineLabel);
        onlineRow.addView(onlineSwitch);
        form.addView(onlineRow);

        MaterialButton chooseImage = new MaterialButton(this);
        chooseImage.setText("SELECT PNG/JPG FROM DEVICE");
        chooseImage.setTextColor(getColor(R.color.text_primary));
        chooseImage.setMaxLines(1);
        LinearLayout.LayoutParams chooseParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        chooseParams.topMargin = dp(6);
        chooseParams.bottomMargin = dp(10);
        chooseImage.setLayoutParams(chooseParams);
        chooseImage.setOnClickListener(v -> chooseCategoryImage());
        form.addView(chooseImage);

        categoryPreview = new ImageView(this);
        categoryPreview.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(140)));
        categoryPreview.setScaleType(ImageView.ScaleType.CENTER_CROP);
        categoryPreview.setBackgroundResource(R.drawable.bg_game_card_blue);
        if (!existing.getImageUrl().isEmpty()) {
            ImageLoader.load(categoryPreview, existing.getImageUrl());
        }
        form.addView(categoryPreview);

        android.widget.ScrollView formScroll = new android.widget.ScrollView(this);
        formScroll.setOverScrollMode(View.OVER_SCROLL_IF_CONTENT_SCROLLS);
        formScroll.addView(form);

        categoryDialog = buildStickyFormDialog(
                "Edit " + existing.getTitle(),
                "Change the slot position to move this category to a different line/spot on the Home screen grid (2 per line).",
                formScroll,
                "SAVE",
                () -> {
                    String categoryTitle = title.getText().toString().trim();
                    if (categoryTitle.isEmpty()) {
                        title.setError("Enter a category name");
                        return;
                    }
                    int position = parsePosition(positionField.getText().toString().trim(), existing.getDisplayOrder());
                    int totalUsers = parseNonNegative(usersField.getText().toString().trim(), existing.getTotalUsers());
                    boolean online = onlineSwitch.isChecked();
                    if (selectedCategoryImage != null) {
                        FancyText.toast(this, "Uploading image securely…", Toast.LENGTH_SHORT).show();
                        com.arenax.tournament.data.ImgBbUploader.uploadImage(this, selectedCategoryImage,
                                new com.arenax.tournament.data.StorageUploader.Callback() {
                                    @Override public void onSuccess(String fileUrl) {
                                        saveCategory(existing.getId(), categoryTitle, fileUrl, position, online, totalUsers);
                                    }
                                    @Override public void onFailure(String message) {
                                        showUploadErrorDialog("Image upload failed", message);
                                    }
                                });
                    } else {
                        saveCategory(existing.getId(), categoryTitle, categoryImageUrl.getText().toString().trim(), position, online, totalUsers);
                    }
                });
        categoryDialog.show();
    }

    private void chooseCategoryImage() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("image/*");
        startActivityForResult(intent, 7001);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 7001 && resultCode == RESULT_OK && data != null && data.getData() != null) {
            selectedCategoryImage = data.getData();
            if (categoryPreview != null) categoryPreview.setImageURI(selectedCategoryImage);
        }
        if (requestCode == 7002 && resultCode == RESULT_OK && data != null && data.getData() != null) {
            selectedLogoImage = data.getData();
            if (logoPreview != null) logoPreview.setImageURI(selectedLogoImage);
        }
        if (requestCode == 7003 && resultCode == RESULT_OK && data != null && data.getData() != null) {
            selectedBannerImage = data.getData();
            if (bannerPreview != null) bannerPreview.setImageURI(selectedBannerImage);
        }
        if (requestCode == 7004 && resultCode == RESULT_OK && data != null && data.getData() != null) {
            selectedTournamentImage = data.getData();
            if (tournamentPreview != null) tournamentPreview.setImageURI(selectedTournamentImage);
        }
        // Full-screen editor/room pages report back so the admin lists refresh instantly.
        if (requestCode == REQUEST_MATCH_EDITOR && resultCode == RESULT_OK) {
            refreshAfterEdit();
        }
        if (requestCode == REQUEST_ROOM_CONTROL && resultCode == RESULT_OK) {
            refreshAfterEdit();
        }
        if (requestCode == REQUEST_CATEGORY_EDITOR && resultCode == RESULT_OK) {
            FancyText.toast(this, "Category list updated.", Toast.LENGTH_SHORT).show();
        }
        if (requestCode == REQUEST_WITHDRAWAL_DETAIL && resultCode == RESULT_OK) {
            showWorkspacePage("payments");
        }
    }

    private static final int REQUEST_MATCH_EDITOR = 9081;
    private static final int REQUEST_ROOM_CONTROL = 9082;
    private static final int REQUEST_WITHDRAWAL_DETAIL = 9084;

    /** Re-renders whichever admin workspace page is on screen after a match edit or room
     *  change done in a full-screen page, so the admin sees fresh status without pulling
     *  to reload the whole workspace. */
    private void refreshAfterEdit() {
        if (activeTournament != null) {
            showMatchesForTournament(activeTournament);
        } else {
            loadTournamentsPage("tournaments");
        }
    }

    private void publishCategory(String title, String imageUrl, int position) {
        String id = FirebaseRepository.gameModes().push().getKey();
        if (id == null) {
            FancyText.toast(this, "Could not create category key.", Toast.LENGTH_LONG).show();
            return;
        }
        if (selectedCategoryImage == null) {
            saveCategory(id, title, imageUrl, position);
            return;
        }
        FancyText.toast(this, "Uploading image securely…", Toast.LENGTH_SHORT).show();
        com.arenax.tournament.data.ImgBbUploader.uploadImage(this, selectedCategoryImage,
                new com.arenax.tournament.data.StorageUploader.Callback() {
                    @Override public void onSuccess(String fileUrl) {
                        saveCategory(id, title, fileUrl, position);
                    }
                    @Override public void onFailure(String message) {
                        showUploadErrorDialog("Image upload failed", message);
                    }
                });
    }

    /** Toast truncates long text; upload errors (e.g. Telegram's JSON error body) need the full message visible and copyable. */
    private void showUploadErrorDialog(String title, String message) {
        android.widget.TextView content = new android.widget.TextView(this);
        content.setText(message);
        content.setTextIsSelectable(true);
        int pad = (int) (20 * getResources().getDisplayMetrics().density);
        content.setPadding(pad, pad, pad, pad);
        new FullScreenDialog.Builder(this)
                .setTitle(title)
                .setView(content)
                .setPositiveButton("OK", null)
                .show();
    }

    /** Whether a category with this Firebase key already exists (i.e. this save is an edit, not a new create). */
    private boolean categoryExists(String id) {
        for (GameMode existing : gameModes) {
            if (existing.getId().equals(id)) return true;
        }
        return false;
    }

    private long existingCreatedAt(String id, long fallback) {
        for (GameMode existing : gameModes) {
            if (existing.getId().equals(id)) return existing.getCreatedAt();
        }
        return fallback;
    }

    private void saveCategory(String id, String title, String imageUrl, int displayOrder) {
        saveCategory(id, title, imageUrl, displayOrder, false, 0);
    }

    private void saveCategory(String id, String title, String imageUrl, int displayOrder, boolean online, int totalUsers) {
        boolean isUpdate = categoryExists(id);
        long createdAt = existingCreatedAt(id, System.currentTimeMillis());
        Map<String, Object> mode = new HashMap<>();
        mode.put("title", title.toUpperCase());
        mode.put("imageUrl", imageUrl);
        mode.put("displayOrder", displayOrder);
        mode.put("createdAt", createdAt);
        mode.put("active", true);
        mode.put("online", online);
        mode.put("totalUsers", totalUsers);
        FirebaseRepository.saveGameMode(id, mode)
                .addOnSuccessListener(unused -> {
                    FancyText.toast(this, isUpdate ? "Category updated. Slot #" + displayOrder + "."
                            : "Category published live at slot #" + displayOrder + ".", Toast.LENGTH_SHORT).show();
                    FirebaseRepository.logActivity(isUpdate ? "CATEGORY_UPDATED" : "CATEGORY_CREATED",
                            title, "slot #" + displayOrder);
                    if (categoryDialog != null) categoryDialog.dismiss();
                })
                .addOnFailureListener(error ->
                        FancyText.toast(this, "Category save failed: " + error.getMessage(), Toast.LENGTH_LONG).show());
    }

    private void confirmDeleteGameMode(GameMode mode) {
        new FullScreenDialog.Builder(this)
                .setTitle("Remove " + mode.getTitle() + "?")
                .setMessage("This category will disappear from the User app after Firebase updates.")
                .setNegativeButton("CANCEL", null)
                .setPositiveButton("REMOVE", (dialog, which) ->
                        FirebaseRepository.deleteGameMode(mode.getId())
                                .addOnSuccessListener(unused -> {
                                    FancyText.toast(this, "Category removed.", Toast.LENGTH_SHORT).show();
                                    FirebaseRepository.logActivity("CATEGORY_DELETED", mode.getTitle(), "");
                                })
                                .addOnFailureListener(error -> FancyText.toast(this, error.getMessage(), Toast.LENGTH_LONG).show()))
                .show();
    }

    private static final int MAX_HOME_BANNERS = 10;

    private void showAddBannerDialog() {
        if (banners.size() >= MAX_HOME_BANNERS) {
            FancyText.toast(this, "Maximum " + MAX_HOME_BANNERS + " banners reached. Delete one to add a new banner.",
                    Toast.LENGTH_LONG).show();
            return;
        }
        startActivity(new Intent(this, BannerEditorActivity.class));
        return;
        /*
        selectedBannerImage = null;
        LinearLayout form = new LinearLayout(this);
        form.setOrientation(LinearLayout.VERTICAL);
        form.setPadding(dp(24), dp(8), dp(24), dp(8));

        EditText title = field("Banner title (e.g. SEASON 04 LIVE)");
        EditText subtitle = field("Subtitle (optional)");
        bannerImageUrlField = field("Banner image URL (optional)");
        form.addView(title);
        form.addView(subtitle);
        form.addView(bannerImageUrlField);

        MaterialButton chooseImage = new MaterialButton(this);
        chooseImage.setText("SELECT IMAGE FROM DEVICE");
        chooseImage.setTextColor(getColor(R.color.text_primary));
        chooseImage.setMaxLines(1);
        LinearLayout.LayoutParams chooseParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        chooseParams.topMargin = dp(6);
        chooseParams.bottomMargin = dp(10);
        chooseImage.setLayoutParams(chooseParams);
        chooseImage.setOnClickListener(v -> chooseBannerImage());
        form.addView(chooseImage);

        bannerPreview = new ImageView(this);
        bannerPreview.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(140)));
        bannerPreview.setScaleType(ImageView.ScaleType.CENTER_CROP);
        bannerPreview.setBackgroundResource(R.drawable.bg_banner);
        form.addView(bannerPreview);

        bannerDialog = new FullScreenDialog.Builder(this)
                .setTitle("Add home banner")
                .setMessage("Publish live to Firebase. This appears instantly at the top of the User app home screen.")
                .setView(form)
                .setNegativeButton("CANCEL", null)
                .setPositiveButton("PUBLISH", null)
                .create();
        bannerDialog.setOnShowListener(ignored -> bannerDialog.getButton(Dialog.BUTTON_POSITIVE).setOnClickListener(v ->
                publishBanner(title.getText().toString().trim(), subtitle.getText().toString().trim(),
                        bannerImageUrlField.getText().toString().trim())));
        bannerDialog.show();
        */
    }

    private void chooseBannerImage() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("image/*");
        startActivityForResult(intent, 7003);
    }

    private void publishBanner(String title, String subtitle, String imageUrl) {
        if (banners.size() >= MAX_HOME_BANNERS) {
            FancyText.toast(this, "Maximum " + MAX_HOME_BANNERS + " banners reached. Delete one to add a new banner.",
                    Toast.LENGTH_LONG).show();
            if (bannerDialog != null) bannerDialog.dismiss();
            return;
        }
        String id = FirebaseRepository.banners().push().getKey();
        if (id == null) {
            FancyText.toast(this, "Could not create banner key.", Toast.LENGTH_LONG).show();
            return;
        }
        if (selectedBannerImage == null) {
            saveBanner(id, title, subtitle, imageUrl);
            return;
        }
        FancyText.toast(this, "Uploading image securely…", Toast.LENGTH_SHORT).show();
        com.arenax.tournament.data.ImgBbUploader.uploadImage(this, selectedBannerImage,
                new com.arenax.tournament.data.StorageUploader.Callback() {
                    @Override public void onSuccess(String fileUrl) {
                        saveBanner(id, title, subtitle, fileUrl);
                    }
                    @Override public void onFailure(String message) {
                        showUploadErrorDialog("Image upload failed", message);
                    }
                });
    }

    private void saveBanner(String id, String title, String subtitle, String imageUrl) {
        Map<String, Object> banner = new HashMap<>();
        banner.put("title", title);
        banner.put("subtitle", subtitle);
        banner.put("imageUrl", imageUrl);
        banner.put("displayOrder", banners.size());
        banner.put("createdAt", System.currentTimeMillis());
        banner.put("active", true);
        FirebaseRepository.saveBanner(id, banner)
                .addOnSuccessListener(unused -> {
                    FancyText.toast(this, "Banner published live.", Toast.LENGTH_SHORT).show();
                    FirebaseRepository.logActivity("BANNER_CREATED", title.isEmpty() ? "Untitled banner" : title, "");
                    if (bannerDialog != null) bannerDialog.dismiss();
                })
                .addOnFailureListener(error ->
                        FancyText.toast(this, "Banner publish failed: " + error.getMessage(), Toast.LENGTH_LONG).show());
    }

    private void confirmDeleteBanner(Banner banner) {
        String label = banner.getTitle() == null || banner.getTitle().trim().isEmpty() ? "this banner" : banner.getTitle();
        new FullScreenDialog.Builder(this)
                .setTitle("Remove " + label + "?")
                .setMessage("This banner will disappear from the User app home screen after Firebase updates.")
                .setNegativeButton("CANCEL", null)
                .setPositiveButton("REMOVE", (dialog, which) ->
                        FirebaseRepository.deleteBanner(banner.getId())
                                .addOnSuccessListener(unused -> {
                                    FancyText.toast(this, "Banner removed.", Toast.LENGTH_SHORT).show();
                                    FirebaseRepository.logActivity("BANNER_DELETED", label, "");
                                })
                                .addOnFailureListener(error -> FancyText.toast(this, error.getMessage(), Toast.LENGTH_LONG).show()))
                .show();
    }

    private void showTournamentActions(Tournament tournament) {
        String details = "Mode: " + tournament.getMode() + "\n"
                + "Date: " + tournament.getDate() + " " + tournament.getTime() + "\n"
                + "Entry: FREE   Prize: " + tournament.getPrizeInfo() + "\n"
                + "Slots: " + tournament.getJoinedSlots() + "/" + tournament.getTotalSlots();
        new FullScreenDialog.Builder(this)
                .setTitle(tournament.getTitle())
                .setMessage(details)
                .setNeutralButton("CONTROL CENTER", (dialog, which) -> {
                    Intent page = new Intent(this, TournamentControlCenterActivity.class);
                    page.putExtra("tournamentId", tournament.getId());
                    page.putExtra("title", tournament.getTitle());
                    startActivity(page);
                })
                .setNegativeButton(canCreateMatch() ? "DELETE" : "CLOSE",
                        (dialog, which) -> { if (canCreateMatch()) showDeleteConfirm(tournament); })
                .setPositiveButton("MANAGE ROOM", (dialog, which) -> {
                    Intent page = new Intent(this, RoomControlActivity.class);
                    page.putExtra(RoomControlActivity.EXTRA_TOURNAMENT, tournament);
                    startActivityForResult(page, REQUEST_ROOM_CONTROL);
                })
                .show();
    }

    private void showRoomControlDialog(Tournament tournament) {
        LinearLayout form = new LinearLayout(this);
        form.setOrientation(LinearLayout.VERTICAL);
        form.setPadding(dp(24), dp(8), dp(24), dp(8));

        TextView status = new TextView(this);
        status.setText(tournament.isRoomReleased() ? "ROOM CURRENTLY RELEASED TO PLAYERS" : "ROOM CURRENTLY HIDDEN");
        status.setTextColor(tournament.isRoomReleased() ? getColor(R.color.success) : getColor(R.color.text_secondary));
        status.setTextSize(12);
        status.setPadding(0, 0, 0, dp(10));
        form.addView(status);

        EditText roomId = field("Room ID");
        roomId.setText(tournament.getRoomId());
        EditText roomPass = field("Room Password");
        roomPass.setText(tournament.getRoomPassword());
        EditText delay = field("Delay reason (leave empty if not delayed)");
        delay.setText(tournament.getDelayReason());
        form.addView(roomId);
        form.addView(roomPass);
        form.addView(delay);

        // A8 — Waitlist control lives alongside room/slot control since both manage match capacity.
        TextView waitlistStatus = new TextView(this);
        waitlistStatus.setTextColor(getColor(R.color.text_secondary));
        waitlistStatus.setTextSize(12);
        waitlistStatus.setPadding(0, dp(14), 0, dp(4));
        waitlistStatus.setText("Checking waitlist…");
        form.addView(waitlistStatus);
        MaterialButton promote = new MaterialButton(this);
        promote.setText("PROMOTE NEXT FROM WAITLIST");
        promote.setTextColor(Color.WHITE);
        promote.setTextSize(11);
        promote.setAllCaps(false);
        promote.setCornerRadius(dp(4));
        promote.setBackgroundTintList(android.content.res.ColorStateList.valueOf(getColor(R.color.surface_3)));
        promote.setElevation(0f);
        promote.setInsetTop(0);
        promote.setInsetBottom(0);
        promote.setEnabled(false);
        form.addView(promote, new LinearLayout.LayoutParams(-1, dp(44)));
        refreshWaitlistStatus(tournament, waitlistStatus, promote);
        promote.setOnClickListener(v -> FirebaseRepository.promoteNextFromWaitlist(tournament.getId())
                .addOnSuccessListener(done -> {
                    FancyText.toast(this, "Promoted the next waitlisted player into the match.", Toast.LENGTH_SHORT).show();
                    FirebaseRepository.logActivity("WAITLIST_PROMOTED", tournament.getTitle(), "");
                    refreshWaitlistStatus(tournament, waitlistStatus, promote);
                })
                .addOnFailureListener(error -> FancyText.toast(this, error.getMessage(), Toast.LENGTH_SHORT).show()));

        FullScreenDialog.Builder builder = new FullScreenDialog.Builder(this)
                .setTitle("Room control • " + tournament.getTitle())
                .setMessage("Release sends Room ID + Password live to every registered participant instantly.")
                .setView(form)
                .setNegativeButton("CANCEL", null)
                .setNeutralButton(tournament.isRoomReleased() ? "HIDE ROOM" : "RELEASE ROOM", null)
                .setPositiveButton("SAVE", null);
        FullScreenDialog dialog = builder.create();
        dialog.setOnShowListener(ignored -> {
            dialog.getButton(Dialog.BUTTON_POSITIVE).setOnClickListener(v ->
                    updateRoom(tournament, roomId.getText().toString().trim(),
                            roomPass.getText().toString().trim(),
                            tournament.isRoomReleased(),
                            delay.getText().toString().trim(), dialog));
            dialog.getButton(Dialog.BUTTON_NEUTRAL).setOnClickListener(v ->
                    updateRoom(tournament, roomId.getText().toString().trim(),
                            roomPass.getText().toString().trim(),
                            !tournament.isRoomReleased(),
                            delay.getText().toString().trim(), dialog));
        });
        dialog.show();
    }

    /** A8 — shows the current free-waitlist count and enables "Promote" only when someone is waiting. */
    private void refreshWaitlistStatus(Tournament tournament, TextView status, MaterialButton promote) {
        FirebaseRepository.tournamentWaitlist(tournament.getId()).get()
                .addOnSuccessListener(snapshot -> {
                    long count = snapshot.getChildrenCount();
                    status.setText(count == 0 ? "Waitlist is empty." : count + " player(s) waiting for a free slot.");
                    promote.setEnabled(count > 0);
                })
                .addOnFailureListener(error -> status.setText("Waitlist unavailable: " + error.getMessage()));
    }

    /**
     * A19 — Targeted room-release push: notifies ONLY the joined participants under
     * participantsRef (a tournament's or match's "participants" node), never "All Users".
     * Looks up each participant's /users/{uid}/fcmToken, then sends via the FCM HTTP v1 API
     * through the authenticated backend relay. The admin APK never contains a
     * Firebase service-account private key; the database notice remains the
     * fallback if the relay is temporarily unavailable.
     */
    private void sendRoomReleasePush(com.google.firebase.database.DatabaseReference participantsRef,
                                      String title, String body) {
        FirebaseRepository.collectParticipantFcmTokens(participantsRef, tokens -> {
            if (tokens.isEmpty()) return;
            new Thread(() -> {
                try {
                    com.arenax.tournament.util.FcmSender.sendToAllTokens(null, tokens, title, body, "",
                            (successCount, total, errorLog) -> runOnUiThread(() ->
                                    toast("Notified " + successCount + "/" + total + " joined player(s).")));
                } catch (Exception e) {
                    runOnUiThread(() -> toast("Push notify failed: " + e.getMessage()));
                }
            }).start();
        });
    }

    private void updateRoom(Tournament t, String roomId, String roomPass, boolean released,
                             String delayReason, FullScreenDialog dialog) {
        // Manual action wins over any pending exact-time auto-release for this match/tournament.
        RoomReleaseScheduler.cancel(this, t.getId());
        Tournament updated = new Tournament(t.getId(), t.getTitle(), t.getMode(), t.getCategoryId(),
                t.getBannerUrl(), t.getDescription(), t.getDate(), t.getTime(), t.getStartAt(),
                t.getRegistrationCloseAt(), t.getRoomReleaseAt(), t.getPrizeInfo(), t.getTotalSlots(),
                t.getJoinedSlots(), t.getTeamSize(), t.getMap(), t.getMatchType(), t.getRules(),
                t.getPrizeDistribution(), roomId, roomPass, released, delayReason,
                t.getStatus(), t.getRegistrationStatus(), t.isActive(), t.getAccentColor());
        updated.setCoinDetails(t.getEntryFeeCoins(), t.getPrizePoolCoins(), t.getPerKillCoins(), t.getGameType());
        updated.setResultSystem(t.getResultSystem());
        FirebaseRepository.saveTournament(updated)
                .addOnSuccessListener(unused -> {
                    FancyText.toast(this, released ? "Room released live to players." : "Room hidden from players.",
                            Toast.LENGTH_SHORT).show();
                    FirebaseRepository.logActivity(released ? "ROOM_RELEASED" : "ROOM_HIDDEN", t.getTitle(), delayReason);
                    FirebaseRepository.publishNotification(
                            released ? "Room Released" : "Room Update",
                            released ? t.getTitle() + " room ID & password are now live."
                                    : (delayReason.isEmpty() ? t.getTitle() + " room hidden."
                                    : t.getTitle() + " delayed: " + delayReason));
                    if (released) {
                        sendRoomReleasePush(FirebaseRepository.tournamentParticipants(t.getId()),
                                t.getTitle() + " — Room Released!",
                                "Room ID: " + roomId + " | Password: " + roomPass);
                    }
                    dialog.dismiss();
                })
                .addOnFailureListener(error -> FancyText.toast(this, error.getMessage(), Toast.LENGTH_LONG).show());
    }

    /** Cancel sits next to Delete. 1VS1 -> Completed + manual coin leaderboard; other modes -> normal cancel. */
    private void showCancelConfirm(Tournament tournament) {
        final boolean battle = "BATTLE_1V1".equals(tournament.getResultSystem());
        new FullScreenDialog.Builder(this)
                .setTitle("Cancel " + tournament.getTitle() + "?")
                .setMessage(battle
                        ? "Match Completed me chala jayega aur joining band ho jayegi. Koi coin apne aap wapas nahi jayega; "
                          + "coins ya refund Rank Manage se manually do."
                        : "Players will not be able to join. Paid matches with joined players must be refunded first.")
                .setNegativeButton("BACK", null)
                .setPositiveButton("CANCEL MATCH", (confirm, ignored) -> (battle
                        ? FirebaseRepository.cancelNoOpponent(tournament.getId())
                        : FirebaseRepository.cancelTournament(tournament, "Cancelled by admin"))
                        .addOnSuccessListener(done -> {
                            FancyText.toast(this, battle ? "Match Completed me chala gaya." : "Match cancelled.", Toast.LENGTH_SHORT).show();
                            FirebaseRepository.logActivity("TOURNAMENT_CANCELLED", tournament.getTitle(), "");
                        })
                        .addOnFailureListener(error -> FancyText.toast(this, error.getMessage(), Toast.LENGTH_LONG).show()))
                .show();
    }

    private void showDeleteConfirm(Tournament tournament) {
        new FullScreenDialog.Builder(this)
                        .setTitle("Delete " + tournament.getTitle() + "?")
                        .setMessage("This permanently removes the live Firebase tournament record.")
                        .setNegativeButton("CANCEL", null)
                        .setPositiveButton("DELETE", (confirm, ignored) -> FirebaseRepository.deleteTournament(tournament.getId())
                                .addOnSuccessListener(done -> {
                                    FancyText.toast(this, "Tournament deleted.", Toast.LENGTH_SHORT).show();
                                    FirebaseRepository.logActivity("TOURNAMENT_DELETED", tournament.getTitle(), "");
                                })
                                .addOnFailureListener(error -> FancyText.toast(this, error.getMessage(), Toast.LENGTH_LONG).show()))
                .show();
    }

    private void setupNavigation() {
        int[] ids = {R.id.admin_nav_dashboard, R.id.admin_nav_users, R.id.admin_nav_battles,
                R.id.admin_nav_tournaments, R.id.admin_nav_esports, R.id.admin_nav_category,
                R.id.admin_nav_teams, R.id.admin_nav_matches, R.id.admin_nav_payments, R.id.admin_nav_results, R.id.admin_nav_disputes,
                R.id.admin_nav_reports, R.id.admin_nav_faq,
                R.id.admin_nav_notice, R.id.admin_nav_analytics, R.id.admin_nav_activity, R.id.admin_nav_settings,
                R.id.admin_nav_roles};
        String[] pages = {"dashboard", "users", "battles", "tournaments", "esports", "category",
                "teams", "matches", "payments", "results", "disputes", "reports", "faq",
                "notice", "analytics", "activity", "settings", "roles"};
        for (int i = 0; i < ids.length; i++) {
            final String page = pages[i];
            View view = findViewById(ids[i]);
            if (view != null) view.setOnClickListener(v -> showWorkspacePage(page));
        }
    }

    private void showWorkspacePage(String page) {
        if ("dashboard".equals(page)) {
            resetWorkspaceChrome(null);
            workspaceScroll.setVisibility(View.GONE);
            dashboardScroll.setVisibility(View.VISIBLE);
            return;
        }
        if ("roles".equals(page) && "SUPER_ADMIN".equals(adminRole)) {
            Intent hub = new Intent(this, AdminWorkHubActivity.class);
            hub.putExtra(AdminWorkHubActivity.EXTRA_OWNER, true);
            startActivity(hub);
            return;
        }
        // A1 — hidden nav rows already stop normal taps, but this blocks any direct call too
        // (client-side only: true enforcement still needs the Firebase rules / custom claims layer).
        java.util.Set<String> allowed = rolePages();
        boolean pageAllowed = "bannerlinks".equals(page) ? hasPerm("banners")
                : "revenue".equals(page) ? (allowed.contains("analytics") || allowed.contains("payments"))
                : allowed.contains(page);
        if (!pageAllowed) {
            FancyText.toast(this, "Your admin role does not have access to this section.", Toast.LENGTH_SHORT).show();
            return;
        }
        dashboardScroll.setVisibility(View.GONE);
        workspaceScroll.setVisibility(View.VISIBLE);
        workspaceContent.removeAllViews();
        resetWorkspaceChrome(() -> showWorkspacePage(page));
        activeTournament = null;
        if (!"users".equals(page) && !"payments".equals(page)) {
            TextView title = pageTitle(page);
            workspaceContent.addView(title);
        }
        if ("users".equals(page)) loadUsersPage();
        else if ("battles".equals(page) || "tournaments".equals(page)) loadTournamentsPage(page);
        else if ("esports".equals(page) || "category".equals(page)) loadCategoriesPage();
        else if ("teams".equals(page)) loadTeamsPage();
        else if ("matches".equals(page)) loadMatchesPage();
        else if ("payments".equals(page)) loadPaymentsPage();
        else if ("results".equals(page)) loadResultsPage();
        else if ("disputes".equals(page)) loadDisputesPage();
        else if ("reports".equals(page)) loadReportsPage();
        else if ("faq".equals(page)) loadFaqPage();
        else if ("notice".equals(page)) loadNoticePage();
        else if ("analytics".equals(page)) loadAnalyticsPage();
        else if ("revenue".equals(page)) loadRevenuePage();
        else if ("activity".equals(page)) loadActivityLogPage();
        else if ("settings".equals(page)) loadSettingsPage();
        else if ("roles".equals(page)) loadRolesPage();
        else if ("bannerlinks".equals(page)) loadBannerLinksPage();
        else if ("terms".equals(page) || "privacy".equals(page) || "about".equals(page)) loadContentPage(page);
    }

    private TextView pageTitle(String page) {
        Map<String, String> labels = new HashMap<>();
        labels.put("users", "User Management"); labels.put("battles", "Battle Management");
        labels.put("tournaments", "Tournaments"); labels.put("esports", "Esports Categories");
        labels.put("category", "Categories"); labels.put("teams", "Teams");
        labels.put("matches", "Match Management"); labels.put("payments", "Payment Management");
        labels.put("results", "Results & Leaderboard"); labels.put("disputes", "Disputes");
        labels.put("reports", "Reports & Moderation"); labels.put("faq", "FAQ Management");
        labels.put("notice", "Notifications & Logs"); labels.put("analytics", "Analytics"); labels.put("revenue", "Revenue Dashboard");
        labels.put("activity", "Activity Log"); labels.put("settings", "Settings"); labels.put("roles", "Roles & Permissions"); labels.put("bannerlinks", "Banner Customer Support Link");
        labels.put("terms", "Terms & Conditions"); labels.put("privacy", "Privacy Policy"); labels.put("about", "About Us");
        String key = page == null ? "" : page.toLowerCase(Locale.ENGLISH);
        TextView title = pageText(labels.containsKey(key) ? labels.get(key) : page);
        title.setTextSize(21);
        title.setTextColor(getColor(R.color.text_primary));
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        title.setPadding(0, dp(10), 0, dp(2));
        return title;
    }

    private TextView pageText(String value) {
        TextView text = new TextView(this);
        text.setText(value);
        text.setTextColor(getColor(R.color.text_secondary));
        text.setTextSize(11.5f);
        text.setLineSpacing(0f, 1.08f);
        text.setPadding(0, dp(3), 0, dp(3));
        return text;
    }

    /** Like iconButton but shows an emoji (e.g. the 🪙 coin) instead of a tinted vector. */
    private TextView emojiButton(String emoji, int tintRes, int strokeRes, String description, View.OnClickListener listener) {
        TextView t = new TextView(this);
        t.setText(emoji);
        t.setTextSize(21);
        t.setGravity(Gravity.CENTER);
        android.graphics.drawable.GradientDrawable bg = new android.graphics.drawable.GradientDrawable();
        bg.setCornerRadius(dp(6));
        bg.setColor(getColor(tintRes));
        bg.setStroke(dp(1), getColor(strokeRes));
        t.setBackground(bg);
        t.setContentDescription(description);
        t.setOnClickListener(listener);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(44), dp(44));
        lp.setMarginStart(dp(6));
        lp.setMarginEnd(dp(6));
        t.setLayoutParams(lp);
        return t;
    }

    /** Icon-only action (no text button): tinted rounded square, 44dp. */
    private ImageView iconButton(int iconRes, int colorRes, int tintRes, int strokeRes, String description, View.OnClickListener listener) {
        ImageView icon = new ImageView(this);
        icon.setImageResource(iconRes);
        icon.setImageTintList(android.content.res.ColorStateList.valueOf(getColor(colorRes)));
        android.graphics.drawable.GradientDrawable bg = new android.graphics.drawable.GradientDrawable();
        bg.setCornerRadius(dp(6));
        bg.setColor(getColor(tintRes));
        bg.setStroke(dp(1), getColor(strokeRes));
        icon.setBackground(bg);
        icon.setPadding(dp(11), dp(11), dp(11), dp(11));
        icon.setContentDescription(description);
        icon.setOnClickListener(listener);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(44), dp(44));
        lp.setMarginStart(dp(6));
        lp.setMarginEnd(dp(6));
        icon.setLayoutParams(lp);
        return icon;
    }

    /** Player card background: small radius, red outline when banned. */
    private android.graphics.drawable.GradientDrawable playerCardBg(boolean banned) {
        android.graphics.drawable.GradientDrawable d = new android.graphics.drawable.GradientDrawable();
        d.setCornerRadius(dp(8));
        d.setColor(getColor(banned ? R.color.admin_red_tint : R.color.surface));
        d.setStroke(dp(banned ? 2 : 1), getColor(banned ? R.color.admin_red : R.color.stroke));
        return d;
    }

    /** Equal-size labelled action button (weight 1, 44dp tall, 6dp radius) so Coin + Ban sit level, side by side. */
    private TextView actionButton(String text, int textColorRes, int tintRes, int strokeRes,
                                  String description, View.OnClickListener listener) {
        TextView b = new TextView(this);
        b.setText(text);
        b.setTextSize(13);
        b.setTypeface(null, android.graphics.Typeface.BOLD);
        b.setGravity(Gravity.CENTER);
        b.setSingleLine(true);
        b.setIncludeFontPadding(false);
        b.setTextColor(getColor(textColorRes));
        android.graphics.drawable.GradientDrawable bg = new android.graphics.drawable.GradientDrawable();
        bg.setCornerRadius(dp(6));
        bg.setColor(getColor(tintRes));
        bg.setStroke(dp(1), getColor(strokeRes));
        b.setBackground(bg);
        b.setContentDescription(description);
        b.setOnClickListener(listener);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(44), 1f);
        lp.setMarginStart(dp(4));
        lp.setMarginEnd(dp(4));
        b.setLayoutParams(lp);
        return b;
    }

    /** Ban / Unban (green "Unban" for banned players, red "Ban" for active ones). */
    private TextView banToggleButton(boolean banned, View.OnClickListener listener) {
        return actionButton(banned ? "✓  Unban" : "⛔  Ban",
                banned ? R.color.admin_green : R.color.admin_red,
                banned ? R.color.admin_green_tint : R.color.admin_red_tint,
                banned ? R.color.admin_green : R.color.admin_red,
                banned ? "Unban player" : "Ban player", listener);
    }

    private MaterialButton pageButton(String label, View.OnClickListener listener) {
        MaterialButton button = new MaterialButton(this);
        button.setText(label);
        button.setTextColor(getColor(R.color.admin_blue));
        button.setTextSize(12);
        button.setTypeface(null, android.graphics.Typeface.BOLD);
        button.setAllCaps(false);
        button.setLetterSpacing(0.02f);
        button.setCornerRadius(dp(4));
        button.setBackgroundTintList(android.content.res.ColorStateList.valueOf(getColor(R.color.admin_blue_tint)));
        button.setStrokeColor(android.content.res.ColorStateList.valueOf(getColor(R.color.admin_blue)));
        button.setStrokeWidth(dp(1));
        button.setRippleColor(android.content.res.ColorStateList.valueOf(getColor(R.color.admin_blue_tint)));
        button.setElevation(0f);
        button.setInsetTop(0);
        button.setInsetBottom(0);
        button.setOnClickListener(listener);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(44));
        p.topMargin = dp(10);
        workspaceContent.addView(button, p);
        return button;
    }

    private MaterialButton pageButtonTonal(String label, int tintColorRes, int strokeColorRes, View.OnClickListener listener) {
        MaterialButton button = new MaterialButton(this);
        button.setText(label);
        button.setTextColor(getColor(tintColorRes));
        button.setTextSize(12);
        button.setTypeface(null, android.graphics.Typeface.BOLD);
        button.setAllCaps(false);
        button.setLetterSpacing(0.02f);
        button.setCornerRadius(dp(4));
        button.setBackgroundTintList(android.content.res.ColorStateList.valueOf(getColor(tintColorRes == R.color.accent_purple ? R.color.accent_purple_tint
                : tintColorRes == R.color.accent_blue ? R.color.accent_blue_tint
                : tintColorRes == R.color.accent_green ? R.color.accent_green_tint
                : R.color.accent_yellow_tint)));
        button.setStrokeColor(android.content.res.ColorStateList.valueOf(getColor(strokeColorRes)));
        button.setStrokeWidth(dp(1));
        button.setRippleColor(android.content.res.ColorStateList.valueOf(getColor(strokeColorRes)));
        button.setElevation(0f);
        button.setInsetTop(0);
        button.setInsetBottom(0);
        button.setOnClickListener(listener);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(44));
        p.topMargin = dp(10);
        workspaceContent.addView(button, p);
        return button;
    }

    private void loadUsersPage() {
        // Refresh = pull down. Coin history = inside each user's info page. Coin requests = bell (top right).

        EditText search = new EditText(this);
        search.setHint("Search by Name, UID, Gmail or Profile No...");
        search.setHintTextColor(getColor(R.color.text_muted));
        search.setTextColor(getColor(R.color.text_primary));
        search.setTextSize(13);
        search.setSingleLine(true);
        search.setPadding(dp(16), dp(12), dp(16), dp(12));
        android.graphics.drawable.GradientDrawable searchBg = new android.graphics.drawable.GradientDrawable();
        searchBg.setColor(getColor(R.color.surface_2));
        searchBg.setCornerRadius(dp(4));
        searchBg.setStroke(dp(1), getColor(R.color.admin_card_stroke));
        search.setBackground(searchBg);
        LinearLayout.LayoutParams searchLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        searchLp.topMargin = dp(10);
        search.setLayoutParams(searchLp);
        workspaceContent.addView(search);

        // Tabs (icons + count): all players | banned players
        LinearLayout tabs = new LinearLayout(this);
        tabs.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams tabsLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        tabsLp.topMargin = dp(10);
        workspaceContent.addView(tabs, tabsLp);
        TextView allTab = userTab(R.drawable.ic_profile);
        TextView bannedTab = userTab(R.drawable.ic_block);
        tabs.addView(allTab);
        tabs.addView(bannedTab);

        LinearLayout listHolder = new LinearLayout(this);
        listHolder.setOrientation(LinearLayout.VERTICAL);
        workspaceContent.addView(listHolder);

        final boolean[] showBanned = {false};
        final java.util.List<View> rows = new java.util.ArrayList<>();
        final java.util.List<Boolean> bannedFlags = new java.util.ArrayList<>();
        final int[] counts = {0, 0};
        Runnable applyFilter = () -> {
            String query = search.getText().toString().trim().toLowerCase(Locale.ENGLISH);
            if (query.startsWith("#")) query = query.substring(1).trim();
            styleUserTab(allTab, !showBanned[0], R.color.admin_blue, R.color.admin_blue_tint, counts[0]);
            styleUserTab(bannedTab, showBanned[0], R.color.admin_red, R.color.admin_red_tint, counts[1]);
            int shown = 0;
            for (int i2 = 0; i2 < rows.size(); i2++) {
                View rowView = rows.get(i2);
                boolean isBanned = bannedFlags.get(i2);
                String haystack = rowView.getTag() == null ? "" : String.valueOf(rowView.getTag());
                boolean ok = (showBanned[0] == isBanned) && (query.isEmpty() || haystack.contains(query));
                rowView.setVisibility(ok ? View.VISIBLE : View.GONE);
                if (ok) shown++;
            }
            emptyLabel(listHolder, shown == 0 && !rows.isEmpty(), showBanned[0] ? "No banned players" : "No active players found");
        };
        allTab.setOnClickListener(v -> { showBanned[0] = false; applyFilter.run(); });
        bannedTab.setOnClickListener(v -> { showBanned[0] = true; applyFilter.run(); });
        styleUserTab(allTab, true, R.color.admin_blue, R.color.admin_blue_tint, 0);
        styleUserTab(bannedTab, false, R.color.admin_red, R.color.admin_red_tint, 0);

        search.addTextChangedListener(new android.text.TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) { applyFilter.run(); }
            @Override public void afterTextChanged(android.text.Editable s) { }
        });

        FirebaseRepository.users().addListenerForSingleValueEvent(new ValueEventListener() {
            @Override public void onDataChange(DataSnapshot snapshot) {
                listHolder.removeAllViews();
                rows.clear();
                bannedFlags.clear();
                counts[0] = 0;
                counts[1] = 0;
                for (DataSnapshot child : snapshot.getChildren()) {
                    boolean isBanned = "BANNED".equals(String.valueOf(child.child("status").getValue()).toUpperCase(Locale.ENGLISH));
                    View row = buildPlayerRow(child);
                    listHolder.addView(row);
                    rows.add(row);
                    bannedFlags.add(isBanned);
                    if (isBanned) counts[1]++; else counts[0]++;
                }
                applyFilter.run();
            }
            @Override public void onCancelled(DatabaseError error) { workspaceContent.addView(pageText("Users unavailable: " + error.getMessage())); }
        });
    }

    private TextView userTab(int iconRes) {
        TextView t = new TextView(this);
        t.setGravity(Gravity.CENTER);
        t.setTextSize(15);
        t.setTypeface(null, android.graphics.Typeface.BOLD);
        t.setCompoundDrawablePadding(dp(8));
        t.setTag(iconRes);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(46), 1f);
        lp.setMarginEnd(dp(6));
        t.setLayoutParams(lp);
        return t;
    }

    private void styleUserTab(TextView tab, boolean active, int colorRes, int tintRes, int count) {
        int color = getColor(active ? colorRes : R.color.text_muted);
        android.graphics.drawable.Drawable icon = getDrawable((Integer) tab.getTag()).mutate();
        icon.setTint(color);
        icon.setBounds(0, 0, dp(20), dp(20));
        tab.setCompoundDrawables(icon, null, null, null);
        tab.setText(String.valueOf(count));
        tab.setTextColor(color);
        tab.setContentDescription(colorRes == R.color.admin_red ? "Banned players" : "All players");
        android.graphics.drawable.GradientDrawable bg = new android.graphics.drawable.GradientDrawable();
        bg.setCornerRadius(dp(8));
        bg.setColor(getColor(active ? tintRes : R.color.surface));
        bg.setStroke(dp(active ? 2 : 1), getColor(active ? colorRes : R.color.admin_card_stroke));
        tab.setBackground(bg);
    }

    private void emptyLabel(LinearLayout holder, boolean show, String text) {
        View old = holder.findViewWithTag("empty");
        if (old != null) holder.removeView(old);
        if (!show) return;
        TextView t = pageText(text);
        t.setTag("empty");
        t.setGravity(Gravity.CENTER);
        t.setPadding(0, dp(30), 0, dp(30));
        holder.addView(t);
    }

    /** Shows the player's profile photo (round) when they have one, else the default person icon. */
    private void bindUserAvatar(ImageView avatar, String photoUrl, int padDp) {
        avatar.setImageResource(R.drawable.ic_profile);
        avatar.setImageTintList(android.content.res.ColorStateList.valueOf(getColor(R.color.admin_blue)));
        avatar.setPadding(dp(padDp), dp(padDp), dp(padDp), dp(padDp));
        if (photoUrl == null || photoUrl.trim().isEmpty() || "null".equals(photoUrl.trim())) return;
        if (isFinishing() || isDestroyed()) return; // Glide throws if the activity is already gone
        com.bumptech.glide.Glide.with(getApplicationContext()).load(photoUrl.trim())
                .transform(new com.bumptech.glide.load.resource.bitmap.CircleCrop())
                .listener(new com.bumptech.glide.request.RequestListener<android.graphics.drawable.Drawable>() {
                    @Override public boolean onLoadFailed(com.bumptech.glide.load.engine.GlideException e, Object model,
                            com.bumptech.glide.request.target.Target<android.graphics.drawable.Drawable> target, boolean isFirst) { return false; }
                    @Override public boolean onResourceReady(android.graphics.drawable.Drawable r, Object model,
                            com.bumptech.glide.request.target.Target<android.graphics.drawable.Drawable> target,
                            com.bumptech.glide.load.DataSource src, boolean isFirst) {
                        avatar.setImageTintList(null);
                        avatar.setPadding(0, 0, 0, 0);
                        return false;
                    }
                }).into(avatar);
    }

    /** A10 — Player Management card: avatar, status pill, matches/winnings stats, View Details + Block actions. */
    private android.view.View buildPlayerRow(DataSnapshot child) {
        String uid = child.getKey();
        Object raw = child.getValue();
        Map<String, Object> data = raw instanceof Map ? (Map<String, Object>) raw : null;
        String name = data == null || data.get("name") == null ? "" : String.valueOf(data.get("name"));
        String email = data == null || data.get("email") == null ? "" : String.valueOf(data.get("email"));
        String phone = data == null || data.get("phone") == null ? "" : String.valueOf(data.get("phone"));
        String status = data == null || data.get("status") == null ? "ACTIVE" : String.valueOf(data.get("status")).toUpperCase(Locale.ENGLISH);
        boolean banned = "BANNED".equals(status);

        long matchesCount = 0;
        Object matchesRaw = data == null ? null : data.get("matches");
        if (matchesRaw instanceof Number) matchesCount = ((Number) matchesRaw).longValue();

        long winnings = 0;
        Object walletRaw = data == null ? null : data.get("wallet");
        if (walletRaw instanceof Map) {
            Object balance = ((Map<String, Object>) walletRaw).get("balance");
            if (balance instanceof Number) winnings = ((Number) balance).longValue();
        }

        String displayName = name.isEmpty() || "null".equals(name) ? "STARX24 Player" : name;
        String shortId = uid == null ? "" : uid.substring(Math.max(0, uid.length() - 6)).toUpperCase(Locale.ENGLISH);
        final long finalMatchesCount = matchesCount;
        final long finalWinnings = winnings;

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        if (banned) {
            card.setBackground(playerCardBg(true));
        } else {
            card.setBackground(playerCardBg(false));
        }
        card.setPadding(dp(14), dp(14), dp(14), dp(14));
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        cp.topMargin = dp(10);
        card.setLayoutParams(cp);
        card.setTag((displayName + " " + email + " " + phone + " " + shortId + " " + uid).toLowerCase(Locale.ENGLISH));
        final String photoUrl = data == null || data.get("photoUrl") == null ? "" : String.valueOf(data.get("photoUrl"));

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        card.addView(header);

        ImageView avatar = new ImageView(this);
        android.graphics.drawable.GradientDrawable avatarBg = new android.graphics.drawable.GradientDrawable();
        avatarBg.setShape(android.graphics.drawable.GradientDrawable.OVAL);
        avatarBg.setColor(getColor(R.color.admin_blue_tint));
        avatarBg.setStroke(dp(1), getColor(R.color.admin_blue));
        avatar.setBackground(avatarBg);
        bindUserAvatar(avatar, photoUrl, 11);
        header.addView(avatar, new LinearLayout.LayoutParams(dp(48), dp(48)));

        LinearLayout nameCol = new LinearLayout(this);
        nameCol.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams nameLp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        nameLp.leftMargin = dp(12);
        TextView nameText = pageText(displayName);
        nameText.setTextColor(getColor(R.color.text_primary));
        nameText.setTextSize(15);
        nameText.setTypeface(null, android.graphics.Typeface.BOLD);
        nameText.setPadding(0, 0, 0, 0);
        TextView idText = pageText("Profile No: " + (shortId.isEmpty() ? "—" : shortId));
        idText.setPadding(0, dp(2), 0, 0);
        nameCol.addView(nameText);
        nameCol.addView(idText);
        TextView mailText = pageText("Gmail: " + (email.isEmpty() || "null".equals(email) ? "—" : email));
        nameCol.addView(mailText);
        TextView uidLine = pageText("UID: " + (uid == null ? "—" : uid));
        if (banned) {
            uidLine.setTextColor(getColor(R.color.admin_red));
            uidLine.setTypeface(null, android.graphics.Typeface.BOLD);
            uidLine.setOnClickListener(v -> {
                android.content.ClipboardManager cm = (android.content.ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
                if (cm != null) cm.setPrimaryClip(android.content.ClipData.newPlainText("uid", uid));
                toast("UID copied");
            });
        }
        nameCol.addView(uidLine);
        header.addView(nameCol, nameLp);

        TextView statusPill = new TextView(this);
        statusPill.setText(banned ? "● Banned" : "● Active");
        statusPill.setTextSize(11);
        statusPill.setTypeface(null, android.graphics.Typeface.BOLD);
        statusPill.setPadding(dp(10), dp(5), dp(10), dp(5));
        android.graphics.drawable.GradientDrawable pillBg = new android.graphics.drawable.GradientDrawable();
        pillBg.setCornerRadius(dp(4));
        pillBg.setColor(getColor(banned ? R.color.surface : R.color.admin_green_tint));
        statusPill.setBackground(pillBg);
        statusPill.setTextColor(getColor(banned ? R.color.admin_red : R.color.admin_green));
        header.addView(statusPill);

        android.view.View divider = new android.view.View(this);
        LinearLayout.LayoutParams divLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(1));
        divLp.topMargin = dp(14);
        divLp.bottomMargin = dp(12);
        divider.setBackgroundColor(getColor(banned ? R.color.admin_red : R.color.admin_card_stroke));
        card.addView(divider, divLp);

        LinearLayout statsRow = new LinearLayout(this);
        statsRow.setOrientation(LinearLayout.HORIZONTAL);
        statsRow.addView(statChip(R.drawable.ic_trophy, String.valueOf(matchesCount), "Matches"));
        statsRow.addView(statChip(0, groupDigits(winnings), "Coins"));
        card.addView(statsRow);

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams actionsLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        actionsLp.topMargin = dp(14);
        actions.setLayoutParams(actionsLp);

        card.setOnClickListener(v -> showUserDetailPage(uid, displayName, email, phone, status, finalMatchesCount, finalWinnings));
        actions.setGravity(Gravity.CENTER_VERTICAL);
        if (canEditCoins()) {
            actions.addView(actionButton(CoinEmoji.EMOJI + "  Coins", R.color.text_primary, R.color.accent_yellow_tint, R.color.coin_gold,
                    "Coin edit", v -> showCoinEditPage(uid, displayName, () -> showWorkspacePage("users"))));
        }
        actions.addView(banToggleButton(banned, v -> moderatePlayer(uid, displayName, banned ? "ACTIVE" : "BANNED")));
        card.addView(actions);
        return card;
    }

    /** One "Matches" or "Winnings" stat with a small leading icon, used inside a player card. */
    private LinearLayout statChip(int iconRes, String value, String label) {
        LinearLayout chip = new LinearLayout(this);
        chip.setOrientation(LinearLayout.HORIZONTAL);
        chip.setGravity(Gravity.CENTER_VERTICAL);
        chip.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        if (iconRes == 0) {
            TextView coin = new TextView(this);
            coin.setText(CoinEmoji.EMOJI);
            coin.setTextSize(18);
            coin.setGravity(Gravity.CENTER);
            LinearLayout.LayoutParams coinLp = new LinearLayout.LayoutParams(dp(22), dp(22));
            coinLp.rightMargin = dp(8);
            chip.addView(coin, coinLp);
        } else {
            ImageView icon = new ImageView(this);
            icon.setImageResource(iconRes);
            icon.setImageTintList(android.content.res.ColorStateList.valueOf(getColor(R.color.text_muted)));
            LinearLayout.LayoutParams iconLp = new LinearLayout.LayoutParams(dp(18), dp(18));
            iconLp.rightMargin = dp(8);
            chip.addView(icon, iconLp);
        }

        LinearLayout textCol = new LinearLayout(this);
        textCol.setOrientation(LinearLayout.VERTICAL);
        TextView valueText = pageText(value);
        valueText.setTextColor(getColor(R.color.text_primary));
        valueText.setTypeface(null, android.graphics.Typeface.BOLD);
        valueText.setTextSize(14);
        valueText.setPadding(0, 0, 0, 0);
        TextView labelText = pageText(label);
        labelText.setTextSize(11);
        labelText.setPadding(0, 0, 0, 0);
        textCol.addView(valueText);
        textCol.addView(labelText);
        chip.addView(textCol);
        return chip;
    }

    private String groupDigits(long value) {
        return java.text.NumberFormat.getIntegerInstance(Locale.US).format(value);
    }

    /** Full-screen "User Profile" page shown from "View Details" (replaces the old floating dialog). */
    private void showUserDetailPage(String uid, String name, String email, String phone, String status,
                                     long matches, long winnings) {
        boolean banned = "BANNED".equals(status);
        workspaceContent.removeAllViews();
        resetWorkspaceChrome(() -> refreshUserDetailFromDb(uid));
        activeTournament = null;

        // Back row
        LinearLayout backRow = new LinearLayout(this);
        backRow.setOrientation(LinearLayout.HORIZONTAL);
        backRow.setGravity(Gravity.CENTER_VERTICAL);
        backRow.setPadding(0, dp(8), 0, 0);
        ImageView backIcon = new ImageView(this);
        backIcon.setImageResource(R.drawable.ic_arrow_back);
        backIcon.setImageTintList(android.content.res.ColorStateList.valueOf(getColor(R.color.text_primary)));
        backRow.addView(backIcon, new LinearLayout.LayoutParams(dp(20), dp(20)));
        TextView backText = pageText("Back to Users");
        backText.setTextColor(getColor(R.color.text_primary));
        backText.setTypeface(null, android.graphics.Typeface.BOLD);
        backText.setTextSize(13);
        LinearLayout.LayoutParams backTextLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        backTextLp.leftMargin = dp(8);
        backRow.addView(backText, backTextLp);
        backRow.setOnClickListener(v -> showWorkspacePage("users"));
        workspaceContent.addView(backRow);

        TextView title = pageText("User Profile");
        title.setTextSize(21);
        title.setTextColor(getColor(R.color.text_primary));
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        title.setPadding(0, dp(10), 0, dp(4));
        workspaceContent.addView(title);

        // Outer card
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        if (banned) {
            card.setBackground(playerCardBg(true));
        } else {
            card.setBackground(playerCardBg(false));
        }
        card.setPadding(dp(18), dp(20), dp(18), dp(20));
        LinearLayout.LayoutParams cardLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        cardLp.topMargin = dp(6);
        workspaceContent.addView(card, cardLp);

        // Avatar (centered)
        ImageView avatar = new ImageView(this);
        android.graphics.drawable.GradientDrawable avatarBg = new android.graphics.drawable.GradientDrawable();
        avatarBg.setShape(android.graphics.drawable.GradientDrawable.OVAL);
        avatarBg.setColor(getColor(R.color.admin_blue_tint));
        avatarBg.setStroke(dp(1), getColor(R.color.admin_blue));
        avatar.setBackground(avatarBg);
        bindUserAvatar(avatar, "", 20);
        FirebaseRepository.users().child(uid).child("photoUrl").get().addOnSuccessListener(ps -> {
            Object pv = ps.getValue();
            if (pv != null) bindUserAvatar(avatar, String.valueOf(pv), 20);
        });
        LinearLayout.LayoutParams avatarLp = new LinearLayout.LayoutParams(dp(76), dp(76));
        avatarLp.gravity = Gravity.CENTER_HORIZONTAL;
        card.addView(avatar, avatarLp);

        // Name (centered)
        TextView nameText = pageText(name == null || name.isEmpty() ? "STARX24 Player" : name);
        nameText.setTextColor(getColor(R.color.text_primary));
        nameText.setTypeface(null, android.graphics.Typeface.BOLD);
        nameText.setTextSize(21);
        nameText.setGravity(Gravity.CENTER_HORIZONTAL);
        nameText.setPadding(0, dp(12), 0, dp(18));
        card.addView(nameText);

        // Status row
        LinearLayout statusRow = detailRowContainer();
        TextView statusDot = new TextView(this);
        statusDot.setText("●");
        statusDot.setTextColor(getColor(banned ? R.color.admin_red : R.color.admin_green));
        statusDot.setTextSize(16);
        statusRow.addView(statusDot, new LinearLayout.LayoutParams(dp(22), ViewGroup.LayoutParams.WRAP_CONTENT));
        statusRow.addView(detailRowText("Status: " + status));
        card.addView(statusRow);

        // Matches / Winnings row
        LinearLayout statsRow = detailRowContainer();
        ImageView trophyIcon = detailRowIcon(R.drawable.ic_trophy);
        statsRow.addView(trophyIcon);
        LinearLayout statsCol = new LinearLayout(this);
        statsCol.setOrientation(LinearLayout.VERTICAL);
        statsCol.addView(detailRowText("Matches: " + matches));
        statsCol.addView(detailRowText("Coins: " + groupDigits(winnings)));
        statsRow.addView(statsCol);
        card.addView(statsRow);

        // Phone / Email row
        LinearLayout contactRow = detailRowContainer();
        LinearLayout contactIconCol = new LinearLayout(this);
        contactIconCol.setOrientation(LinearLayout.VERTICAL);
        contactIconCol.addView(detailRowIcon(R.drawable.ic_phone));
        ImageView emailIcon = detailRowIcon(R.drawable.ic_email);
        LinearLayout.LayoutParams emailIconLp = new LinearLayout.LayoutParams(dp(22), dp(22));
        emailIconLp.topMargin = dp(10);
        contactIconCol.addView(emailIcon, emailIconLp);
        contactRow.addView(contactIconCol);
        LinearLayout contactCol = new LinearLayout(this);
        contactCol.setOrientation(LinearLayout.VERTICAL);
        contactCol.addView(detailRowText("Phone: " + (phone.isEmpty() || "null".equals(phone) ? "—" : phone)));
        TextView emailText = detailRowText("Email: " + (email.isEmpty() || "null".equals(email) ? "—" : email));
        LinearLayout.LayoutParams emailTextLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        emailTextLp.topMargin = dp(10);
        contactCol.addView(emailText, emailTextLp);
        contactRow.addView(contactCol);
        card.addView(contactRow);

        // Password row
        LinearLayout passwordRow = detailRowContainer();
        passwordRow.addView(detailRowIcon(R.drawable.ic_lock));
        LinearLayout passwordTextRow = new LinearLayout(this);
        passwordTextRow.setOrientation(LinearLayout.HORIZONTAL);
        passwordTextRow.setGravity(Gravity.CENTER_VERTICAL);
        TextView passwordLabel = detailRowText("Password: [Encrypted] / ");
        passwordTextRow.addView(passwordLabel);
        TextView resetLink = detailRowText("Send Reset Link");
        resetLink.setTextColor(getColor(R.color.admin_blue));
        resetLink.setTypeface(null, android.graphics.Typeface.BOLD);
        boolean hasEmail = !email.isEmpty() && !"null".equals(email);
        resetLink.setOnClickListener(v -> {
            if (!hasEmail) { toast("No email on file for this player."); return; }
            new FullScreenDialog.Builder(this)
                    .setTitle("Send password reset link?")
                    .setMessage("A password reset email will be sent to " + email + ".")
                    .setNegativeButton("CANCEL", null)
                    .setPositiveButton("SEND", (d, w) -> FirebaseAuth.getInstance().sendPasswordResetEmail(email)
                            .addOnSuccessListener(u -> toast("Reset link sent to " + email))
                            .addOnFailureListener(e -> toast("Failed: " + e.getMessage())))
                    .show();
        });
        passwordTextRow.addView(resetLink);
        passwordRow.addView(passwordTextRow);
        card.addView(passwordRow);

        // UID row
        LinearLayout uidRow = detailRowContainer();
        uidRow.addView(detailRowIcon(R.drawable.ic_info));
        LinearLayout uidCol = new LinearLayout(this);
        uidCol.setOrientation(LinearLayout.VERTICAL);
        uidCol.addView(detailRowText("UID:"));
        TextView uidValue = detailRowText(uid == null ? "—" : uid);
        LinearLayout.LayoutParams uidValueLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        uidValueLp.topMargin = dp(2);
        uidCol.addView(uidValue, uidValueLp);
        uidRow.addView(uidCol);
        card.addView(uidRow);

        // Profile number (short ID shown on the users list)
        LinearLayout profNoRow = detailRowContainer();
        profNoRow.addView(detailRowIcon(R.drawable.ic_info));
        String profNo = uid == null ? "—" : uid.substring(Math.max(0, uid.length() - 6)).toUpperCase(Locale.ENGLISH);
        profNoRow.addView(detailRowText("Profile No: " + profNo));
        card.addView(profNoRow);

        LinearLayout iconRow = new LinearLayout(this);
        iconRow.setOrientation(LinearLayout.HORIZONTAL);
        iconRow.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams iconRowLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        iconRowLp.topMargin = dp(14);
        card.addView(iconRow, iconRowLp);
        if (canEditCoins()) {
            iconRow.addView(emojiButton(CoinEmoji.EMOJI, R.color.accent_yellow_tint, R.color.coin_gold,
                    "Coin edit (add / remove)", v -> showCoinEditPage(uid, name, () -> refreshUserDetailFromDb(uid))));
        }
        iconRow.addView(iconButton(R.drawable.ic_edit_pencil, R.color.accent_purple, R.color.accent_purple_tint, R.color.accent_purple_stroke,
                "Edit profile", v -> showEditUserProfileDialog(uid, name, email, phone, status, matches, winnings)));
        iconRow.addView(iconButton(R.drawable.ic_megaphone, R.color.admin_blue, R.color.admin_blue_tint, R.color.admin_blue,
                "Send notice", v -> showAdminNoticeDialog(uid, name)));
        iconRow.addView(banToggleButton(banned, v -> moderatePlayer(uid, name, banned ? "ACTIVE" : "BANNED")));

        if (canEditCoins()) {
            TextView histTitle = pageText("MANUAL COIN HISTORY");
            histTitle.setTextColor(getColor(R.color.text_primary));
            histTitle.setTypeface(null, android.graphics.Typeface.BOLD);
            histTitle.setPadding(0, dp(16), 0, dp(4));
            card.addView(histTitle);
            LinearLayout histHolder = new LinearLayout(this);
            histHolder.setOrientation(LinearLayout.VERTICAL);
            card.addView(histHolder);
            loadCoinLogInto(histHolder, uid, 10);
        }

    }

    /** One rounded, bordered box used for each row (Status / Matches & Winnings / Phone & Email / Password / UID) on the user profile page. */
    private LinearLayout detailRowContainer() {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setBackgroundResource(R.drawable.bg_admin_surface);
        row.setPadding(dp(14), dp(14), dp(14), dp(14));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(10);
        row.setLayoutParams(lp);
        return row;
    }

    private ImageView detailRowIcon(int iconRes) {
        ImageView icon = new ImageView(this);
        icon.setImageResource(iconRes);
        icon.setImageTintList(android.content.res.ColorStateList.valueOf(getColor(R.color.text_muted)));
        icon.setLayoutParams(new LinearLayout.LayoutParams(dp(22), dp(22)));
        return icon;
    }

    private TextView detailRowText(String value) {
        TextView text = new TextView(this);
        text.setText(value);
        text.setTextColor(getColor(R.color.text_primary));
        text.setTextSize(14);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.leftMargin = dp(12);
        text.setLayoutParams(lp);
        return text;
    }

    /** Only Master, Results & Coins admins, or an owner-assigned coin permission may change coins. */
    private boolean canEditCoins() {
        return "SUPER_ADMIN".equals(adminRole) || "MASTER_ADMIN".equals(adminRole)
                || "MODERATOR".equals(adminRole) || "RESULTS_COINS_ADMIN".equals(adminRole)
                || hasPerm("coin_requests");
    }

    /** Reloads one user from Firebase and re-opens their profile page (used after a coin change). */
    private void refreshUserDetailFromDb(String uid) {
        FirebaseRepository.users().child(uid).get().addOnSuccessListener(snap -> {
            Object raw = snap.getValue();
            Map<String, Object> data = raw instanceof Map ? (Map<String, Object>) raw : new HashMap<>();
            String n = data.get("name") == null ? "" : String.valueOf(data.get("name"));
            String em = data.get("email") == null ? "" : String.valueOf(data.get("email"));
            String ph = data.get("phone") == null ? "" : String.valueOf(data.get("phone"));
            String st = data.get("status") == null ? "ACTIVE" : String.valueOf(data.get("status")).toUpperCase(Locale.ENGLISH);
            long m = data.get("matches") instanceof Number ? ((Number) data.get("matches")).longValue() : 0;
            long coins = 0;
            if (data.get("wallet") instanceof Map) {
                Object b = ((Map<String, Object>) data.get("wallet")).get("balance");
                if (b instanceof Number) coins = ((Number) b).longValue();
            }
            showUserDetailPage(uid, n.isEmpty() || "null".equals(n) ? "STARX24 Player" : n, em, ph, st, m, coins);
        }).addOnFailureListener(e -> showWorkspacePage("users"));
    }

    /** Full-screen Coin Edit: user details, live balance, add/remove toggle, amount, reason, preview, history. */
    private void showCoinEditPage(String uid, String name, Runnable onBack) {
        workspaceContent.removeAllViews();
        resetWorkspaceChrome(() -> showCoinEditPage(uid, name, onBack));
        activeTournament = null;

        final long[] balance = {0};
        final boolean[] balanceLoaded = {false};
        final boolean[] add = {true};
        final boolean[] busy = {false};

        // Top row: back icon + title
        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        ImageView backBtn = iconButton(R.drawable.ic_arrow_back, R.color.text_primary, R.color.surface, R.color.admin_card_stroke,
                "Back", v -> { if (onBack != null) onBack.run(); else showWorkspacePage("users"); });
        ((LinearLayout.LayoutParams) backBtn.getLayoutParams()).setMarginStart(0);
        top.addView(backBtn);
        TextView title = pageText("Coin Edit");
        title.setTextSize(20);
        title.setTextColor(getColor(R.color.text_primary));
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        title.setPadding(dp(8), 0, 0, 0);
        top.addView(title);
        workspaceContent.addView(top);

        // User card
        LinearLayout userCard = new LinearLayout(this);
        userCard.setOrientation(LinearLayout.HORIZONTAL);
        userCard.setGravity(Gravity.CENTER_VERTICAL);
        userCard.setBackgroundResource(R.drawable.bg_admin_surface);
        userCard.setPadding(dp(14), dp(14), dp(14), dp(14));
        LinearLayout.LayoutParams ucLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        ucLp.topMargin = dp(14);
        workspaceContent.addView(userCard, ucLp);

        ImageView avatar = new ImageView(this);
        android.graphics.drawable.GradientDrawable avatarBg = new android.graphics.drawable.GradientDrawable();
        avatarBg.setShape(android.graphics.drawable.GradientDrawable.OVAL);
        avatarBg.setColor(getColor(R.color.admin_blue_tint));
        avatarBg.setStroke(dp(1), getColor(R.color.admin_blue));
        avatar.setBackground(avatarBg);
        bindUserAvatar(avatar, "", 11);
        userCard.addView(avatar, new LinearLayout.LayoutParams(dp(48), dp(48)));

        LinearLayout info = new LinearLayout(this);
        info.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams infoLp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        infoLp.setMarginStart(dp(12));
        userCard.addView(info, infoLp);
        TextView nameTv = pageText(name);
        nameTv.setTextSize(16);
        nameTv.setTextColor(getColor(R.color.text_primary));
        nameTv.setTypeface(null, android.graphics.Typeface.BOLD);
        info.addView(nameTv);
        String shortId = uid == null ? "—" : uid.substring(Math.max(0, uid.length() - 6)).toUpperCase(Locale.ENGLISH);
        TextView profTv = pageText("Profile No: " + shortId);
        info.addView(profTv);
        TextView emailTv = pageText("");
        info.addView(emailTv);
        TextView statusTv = pageText("");
        statusTv.setTypeface(null, android.graphics.Typeface.BOLD);
        info.addView(statusTv);

        // Balance card (gold tinted, big 🪙 + amount + live preview)
        LinearLayout balCard = new LinearLayout(this);
        balCard.setOrientation(LinearLayout.VERTICAL);
        balCard.setGravity(Gravity.CENTER);
        android.graphics.drawable.GradientDrawable balBg = new android.graphics.drawable.GradientDrawable();
        balBg.setCornerRadius(dp(16));
        balBg.setColor(getColor(R.color.accent_yellow_tint));
        balBg.setStroke(dp(1), getColor(R.color.coin_gold));
        balCard.setBackground(balBg);
        balCard.setPadding(dp(14), dp(20), dp(14), dp(16));
        LinearLayout.LayoutParams bcLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        bcLp.topMargin = dp(12);
        workspaceContent.addView(balCard, bcLp);
        TextView liveTag = new TextView(this);
        liveTag.setText("● LIVE");
        liveTag.setTextSize(11);
        liveTag.setTypeface(null, android.graphics.Typeface.BOLD);
        liveTag.setTextColor(getColor(R.color.text_muted));
        liveTag.setPadding(0, 0, 0, dp(6));
        balCard.addView(liveTag);
        LinearLayout balRow = new LinearLayout(this);
        balRow.setOrientation(LinearLayout.HORIZONTAL);
        balRow.setGravity(Gravity.CENTER_VERTICAL);
        TextView coinIcon = new TextView(this);
        coinIcon.setText(CoinEmoji.EMOJI);
        coinIcon.setTextSize(36);
        balRow.addView(coinIcon);
        TextView balTv = new TextView(this);
        balTv.setText("…");
        balTv.setTextColor(getColor(R.color.text_primary));
        balTv.setTextSize(34);
        balTv.setTypeface(null, android.graphics.Typeface.BOLD);
        balTv.setPadding(dp(10), 0, 0, 0);
        balRow.addView(balTv);
        balCard.addView(balRow);
        TextView previewTv = pageText("");
        previewTv.setGravity(Gravity.CENTER);
        previewTv.setTextSize(14);
        previewTv.setTypeface(null, android.graphics.Typeface.BOLD);
        previewTv.setPadding(0, dp(6), 0, 0);
        balCard.addView(previewTv);

        // Add / Remove toggle (icons only)
        LinearLayout toggle = new LinearLayout(this);
        toggle.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams tgLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        tgLp.topMargin = dp(14);
        workspaceContent.addView(toggle, tgLp);
        ImageView addTab = new ImageView(this);
        addTab.setImageResource(R.drawable.ic_admin_plus);
        addTab.setContentDescription("Add coins");
        addTab.setPadding(dp(12), dp(12), dp(12), dp(12));
        LinearLayout.LayoutParams atLp = new LinearLayout.LayoutParams(0, dp(52), 1f);
        atLp.setMarginEnd(dp(6));
        toggle.addView(addTab, atLp);
        ImageView removeTab = new ImageView(this);
        removeTab.setImageResource(R.drawable.ic_admin_minus);
        removeTab.setContentDescription("Remove coins");
        removeTab.setPadding(dp(12), dp(12), dp(12), dp(12));
        LinearLayout.LayoutParams rtLp = new LinearLayout.LayoutParams(0, dp(52), 1f);
        rtLp.setMarginStart(dp(6));
        toggle.addView(removeTab, rtLp);

        EditText amountField = field("Amount (coins)");
        amountField.setInputType(InputType.TYPE_CLASS_NUMBER);
        amountField.setFilters(new android.text.InputFilter[]{new android.text.InputFilter.LengthFilter(9)});
        workspaceContent.addView(amountField);

        // Quick amounts
        LinearLayout quick = new LinearLayout(this);
        quick.setOrientation(LinearLayout.HORIZONTAL);
        for (int q : new int[]{10, 50, 100, 500, 1000}) {
            TextView chip = new TextView(this);
            chip.setText(CoinEmoji.EMOJI + " " + q);
            chip.setGravity(Gravity.CENTER);
            chip.setTextSize(12);
            chip.setTypeface(null, android.graphics.Typeface.BOLD);
            chip.setTextColor(getColor(R.color.text_primary));
            android.graphics.drawable.GradientDrawable cbg = new android.graphics.drawable.GradientDrawable();
            cbg.setCornerRadius(dp(10));
            cbg.setColor(getColor(R.color.surface));
            cbg.setStroke(dp(1), getColor(R.color.admin_card_stroke));
            chip.setBackground(cbg);
            chip.setOnClickListener(v -> {
                int cur = numberOrDefault(amountField.getText().toString().trim(), 0);
                amountField.setText(String.valueOf(cur + q));
                amountField.setSelection(amountField.getText().length());
            });
            LinearLayout.LayoutParams cLp = new LinearLayout.LayoutParams(0, dp(38), 1f);
            cLp.setMarginEnd(dp(6));
            quick.addView(chip, cLp);
        }
        workspaceContent.addView(quick);

        EditText reasonField = field("Reason (required)");
        workspaceContent.addView(reasonField);

        // Apply (icon only, colour follows mode)
        ImageView applyBtn = new ImageView(this);
        applyBtn.setImageResource(R.drawable.ic_admin_check);
        applyBtn.setImageTintList(android.content.res.ColorStateList.valueOf(0xFFFFFFFF));
        applyBtn.setContentDescription("Apply coin change");
        applyBtn.setPadding(dp(12), dp(12), dp(12), dp(12));
        LinearLayout.LayoutParams apLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(56));
        apLp.topMargin = dp(10);
        workspaceContent.addView(applyBtn, apLp);

        // History
        TextView histTitle = pageText("Recent manual changes");
        histTitle.setTextColor(getColor(R.color.text_primary));
        histTitle.setTypeface(null, android.graphics.Typeface.BOLD);
        histTitle.setPadding(0, dp(20), 0, dp(2));
        workspaceContent.addView(histTitle);
        LinearLayout histHolder = new LinearLayout(this);
        histHolder.setOrientation(LinearLayout.VERTICAL);
        workspaceContent.addView(histHolder);

        // Refresh of mode / preview styling
        Runnable restyle = () -> {
            int accent = getColor(add[0] ? R.color.admin_green : R.color.admin_red);
            styleCoinToggle(addTab, add[0], R.color.admin_green, R.color.admin_green_tint);
            styleCoinToggle(removeTab, !add[0], R.color.admin_red, R.color.admin_red_tint);
            android.graphics.drawable.GradientDrawable abg = new android.graphics.drawable.GradientDrawable();
            abg.setCornerRadius(dp(12));
            abg.setColor(accent);
            applyBtn.setBackground(abg);
            applyBtn.setAlpha(busy[0] || !balanceLoaded[0] ? 0.5f : 1f);
            int amt = numberOrDefault(amountField.getText().toString().trim(), 0);
            if (!balanceLoaded[0] || amt <= 0) { previewTv.setText(""); return; }
            long after = add[0] ? balance[0] + amt : balance[0] - amt;
            previewTv.setText((add[0] ? "+" : "−") + groupDigits(amt) + " " + CoinEmoji.EMOJI + "   →   " + groupDigits(after) + " " + CoinEmoji.EMOJI);
            previewTv.setTextColor(getColor(after < 0 ? R.color.admin_red : (add[0] ? R.color.admin_green : R.color.admin_red)));
        };
        addTab.setOnClickListener(v -> { add[0] = true; restyle.run(); });
        removeTab.setOnClickListener(v -> { add[0] = false; restyle.run(); });
        amountField.addTextChangedListener(new android.text.TextWatcher() {
            @Override public void beforeTextChanged(CharSequence c, int a, int b, int d) {}
            @Override public void onTextChanged(CharSequence c, int a, int b, int d) { restyle.run(); }
            @Override public void afterTextChanged(android.text.Editable e) {}
        });
        restyle.run();

        // Live user + balance: updates the moment Firebase changes (no refresh needed).
        coinEditRef = FirebaseRepository.users().child(uid);
        coinEditListener = new ValueEventListener() {
            @Override public void onDataChange(DataSnapshot snap) {
                Object raw = snap.getValue();
                Map<String, Object> data = raw instanceof Map ? (Map<String, Object>) raw : new HashMap<>();
                String em = data.get("email") == null ? "" : String.valueOf(data.get("email"));
                String ph = data.get("phone") == null ? "" : String.valueOf(data.get("phone"));
                String st = data.get("status") == null ? "ACTIVE" : String.valueOf(data.get("status")).toUpperCase(Locale.ENGLISH);
                emailTv.setText((em.isEmpty() ? "" : em) + (ph.isEmpty() || "null".equals(ph) ? "" : (em.isEmpty() ? "" : "  •  ") + ph));
                statusTv.setText("BANNED".equals(st) ? "● Banned" : "● Active");
                statusTv.setTextColor(getColor("BANNED".equals(st) ? R.color.admin_red : R.color.admin_green));
                final String pu = data.get("photoUrl") == null ? "" : String.valueOf(data.get("photoUrl"));
                if (!pu.equals(avatar.getTag())) { avatar.setTag(pu); bindUserAvatar(avatar, pu, 11); }
                long live = 0;
                if (data.get("wallet") instanceof Map) {
                    Object b = ((Map<String, Object>) data.get("wallet")).get("balance");
                    if (b instanceof Number) live = ((Number) b).longValue();
                }
                balance[0] = live;
                balanceLoaded[0] = true;
                balTv.setText(groupDigits(live));
                liveTag.setText("● LIVE");
                liveTag.setTextColor(getColor(R.color.admin_green));
                restyle.run();
            }
            @Override public void onCancelled(DatabaseError error) {
                liveTag.setText("● OFFLINE");
                liveTag.setTextColor(getColor(R.color.admin_red));
                balTv.setText("?");
                toast("Could not load balance: " + error.getMessage());
            }
        };
        coinEditRef.addValueEventListener(coinEditListener);

        applyBtn.setOnClickListener(v -> {
            if (busy[0]) return;
            if (!balanceLoaded[0]) { toast("Balance is still loading."); return; }
            int amount = numberOrDefault(amountField.getText().toString().trim(), 0);
            String reason = reasonField.getText().toString().trim();
            boolean isAdd = add[0];
            if (amount <= 0) { toast("Enter a valid coin amount."); return; }
            if (reason.isEmpty()) { toast("Please enter a reason."); return; }
            if (!isAdd && amount > balance[0]) { toast("Wallet has only " + groupDigits(balance[0]) + " coins."); return; }
            busy[0] = true;
            restyle.run();
            WithdrawalApiClient.adjustCoins(uid, isAdd ? "ADD" : "REMOVE", amount, reason,
                    new WithdrawalApiClient.SimpleCallback() {
                        @Override public void onSuccess(org.json.JSONObject result) {
                            busy[0] = false;
                            balance[0] = result.has("balanceAfter") ? result.optLong("balanceAfter")
                                    : (isAdd ? balance[0] + amount : balance[0] - amount);
                            balTv.setText(groupDigits(balance[0]));
                            amountField.setText("");
                            reasonField.setText("");
                            toast((isAdd ? "Added " : "Removed ") + amount + " coins. New balance: " + balance[0]);
                            restyle.run();
                            loadCoinLogInto(histHolder, uid, 10);
                        }
                        @Override public void onError(String message) {
                            busy[0] = false;
                            restyle.run();
                            toast(message);
                        }
                    });
        });
        loadCoinLogInto(histHolder, uid, 10);
    }

    private void styleCoinToggle(ImageView tab, boolean active, int colorRes, int tintRes) {
        android.graphics.drawable.GradientDrawable bg = new android.graphics.drawable.GradientDrawable();
        bg.setCornerRadius(dp(8));
        if (active) {
            bg.setColor(getColor(tintRes));
            bg.setStroke(dp(2), getColor(colorRes));
            tab.setImageTintList(android.content.res.ColorStateList.valueOf(getColor(colorRes)));
        } else {
            bg.setColor(getColor(R.color.surface));
            bg.setStroke(dp(1), getColor(R.color.admin_card_stroke));
            tab.setImageTintList(android.content.res.ColorStateList.valueOf(getColor(R.color.text_muted)));
        }
        tab.setBackground(bg);
    }

    /** Coin Edit: admin picks Add or Remove, an amount and a reason; the backend applies it and logs it. */
    private void showCoinEditDialog(String uid, String name, long currentCoins, Runnable onDone) {
        showCoinEditDialogUnlocked(uid, name, currentCoins, onDone);
    }

    private void showCoinEditDialogUnlocked(String uid, String name, long currentCoins, Runnable onDone) {
        LinearLayout form = new LinearLayout(this);
        form.setOrientation(LinearLayout.VERTICAL);
        form.setPadding(dp(20), dp(8), dp(20), 0);

        TextView current = new TextView(this);
        current.setText("Current coins: " + groupDigits(currentCoins));
        current.setTextColor(getColor(R.color.text_primary));
        current.setTextSize(15);
        current.setTypeface(null, android.graphics.Typeface.BOLD);
        form.addView(current);

        android.widget.RadioGroup mode = new android.widget.RadioGroup(this);
        mode.setOrientation(android.widget.RadioGroup.HORIZONTAL);
        android.widget.RadioButton addRb = new android.widget.RadioButton(this);
        addRb.setText("Add coins");
        addRb.setTextColor(getColor(R.color.text_primary));
        addRb.setId(View.generateViewId());
        android.widget.RadioButton removeRb = new android.widget.RadioButton(this);
        removeRb.setText("Remove coins");
        removeRb.setTextColor(getColor(R.color.text_primary));
        removeRb.setId(View.generateViewId());
        mode.addView(addRb);
        mode.addView(removeRb);
        addRb.setChecked(true);
        LinearLayout.LayoutParams modeLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        modeLp.topMargin = dp(10);
        form.addView(mode, modeLp);

        EditText amountField = field("Amount (coins)");
        amountField.setInputType(InputType.TYPE_CLASS_NUMBER);
        EditText reasonField = field("Reason (required)");
        form.addView(amountField);
        form.addView(reasonField);

        FullScreenDialog dialog = new FullScreenDialog.Builder(this)
                .setTitle("Coin Edit • " + name)
                .setView(form)
                .setNegativeButton("CANCEL", null)
                .setPositiveButton("APPLY", null)
                .create();
        dialog.setOnShowListener(d -> dialog.getButton(android.content.DialogInterface.BUTTON_POSITIVE).setOnClickListener(v -> {
            int amount = numberOrDefault(amountField.getText().toString().trim(), 0);
            String reason = reasonField.getText().toString().trim();
            boolean add = mode.getCheckedRadioButtonId() == addRb.getId();
            if (amount <= 0) { toast("Enter a valid coin amount."); return; }
            if (reason.isEmpty()) { toast("Please enter a reason."); return; }
            if (!add && amount > currentCoins) { toast("User has only " + currentCoins + " coins."); return; }
            android.widget.Button apply = dialog.getButton(android.content.DialogInterface.BUTTON_POSITIVE);
            apply.setEnabled(false);
            WithdrawalApiClient.adjustCoins(uid, add ? "ADD" : "REMOVE", amount, reason,
                    new WithdrawalApiClient.SimpleCallback() {
                        @Override public void onSuccess(org.json.JSONObject result) {
                            dialog.dismiss();
                            toast((add ? "Added " : "Removed ") + amount + " coins. New balance: "
                                    + result.optLong("balanceAfter"));
                            if (onDone != null) onDone.run();
                        }
                        @Override public void onError(String message) {
                            apply.setEnabled(true);
                            toast(message);
                        }
                    });
        }));
        dialog.show();
    }

    /** Full-page manual coin history: one user when uid != null, otherwise the latest changes for everyone. */
    private void showCoinLogPage(String uid, String name) {
        workspaceContent.removeAllViews();
        resetWorkspaceChrome(() -> showCoinLogPage(uid, name));
        activeTournament = null;
        TextView back = pageText(uid == null ? "← Back to Users" : "← Back to Profile");
        back.setTextColor(getColor(R.color.text_primary));
        back.setTypeface(null, android.graphics.Typeface.BOLD);
        back.setTextSize(13);
        back.setPadding(0, dp(8), 0, dp(8));
        back.setOnClickListener(v -> { if (uid == null) showWorkspacePage("users"); else refreshUserDetailFromDb(uid); });
        workspaceContent.addView(back);
        TextView title = pageText(uid == null ? "Manual Coin History" : "Coin History • " + name);
        title.setTextSize(20);
        title.setTextColor(getColor(R.color.text_primary));
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        workspaceContent.addView(title);
        LinearLayout holder = new LinearLayout(this);
        holder.setOrientation(LinearLayout.VERTICAL);
        workspaceContent.addView(holder);
        loadCoinLogInto(holder, uid, 50);
    }

    /** Fills `holder` with the newest manual coin changes (newest first). uid == null means all users. */
    private void loadCoinLogInto(LinearLayout holder, String uid, int limit) {
        holder.removeAllViews();
        holder.addView(pageText("Loading..."));
        com.google.firebase.database.Query query = uid == null
                ? FirebaseRepository.manualCoinLog().orderByChild("at").limitToLast(limit)
                : FirebaseRepository.manualCoinLog().orderByChild("uid").equalTo(uid);
        query.get().addOnSuccessListener(snap -> {
            holder.removeAllViews();
            List<DataSnapshot> rows = new ArrayList<>();
            for (DataSnapshot c : snap.getChildren()) rows.add(c);
            java.util.Collections.sort(rows, (a, b) -> Long.compare(logAt(b), logAt(a)));
            if (rows.isEmpty()) { holder.addView(pageText("No manual coin changes yet.")); return; }
            int shown = 0;
            SimpleDateFormat fmt = new SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.ENGLISH);
            for (DataSnapshot row : rows) {
                if (shown++ >= limit) break;
                long delta = row.child("delta").getValue() instanceof Number
                        ? ((Number) row.child("delta").getValue()).longValue() : 0;
                String who = String.valueOf(row.child("userName").getValue());
                String reason = String.valueOf(row.child("reason").getValue());
                String adminName = String.valueOf(row.child("adminEmail").getValue());
                Object before = row.child("balanceBefore").getValue();
                Object after = row.child("balanceAfter").getValue();
                LinearLayout item = new LinearLayout(this);
                item.setOrientation(LinearLayout.VERTICAL);
                item.setBackgroundResource(R.drawable.bg_admin_surface);
                item.setPadding(dp(12), dp(10), dp(12), dp(10));
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                lp.topMargin = dp(8);
                item.setLayoutParams(lp);
                TextView head = pageText((delta >= 0 ? "+" : "") + delta + " coins"
                        + (uid == null && !"null".equals(who) ? "  •  " + who : ""));
                head.setTextSize(14);
                head.setTypeface(null, android.graphics.Typeface.BOLD);
                head.setTextColor(getColor(delta >= 0 ? R.color.admin_green : R.color.admin_red));
                item.addView(head);
                item.addView(pageText(before + " → " + after + "  •  " + reason));
                long at = logAt(row);
                item.addView(pageText((at > 0 ? fmt.format(new Date(at)) : "—") + "  •  by " + adminName));
                holder.addView(item);
            }
        }).addOnFailureListener(e -> {
            holder.removeAllViews();
            holder.addView(pageText("History unavailable: " + e.getMessage() + (String.valueOf(e.getMessage()).toLowerCase(Locale.ENGLISH).contains("permission") ? "  (publish the updated database.rules.json)" : "")));
        });
    }

    private long logAt(DataSnapshot row) {
        Object v = row.child("at").getValue();
        return v instanceof Number ? ((Number) v).longValue() : 0L;
    }

    /** Lets an admin correct a player's name / email / phone, writing straight to their Firebase profile. */
    private void showEditUserProfileDialog(String uid, String name, String email, String phone, String status,
                                            long matches, long winnings) {
        LinearLayout form = new LinearLayout(this);
        form.setOrientation(LinearLayout.VERTICAL);
        form.setPadding(dp(20), dp(8), dp(20), 0);
        EditText nameField = field("Name");
        nameField.setText(name);
        EditText emailField = field("Email");
        emailField.setText(email);
        EditText phoneField = field("Phone");
        phoneField.setText(phone);
        form.addView(nameField);
        form.addView(emailField);
        form.addView(phoneField);
        new FullScreenDialog.Builder(this)
                .setTitle("Edit Profile")
                .setView(form)
                .setNegativeButton("CANCEL", null)
                .setPositiveButton("SAVE", (d, w) -> FirebaseRepository.saveUserProfile(uid,
                        emailField.getText().toString().trim(), nameField.getText().toString().trim(),
                        phoneField.getText().toString().trim(), null)
                        .addOnSuccessListener(u -> {
                            toast("Profile updated.");
                            showUserDetailPage(uid, nameField.getText().toString().trim(),
                                    emailField.getText().toString().trim(), phoneField.getText().toString().trim(),
                                    status, matches, winnings);
                        })
                        .addOnFailureListener(e -> toast("Update failed: " + e.getMessage())))
                .show();
    }

    private void showAdminNoticeDialog(String uid, String name) {
        EditText message = field("Notice message");
        message.setText("Cheat use mat karo. Fair play follow karo, warna account permanently ban ho sakta hai.");
        new FullScreenDialog.Builder(this)
                .setTitle("Send admin notice")
                .setMessage("This warning will be saved in the player's notification history.")
                .setView(message)
                .setNegativeButton("CANCEL", null)
                .setPositiveButton("SEND NOTICE", (d, w) -> FirebaseRepository.sendAdminNotice(uid,
                        message.getText().toString().trim(), name)
                        .addOnSuccessListener(v -> toast("Admin notice sent."))
                        .addOnFailureListener(e -> toast("Notice failed: " + e.getMessage())))
                .show();
    }

    private void moderatePlayer(String uid, String name, String status) {
        final boolean ban = "BANNED".equals(status);
        final EditText reasonField = ban ? field("Ban reason (player ko notice me dikhega)") : null;
        FullScreenDialog.Builder b = new FullScreenDialog.Builder(this)
                .setTitle((name == null || name.isEmpty() ? "This player" : name) + (ban ? " → Ban?" : " → Unban?"))
                .setMessage(ban
                        ? "Player login nahi kar payega. Login par use ek notice dikhega: \"You're banned\" aur neeche likha hua reason."
                        : "Player ka account dobara login kar sakega.")
                .setNegativeButton("CANCEL", null);
        if (ban) b.setView(reasonField);
        b.setPositiveButton("CONFIRM", (d, w) -> {
            String reason = ban ? reasonField.getText().toString().trim() : null;
            if (ban && reason.isEmpty()) reason = "Violation of app rules";
            final String finalReason = reason;
            FirebaseRepository.setUserStatus(uid, status, finalReason)
                    .addOnSuccessListener(u -> {
                        FirebaseRepository.logActivity("USER_" + status, name == null || name.isEmpty() ? uid : name,
                                "uid " + uid + (ban ? " • reason: " + finalReason : ""));
                        toast(ban ? "Player banned." : "Player unbanned.");
                        if (workspaceRefresh != null) workspaceRefresh.run();
                    })
                    .addOnFailureListener(e -> toast(e.getMessage()));
        }).show();
    }

    private void loadTournamentsPage(String page) {
        clearHeaderActions();
        if (canCreateMatch()) addHeaderPlus("New battle", () -> showAddTournamentDialog("", ""));
        workspaceContent.addView(pageText(canCreateMatch()
                ? "Existing tournaments are listed on the Home dashboard. Tap ＋ (top right) to publish a new battle."
                : "Match create / delete owner ya assigned Match Detail Handle se kiya ja sakta hai. Room release, edit aur leaderboard bhi yahin manage karo."));
    }

    private void loadCategoriesPage() {
        clearHeaderActions();
        addHeaderPlus("New esports category", this::openAddCategoryPage);
        // Image-only grid of every category (no title / helper text). Tap = open its matches,
        // long-press = edit. Live-updated by gameModeListener.
        workspaceContent.removeAllViews();
        RecyclerView grid = new RecyclerView(this);
        grid.setLayoutManager(new GridLayoutManager(this, 2));
        grid.setNestedScrollingEnabled(false);
        grid.setOverScrollMode(View.OVER_SCROLL_NEVER);
        categoryImageAdapter = new com.arenax.tournament.adapter.CategoryImageAdapter(
                gameModes, this::showCategoryMatches, this::openEditCategoryPage);
        grid.setAdapter(categoryImageAdapter);
        workspaceContent.addView(grid, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
    }

    // ---------------------------------------------------------------------
    // A1 — Roles & Permissions v2 (Owner only): generate a one-time admin
    // access key per role instead of assigning a role to a known Firebase UID.
    // Payment Admin: ONLY the Payments workspace (deposits/withdrawals). Cannot see matches/tournaments.
    // Match Admin: ONLY match/tournament workspaces (battles, tournaments, esports, category, teams, matches, results). Cannot see payments.
    // Tournament Manager: tournaments, matches, schedule, room, results (+ activity log).
    // Support Agent: tickets, FAQ, announcements, read-only tournaments.
    // Moderator: reports, disputes, warnings, bans.
    // ---------------------------------------------------------------------
    private void loadRolesPage() {
        workspaceContent.addView(pageText("Create a key below, hand it to that admin, and they sign in with it from the "
                + "ADMIN KEY tab on the login screen — no UID or email needed. Revoke a key any time to lock that admin out instantly."));

        EditText labelField = field("Label (e.g. Rahul - Support)");
        workspaceContent.addView(labelField);
        Spinner roleSpinner = new Spinner(this);
        roleSpinner.setAdapter(new android.widget.ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item,
                new String[]{"MASTER_ADMIN", "MATCH_OPERATIONS_ADMIN", "RESULTS_COINS_ADMIN",
                        "CUSTOMER_SUPPORT_ADMIN"}));
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48));
        sp.topMargin = dp(8);
        workspaceContent.addView(roleSpinner, sp);

        pageButton("CREATE PASSWORD", v -> {
            String label = labelField.getText().toString().trim();
            if (label.isEmpty()) { toast("Enter a label so you remember who this key is for."); return; }
            String role = String.valueOf(roleSpinner.getSelectedItem());
            String key = FirebaseRepository.generateReadableKey();
            FirebaseRepository.createAdminKey(key, label, role)
                    .addOnSuccessListener(unused -> {
                        FirebaseRepository.logActivity("ADMIN_KEY_CREATED", label, role);
                        showGeneratedKeyDialog(key, label, role);
                    })
                    .addOnFailureListener(error -> toast(error.getMessage()));
        });

        workspaceContent.addView(pageText("ADMIN KEYS"));
        FirebaseRepository.adminKeys().addListenerForSingleValueEvent(new ValueEventListener() {
            @Override public void onDataChange(DataSnapshot keysSnap) {
                if (!keysSnap.exists() || keysSnap.getChildrenCount() == 0) {
                    workspaceContent.addView(pageText("No admin keys yet. Create one above."));
                    return;
                }
                FirebaseRepository.adminSessions().addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override public void onDataChange(DataSnapshot sessionsSnap) {
                        Map<String, Boolean> onlineByKey = new HashMap<>();
                        for (DataSnapshot session : sessionsSnap.getChildren()) {
                            Object keyVal = session.child("key").getValue();
                            if (keyVal != null && Boolean.TRUE.equals(session.child("online").getValue())) {
                                onlineByKey.put(String.valueOf(keyVal), true);
                            }
                        }
                        for (DataSnapshot child : keysSnap.getChildren()) {
                            workspaceContent.addView(buildAdminKeyRow(child, Boolean.TRUE.equals(onlineByKey.get(child.getKey()))));
                        }
                    }
                    @Override public void onCancelled(DatabaseError error) {
                        for (DataSnapshot child : keysSnap.getChildren()) {
                            workspaceContent.addView(buildAdminKeyRow(child, false));
                        }
                    }
                });
            }
            @Override public void onCancelled(DatabaseError error) { workspaceContent.addView(pageText("Keys unavailable: " + error.getMessage())); }
        });
    }

    /** One row per admin key: label, role, masked key, and a live [ONLINE] online/[OFFLINE] offline/[REVOKED] revoked dot. */
    private android.view.View buildAdminKeyRow(DataSnapshot child, boolean online) {
        String key = child.getKey();
        Object labelVal = child.child("label").getValue();
        Object roleVal = child.child("role").getValue();
        String label = labelVal == null ? "Unnamed" : String.valueOf(labelVal);
        String role = roleVal == null ? "" : String.valueOf(roleVal);
        boolean active = !Boolean.FALSE.equals(child.child("active").getValue());

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setBackgroundResource(R.drawable.bg_card);
        card.setPadding(dp(14), dp(12), dp(14), dp(12));
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        cp.topMargin = dp(8);
        card.setLayoutParams(cp);
        card.setOnClickListener(v -> com.arenax.tournament.util.AdminKeyHistory.show(this, key, label, AdminRoles.label(role)));

        TextView title = pageText(label + "   " + (!active ? "[REVOKED]  REVOKED" : online ? "[ONLINE]  ONLINE" : "[OFFLINE]  OFFLINE"));
        title.setTextColor(getColor(R.color.text_primary));
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        card.addView(title);
        card.addView(pageText(role + "  •  key " + key + "  •  tap = history"));

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(40));
        rp.topMargin = dp(8);
        row.setLayoutParams(rp);
        if (active) {
            row.addView(inlineButton("REVOKE", R.color.accent_yellow_tint, R.color.accent_yellow_stroke, v -> confirmRevokeKey(key, label)));
        } else {
            row.addView(inlineButton("DELETE", R.color.accent_purple_tint, R.color.accent_purple_stroke, v -> confirmDeleteKey(key, label)));
        }
        card.addView(row);
        return card;
    }

    private void confirmRevokeKey(String key, String label) {
        new FullScreenDialog.Builder(this)
                .setTitle("Revoke this key?")
                .setMessage(label + " will be locked out immediately and cannot sign back in with this key.")
                .setNegativeButton("CANCEL", null)
                .setPositiveButton("REVOKE", (d, w) -> FirebaseRepository.revokeAdminKey(key)
                        .addOnSuccessListener(u -> {
                            FirebaseRepository.logActivity("ADMIN_KEY_REVOKED", label, key);
                            toast("Key revoked.");
                            showWorkspacePage("roles");
                        })
                        .addOnFailureListener(e -> toast(e.getMessage())))
                .show();
    }

    private void confirmDeleteKey(String key, String label) {
        new FullScreenDialog.Builder(this)
                .setTitle("Delete this key permanently?")
                .setMessage("This removes " + label + " from the list. It's already revoked, so this is just cleanup.")
                .setNegativeButton("CANCEL", null)
                .setPositiveButton("DELETE", (d, w) -> FirebaseRepository.deleteAdminKey(key)
                        .addOnSuccessListener(u -> { toast("Key deleted."); showWorkspacePage("roles"); })
                        .addOnFailureListener(e -> toast(e.getMessage())))
                .show();
    }

    private void showGeneratedKeyDialog(String key, String label, String role) {
        new FullScreenDialog.Builder(this)
                .setTitle("Key created for " + label)
                .setMessage("Role: " + role + "\n\nAccess key:\n" + key
                        + "\n\nCopy this now and share it only with " + label
                        + ". This is the last time it's shown in full.")
                .setPositiveButton("COPY & CLOSE", (d, w) -> {
                    android.content.ClipboardManager cm = (android.content.ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
                    cm.setPrimaryClip(android.content.ClipData.newPlainText("Admin Key", key));
                    toast("Key copied.");
                    showWorkspacePage("roles");
                })
                .setCancelable(false)
                .show();
    }

    // ---------------------------------------------------------------------
    // A9 — Teams workspace: inspect, verify, disband
    // ---------------------------------------------------------------------
    private void loadTeamsPage() {
        workspaceContent.addView(pageText("Teams are created by players from the User App. Verify or disband them here."));
        FirebaseRepository.teams().addListenerForSingleValueEvent(new ValueEventListener() {
            @Override public void onDataChange(DataSnapshot snapshot) {
                if (!snapshot.exists() || snapshot.getChildrenCount() == 0) {
                    workspaceContent.addView(pageText("No teams created yet."));
                    return;
                }
                for (DataSnapshot child : snapshot.getChildren()) {
                    com.arenax.tournament.model.Team team = com.arenax.tournament.model.Team.fromMap(
                            child.getKey(), (Map<String, Object>) child.getValue());
                    if (team == null) continue;
                    workspaceContent.addView(pageText(team.getName() + "  •  " + team.getStatus()
                            + "  •  " + team.getMemberCount() + " players  •  id: " + team.getId()));
                    LinearLayout row = new LinearLayout(AdminActivity.this);
                    row.setOrientation(LinearLayout.HORIZONTAL);
                    LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(44));
                    rp.bottomMargin = dp(10);
                    row.setLayoutParams(rp);
                    row.addView(inlineButton("VERIFY", R.color.accent_green_tint, R.color.accent_green_stroke, v -> {
                        FirebaseRepository.setTeamStatus(team.getId(), "VERIFIED");
                        FirebaseRepository.logActivity("TEAM_VERIFIED", team.getName(), "Team ID " + team.getId());
                        toast("Team verified.");
                    }));
                    row.addView(inlineButton("DISBAND", R.color.accent_purple_tint, R.color.accent_purple_stroke, v ->
                            new FullScreenDialog.Builder(AdminActivity.this)
                                    .setTitle("Disband " + team.getName() + "?")
                                    .setNegativeButton("CANCEL", null)
                                    .setPositiveButton("DISBAND", (d, w) -> {
                                        FirebaseRepository.disbandTeam(team.getId());
                                        FirebaseRepository.logActivity("TEAM_DISBANDED", team.getName(), "Team ID " + team.getId());
                                        toast("Team disbanded.");
                                    }).show()));
                    workspaceContent.addView(row);
                }
            }
            @Override public void onCancelled(DatabaseError error) { workspaceContent.addView(pageText("Teams unavailable: " + error.getMessage())); }
        });
    }

    // ---------------------------------------------------------------------
    // A5/A6/A7 — Match Management: per-tournament matches with exact countdown + room control
    // ---------------------------------------------------------------------
    private void loadMatchesPage() {
        clearHeaderActions();
        if (canCreateMatch()) addHeaderPlus("Add match", () -> showAddTournamentDialog("", ""));
        if (canCreateMatch()) addHeaderMenu(new String[]{"Bulk actions (select many)"}, new Runnable[]{this::showBulkMatchDialog});

        if (tournaments.isEmpty()) {
            workspaceContent.addView(pageText(canCreateMatch()
                    ? "No matches published yet. Tap ＋ (top right) to create one."
                    : "No matches published yet. Owner ya assigned Match Detail Handle se naya match create karein."));
            return;
        }
        java.util.List<Tournament> ordered = new java.util.ArrayList<>(tournaments);
        java.util.Collections.sort(ordered, (a, b) -> {
                long x = a.getEffectiveStartAt();
                long y = b.getEffectiveStartAt();
                if (x <= 0L && y <= 0L) return 0;
                if (x <= 0L) return 1;
                if (y <= 0L) return -1;
                return Long.compare(x, y);
            });   // sooner start on top
        for (Tournament t : ordered) {
            workspaceContent.addView(tournamentMatchCard(t));
        }
    }

    /** White, rounded match card matching the reference "BR Match Management" design —
     *  thumbnail, title/mode, date & time, entry/prize/players stats, a status pill,
     *  and Edit / Delete / View Details actions. */
    private LinearLayout tournamentMatchCard(Tournament t) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(14), dp(14), dp(14), dp(14));
        android.graphics.drawable.GradientDrawable bg = new android.graphics.drawable.GradientDrawable();
        bg.setColor(getColor(R.color.surface));
        bg.setCornerRadius(dp(4));
        bg.setStroke(dp(1), getColor(R.color.admin_card_stroke));
        card.setBackground(bg);
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        cp.topMargin = dp(12);
        card.setLayoutParams(cp);

        // Header row: thumbnail + title/mode/date/time
        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        ImageView thumb = new ImageView(this);
        thumb.setScaleType(ImageView.ScaleType.CENTER_CROP);
        android.graphics.drawable.GradientDrawable thumbBg = new android.graphics.drawable.GradientDrawable();
        thumbBg.setCornerRadius(dp(4));
        thumbBg.setColor(getColor(R.color.surface_2));
        thumb.setBackground(thumbBg);
        thumb.setClipToOutline(true);
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(dp(56), dp(56));
        tp.rightMargin = dp(12);
        thumb.setLayoutParams(tp);
        ImageLoader.load(thumb, t.getBannerUrl());
        header.addView(thumb);

        LinearLayout titleCol = new LinearLayout(this);
        titleCol.setOrientation(LinearLayout.VERTICAL);
        titleCol.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        TextView title = new TextView(this);
        title.setText(t.getTitle());
        title.setTextColor(getColor(R.color.text_primary));
        title.setTextSize(15);
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        titleCol.addView(title);

        TextView subtitle = new TextView(this);
        subtitle.setText(t.getGameType() + " • " + (t.getMatchType() == null || t.getMatchType().isEmpty() ? "Squad" : t.getMatchType()));
        subtitle.setTextColor(getColor(R.color.text_secondary));
        subtitle.setTextSize(11.5f);
        LinearLayout.LayoutParams stp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        stp.topMargin = dp(1);
        titleCol.addView(subtitle, stp);

        LinearLayout dateTimeRow = new LinearLayout(this);
        dateTimeRow.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams dtp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        dtp.topMargin = dp(6);
        dateTimeRow.addView(iconLabel(R.drawable.ic_calendar, t.getDate()));
        TextView spacer = new TextView(this);
        LinearLayout.LayoutParams spp = new LinearLayout.LayoutParams(dp(14), ViewGroup.LayoutParams.WRAP_CONTENT);
        dateTimeRow.addView(iconLabel(R.drawable.ic_clock, t.getTime()), spp);
        titleCol.addView(dateTimeRow, dtp);

        header.addView(titleCol);
        card.addView(header);

        // Divider
        View divider = new View(this);
        divider.setBackgroundColor(getColor(R.color.stroke));
        LinearLayout.LayoutParams dp2 = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(1));
        dp2.topMargin = dp(12);
        dp2.bottomMargin = dp(10);
        card.addView(divider, dp2);

        // Stats row: Entry / Prize Pool / Players + status pill
        LinearLayout stats = new LinearLayout(this);
        stats.setOrientation(LinearLayout.HORIZONTAL);
        stats.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        stats.addView(statColumn("Entry", "₹" + t.getEntryFeeCoins()));
        stats.addView(statColumn("Prize Pool", "₹" + t.getPrizePoolCoins()));

        LinearLayout playersCol = new LinearLayout(this);
        playersCol.setOrientation(LinearLayout.VERTICAL);
        playersCol.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        playersCol.addView(iconLabel(R.drawable.ic_cd_users, t.getJoinedSlots() + "/" + t.getTotalSlots()));

        String effectiveStatus = t.getEffectiveStatus();
        TextView pill = new TextView(this);
        pill.setText(statusPillLabel(effectiveStatus));
        pill.setTextSize(10.5f);
        pill.setTypeface(null, android.graphics.Typeface.BOLD);
        int[] pillColors = statusPillColors(effectiveStatus);
        pill.setTextColor(getColor(pillColors[0]));
        android.graphics.drawable.GradientDrawable pillBg = new android.graphics.drawable.GradientDrawable();
        pillBg.setColor(getColor(pillColors[1]));
        pillBg.setCornerRadius(dp(4));
        pill.setBackground(pillBg);
        pill.setPadding(dp(10), dp(4), dp(10), dp(4));
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        pp.topMargin = dp(6);
        playersCol.addView(pill, pp);
        stats.addView(playersCol);
        card.addView(stats);

        // Action row: Edit / Delete / View Details
        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams arp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(40));
        arp.topMargin = dp(12);
        actions.setLayoutParams(arp);
        actions.addView(inlineButton("Edit", R.color.surface_2, R.color.stroke, v -> showEditTournamentDialog(t)));
        String effForCancel = t.getEffectiveStatus();
        boolean finishedMatch = Tournament.COMPLETED.equals(effForCancel) || Tournament.CANCELLED.equals(effForCancel);
        if (!finishedMatch) actions.addView(inlineButton("Cancel", R.color.surface_2, R.color.admin_red, v -> showCancelConfirm(t)));
        actions.addView(inlineButton("Delete", R.color.admin_red_tint, R.color.admin_red, v -> showDeleteConfirm(t)));
        actions.addView(inlineButton("View Details", R.color.surface_2, R.color.stroke, v -> showMatchesForTournament(t)));
        card.addView(actions);
        if (canCreateMatch()) {
            LinearLayout dupRow = new LinearLayout(this);
            dupRow.setOrientation(LinearLayout.HORIZONTAL);
            LinearLayout.LayoutParams drp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(40));
            drp.topMargin = dp(8);
            dupRow.setLayoutParams(drp);
            dupRow.addView(inlineButton("Duplicate (copy to new time)", R.color.accent_blue_tint, R.color.accent_blue_stroke, v -> showDuplicateMatchDialog(t)));
            card.addView(dupRow);
        }

        return card;
    }

    private LinearLayout statColumn(String label, String value) {
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        TextView labelView = new TextView(this);
        labelView.setText(label);
        labelView.setTextColor(getColor(R.color.text_secondary));
        labelView.setTextSize(11);
        col.addView(labelView);
        TextView valueView = new TextView(this);
        valueView.setText(value);
        valueView.setTextColor(getColor(R.color.text_primary));
        valueView.setTextSize(13.5f);
        valueView.setTypeface(null, android.graphics.Typeface.BOLD);
        LinearLayout.LayoutParams vp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        vp.topMargin = dp(2);
        col.addView(valueView, vp);
        return col;
    }

    private LinearLayout iconLabel(int drawableRes, String text) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        ImageView icon = new ImageView(this);
        icon.setImageResource(drawableRes);
        icon.setColorFilter(getColor(R.color.text_secondary));
        LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(dp(12), dp(12));
        ip.rightMargin = dp(4);
        row.addView(icon, ip);
        TextView label = new TextView(this);
        label.setText(text == null || text.isEmpty() ? "TBA" : text);
        label.setTextColor(getColor(R.color.text_secondary));
        label.setTextSize(11);
        row.addView(label);
        return row;
    }

    private String statusPillLabel(String effectiveStatus) {
        if (Tournament.ONGOING.equals(effectiveStatus)) return "● Live";
        if (Tournament.COMPLETED.equals(effectiveStatus)) return "Completed";
        if (Tournament.CANCELLED.equals(effectiveStatus)) return "Cancelled";
        if (Tournament.DRAFT.equals(effectiveStatus)) return "Draft";
        if (Tournament.RESULT_PROCESSING.equals(effectiveStatus)) return "Verifying";
        return "Upcoming";
    }

    /** {textColorRes, backgroundTintRes} for a status pill. */
    private int[] statusPillColors(String effectiveStatus) {
        if (Tournament.ONGOING.equals(effectiveStatus)) return new int[]{R.color.admin_green, R.color.admin_green_tint};
        if (Tournament.COMPLETED.equals(effectiveStatus)) return new int[]{R.color.text_secondary, R.color.surface_2};
        if (Tournament.CANCELLED.equals(effectiveStatus)) return new int[]{R.color.admin_red, R.color.admin_red_tint};
        if (Tournament.RESULT_PROCESSING.equals(effectiveStatus)) return new int[]{R.color.admin_orange, R.color.admin_orange_tint};
        return new int[]{R.color.admin_blue, R.color.admin_blue_tint};
    }

    /** Quick edit for the core tournament fields — leaves image, room and rules untouched. */
    private void showEditTournamentDialog(Tournament t) {
        LinearLayout form = new LinearLayout(this);
        form.setOrientation(LinearLayout.VERTICAL);
        form.setPadding(dp(24), dp(8), dp(24), dp(8));

        EditText title = field("Tournament name");
        title.setText(t.getTitle());
        EditText date = field("Start date (e.g. 20 SEP 2026)");
        date.setText(t.getDate());
        EditText time = field("Start time (e.g. 07:00 PM)");
        time.setText(t.getTime());
        EditText entryFee = field("Entry fee (coins)");
        entryFee.setInputType(InputType.TYPE_CLASS_NUMBER);
        entryFee.setText(String.valueOf(t.getEntryFeeCoins()));
        EditText prizePool = field("Prize pool (coins)");
        prizePool.setInputType(InputType.TYPE_CLASS_NUMBER);
        prizePool.setText(String.valueOf(t.getPrizePoolCoins()));
        EditText totalSlots = field("Total slots");
        totalSlots.setInputType(InputType.TYPE_CLASS_NUMBER);
        totalSlots.setText(String.valueOf(t.getTotalSlots()));
        form.addView(fieldLabel("LEADERBOARD & REWARD SYSTEM"));
        Spinner resultSystem = new Spinner(this);
        String[] resultSystemLabels = {"KILL → COIN", "SURVIVAL → COIN", "1VS1 BATTLE", "TEAM → RANK COIN"};
        resultSystem.setAdapter(new android.widget.ArrayAdapter<>(this,
                android.R.layout.simple_spinner_dropdown_item, resultSystemLabels));
        int selectedSystem = "SURVIVAL".equals(t.getResultSystem()) ? 1
                : ("BATTLE_1V1".equals(t.getResultSystem()) ? 2 : ("TEAM".equals(t.getResultSystem()) ? 3 : 0));
        resultSystem.setSelection(selectedSystem);

        form.addView(title); form.addView(date); form.addView(time);
        form.addView(entryFee); form.addView(prizePool); form.addView(totalSlots); form.addView(resultSystem);
        android.widget.ScrollView scroll = new android.widget.ScrollView(this);
        scroll.addView(form);

        new FullScreenDialog.Builder(this)
                .setTitle("Edit " + t.getTitle())
                .setView(scroll)
                .setNegativeButton("CANCEL", null)
                .setPositiveButton("SAVE", (d, w) -> {
                    int entry = parseIntOr(entryFee.getText().toString().trim(), t.getEntryFeeCoins());
                    int prize = parseIntOr(prizePool.getText().toString().trim(), t.getPrizePoolCoins());
                    String system = resultSystem.getSelectedItemPosition() == 1 ? "SURVIVAL"
                            : (resultSystem.getSelectedItemPosition() == 2 ? "BATTLE_1V1"
                            : (resultSystem.getSelectedItemPosition() == 3 ? "TEAM" : "KILL"));
                    int slots = "BATTLE_1V1".equals(system) ? 2
                            : Math.max(1, parseIntOr(totalSlots.getText().toString().trim(), t.getTotalSlots()));
                    int teamSize = "BATTLE_1V1".equals(system) ? 1 : t.getTeamSize();
                    // startAt (not the date/time text) drives countdown, ONGOING and join-close, so it
                    // must follow the edited date/time or the edit would silently do nothing.
                    long editedStartAt = parseDateTime(date.getText().toString().trim(), time.getText().toString().trim());
                    Tournament updated = new Tournament(t.getId(), title.getText().toString().trim(), t.getMode(), t.getCategoryId(),
                            t.getBannerUrl(), t.getDescription(), date.getText().toString().trim(), time.getText().toString().trim(),
                            editedStartAt > 0L ? editedStartAt : t.getStartAt(), t.getRegistrationCloseAt(), t.getRoomReleaseAt(), t.getPrizeInfo(), slots,
                            t.getJoinedSlots(), teamSize, t.getMap(), t.getMatchType(), t.getRules(),
                            t.getPrizeDistribution(), t.getRoomId(), t.getRoomPassword(), t.isRoomReleased(), t.getDelayReason(),
                            t.getStatus(), t.getRegistrationStatus(), t.isActive(), t.getAccentColor());
                    updated.setCoinDetails(entry, prize, t.getPerKillCoins(), t.getGameType());
                    updated.setResultSystem(system);
                    FirebaseRepository.saveTournament(updated)
                            .addOnSuccessListener(unused -> {
                                toast("Match updated.");
                                FirebaseRepository.logActivity("TOURNAMENT_UPDATED", updated.getTitle(), "");
                                showWorkspacePage("matches");
                            })
                            .addOnFailureListener(error -> toast(error.getMessage()));
                }).show();
    }

    private int parseIntOr(String value, int fallback) {
        try { return Integer.parseInt(value); } catch (Exception e) { return fallback; }
    }

    private void showMatchesForTournament(Tournament t) {
        activeTournament = t;
        workspaceContent.removeAllViews();
        resetWorkspaceChrome(() -> showMatchesForTournament(t));
        addHeaderPlus("Create match", () -> {
            Intent page = new Intent(this, MatchEditorActivity.class);
            page.putExtra(MatchEditorActivity.EXTRA_TOURNAMENT, t);
            startActivityForResult(page, REQUEST_MATCH_EDITOR);
        });
        TextView backToMatches = pageText("← Back to Matches");
        backToMatches.setTextColor(getColor(R.color.text_primary));
        backToMatches.setTypeface(null, android.graphics.Typeface.BOLD);
        backToMatches.setTextSize(13);
        backToMatches.setPadding(0, dp(8), 0, dp(8));
        backToMatches.setOnClickListener(v -> showWorkspacePage("matches"));
        workspaceContent.addView(backToMatches);
        workspaceContent.addView(pageTitle("Matches • " + t.getTitle()));
        FirebaseRepository.matches().orderByChild("tournamentId").equalTo(t.getId())
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override public void onDataChange(DataSnapshot snapshot) {
                        if (!snapshot.exists() || snapshot.getChildrenCount() == 0) {
                            workspaceContent.addView(pageText("No matches scheduled yet for this tournament."));
                            return;
                        }
                        for (DataSnapshot child : snapshot.getChildren()) {
                            com.arenax.tournament.model.Match match = com.arenax.tournament.model.Match.fromMap(
                                    child.getKey(), (Map<String, Object>) child.getValue());
                            if (match != null) workspaceContent.addView(matchCard(t, match));
                        }
                    }
                    @Override public void onCancelled(DatabaseError error) { workspaceContent.addView(pageText("Matches unavailable: " + error.getMessage())); }
                });
    }

    private LinearLayout matchCard(Tournament t, com.arenax.tournament.model.Match m) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(14), dp(12), dp(14), dp(12));
        android.graphics.drawable.GradientDrawable bg = new android.graphics.drawable.GradientDrawable();
        bg.setColor(getColor(R.color.surface));
        bg.setCornerRadius(dp(4));
        bg.setStroke(dp(1), getColor(R.color.stroke));
        card.setBackground(bg);
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        cp.topMargin = dp(10);
        card.setLayoutParams(cp);

        TextView name = pageText("ROUND " + m.getRound() + " • " + m.getName());
        name.setTextColor(getColor(R.color.text_primary));
        name.setTypeface(null, android.graphics.Typeface.BOLD);
        card.addView(name);
        card.addView(pageText(m.getMap() + "  •  " + m.getMode()
                + "  •  " + (m.getScheduledAt() > 0
                ? new SimpleDateFormat("dd MMM yyyy hh:mm a", Locale.ENGLISH).format(new Date(m.getScheduledAt()))
                : "Time TBA")));
        TextView status = pageText("STATUS: " + m.getEffectiveStatus() + (m.isDelayed() && !m.getDelayReason().isEmpty() ? " — " + m.getDelayReason() : ""));
        status.setTextColor(getColor(matchStatusColor(m.getEffectiveStatus())));
        status.setTypeface(null, android.graphics.Typeface.BOLD);
        card.addView(status);
        if (m.isRoomReleased()) {
            card.addView(pageText("Room ID: " + m.getRoomId() + "   Password: " + m.getRoomPassword()));
        }

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(44));
        rp.topMargin = dp(8);
        row.setLayoutParams(rp);
        row.addView(inlineButton("EDIT", R.color.accent_blue_tint, R.color.accent_blue_stroke, v -> {
            Intent page = new Intent(this, MatchEditorActivity.class);
            page.putExtra(MatchEditorActivity.EXTRA_TOURNAMENT, t);
            page.putExtra(MatchEditorActivity.EXTRA_MATCH, m);
            startActivityForResult(page, REQUEST_MATCH_EDITOR);
        }));
        row.addView(inlineButton("ROOM", R.color.accent_green_tint, R.color.accent_green_stroke, v -> {
            Intent page = new Intent(this, RoomControlActivity.class);
            page.putExtra(RoomControlActivity.EXTRA_TOURNAMENT, t);
            page.putExtra(RoomControlActivity.EXTRA_MATCH, m);
            startActivityForResult(page, REQUEST_ROOM_CONTROL);
        }));
        row.addView(inlineButton(m.getStatus().equals(com.arenax.tournament.model.Match.LIVE) ? "SET COMPLETED" : "SET LIVE",
                R.color.accent_yellow_tint, R.color.accent_yellow_stroke, v -> {
                    String next = com.arenax.tournament.model.Match.LIVE.equals(m.getStatus())
                            ? com.arenax.tournament.model.Match.COMPLETED : com.arenax.tournament.model.Match.LIVE;
                    FirebaseRepository.setMatchStatus(m.getId(), next);
                    FirebaseRepository.logActivity("MATCH_STATUS", m.getName(), next);
                    if (com.arenax.tournament.model.Match.COMPLETED.equals(next)) {
                        FirebaseRepository.publishNotification("Match Completed", m.getName() + " has ended. Check results & leaderboard.");
                    } else {
                        FirebaseRepository.publishNotification("Match Live", m.getName() + " is now LIVE.");
                    }
                    toast("Match status updated.");
                    showMatchesForTournament(t);
                }));
        if (canCreateMatch()) row.addView(inlineButton("DELETE", R.color.accent_purple_tint, R.color.accent_purple_stroke, v ->
                new FullScreenDialog.Builder(this)
                        .setTitle("Delete " + m.getName() + "?")
                        .setNegativeButton("CANCEL", null)
                        .setPositiveButton("DELETE", (d, w) -> {
                            FirebaseRepository.deleteMatch(m.getId());
                            FirebaseRepository.logActivity("MATCH_DELETED", m.getName(), "");
                            toast("Match deleted.");
                            showMatchesForTournament(t);
                        }).show()));
        card.addView(row);
        return card;
    }

    private int matchStatusColor(String status) {
        switch (status) {
            case "LIVE": return R.color.blood_red;
            case "ROOM_RELEASED": return R.color.accent_green;
            case "WAITING": return R.color.accent_yellow;
            case "DELAYED": return R.color.accent_yellow;
            case "COMPLETED": return R.color.text_secondary;
            case "CANCELLED": return R.color.text_muted;
            default: return R.color.accent_blue;
        }
    }

    private void showMatchDialog(Tournament t, com.arenax.tournament.model.Match existing) {
        LinearLayout form = new LinearLayout(this);
        form.setOrientation(LinearLayout.VERTICAL);
        form.setPadding(dp(24), dp(8), dp(24), dp(8));

        EditText name = field("Match name (e.g. Round 1 — Group A)");
        EditText round = field("Round number");
        round.setInputType(InputType.TYPE_CLASS_NUMBER);
        EditText map = field("Map (e.g. Bermuda, Purgatory, Kalahari)");
        EditText mode = field("Mode (e.g. Squad, Clash Squad)");
        EditText date = field("Scheduled date (e.g. 20 SEP 2026)");
        EditText time = field("Scheduled time (e.g. 08:30 PM)");
        EditText maxSlots = field("Max slots");
        maxSlots.setInputType(InputType.TYPE_CLASS_NUMBER);
        EditText rules = field("Match rules (optional)");
        if (existing != null) {
            name.setText(existing.getName());
            round.setText(String.valueOf(existing.getRound()));
            map.setText(existing.getMap());
            mode.setText(existing.getMode());
            if (existing.getScheduledAt() > 0) {
                Date d = new Date(existing.getScheduledAt());
                date.setText(new SimpleDateFormat("dd MMM yyyy", Locale.ENGLISH).format(d));
                time.setText(new SimpleDateFormat("hh:mm a", Locale.ENGLISH).format(d));
            }
            maxSlots.setText(String.valueOf(existing.getMaxSlots()));
            rules.setText(existing.getRules());
        } else {
            round.setText("1");
            mode.setText(t.getMatchType());
            maxSlots.setText(String.valueOf(t.getTotalSlots()));
        }
        form.addView(name); form.addView(round); form.addView(map); form.addView(mode);
        form.addView(date); form.addView(time); form.addView(maxSlots); form.addView(rules);
        android.widget.ScrollView scroll = new android.widget.ScrollView(this);
        scroll.addView(form);

        new FullScreenDialog.Builder(this)
                .setTitle(existing == null ? "Create match" : "Edit match")
                .setMessage("Countdown on the User App is computed from this exact date/time, not a client timer — it stays correct after refresh.")
                .setView(scroll)
                .setNegativeButton("CANCEL", null)
                .setPositiveButton("SAVE", (d, w) -> {
                    long scheduledAt = parseDateTime(date.getText().toString().trim(), time.getText().toString().trim());
                    com.arenax.tournament.model.Match match = new com.arenax.tournament.model.Match(
                            existing == null ? null : existing.getId(), t.getId(), t.getTitle(),
                            name.getText().toString().trim(), numberOrDefault(round.getText().toString().trim(), 1),
                            map.getText().toString().trim(), mode.getText().toString().trim(), scheduledAt,
                            numberOrDefault(maxSlots.getText().toString().trim(), 0), rules.getText().toString().trim(),
                            existing == null ? com.arenax.tournament.model.Match.UPCOMING : existing.getStatus(),
                            existing == null ? "" : existing.getRoomId(), existing == null ? "" : existing.getRoomPassword(),
                            existing != null && existing.isRoomReleased(), existing == null ? 0L : existing.getRoomReleasedAt(),
                            existing == null ? "" : existing.getDelayReason(), existing == null ? 0L : existing.getDelayExpectedAt());
                    FirebaseRepository.saveMatch(match)
                            .addOnSuccessListener(unused -> {
                                FirebaseRepository.logActivity(existing == null ? "MATCH_CREATED" : "MATCH_EDITED", match.getName(), t.getTitle());
                                if (existing == null) FirebaseRepository.publishNotification("New Match Scheduled", match.getName() + " • " + t.getTitle());
                                toast(existing == null ? "Match created." : "Match updated.");
                                showMatchesForTournament(t);
                            })
                            .addOnFailureListener(error -> toast(error.getMessage()));
                })
                .show();
    }

    private void showMatchRoomDialog(com.arenax.tournament.model.Match m) {
        LinearLayout form = new LinearLayout(this);
        form.setOrientation(LinearLayout.VERTICAL);
        form.setPadding(dp(24), dp(8), dp(24), dp(8));

        TextView status = new TextView(this);
        status.setText(m.isRoomReleased() ? "ROOM CURRENTLY RELEASED TO PLAYERS" : "ROOM CURRENTLY HIDDEN");
        status.setTextColor(m.isRoomReleased() ? getColor(R.color.success) : getColor(R.color.text_secondary));
        status.setTextSize(12);
        status.setPadding(0, 0, 0, dp(10));
        form.addView(status);

        EditText roomId = field("Room ID");
        roomId.setText(m.getRoomId());
        EditText roomPass = field("Room Password");
        roomPass.setText(m.getRoomPassword());
        EditText delay = field("Delay reason (leave empty if not delayed)");
        delay.setText(m.getDelayReason());
        form.addView(roomId); form.addView(roomPass); form.addView(delay);

        FullScreenDialog.Builder builder = new FullScreenDialog.Builder(this)
                .setTitle("Room control • " + m.getName())
                .setMessage("Release sends Room ID + Password live to this match's participants instantly. A delay reason shows \"MATCH DELAYED — WAIT FOR ROOM ID & PASSWORD\" on the User App.")
                .setView(form)
                .setNegativeButton("CANCEL", null)
                .setNeutralButton(m.isRoomReleased() ? "HIDE ROOM" : "RELEASE ROOM", null)
                .setPositiveButton(delay.getText().toString().trim().isEmpty() ? "SAVE" : "SAVE + MARK DELAYED", null);
        FullScreenDialog dialog = builder.create();
        dialog.setOnShowListener(ignored -> {
            dialog.getButton(Dialog.BUTTON_POSITIVE).setOnClickListener(v -> {
                String reason = delay.getText().toString().trim();
                if (!reason.isEmpty()) {
                    FirebaseRepository.setMatchDelay(m.getId(), reason, 0L);
                    FirebaseRepository.publishNotification("Match Delayed", m.getName() + " delayed: " + reason);
                    FirebaseRepository.logActivity("MATCH_DELAYED", m.getName(), reason);
                } else {
                    FirebaseRepository.clearMatchDelay(m.getId());
                }
                toast("Room details saved.");
                dialog.dismiss();
            });
            dialog.getButton(Dialog.BUTTON_NEUTRAL).setOnClickListener(v -> {
                // Manual action wins over any pending exact-time auto-release for this match
                // (see RoomReleaseScheduler) so it can never double-fire later.
                RoomReleaseScheduler.cancel(this, m.getId());
                if (m.isRoomReleased()) {
                    FirebaseRepository.hideMatchRoom(m.getId());
                    FirebaseRepository.logActivity("MATCH_ROOM_HIDDEN", m.getName(), "");
                    toast("Room hidden from players.");
                } else {
                    String id = roomId.getText().toString().trim();
                    String pass = roomPass.getText().toString().trim();
                    FirebaseRepository.releaseMatchRoom(m.getId(), id, pass);
                    FirebaseRepository.logActivity("MATCH_ROOM_RELEASED", m.getName(), "Room " + id);
                    FirebaseRepository.publishNotification("Room Released", m.getName() + " room ID & password are now live.");
                    sendRoomReleasePush(FirebaseRepository.matchParticipants(m.getId()),
                            m.getName() + " — Room Released!",
                            "Room ID: " + id + " | Password: " + pass);
                    toast("Room released live to players.");
                }
                dialog.dismiss();
            });
        });
        dialog.show();
    }

    // ---------------------------------------------------------------------
    // A12 — Match Results entry: pick a tournament -> enter kills/placement per participant
    // ---------------------------------------------------------------------
    private void loadResultsPage() {
        workspaceContent.addView(pageText("Pick a tournament to enter kills + placement per participant. Points auto-calculate and push straight to the leaderboard."));
        for (Tournament t : tournaments) {
            // resultsTournamentButton() already adds the button to workspaceContent.
            resultsTournamentButton(t);
        }
        if (tournaments.isEmpty()) workspaceContent.addView(pageText("No tournaments published yet."));
    }

    private void resultsTournamentButton(Tournament t) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setBackgroundResource(R.drawable.bg_admin_surface);
        row.setPadding(dp(14), dp(14), dp(14), dp(14));
        TextView name = new TextView(this);
        name.setText(t.getTitle());
        name.setTextColor(getColor(R.color.text_primary));
        name.setTextSize(13.5f);
        name.setTypeface(null, android.graphics.Typeface.BOLD);
        row.addView(name, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        ImageView chevron = new ImageView(this);
        chevron.setImageResource(R.drawable.ic_chevron_right);
        chevron.setImageTintList(android.content.res.ColorStateList.valueOf(getColor(R.color.text_muted)));
        row.addView(chevron, new LinearLayout.LayoutParams(dp(20), dp(20)));
        row.setOnClickListener(v -> showResultsEntryDialog(t));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(10);
        workspaceContent.addView(row, lp);
    }

    private void showResultsEntryDialog(Tournament t) {
        FirebaseRepository.tournamentParticipants(t.getId()).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override public void onDataChange(DataSnapshot snapshot) {
                if (!snapshot.exists() || snapshot.getChildrenCount() == 0) {
                    toast("No registered participants yet for " + t.getTitle() + ".");
                    return;
                }
                LinearLayout form = new LinearLayout(AdminActivity.this);
                form.setOrientation(LinearLayout.VERTICAL);
                form.setPadding(dp(24), dp(8), dp(24), dp(8));
                List<String> uids = new ArrayList<>();
                List<EditText> killFields = new ArrayList<>();
                List<EditText> placeFields = new ArrayList<>();
                for (DataSnapshot participant : snapshot.getChildren()) {
                    String uid = participant.getKey();
                    String teamName = String.valueOf(participant.child("teamName").getValue());
                    TextView rowLabel = pageText((teamName == null || teamName.isEmpty() || "null".equals(teamName)
                            ? "Player " + (uids.size() + 1) : teamName) + "  (uid " + uid + ")");
                    rowLabel.setTextColor(getColor(R.color.text_primary));
                    form.addView(rowLabel);
                    EditText kills = field("Kills");
                    kills.setInputType(InputType.TYPE_CLASS_NUMBER);
                    EditText placement = field("Placement (1 = winner)");
                    placement.setInputType(InputType.TYPE_CLASS_NUMBER);
                    form.addView(kills);
                    form.addView(placement);
                    uids.add(uid);
                    killFields.add(kills);
                    placeFields.add(placement);
                }
                android.widget.ScrollView scroll = new android.widget.ScrollView(AdminActivity.this);
                scroll.addView(form);
                new FullScreenDialog.Builder(AdminActivity.this)
                        .setTitle("Enter results • " + t.getTitle())
                        .setView(scroll)
                        .setNegativeButton("CANCEL", null)
                        .setPositiveButton("PUBLISH RESULTS", (d, w) -> {
                             boolean invalid = false;
                             int maxPlacement = Math.max(1, t.getTotalSlots());
                             int publishedRows = 0;
                            for (int i = 0; i < uids.size(); i++) {
                                 String killsText = killFields.get(i).getText().toString().trim();
                                 String placementText = placeFields.get(i).getText().toString().trim();
                                 if (placementText.isEmpty()) continue;
                                 int kills = numberOrDefault(killsText, 0);
                                 int placement = numberOrDefault(placementText, 0);
                                 if (kills < 0 || placement < 1 || placement > maxPlacement) {
                                     invalid = true;
                                     break;
                                 }
                             }
                             if (invalid) {
                                 toast("Check results: kills cannot be negative and placement must be between 1 and "
                                         + maxPlacement + ".");
                                 return;
                             }
                             for (int i = 0; i < uids.size(); i++) {
                                 String placementText = placeFields.get(i).getText().toString().trim();
                                 if (placementText.isEmpty()) continue;
                                 int kills = numberOrDefault(killFields.get(i).getText().toString().trim(), 0);
                                 int placement = numberOrDefault(placementText, 0);
                                FirebaseRepository.publishResult(t.getId(), uids.get(i), t.getTitle(), kills, placement);
                                 publishedRows++;
                             }
                             if (publishedRows == 0) {
                                 toast("Enter at least one placement before publishing.");
                                 return;
                            }
                            FirebaseRepository.logActivity("RESULT_PUBLISHED", t.getTitle(),
                                     publishedRows + " participant rows entered");
                            FirebaseRepository.publishNotification("Result Published",
                                    t.getTitle() + " results are live. Check the leaderboard!");
                            toast("Results published. Leaderboard updated live.");
                        })
                        .show();
            }
            @Override public void onCancelled(DatabaseError error) { toast(error.getMessage()); }
        });
    }

    // ---------------------------------------------------------------------
    // A13 — Result Disputes queue
    // ---------------------------------------------------------------------
    // ---------------------------------------------------------------------
    // A24 — Payments workspace (Payment Admin role): a unified Transaction
    // History table (deposits + withdrawals merged, newest first) with
    // All / Deposit / Withdrawal tabs, matching the reference admin design.
    // Tapping a PENDING row opens the approve/reject actions; PAID /
    // APPROVED / REJECTED rows are read-only history.
    // ---------------------------------------------------------------------
    private void loadPaymentsPage() {
        paymentsTxnCache.clear();
        paymentsFilter = "ALL";
        clearHeaderActions();
        addHeaderAction(R.drawable.ic_admin_delete, "Delete all withdrawal history", v -> confirmDeleteAllWithdrawals());
        workspaceContent.addView(buildTxnTabsRow());

        LinearLayout table = new LinearLayout(this);
        table.setOrientation(LinearLayout.VERTICAL);
        table.setBackgroundResource(R.drawable.bg_card);
        table.setPadding(dp(10), dp(10), dp(10), dp(4));
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        tp.topMargin = dp(12);
        table.setLayoutParams(tp);
        workspaceContent.addView(table);

        paymentsTableBody = new LinearLayout(this);
        paymentsTableBody.setOrientation(LinearLayout.VERTICAL);
        table.addView(paymentsTableBody);
        paymentsTableBody.addView(pageText("Loading transactions…"));

        FirebaseRepository.withdrawals().addListenerForSingleValueEvent(new ValueEventListener() {
            @Override public void onDataChange(DataSnapshot wSnap) {
                long now = System.currentTimeMillis();
                List<TxnRow> withdrawalRows = new ArrayList<>();
                if (wSnap.exists()) {
                    for (DataSnapshot child : wSnap.getChildren()) {
                        withdrawalRows.add(toTxnRow(child, "Withdrawal", true, now));
                    }
                }
                FirebaseRepository.deposits().addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override public void onDataChange(DataSnapshot dSnap) {
                        List<TxnRow> all = new ArrayList<>(withdrawalRows);
                        if (dSnap.exists()) {
                            for (DataSnapshot child : dSnap.getChildren()) {
                                all.add(toTxnRow(child, "Deposit", false, now));
                            }
                        }
                        java.util.Collections.sort(all, (a, b) -> Long.compare(b.ts, a.ts));
                        paymentsTxnCache.clear();
                        paymentsTxnCache.addAll(all);
                        renderPaymentsTable();
                        resolveTxnUsers(all, () -> renderPaymentsTable());
                    }
                    @Override public void onCancelled(DatabaseError error) {
                        paymentsTableBody.removeAllViews();
                        paymentsTableBody.addView(pageText("Deposits unavailable: " + error.getMessage()));
                    }
                });
            }
            @Override public void onCancelled(DatabaseError error) {
                paymentsTableBody.removeAllViews();
                paymentsTableBody.addView(pageText("Withdrawals unavailable: " + error.getMessage()));
            }
        });
    }

    private TxnRow toTxnRow(DataSnapshot child, String type, boolean withdrawal, long now) {
        String id = child.getKey();
        String userId = String.valueOf(child.child("userId").getValue());
        Object amountVal = child.child("amount").getValue();
        String rawStatus = String.valueOf(child.child("status").getValue());
        Object tsVal = child.child("createdAt").getValue();
        long ts = tsVal instanceof Number ? ((Number) tsVal).longValue() : now;
        String status;
        if (withdrawal) {
            com.arenax.tournament.admin.WithdrawalStatus.State state =
                    com.arenax.tournament.admin.WithdrawalStatus.resolve(rawStatus, ts, now);
            status = "REJECTED".equalsIgnoreCase(rawStatus) ? "REJECTED"
                    : state == com.arenax.tournament.admin.WithdrawalStatus.State.PAID ? "PAID" : "PENDING";
        } else {
            status = "APPROVED".equalsIgnoreCase(rawStatus) ? "APPROVED"
                    : "REJECTED".equalsIgnoreCase(rawStatus) ? "REJECTED" : "PENDING";
        }
        Object upiVal = child.child("upiId").getValue();
        TxnRow built = new TxnRow(id, type, userId, "₹" + amountVal, status, ts, withdrawal, upiVal == null ? "" : String.valueOf(upiVal));
        built.flagged = Boolean.TRUE.equals(child.child("flagged").getValue(Boolean.class));
        return built;
    }

    /** All / Deposit / Withdrawal segmented tabs above the table (dark pill = active). */
    private LinearLayout buildTxnTabsRow() {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        rp.topMargin = dp(10);
        row.setLayoutParams(rp);
        row.addView(buildTxnTabButton(R.drawable.ic_admin_list, "Transactions", "ALL"));
        row.addView(buildTxnTabButton(R.drawable.ic_admin_deposit, "Add Money", "DEPOSIT"));
        row.addView(buildTxnTabButton(R.drawable.ic_admin_withdraw, "Withdrawals", "WITHDRAWAL"));
        return row;
    }

    /** "Delete All History" row: clears every already-resolved (PAID/REJECTED)
     *  withdrawal in one tap. Sits next to the per-row DELETE on the
     *  withdrawal detail page — this one is the bulk option; that one is the
     *  single-record option. PENDING requests are never touched by either. */
    /** Per-row delete (the ✕ in the history table) — same backend call as the
     *  bulk "Delete All" above, scoped to just this one withdrawal record. */
    private void confirmDeleteWithdrawalRow(TxnRow row) {
        boolean pending = "PENDING".equals(row.status);
        new FullScreenDialog.Builder(this)
                .setTitle("Delete " + txnShortId(row.id) + "?")
                .setMessage(pending
                        ? "This request is still PENDING. The player's locked coins will be refunded to their wallet (request marked Rejected), then the record is deleted."
                        : "This removes this withdrawal record permanently. This cannot be undone.")
                .setNegativeButton("CANCEL", null)
                .setPositiveButton(pending ? "REFUND & DELETE" : "DELETE", (d, w) -> WithdrawalApiClient.deleteWithdrawalAnyStatus(row.id, new WithdrawalApiClient.SimpleCallback() {
                    @Override public void onSuccess(org.json.JSONObject result) {
                        if (isFinishing() || isDestroyed()) return;
                        toast(pending ? "Deleted. Coins refunded to the player." : "Withdrawal deleted.");
                        paymentsTxnCache.remove(row);
                        renderPaymentsTable();
                    }
                    @Override public void onError(String message) {
                        if (isFinishing() || isDestroyed()) return;
                        toast("Failed: " + message);
                    }
                }))
                .show();
    }

    private void confirmDeleteAllWithdrawals() {
        new FullScreenDialog.Builder(this)
                .setTitle("Delete all withdrawal history?")
                .setMessage("This permanently removes every Paid and Rejected withdrawal record. Pending requests are kept and are not affected.")
                .setNegativeButton("CANCEL", null)
                .setPositiveButton("DELETE ALL", (d, w) -> deleteAllWithdrawals())
                .show();
    }

    private void deleteAllWithdrawals() {
        WithdrawalApiClient.deleteAllWithdrawals(new WithdrawalApiClient.SimpleCallback() {
            @Override public void onSuccess(org.json.JSONObject result) {
                int count = result.optInt("count", 0);
                toast("Deleted " + count + " withdrawal record(s) from history.");
                showWorkspacePage("payments");
            }
            @Override public void onError(String message) {
                toast(message);
            }
        });
    }

    private ImageView buildTxnTabButton(int iconRes, String label, String filterKey) {
        ImageView tab = new ImageView(this);
        tab.setImageResource(iconRes);
        tab.setContentDescription(label);
        tab.setPadding(dp(10), dp(10), dp(10), dp(10));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, dp(44), 1f);
        p.setMarginEnd(dp(6));
        tab.setLayoutParams(p);
        tab.setTag(filterKey);
        styleTxnTab(tab, filterKey.equals(paymentsFilter));
        tab.setOnClickListener(v -> {
            paymentsFilter = filterKey;
            LinearLayout parent = (LinearLayout) tab.getParent();
            for (int i = 0; i < parent.getChildCount(); i++) {
                View child = parent.getChildAt(i);
                if (child instanceof ImageView) styleTxnTab((ImageView) child, filterKey.equals(child.getTag()));
            }
            renderPaymentsTable();
        });
        return tab;
    }

    private void styleTxnTab(ImageView tab, boolean active) {
        android.graphics.drawable.GradientDrawable bg = new android.graphics.drawable.GradientDrawable();
        bg.setCornerRadius(dp(10));
        if (active) {
            bg.setColor(getColor(R.color.admin_blue_tint));
            bg.setStroke(dp(1), getColor(R.color.admin_blue));
            tab.setImageTintList(android.content.res.ColorStateList.valueOf(getColor(R.color.admin_blue)));
        } else {
            bg.setColor(getColor(R.color.surface));
            bg.setStroke(dp(1), getColor(R.color.admin_card_stroke));
            tab.setImageTintList(android.content.res.ColorStateList.valueOf(getColor(R.color.text_secondary)));
        }
        tab.setBackground(bg);
    }

    private LinearLayout buildTxnHeaderRow() {
        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setPadding(0, dp(4), 0, dp(8));
        header.addView(txnCell("TXN ID", 1.15f, true, R.color.text_secondary));
        header.addView(txnCell("User", 0.85f, true, R.color.text_secondary));
        header.addView(txnCell("Type", 0.9f, true, R.color.text_secondary));
        header.addView(txnCell("Amount", 0.95f, true, R.color.text_secondary));
        header.addView(txnCell("Status", 1.1f, true, R.color.text_secondary));
        return header;
    }

    private TextView txnCell(String text, float weight, boolean bold, int colorRes) {
        TextView cell = new TextView(this);
        cell.setText(text);
        cell.setTextSize(10.5f);
        cell.setTextColor(getColor(colorRes));
        if (bold) cell.setTypeface(null, android.graphics.Typeface.BOLD);
        cell.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, weight));
        return cell;
    }

    private void renderPaymentsTable() {
        if (paymentsTableBody == null) return;
        paymentsTableBody.removeAllViews();
        List<TxnRow> filtered = new ArrayList<>();
        for (TxnRow row : paymentsTxnCache) {
            boolean match = "ALL".equals(paymentsFilter)
                    || ("DEPOSIT".equals(paymentsFilter) && !row.withdrawal)
                    || ("WITHDRAWAL".equals(paymentsFilter) && row.withdrawal);
            if (match) filtered.add(row);
        }
        if (filtered.isEmpty()) {
            paymentsTableBody.addView(pageText("No transactions in this view yet."));
            return;
        }
        for (TxnRow row : filtered) paymentsTableBody.addView(buildTxnRow(row));
    }

    /** Loads name / email / phone / UPI for every distinct user in the list (cached), then calls done. */
    private void resolveTxnUsers(List<TxnRow> rows, Runnable done) {
        java.util.Set<String> need = new java.util.HashSet<>();
        for (TxnRow r : rows) {
            if (r.userId != null && !r.userId.isEmpty() && !"null".equals(r.userId) && !txnUserCache.containsKey(r.userId)) need.add(r.userId);
        }
        if (need.isEmpty()) return;
        final java.util.concurrent.atomic.AtomicInteger left = new java.util.concurrent.atomic.AtomicInteger(need.size());
        for (String uid : need) {
            FirebaseRepository.users().child(uid).get().addOnCompleteListener(t -> {
                if (t.isSuccessful() && t.getResult() != null && t.getResult().getValue() instanceof Map) {
                    Map<String, Object> d = (Map<String, Object>) t.getResult().getValue();
                    txnUserCache.put(uid, new String[]{
                            cleanField(d.get("name")), cleanField(d.get("email")), cleanField(d.get("phone")), cleanField(d.get("upiId"))});
                }
                if (left.decrementAndGet() == 0) done.run();
            });
        }
    }

    private String cleanField(Object o) {
        String v = o == null ? "" : String.valueOf(o).trim();
        return "null".equals(v) ? "" : v;
    }

    private TextView txnLine(String text, float size, int colorRes, boolean bold) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(size);
        t.setTextColor(getColor(colorRes));
        if (bold) t.setTypeface(null, android.graphics.Typeface.BOLD);
        t.setSingleLine(false);
        return t;
    }

    /** One payment: type icon | name + UPI + gmail/phone + TXN/date | amount + status | delete. Pending rows are tappable. */
    private android.view.View buildTxnRow(TxnRow row) {
        String[] info = txnUserCache.get(row.userId);
        String name = info == null ? "…" : (info[0].isEmpty() ? "STARX24 Player" : info[0]);
        String email = info == null ? "" : info[1];
        String phone = info == null ? "" : info[2];
        String upi = !row.upiId.isEmpty() ? row.upiId : (info == null ? "" : info[3]);

        LinearLayout line = new LinearLayout(this);
        line.setOrientation(LinearLayout.HORIZONTAL);
        line.setGravity(Gravity.CENTER_VERTICAL);
        line.setPadding(0, dp(12), 0, dp(12));

        ImageView typeIcon = new ImageView(this);
        typeIcon.setImageResource(row.withdrawal ? R.drawable.ic_admin_withdraw : R.drawable.ic_admin_deposit);
        typeIcon.setImageTintList(android.content.res.ColorStateList.valueOf(getColor(row.withdrawal ? R.color.admin_orange : R.color.admin_green)));
        typeIcon.setContentDescription(row.type);
        typeIcon.setPadding(dp(8), dp(8), dp(8), dp(8));
        android.graphics.drawable.GradientDrawable iconBg = new android.graphics.drawable.GradientDrawable();
        iconBg.setShape(android.graphics.drawable.GradientDrawable.OVAL);
        iconBg.setColor(getColor(row.withdrawal ? R.color.admin_orange_tint : R.color.admin_green_tint));
        typeIcon.setBackground(iconBg);
        line.addView(typeIcon, new LinearLayout.LayoutParams(dp(36), dp(36)));

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams colLp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        colLp.setMarginStart(dp(10));
        colLp.setMarginEnd(dp(8));
        col.addView(txnLine((row.flagged ? "⚠ " : "") + name, 14f, R.color.text_primary, true));
        if (!upi.isEmpty()) col.addView(txnLine("UPI: " + upi, 12f, R.color.admin_blue, false));
        String contact = (email.isEmpty() ? "" : email) + (phone.isEmpty() ? "" : (email.isEmpty() ? "" : "  •  ") + phone);
        if (!contact.isEmpty()) col.addView(txnLine(contact, 11.5f, R.color.text_secondary, false));
        String when = new java.text.SimpleDateFormat("dd MMM, hh:mm a", Locale.ENGLISH).format(new java.util.Date(row.ts));
        col.addView(txnLine(txnShortId(row.id) + "  •  " + when, 10.5f, R.color.text_muted, false));
        line.addView(col, colLp);

        LinearLayout right = new LinearLayout(this);
        right.setOrientation(LinearLayout.VERTICAL);
        right.setGravity(Gravity.END);
        TextView amountView = txnLine(row.amount, 15f, R.color.text_primary, true);
        amountView.setGravity(Gravity.END);
        right.addView(amountView);
        LinearLayout pillWrap = new LinearLayout(this);
        pillWrap.setGravity(Gravity.END);
        pillWrap.setPadding(0, dp(6), 0, 0);
        pillWrap.addView(buildStatusPill(row.status));
        right.addView(pillWrap);
        line.addView(right);

        // Per-row delete — only for withdrawal rows, since that's the only type
        // WithdrawalApiClient can remove; deposits have no delete endpoint here.
        if (row.withdrawal) {
            TextView rowDelete = new TextView(this);
            rowDelete.setText("✕");
            rowDelete.setTextSize(13f);
            rowDelete.setTypeface(null, android.graphics.Typeface.BOLD);
            rowDelete.setTextColor(getColor(R.color.admin_red));
            rowDelete.setPadding(dp(10), dp(4), dp(4), dp(4));
            rowDelete.setOnClickListener(v -> confirmDeleteWithdrawalRow(row));
            line.addView(rowDelete, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        }

        View divider = new View(this);
        divider.setBackgroundColor(getColor(R.color.admin_card_stroke));

        LinearLayout wrapper = new LinearLayout(this);
        wrapper.setOrientation(LinearLayout.VERTICAL);
        wrapper.addView(line);
        wrapper.addView(divider, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(1)));

        // Every withdrawal row opens its full detail page (pending = approve/reject, resolved = read-only);
        // deposits keep the old rule: only PENDING rows are actionable.
        if (row.withdrawal || "PENDING".equals(row.status)) {
            line.setOnClickListener(v -> showTxnActionDialog(row));
            wrapper.setOnClickListener(v -> showTxnActionDialog(row));
            android.util.TypedValue tv = new android.util.TypedValue();
            if (getTheme().resolveAttribute(android.R.attr.selectableItemBackground, tv, true)) {
                wrapper.setForeground(getDrawable(tv.resourceId));
            }
        }
        return wrapper;
    }

    private TextView buildStatusPill(String status) {
        TextView pill = new TextView(this);
        String label; int colorRes; int tintRes;
        if ("PAID".equals(status) || "APPROVED".equals(status)) {
            label = "Success"; colorRes = R.color.admin_green; tintRes = R.color.admin_green_tint;
        } else if ("REJECTED".equals(status)) {
            label = "Rejected"; colorRes = R.color.admin_red; tintRes = R.color.admin_red_tint;
        } else {
            label = "Pending"; colorRes = R.color.admin_orange; tintRes = R.color.admin_orange_tint;
        }
        pill.setText(label);
        pill.setTextSize(10.5f);
        pill.setTypeface(null, android.graphics.Typeface.BOLD);
        pill.setTextColor(getColor(colorRes));
        pill.setPadding(dp(10), dp(4), dp(10), dp(4));
        android.graphics.drawable.GradientDrawable bg = new android.graphics.drawable.GradientDrawable();
        bg.setCornerRadius(dp(4));
        bg.setColor(getColor(tintRes));
        pill.setBackground(bg);
        pill.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        return pill;
    }

    private String txnShortId(String id) {
        if (id == null) return "TXN";
        String tail = id.length() > 6 ? id.substring(id.length() - 6) : id;
        return "TXN-" + tail.toUpperCase(Locale.ENGLISH);
    }

    private void showTxnActionDialog(TxnRow row) {
        if (row.withdrawal) {
            // Full-page detail (user card, UPI details + QR, user info, admin notice,
            // approve/reject) instead of the old cramped 3-button dialog.
            try {
                Intent page = new Intent(this, WithdrawalDetailActivity.class);
                page.putExtra(WithdrawalDetailActivity.EXTRA_TXN_ID, row.id);
                page.putExtra(WithdrawalDetailActivity.EXTRA_USER_ID, row.userId);
                page.putExtra(WithdrawalDetailActivity.EXTRA_AMOUNT_LABEL, row.amount);
                page.putExtra(WithdrawalDetailActivity.EXTRA_CREATED_AT, row.ts);
                page.putExtra(WithdrawalDetailActivity.EXTRA_STATUS, row.status);
                startActivityForResult(page, REQUEST_WITHDRAWAL_DETAIL);
            } catch (Throwable error) {
                toast("Could not open withdrawal details: " + error.getMessage());
            }
            return;
        }
        new FullScreenDialog.Builder(this)
                .setTitle("Deposit " + txnShortId(row.id))
                .setMessage(row.amount + "  •  " + (txnUserCache.get(row.userId) != null && !txnUserCache.get(row.userId)[0].isEmpty() ? txnUserCache.get(row.userId)[0] : "STARX24 Player"))
                .setNegativeButton("REJECT", (d, w) -> updateDeposit(row.id, "REJECTED", row.userId))
                .setPositiveButton("APPROVE", (d, w) -> updateDeposit(row.id, "APPROVED", row.userId))
                .setNeutralButton("CANCEL", null)
                .show();
    }

    private void updateWithdrawal(String id, String status, String userId) {
        // Goes through the backend now instead of a direct Firebase write: only the
        // backend (Admin SDK) can move coins out of wallet.locked, so this is also
        // what actually finalizes the payout, not just a status label change.
        WithdrawalApiClient.approveWithdrawal(id, status, new WithdrawalApiClient.SimpleCallback() {
            @Override public void onSuccess(org.json.JSONObject result) {
                toast("Withdrawal marked " + status + ".");
                showWorkspacePage("payments");
            }
            @Override public void onError(String message) {
                toast(message);
            }
        });
    }

    private void updateDeposit(String id, String status, String userId) {
        FirebaseRepository.updateDepositStatus(id, status)
                .addOnSuccessListener(u -> {
                    FirebaseRepository.logActivity("DEPOSIT_" + status, userId, "Deposit " + id);
                    toast("Deposit marked " + status + ".");
                    showWorkspacePage("payments");
                })
                .addOnFailureListener(e -> toast(e.getMessage()));
    }

    private void loadDisputesPage() {
        workspaceContent.addView(pageText("Player-submitted result disputes. Review, resolve or reject each one."));
        FirebaseRepository.disputes().addListenerForSingleValueEvent(new ValueEventListener() {
            @Override public void onDataChange(DataSnapshot snapshot) {
                if (!snapshot.exists() || snapshot.getChildrenCount() == 0) {
                    workspaceContent.addView(pageText("No disputes right now."));
                    return;
                }
                for (DataSnapshot child : snapshot.getChildren()) {
                    String id = child.getKey();
                    String title = String.valueOf(child.child("tournamentTitle").getValue());
                    String reason = String.valueOf(child.child("reason").getValue());
                    String description = String.valueOf(child.child("description").getValue());
                    String status = String.valueOf(child.child("status").getValue());
                    workspaceContent.addView(pageText(title + "  •  " + reason + "  •  STATUS: " + status));
                    workspaceContent.addView(pageText(description));
                    LinearLayout row = new LinearLayout(AdminActivity.this);
                    row.setOrientation(LinearLayout.HORIZONTAL);
                    LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(44));
                    rp.bottomMargin = dp(14);
                    row.setLayoutParams(rp);
                    row.addView(inlineButton("REVIEW", R.color.accent_blue_tint, R.color.accent_blue_stroke, v ->
                            updateDispute(id, "UNDER_REVIEW", title)));
                    row.addView(inlineButton("RESOLVE", R.color.accent_green_tint, R.color.accent_green_stroke, v ->
                            updateDispute(id, "RESOLVED", title)));
                    row.addView(inlineButton("REJECT", R.color.accent_purple_tint, R.color.accent_purple_stroke, v ->
                            updateDispute(id, "REJECTED", title)));
                    workspaceContent.addView(row);
                }
            }
            @Override public void onCancelled(DatabaseError error) { workspaceContent.addView(pageText("Disputes unavailable: " + error.getMessage())); }
        });
    }

    private void updateDispute(String id, String status, String title) {
        FirebaseRepository.updateDisputeStatus(id, status, "")
                .addOnSuccessListener(u -> {
                    FirebaseRepository.logActivity("DISPUTE_" + status, title, "Dispute " + id);
                    toast("Dispute marked " + status + ".");
                })
                .addOnFailureListener(e -> toast(e.getMessage()));
    }

    // ---------------------------------------------------------------------
    // A14 — Reports & Moderation queue
    // ---------------------------------------------------------------------
    private void loadReportsPage() {
        workspaceContent.addView(pageText("Player-submitted reports. Warn, restrict, suspend or ban the reported user, or dismiss the report."));
        clearHeaderActions();
        addHeaderMenu(new String[]{"Export reports CSV", "Moderate a user by UID"},
                new Runnable[]{this::exportReportsCsv, this::showModerateUserDialog});
        FirebaseRepository.reports().addListenerForSingleValueEvent(new ValueEventListener() {
            @Override public void onDataChange(DataSnapshot snapshot) {
                if (!snapshot.exists() || snapshot.getChildrenCount() == 0) {
                    workspaceContent.addView(pageText("No reports right now."));
                    return;
                }
                for (DataSnapshot child : snapshot.getChildren()) {
                    String id = child.getKey();
                    String targetType = String.valueOf(child.child("targetType").getValue());
                    String targetLabel = String.valueOf(child.child("targetLabel").getValue());
                    String reason = String.valueOf(child.child("reason").getValue());
                    String description = String.valueOf(child.child("description").getValue());
                    String status = String.valueOf(child.child("status").getValue());
                    String reporterUid = String.valueOf(child.child("userId").getValue());
                    String reportedUid = String.valueOf(child.child("reportedUid").getValue());
                    workspaceContent.addView(pageText(targetType + ": " + targetLabel + "  •  " + reason + "  •  STATUS: " + status));
                    workspaceContent.addView(pageText(description));
                    if (!"null".equals(reportedUid)) workspaceContent.addView(pageText("Reported UID: " + reportedUid));
                    workspaceContent.addView(pageText("Reporter UID: " + reporterUid));
                    LinearLayout row = new LinearLayout(AdminActivity.this);
                    row.setOrientation(LinearLayout.HORIZONTAL);
                    LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(44));
                    rp.bottomMargin = dp(14);
                    row.setLayoutParams(rp);
                    row.addView(inlineButton("DISMISS", R.color.accent_blue_tint, R.color.accent_blue_stroke, v ->
                            updateReport(id, "DISMISSED", targetLabel)));
                    row.addView(inlineButton("RESOLVE", R.color.accent_green_tint, R.color.accent_green_stroke, v ->
                            updateReport(id, "RESOLVED", targetLabel)));
                    workspaceContent.addView(row);
                }
                workspaceContent.addView(pageText("To warn, restrict, suspend or ban a specific player, use ⋮ (top right) → Moderate a user by UID."));
            }
            @Override public void onCancelled(DatabaseError error) { workspaceContent.addView(pageText("Reports unavailable: " + error.getMessage())); }
        });
    }

    private void updateReport(String id, String status, String target) {
        FirebaseRepository.updateReportStatus(id, status, "")
                .addOnSuccessListener(u -> {
                    FirebaseRepository.logActivity("REPORT_" + status, target, "Report " + id);
                    toast("Report marked " + status + ".");
                })
                .addOnFailureListener(e -> toast(e.getMessage()));
    }

    /** A21 — lightweight CSV export that works without storage permissions or a backend job. */
    private void exportReportsCsv() {
        FirebaseRepository.reports().get().addOnSuccessListener(snapshot -> {
            StringBuilder csv = new StringBuilder("id,targetType,targetLabel,reportedUid,reason,status,userId,createdAt,description\n");
            for (DataSnapshot child : snapshot.getChildren()) {
                csv.append(csvCell(child.getKey())).append(',')
                        .append(csvCell(child.child("targetType").getValue(String.class))).append(',')
                        .append(csvCell(child.child("targetLabel").getValue(String.class))).append(',')
                        .append(csvCell(child.child("reportedUid").getValue(String.class))).append(',')
                        .append(csvCell(child.child("reason").getValue(String.class))).append(',')
                        .append(csvCell(child.child("status").getValue(String.class))).append(',')
                        .append(csvCell(child.child("userId").getValue(String.class))).append(',')
                        .append(csvCell(String.valueOf(child.child("createdAt").getValue()))).append(',')
                        .append(csvCell(child.child("description").getValue(String.class))).append('\n');
            }
            Intent share = new Intent(Intent.ACTION_SEND);
            share.setType("text/csv");
            share.putExtra(Intent.EXTRA_SUBJECT, "STARX24 reports export");
            share.putExtra(Intent.EXTRA_TEXT, csv.toString());
            startActivity(Intent.createChooser(share, "Share reports CSV"));
        }).addOnFailureListener(e -> toast("Could not export reports: " + e.getMessage()));
    }

    private String csvCell(String value) {
        if (value == null || "null".equals(value)) return "\"\"";
        return "\"" + value.replace("\"", "\"\"").replace("\n", " ").replace("\r", " ") + "\"";
    }

    private void showModerateUserDialog() {
        LinearLayout form = new LinearLayout(this);
        form.setOrientation(LinearLayout.VERTICAL);
        form.setPadding(dp(24), dp(8), dp(24), dp(8));
        EditText uid = field("Player UID");
        form.addView(uid);
        new FullScreenDialog.Builder(this)
                .setTitle("Moderate player")
                .setView(form)
                .setNegativeButton("CANCEL", null)
                .setNeutralButton("WARN", (d, w) -> moderate(uid.getText().toString().trim(), "WARNED"))
                .setPositiveButton("BAN", (d, w) -> moderate(uid.getText().toString().trim(), "BANNED"))
                .show();
    }

    private void moderate(String uid, String status) {
        if (uid.isEmpty()) { toast("Enter a UID."); return; }
        FirebaseRepository.setUserStatus(uid, status)
                .addOnSuccessListener(u -> {
                    FirebaseRepository.logActivity("USER_" + status, uid, "Moderation action");
                    toast("BANNED".equals(status) ? "Player banned." : "Player unbanned.");
                })
                .addOnFailureListener(e -> toast(e.getMessage()));
    }

    // ---------------------------------------------------------------------
    // A16 — FAQ Management
    // ---------------------------------------------------------------------
    private void loadFaqPage() {
        clearHeaderActions();
        addHeaderPlus("New FAQ entry", this::showAddFaqDialog);
        FirebaseRepository.faq().addListenerForSingleValueEvent(new ValueEventListener() {
            @Override public void onDataChange(DataSnapshot snapshot) {
                if (!snapshot.exists() || snapshot.getChildrenCount() == 0) {
                    workspaceContent.addView(pageText("No FAQ entries yet. Tap ＋ (top right) to add one — it appears instantly in the User App Help Center."));
                    return;
                }
                for (DataSnapshot child : snapshot.getChildren()) {
                    String id = child.getKey();
                    String question = String.valueOf(child.child("question").getValue());
                    workspaceContent.addView(pageText("Q: " + question));
                    workspaceContent.addView(inlineButton("DELETE", R.color.accent_purple_tint, R.color.accent_purple_stroke, v -> {
                        FirebaseRepository.deleteFaq(id);
                        FirebaseRepository.logActivity("FAQ_DELETED", question, "FAQ " + id);
                        toast("FAQ removed.");
                    }));
                }
            }
            @Override public void onCancelled(DatabaseError error) { workspaceContent.addView(pageText("FAQ unavailable: " + error.getMessage())); }
        });
    }

    private void showAddFaqDialog() {
        LinearLayout form = new LinearLayout(this);
        form.setOrientation(LinearLayout.VERTICAL);
        form.setPadding(dp(24), dp(8), dp(24), dp(8));
        EditText question = field("Question");
        EditText answer = bigField("Answer", "");
        answer.setMinLines(6);
        EditText category = field("Category (e.g. Registration, Room ID, Result)");
        form.addView(question);
        form.addView(answer);
        form.addView(category);
        new FullScreenDialog.Builder(this)
                .setTitle("Add FAQ entry")
                .setView(form)
                .setNegativeButton("CANCEL", null)
                .setPositiveButton("PUBLISH", (d, w) -> {
                    String q = question.getText().toString().trim();
                    String a = answer.getText().toString().trim();
                    if (q.isEmpty() || a.isEmpty()) { toast("Enter both a question and an answer."); return; }
                    FirebaseRepository.saveFaq(null, q, a, category.getText().toString().trim())
                            .addOnSuccessListener(u -> {
                                FirebaseRepository.logActivity("FAQ_CREATED", q, "");
                                toast("FAQ published live.");
                            })
                            .addOnFailureListener(e -> toast(e.getMessage()));
                })
                .show();
    }

    // ---------------------------------------------------------------------
    // Editable app content — Terms & Conditions / Privacy Policy / About Us
    // Saved at appContent/{terms|privacy|about}; the user app shows it live.
    // ---------------------------------------------------------------------
    private void loadContentPage(String key) {
        clearHeaderActions();
        workspaceContent.addView(pageText("Edit the text below and tap SAVE & PUBLISH — it shows instantly on the matching page in the User App."));
        final DatabaseReference ref = FirebaseRepository.appContent().child(key);
        ref.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override public void onDataChange(DataSnapshot snapshot) {
                if ("about".equals(key)) buildAboutEditor(ref, snapshot);
                else buildSectionsEditor(key, ref, snapshot);
            }
            @Override public void onCancelled(DatabaseError error) {
                workspaceContent.addView(pageText("Could not load: " + error.getMessage()));
            }
        });
    }

    private EditText bigField(String hint, String value) {
        EditText input = field(hint);
        input.setSingleLine(false);
        input.setMinLines(3);
        input.setGravity(Gravity.TOP | Gravity.START);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE
                | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        input.setText(value);
        return input;
    }

    // ---- small UI helpers for the content editors (rounded cards + outlined buttons) ----
    private android.graphics.drawable.GradientDrawable roundBg(int fill, int radiusDp, int strokeColor, int strokeDp) {
        android.graphics.drawable.GradientDrawable d = new android.graphics.drawable.GradientDrawable();
        d.setColor(fill);
        d.setCornerRadius(dp(radiusDp));
        if (strokeDp > 0) d.setStroke(dp(strokeDp), strokeColor);
        return d;
    }

    /** Small outlined button with icon + label (Edit / Delete style). */
    private TextView smallIconButton(String label, int iconRes, int color, View.OnClickListener l) {
        TextView t = new TextView(this);
        t.setText(label);
        t.setTextColor(color);
        t.setTextSize(12);
        t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(10), 0, dp(12), 0);
        t.setCompoundDrawablePadding(dp(5));
        android.graphics.drawable.Drawable icon = getDrawable(iconRes);
        if (icon != null) {
            icon = icon.mutate();
            icon.setTint(color);
            icon.setBounds(0, 0, dp(15), dp(15));
            t.setCompoundDrawablesRelative(icon, null, null, null);
        }
        t.setBackground(roundBg(0xFFFFFFFF, 10, color, 1));
        t.setOnClickListener(l);
        t.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(34)));
        return t;
    }

    /** Full-width rounded button. filled=true -> solid colour with white text, else outlined. */
    private TextView wideButton(String label, int color, boolean filled, View.OnClickListener l) {
        TextView t = new TextView(this);
        t.setText(label);
        t.setTextSize(14);
        t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setGravity(Gravity.CENTER);
        t.setTextColor(filled ? 0xFFFFFFFF : color);
        t.setBackground(filled ? roundBg(color, 14, 0, 0) : roundBg(0xFFFFFFFF, 14, color, 1));
        t.setOnClickListener(l);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(50));
        lp.topMargin = dp(10);
        t.setLayoutParams(lp);
        return t;
    }

    private void buildSectionsEditor(String key, DatabaseReference ref, DataSnapshot snapshot) {
        final String niceName = "terms".equals(key) ? "Terms & Conditions" : "Privacy Policy";
        final List<String[]> items = new ArrayList<>();
        for (DataSnapshot c : snapshot.child("sections").getChildren()) {
            String t = c.child("title").getValue(String.class);
            String b = c.child("body").getValue(String.class);
            if ((t != null && !t.trim().isEmpty()) || (b != null && !b.trim().isEmpty())) {
                items.add(new String[]{t == null ? "" : t, b == null ? "" : b});
            }
        }
        if (items.isEmpty()) {
            String[][] defaults = "terms".equals(key) ? TermsActivity.defaultContent() : PrivacyPolicyActivity.defaultContent();
            for (String[] d : defaults) items.add(new String[]{d[0], d[1]});
        }

        // Everything above (page title + hint) is hidden while the full-screen editor is open.
        final int preChildren = workspaceContent.getChildCount();
        final LinearLayout listPage = new LinearLayout(this);
        listPage.setOrientation(LinearLayout.VERTICAL);
        workspaceContent.addView(listPage, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        final int green = getColor(R.color.admin_green);
        final int red = getColor(R.color.admin_red);
        final int ink = getColor(R.color.text_primary);
        final int muted = getColor(R.color.text_secondary);
        final int stroke = getColor(R.color.stroke);
        final int soft = getColor(R.color.surface_2);

        // top row: section count + Add button
        LinearLayout topRow = new LinearLayout(this);
        topRow.setOrientation(LinearLayout.HORIZONTAL);
        topRow.setGravity(Gravity.CENTER_VERTICAL);
        topRow.setPadding(0, dp(10), 0, dp(4));
        final TextView count = new TextView(this);
        count.setTextColor(muted);
        count.setTextSize(12.5f);
        count.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        topRow.addView(count, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        listPage.addView(topRow);

        final LinearLayout holder = new LinearLayout(this);
        holder.setOrientation(LinearLayout.VERTICAL);
        listPage.addView(holder);

        final TextView status = new TextView(this);
        status.setTextSize(12);
        status.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        status.setTextColor(0xFFB45309);
        status.setText("●  Unsaved changes — tap SAVE & PUBLISH");
        status.setVisibility(View.GONE);
        status.setPadding(0, dp(6), 0, 0);

        final Runnable[] render = new Runnable[1];
        final Runnable markDirty = () -> status.setVisibility(View.VISIBLE);

        // Full-screen Add / Edit page (index -1 = new section). Not a popup — it replaces the whole page.
        final java.util.function.IntConsumer openEditor = index -> {
            for (int c = 0; c < preChildren; c++) workspaceContent.getChildAt(c).setVisibility(View.GONE);
            listPage.setVisibility(View.GONE);

            final LinearLayout page = new LinearLayout(this);
            page.setOrientation(LinearLayout.VERTICAL);
            workspaceContent.addView(page, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

            final Runnable close = () -> {
                workspaceContent.removeView(page);
                for (int c = 0; c < preChildren; c++) workspaceContent.getChildAt(c).setVisibility(View.VISIBLE);
                listPage.setVisibility(View.VISIBLE);
                if (workspaceScroll != null) workspaceScroll.scrollTo(0, 0);
            };

            LinearLayout bar = new LinearLayout(this);
            bar.setOrientation(LinearLayout.HORIZONTAL);
            bar.setGravity(Gravity.CENTER_VERTICAL);
            bar.setPadding(0, dp(8), 0, dp(6));
            TextView back = new TextView(this);
            back.setText("‹");
            back.setTextSize(26);
            back.setTextColor(ink);
            back.setGravity(Gravity.CENTER);
            back.setBackground(roundBg(0xFFFFFFFF, 20, stroke, 1));
            back.setOnClickListener(v -> close.run());
            bar.addView(back, new LinearLayout.LayoutParams(dp(40), dp(40)));
            TextView barTitle = new TextView(this);
            barTitle.setText(index >= 0 ? "Edit section" : "Add new section");
            barTitle.setTextColor(ink);
            barTitle.setTextSize(21);
            barTitle.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
            LinearLayout.LayoutParams btlp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
            btlp.setMarginStart(dp(12));
            bar.addView(barTitle, btlp);
            page.addView(bar);

            TextView sub = pageText(niceName + " — fill in the heading and text, then tap SAVE SECTION.");
            page.addView(sub);

            TextView l1 = new TextView(this);
            l1.setText("HEADING");
            l1.setTextColor(muted);
            l1.setTextSize(11);
            l1.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
            l1.setLetterSpacing(0.08f);
            l1.setPadding(dp(2), dp(14), 0, 0);
            page.addView(l1);
            EditText titleField = field("e.g. Fair Play & No Cheating");
            titleField.setTextSize(16);
            page.addView(titleField);

            TextView l2 = new TextView(this);
            l2.setText("TEXT");
            l2.setTextColor(muted);
            l2.setTextSize(11);
            l2.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
            l2.setLetterSpacing(0.08f);
            l2.setPadding(dp(2), dp(10), 0, 0);
            page.addView(l2);
            EditText bodyField = bigField("Write the text here (leave a blank line for a new paragraph)", "");
            bodyField.setMinLines(12);
            bodyField.setTextSize(14.5f);
            bodyField.setLineSpacing(dp(3), 1f);
            page.addView(bodyField);

            if (index >= 0) {
                titleField.setText(items.get(index)[0]);
                bodyField.setText(items.get(index)[1]);
            }

            page.addView(wideButton("SAVE SECTION", green, true, v -> {
                String t = titleField.getText().toString().trim();
                String b = bodyField.getText().toString().trim();
                if (t.isEmpty() && b.isEmpty()) { toast("Enter a heading or some text."); return; }
                if (index >= 0) { items.get(index)[0] = t; items.get(index)[1] = b; }
                else items.add(new String[]{t, b});
                markDirty.run();
                render[0].run();
                close.run();
            }));
            page.addView(wideButton("CANCEL", muted, false, v -> close.run()));
            page.addView(new View(this), new LinearLayout.LayoutParams(1, dp(28)));

            if (workspaceScroll != null) workspaceScroll.scrollTo(0, 0);
            if (index < 0) titleField.requestFocus();
        };

        topRow.addView(smallIconButton("Add section", R.drawable.ic_admin_plus, green, v -> openEditor.accept(-1)));

        render[0] = () -> {
            holder.removeAllViews();
            count.setText(items.size() + (items.size() == 1 ? " section" : " sections"));
            if (items.isEmpty()) {
                holder.addView(pageText("No sections yet. Tap “Add section” to create one."));
                return;
            }
            for (int i = 0; i < items.size(); i++) {
                final int index = i;
                final String[] item = items.get(i);

                LinearLayout card = new LinearLayout(this);
                card.setOrientation(LinearLayout.VERTICAL);
                card.setBackground(roundBg(0xFFFFFFFF, 16, stroke, 1));
                card.setPadding(dp(14), dp(14), dp(14), dp(14));
                LinearLayout.LayoutParams cardLp = new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                cardLp.topMargin = dp(10);

                LinearLayout head = new LinearLayout(this);
                head.setOrientation(LinearLayout.HORIZONTAL);
                head.setGravity(Gravity.CENTER_VERTICAL);

                TextView num = new TextView(this);
                num.setText(String.format(Locale.ENGLISH, "%02d", i + 1));
                num.setTextColor(muted);
                num.setTextSize(12);
                num.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
                num.setGravity(Gravity.CENTER);
                num.setBackground(roundBg(soft, 8, 0, 0));
                num.setPadding(dp(9), dp(6), dp(9), dp(6));
                head.addView(num);

                TextView title = new TextView(this);
                title.setText(item[0].isEmpty() ? "(No heading)" : item[0]);
                title.setTextColor(ink);
                title.setTextSize(15);
                title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
                title.setMaxLines(3);
                LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
                tlp.setMarginStart(dp(10));
                tlp.setMarginEnd(dp(8));
                head.addView(title, tlp);

                head.addView(smallIconButton("Edit", R.drawable.ic_edit_pencil, ink, v -> openEditor.accept(index)));
                TextView del = smallIconButton("Delete", R.drawable.ic_admin_delete, red, v ->
                        new FullScreenDialog.Builder(this)
                                .setTitle("Delete this section?")
                                .setMessage(item[0].isEmpty() ? "This section will be removed." : item[0])
                                .setNegativeButton("CANCEL", null)
                                .setPositiveButton("DELETE", (d, w) -> {
                                    items.remove(index);
                                    markDirty.run();
                                    render[0].run();
                                })
                                .show());
                ((LinearLayout.LayoutParams) del.getLayoutParams()).setMarginStart(dp(6));
                head.addView(del);
                card.addView(head);

                View divider = new View(this);
                divider.setBackgroundColor(stroke);
                LinearLayout.LayoutParams dlp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(1));
                dlp.topMargin = dp(12);
                card.addView(divider, dlp);

                TextView body = new TextView(this);
                body.setText(item[1].isEmpty() ? "No text yet — tap Edit to add." : item[1]);
                body.setTextColor(item[1].isEmpty() ? muted : 0xFF3A3A3F);
                body.setTextSize(13.5f);
                body.setLineSpacing(dp(4), 1f);
                body.setBackground(roundBg(soft, 12, 0, 0));
                body.setPadding(dp(14), dp(12), dp(14), dp(12));
                LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                blp.topMargin = dp(12);
                card.addView(body, blp);

                holder.addView(card, cardLp);
            }
        };
        render[0].run();

        listPage.addView(wideButton("＋  ADD NEW SECTION", getColor(R.color.admin_blue), false, v -> openEditor.accept(-1)));
        listPage.addView(status);
        listPage.addView(wideButton("SAVE & PUBLISH", green, true, v -> {
            List<Map<String, Object>> out = new ArrayList<>();
            for (String[] it : items) {
                if (it[0].trim().isEmpty() && it[1].trim().isEmpty()) continue;
                Map<String, Object> m = new HashMap<>();
                m.put("title", it[0].trim());
                m.put("body", it[1].trim());
                out.add(m);
            }
            if (out.isEmpty()) { toast("Add at least one section."); return; }
            Map<String, Object> payload = new HashMap<>();
            payload.put("sections", out);
            payload.put("updatedAt", com.google.firebase.database.ServerValue.TIMESTAMP);
            ref.setValue(payload)
                    .addOnSuccessListener(u -> {
                        status.setVisibility(View.GONE);
                        FirebaseRepository.logActivity("CONTENT_UPDATED", niceName, out.size() + " sections");
                        toast(niceName + " published live.");
                    })
                    .addOnFailureListener(e -> toast(e.getMessage()));
        }));
        listPage.addView(wideButton("RESET TO DEFAULT TEXT", red, false, v ->
                new FullScreenDialog.Builder(this)
                        .setTitle("Reset " + niceName + "?")
                        .setMessage("Your edited text will be removed and the original built-in text will show in the User App.")
                        .setNegativeButton("CANCEL", null)
                        .setPositiveButton("RESET", (d, w) -> ref.removeValue()
                                .addOnSuccessListener(u -> {
                                    FirebaseRepository.logActivity("CONTENT_RESET", niceName, "");
                                    toast("Reset to default.");
                                    showWorkspacePage(key);
                                })
                                .addOnFailureListener(e -> toast(e.getMessage())))
                        .show()));
        View spacer = new View(this);
        listPage.addView(spacer, new LinearLayout.LayoutParams(1, dp(28)));
    }

    private void buildAboutEditor(DatabaseReference ref, DataSnapshot snapshot) {
        final String[][] fields = AboutUsActivity.FIELDS;
        final EditText[] inputs = new EditText[fields.length];
        for (int i = 0; i < fields.length; i++) {
            String saved = snapshot.child(fields[i][0]).getValue(String.class);
            String value = saved == null || saved.trim().isEmpty() ? fields[i][2] : saved;
            workspaceContent.addView(pageText(fields[i][1]));
            boolean heading = fields[i][0].startsWith("t") && !"tag".equals(fields[i][0]);
            if (heading || "tag".equals(fields[i][0])) {
                inputs[i] = field(fields[i][1]);
                inputs[i].setText(value);
            } else {
                inputs[i] = bigField(fields[i][1], value);
            }
            workspaceContent.addView(inputs[i]);
        }
        workspaceContent.addView(wideButton("SAVE & PUBLISH", getColor(R.color.admin_green), true, v -> {
            Map<String, Object> payload = new HashMap<>();
            for (int i = 0; i < fields.length; i++) {
                String text = inputs[i].getText().toString().trim();
                // Unchanged-from-default or empty text is not stored, so the built-in text keeps applying.
                if (!text.isEmpty() && !text.equals(fields[i][2])) payload.put(fields[i][0], text);
            }
            if (payload.isEmpty()) {
                ref.removeValue();
            } else {
                payload.put("updatedAt", com.google.firebase.database.ServerValue.TIMESTAMP);
                ref.setValue(payload);
            }
            FirebaseRepository.logActivity("CONTENT_UPDATED", "About Us", "");
            toast("About Us published live.");
        }));
        workspaceContent.addView(wideButton("RESET TO DEFAULT TEXT", getColor(R.color.admin_red), false,
                v -> new FullScreenDialog.Builder(this)
                        .setTitle("Reset About Us?")
                        .setMessage("Your edited text will be removed and the original built-in text will show in the User App.")
                        .setNegativeButton("CANCEL", null)
                        .setPositiveButton("RESET", (d, w) -> ref.removeValue()
                                .addOnSuccessListener(u -> {
                                    toast("Reset to default.");
                                    showWorkspacePage("about");
                                })
                                .addOnFailureListener(e -> toast(e.getMessage())))
                        .show()));
    }

    // ---------------------------------------------------------------------
    // A22 — Admin Activity Log
    // ---------------------------------------------------------------------

    // ---------------------------------------------------------------------
    // Duplicate match / bulk actions
    // ---------------------------------------------------------------------
    private void showDuplicateMatchDialog(Tournament t) {
        final java.util.Calendar cal = java.util.Calendar.getInstance();
        long base = t.getEffectiveStartAt();
        cal.setTimeInMillis(base > System.currentTimeMillis() ? base + 24L * 3600L * 1000L : System.currentTimeMillis() + 3600L * 1000L);
        new android.app.DatePickerDialog(this, (dv, y, m, d) -> {
            cal.set(y, m, d);
            new android.app.TimePickerDialog(this, (tv, h, min) -> {
                cal.set(java.util.Calendar.HOUR_OF_DAY, h);
                cal.set(java.util.Calendar.MINUTE, min);
                cal.set(java.util.Calendar.SECOND, 0);
                cal.set(java.util.Calendar.MILLISECOND, 0);
                long when = cal.getTimeInMillis();
                if (when <= System.currentTimeMillis()) { toast("Choose a future date and time."); return; }
                FirebaseRepository.duplicateTournament(t, when)
                        .addOnSuccessListener(v -> {
                            FirebaseRepository.logActivity("MATCH_DUPLICATED", t.getTitle(), "New start " + when);
                            toast("Match duplicated.");
                            showWorkspacePage("matches");
                        })
                        .addOnFailureListener(e -> toast("Duplicate failed: " + e.getMessage()));
            }, cal.get(java.util.Calendar.HOUR_OF_DAY), cal.get(java.util.Calendar.MINUTE), false).show();
        }, cal.get(java.util.Calendar.YEAR), cal.get(java.util.Calendar.MONTH), cal.get(java.util.Calendar.DAY_OF_MONTH)).show();
    }

    private void showBulkMatchDialog() {
        if (tournaments.isEmpty()) { toast("No matches to select."); return; }
        final List<Tournament> list = new ArrayList<>(tournaments);
        final String[] labels = new String[list.size()];
        final boolean[] checked = new boolean[list.size()];
        for (int i = 0; i < list.size(); i++) {
            Tournament t = list.get(i);
            labels[i] = t.getTitle() + "  •  " + t.getDate() + " " + t.getTime() + "  •  " + statusPillLabel(t.getEffectiveStatus());
        }
        new FancyText.MaterialBuilder(this)
                .setTitle("Select matches")
                .setMultiChoiceItems(labels, checked, (d, which, isChecked) -> checked[which] = isChecked)
                .setPositiveButton("DELETE", (d, w) -> {
                    List<Tournament> sel = pickChecked(list, checked);
                    if (sel.isEmpty()) { toast("Select at least one match."); return; }
                    bulkDelete(sel);
                })
                .setNegativeButton("CANCEL MATCH", (d, w) -> {
                    List<Tournament> sel = pickChecked(list, checked);
                    if (sel.isEmpty()) { toast("Select at least one match."); return; }
                    bulkCancel(sel);
                })
                .setNeutralButton("SHIFT TIME", (d, w) -> {
                    List<Tournament> sel = pickChecked(list, checked);
                    if (sel.isEmpty()) { toast("Select at least one match."); return; }
                    showBulkShiftDialog(sel);
                })
                .show();
    }

    private List<Tournament> pickChecked(List<Tournament> list, boolean[] checked) {
        List<Tournament> out = new ArrayList<>();
        for (int i = 0; i < list.size(); i++) if (checked[i]) out.add(list.get(i));
        return out;
    }

    private void bulkReport(String what, int ok, List<String> problems) {
        StringBuilder msg = new StringBuilder(what + ": " + ok + " done");
        if (!problems.isEmpty()) msg.append(", ").append(problems.size()).append(" skipped (").append(problems.get(0)).append(")");
        toast(msg.toString());
        FirebaseRepository.logActivity("BULK_" + what.toUpperCase(Locale.ENGLISH), ok + " matches", msg.toString());
        showWorkspacePage("matches");
    }

    private void bulkDelete(List<Tournament> sel) {
        new FancyText.MaterialBuilder(this)
                .setTitle("Delete " + sel.size() + " matches?")
                .setMessage("Paid matches that still have joined players are skipped (they need a refund first).")
                .setNegativeButton("BACK", null)
                .setPositiveButton("DELETE", (d, w) -> {
                    final int[] ok = {0};
                    final List<String> problems = new ArrayList<>();
                    final int[] left = {sel.size()};
                    for (Tournament t : sel) {
                        FirebaseRepository.deleteTournament(t.getId()).addOnCompleteListener(task -> {
                            if (task.isSuccessful()) ok[0]++;
                            else problems.add(task.getException() == null ? "error" : String.valueOf(task.getException().getMessage()));
                            if (--left[0] == 0) bulkReport("Delete", ok[0], problems);
                        });
                    }
                })
                .show();
    }

    private void bulkCancel(List<Tournament> sel) {
        new FancyText.MaterialBuilder(this)
                .setTitle("Cancel " + sel.size() + " matches?")
                .setMessage("Players will not be able to join. Paid matches with joined players are skipped.")
                .setNegativeButton("BACK", null)
                .setPositiveButton("CANCEL MATCHES", (d, w) -> {
                    final int[] ok = {0};
                    final List<String> problems = new ArrayList<>();
                    final int[] left = {sel.size()};
                    for (Tournament t : sel) {
                        FirebaseRepository.cancelTournament(t, "Cancelled by admin").addOnCompleteListener(task -> {
                            if (task.isSuccessful()) ok[0]++;
                            else problems.add(task.getException() == null ? "error" : String.valueOf(task.getException().getMessage()));
                            if (--left[0] == 0) bulkReport("Cancel", ok[0], problems);
                        });
                    }
                })
                .show();
    }

    private void showBulkShiftDialog(List<Tournament> sel) {
        LinearLayout form = new LinearLayout(this);
        form.setOrientation(LinearLayout.VERTICAL);
        form.setPadding(dp(24), dp(8), dp(24), dp(8));
        EditText minutes = field("Minutes (+ later, - earlier). e.g. 30 or -15");
        minutes.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_SIGNED);
        form.addView(minutes);
        new FancyText.MaterialBuilder(this)
                .setTitle("Shift " + sel.size() + " matches")
                .setView(form)
                .setNegativeButton("BACK", null)
                .setPositiveButton("SHIFT", (d, w) -> {
                    long mins;
                    try { mins = Long.parseLong(minutes.getText().toString().trim()); }
                    catch (NumberFormatException e) { toast("Enter minutes, like 30 or -15."); return; }
                    if (mins == 0L) { toast("Enter a non-zero value."); return; }
                    final long delta = mins * 60_000L;
                    final int[] ok = {0};
                    final List<String> problems = new ArrayList<>();
                    final int[] left = {sel.size()};
                    for (Tournament t : sel) {
                        String st = t.getEffectiveStatus();
                        if (Tournament.COMPLETED.equals(st) || Tournament.CANCELLED.equals(st) || Tournament.RESULT_PUBLISHED.equals(st)) {
                            problems.add("finished match");
                            if (--left[0] == 0) bulkReport("Shift", ok[0], problems);
                            continue;
                        }
                        FirebaseRepository.shiftTournament(t, delta).addOnCompleteListener(task -> {
                            if (task.isSuccessful()) ok[0]++;
                            else problems.add(task.getException() == null ? "error" : String.valueOf(task.getException().getMessage()));
                            if (--left[0] == 0) bulkReport("Shift", ok[0], problems);
                        });
                    }
                })
                .show();
    }

    // ---------------------------------------------------------------------
    // Revenue dashboard: entry fees collected, prizes paid out, profit (from tournaments + results)
    // ---------------------------------------------------------------------
    private void loadRevenuePage() {
        clearHeaderActions();
        workspaceContent.addView(pageText("Entry fees collected minus prize/refund coins paid out. Cancelled matches are ignored."));
        final TextView loading = pageText("Calculating…");
        workspaceContent.addView(loading);
        FirebaseRepository.tournaments().addListenerForSingleValueEvent(new ValueEventListener() {
            @Override public void onDataChange(DataSnapshot snapshot) {
                workspaceContent.removeView(loading);
                java.util.TreeMap<String, long[]> perDay = new java.util.TreeMap<>();   // yyyy-MM-dd -> {collected, paidOut}
                java.text.SimpleDateFormat dayFmt = new java.text.SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH);
                long now = System.currentTimeMillis();
                long[] today = new long[2], week = new long[2], month = new long[2], all = new long[2];
                for (DataSnapshot t : snapshot.getChildren()) {
                    String status = String.valueOf(t.child("status").getValue()).toUpperCase(Locale.ENGLISH);
                    if ("CANCELLED".equals(status) || "DRAFT".equals(status)) continue;
                    long fee = numberOf(t.child("entryFeeCoins").getValue());
                    long joined = numberOf(t.child("joinedSlots").getValue());
                    long collected = fee * joined;
                    long paid = 0L;
                    for (DataSnapshot r : t.child("results").getChildren()) paid += numberOf(r.child("coins").getValue());
                    if (collected == 0L && paid == 0L) continue;
                    long when = numberOf(t.child("startAt").getValue());
                    if (when <= 0L) when = numberOf(t.child("resultPublishedAt").getValue());
                    if (when <= 0L) when = numberOf(t.child("createdAt").getValue());
                    if (when <= 0L) continue;
                    String day = dayFmt.format(new java.util.Date(when));
                    long[] agg = perDay.get(day);
                    if (agg == null) { agg = new long[2]; perDay.put(day, agg); }
                    agg[0] += collected; agg[1] += paid;
                    all[0] += collected; all[1] += paid;
                    long age = now - when;
                    if (age <= 30L * 86400000L) { month[0] += collected; month[1] += paid; }
                    if (age <= 7L * 86400000L) { week[0] += collected; week[1] += paid; }
                    if (dayFmt.format(new java.util.Date(now)).equals(day)) { today[0] += collected; today[1] += paid; }
                }
                addRevenueSummary("TODAY", today);
                addRevenueSummary("LAST 7 DAYS", week);
                addRevenueSummary("LAST 30 DAYS", month);
                addRevenueSummary("ALL TIME", all);

                // Profit bars for the last 14 days with data.
                List<String> days = new ArrayList<>(perDay.keySet());
                int from = Math.max(0, days.size() - 14);
                long maxAbs = 1L;
                for (int i = from; i < days.size(); i++) {
                    long[] a = perDay.get(days.get(i));
                    maxAbs = Math.max(maxAbs, Math.abs(a[0] - a[1]));
                }
                TextView head = pageText("DAILY PROFIT (last " + (days.size() - from) + " days)");
                head.setTypeface(null, android.graphics.Typeface.BOLD);
                workspaceContent.addView(head);
                if (days.isEmpty()) workspaceContent.addView(pageText("No paid matches yet."));
                for (int i = days.size() - 1; i >= from; i--) {
                    long[] a = perDay.get(days.get(i));
                    long profit = a[0] - a[1];
                    LinearLayout row = new LinearLayout(AdminActivity.this);
                    row.setOrientation(LinearLayout.VERTICAL);
                    row.setPadding(0, dp(6), 0, dp(6));
                    TextView line = pageText(days.get(i) + "   in ₹" + a[0] + "  •  out ₹" + a[1] + "  •  profit ₹" + profit);
                    line.setTextColor(getColor(profit >= 0 ? R.color.admin_green : R.color.admin_red));
                    row.addView(line);
                    View bar = new View(AdminActivity.this);
                    android.graphics.drawable.GradientDrawable bg = new android.graphics.drawable.GradientDrawable();
                    bg.setColor(getColor(profit >= 0 ? R.color.admin_green : R.color.admin_red));
                    bg.setCornerRadius(dp(3));
                    bar.setBackground(bg);
                    int w = Math.max(dp(4), (int) (dp(260) * (Math.abs(profit) / (double) maxAbs)));
                    row.addView(bar, new LinearLayout.LayoutParams(w, dp(8)));
                    workspaceContent.addView(row);
                }
            }
            @Override public void onCancelled(DatabaseError error) {
                workspaceContent.removeView(loading);
                workspaceContent.addView(pageText("Revenue unavailable: " + error.getMessage()));
            }
        });
    }

    private void addRevenueSummary(String label, long[] agg) {
        long profit = agg[0] - agg[1];
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(14), dp(12), dp(14), dp(12));
        android.graphics.drawable.GradientDrawable bg = new android.graphics.drawable.GradientDrawable();
        bg.setColor(getColor(R.color.surface));
        bg.setCornerRadius(dp(4));
        bg.setStroke(dp(1), getColor(R.color.admin_card_stroke));
        card.setBackground(bg);
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        cp.topMargin = dp(10);
        card.setLayoutParams(cp);
        TextView title = pageText(label);
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        card.addView(title);
        LinearLayout stats = new LinearLayout(this);
        stats.setOrientation(LinearLayout.HORIZONTAL);
        stats.addView(statColumn("Collected", "₹" + agg[0]));
        stats.addView(statColumn("Paid out", "₹" + agg[1]));
        stats.addView(statColumn("Profit", "₹" + profit));
        card.addView(stats);
        workspaceContent.addView(card);
    }

    private long numberOf(Object raw) { return raw instanceof Number ? ((Number) raw).longValue() : 0L; }

    private String activityRange = "ALL";
    private String activityQuery = "";

    private void loadActivityLogPage() {
        workspaceContent.addView(pageText("Every meaningful admin action is written here. Search by admin, action or target, and filter by date."));
        clearHeaderActions();
        addHeaderAction(R.drawable.ic_admin_download, "Export activity CSV", v -> exportActivityLogCsv());
        activityRange = "ALL";
        activityQuery = "";

        final EditText search = field("Search admin / action / target");
        workspaceContent.addView(search);

        LinearLayout chips = new LinearLayout(this);
        chips.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams chipsLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(40));
        chipsLp.topMargin = dp(8);
        chips.setLayoutParams(chipsLp);
        workspaceContent.addView(chips);

        final LinearLayout listBox = new LinearLayout(this);
        listBox.setOrientation(LinearLayout.VERTICAL);
        workspaceContent.addView(listBox);
        final TextView loading = pageText("Loading…");
        listBox.addView(loading);

        final List<String[]> entries = new ArrayList<>();   // {admin, action, target, details, ts}
        final Runnable render = () -> {
            listBox.removeAllViews();
            long now = System.currentTimeMillis();
            long minTs = "TODAY".equals(activityRange) ? now - 24L * 3600L * 1000L
                    : "WEEK".equals(activityRange) ? now - 7L * 24L * 3600L * 1000L : 0L;
            String q = activityQuery.trim().toLowerCase(Locale.ENGLISH);
            java.text.SimpleDateFormat fmt = new java.text.SimpleDateFormat("dd MMM, hh:mm a", Locale.ENGLISH);
            int shown = 0;
            for (int i = entries.size() - 1; i >= 0 && shown < 200; i--) {
                String[] e = entries.get(i);
                long ts = 0L;
                try { ts = Long.parseLong(e[4]); } catch (NumberFormatException ignored) { }
                if (minTs > 0L && ts < minTs) continue;
                if (!q.isEmpty() && !(e[0] + " " + e[1] + " " + e[2] + " " + e[3]).toLowerCase(Locale.ENGLISH).contains(q)) continue;
                String when = ts > 0L ? fmt.format(new java.util.Date(ts)) : "";
                listBox.addView(pageText((when.isEmpty() ? "" : when + "  •  ") + e[0] + "  →  " + e[1] + "  →  " + e[2]
                        + (e[3].isEmpty() ? "" : "\n" + e[3])));
                shown++;
            }
            if (shown == 0) listBox.addView(pageText("No matching activity."));
        };

        final String[][] ranges = {{"All", "ALL"}, {"Last 24h", "TODAY"}, {"Last 7 days", "WEEK"}};
        for (String[] r : ranges) {
            chips.addView(inlineButton(r[0], R.color.surface_2, R.color.stroke, v -> { activityRange = r[1]; render.run(); }));
        }
        search.addTextChangedListener(new android.text.TextWatcher() {
            @Override public void beforeTextChanged(CharSequence c, int a, int b, int d) { }
            @Override public void onTextChanged(CharSequence c, int a, int b, int d) { }
            @Override public void afterTextChanged(android.text.Editable e) { activityQuery = e.toString(); render.run(); }
        });

        FirebaseRepository.activityLogs().addListenerForSingleValueEvent(new ValueEventListener() {
            @Override public void onDataChange(DataSnapshot snapshot) {
                if (!snapshot.exists() || snapshot.getChildrenCount() == 0) {
                    listBox.removeAllViews();
                    listBox.addView(pageText("No activity recorded yet."));
                    return;
                }
                for (DataSnapshot entry : snapshot.getChildren()) {
                    String admin = firstNonEmpty(entry.child("admin").getValue(), entry.child("actorUid").getValue(), "system");
                    String action = firstNonEmpty(entry.child("action").getValue(), null, "");
                    String target = firstNonEmpty(entry.child("target").getValue(), entry.child("details").getValue(), "");
                    String details = entry.child("target").exists() ? firstNonEmpty(entry.child("details").getValue(), null, "") : "";
                    String ts = firstNonEmpty(entry.child("timestamp").getValue(), entry.child("at").getValue(), "0");
                    entries.add(new String[]{admin, action, target, details, ts});
                }
                java.util.Collections.sort(entries, (a, b) -> {
                    try { return Long.compare(Long.parseLong(a[4]), Long.parseLong(b[4])); } catch (NumberFormatException e) { return 0; }
                });
                render.run();
            }
            @Override public void onCancelled(DatabaseError error) {
                listBox.removeAllViews();
                listBox.addView(pageText("Activity log unavailable: " + error.getMessage()));
            }
        });
    }

    private String firstNonEmpty(Object a, Object b, String fallback) {
        if (a != null && !String.valueOf(a).trim().isEmpty() && !"null".equals(String.valueOf(a))) return String.valueOf(a);
        if (b != null && !String.valueOf(b).trim().isEmpty() && !"null".equals(String.valueOf(b))) return String.valueOf(b);
        return fallback;
    }

    /** A22 — shareable audit export for compliance reviews and offline analysis. */
    private void exportActivityLogCsv() {
        FirebaseRepository.activityLogs().get().addOnSuccessListener(snapshot -> {
            StringBuilder csv = new StringBuilder("id,admin,action,target,details,timestamp\n");
            for (DataSnapshot child : snapshot.getChildren()) {
                csv.append(csvCell(child.getKey())).append(',')
                        .append(csvCell(child.child("admin").getValue(String.class))).append(',')
                        .append(csvCell(child.child("action").getValue(String.class))).append(',')
                        .append(csvCell(child.child("target").getValue(String.class))).append(',')
                        .append(csvCell(child.child("details").getValue(String.class))).append(',')
                        .append(csvCell(String.valueOf(child.child("timestamp").getValue()))).append('\n');
            }
            Intent share = new Intent(Intent.ACTION_SEND);
            share.setType("text/csv");
            share.putExtra(Intent.EXTRA_SUBJECT, "STARX24 activity log export");
            share.putExtra(Intent.EXTRA_TEXT, csv.toString());
            startActivity(Intent.createChooser(share, "Share activity CSV"));
        }).addOnFailureListener(e -> toast("Could not export activity: " + e.getMessage()));
    }

    private android.view.View inlineButton(String label, int tintRes, int strokeRes, View.OnClickListener listener) {
        MaterialButton button = new MaterialButton(this);
        button.setText(label);
        button.setTextColor(getColor(strokeRes));
        button.setTextSize(11);
        button.setAllCaps(false);
        button.setCornerRadius(dp(4));
        button.setBackgroundTintList(android.content.res.ColorStateList.valueOf(getColor(tintRes)));
        button.setStrokeColor(android.content.res.ColorStateList.valueOf(getColor(strokeRes)));
        button.setStrokeWidth(dp(1));
        button.setElevation(0f);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, dp(40), 1);
        p.rightMargin = dp(6);
        button.setLayoutParams(p);
        button.setOnClickListener(listener);
        return button;
    }

    private void loadNoticePage() {
        clearHeaderActions();
        addHeaderPlus("New announcement", this::showAnnouncementComposer);
        workspaceContent.addView(pageText("Target All Users, a specific Tournament or a specific Team. Pinned announcements stay at the top of the User App feed."));
        FirebaseRepository.announcements().addListenerForSingleValueEvent(new ValueEventListener() {
            @Override public void onDataChange(DataSnapshot snapshot) {
                if (!snapshot.exists() || snapshot.getChildrenCount() == 0) {
                    workspaceContent.addView(pageText("No announcements published yet."));
                    return;
                }
                List<DataSnapshot> entries = new ArrayList<>();
                for (DataSnapshot child : snapshot.getChildren()) entries.add(child);
                for (int i = entries.size() - 1; i >= 0; i--) {
                    DataSnapshot a = entries.get(i);
                    String id = a.getKey();
                    String title = String.valueOf(a.child("title").getValue());
                    String targetType = String.valueOf(a.child("targetType").getValue());
                    String targetId = String.valueOf(a.child("targetId").getValue());
                    boolean pinned = Boolean.TRUE.equals(a.child("pinned").getValue());
                    String target = "ALL".equals(targetType) ? "ALL USERS"
                            : targetType + (targetId == null || targetId.isEmpty() || "null".equals(targetId) ? "" : " • " + targetId);
                    Long scheduledAt = a.child("scheduledAt").getValue(Long.class);
                    Long expiresAt = a.child("expiresAt").getValue(Long.class);
                    String timing = scheduledAt != null && scheduledAt > System.currentTimeMillis()
                            ? " • SCHEDULED " + formatAnnouncementTime(scheduledAt) : "";
                    if (expiresAt != null && expiresAt > 0L) timing += " • EXPIRES " + formatAnnouncementTime(expiresAt);
                    workspaceContent.addView(pageText((pinned ? "PINNED • " : "") + title + "  —  " + target + timing));
                    workspaceContent.addView(inlineButton("DELETE", R.color.accent_purple_tint, R.color.accent_purple_stroke, v -> {
                        FirebaseRepository.deleteAnnouncement(id);
                        FirebaseRepository.logActivity("ANNOUNCEMENT_DELETED", title, "");
                        toast("Announcement removed.");
                    }));
                }
            }
            @Override public void onCancelled(DatabaseError error) { workspaceContent.addView(pageText("Announcements unavailable: " + error.getMessage())); }
        });
    }

    private void showAnnouncementComposer() {
        LinearLayout form = new LinearLayout(this);
        form.setOrientation(LinearLayout.VERTICAL);
        form.setPadding(dp(24), dp(8), dp(24), dp(8));

        EditText title = field("Announcement title");
        EditText message = field("Message");
        Spinner target = new Spinner(this);
        String[] targets = {"ALL USERS", "SPECIFIC TOURNAMENT", "SPECIFIC TEAM"};
        target.setAdapter(new android.widget.ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, targets));
        EditText targetId = field("Tournament or Team ID (leave blank for All Users)");
        EditText scheduledAt = field("Publish at (dd MMM yyyy HH:mm, blank = now)");
        EditText expiresAt = field("Expires at (dd MMM yyyy HH:mm, blank = never)");
        android.widget.CheckBox pin = new android.widget.CheckBox(this);
        pin.setText("Pin to top of feed");
        pin.setTextColor(getColor(R.color.text_primary));

        form.addView(title);
        form.addView(message);
        form.addView(target);
        form.addView(targetId);
        form.addView(scheduledAt);
        form.addView(expiresAt);
        form.addView(pin);
        final com.arenax.tournament.util.RedirectPickerDialog.Field redirectField =
                com.arenax.tournament.util.RedirectPickerDialog.addField(this, form);

        new FullScreenDialog.Builder(this)
                .setTitle("New announcement")
                .setView(form)
                .setNegativeButton("CANCEL", null)
                .setPositiveButton("PUBLISH", (d, w) -> {
                    String titleValue = title.getText().toString().trim();
                    String messageValue = message.getText().toString().trim();
                    if (titleValue.isEmpty() || messageValue.isEmpty()) {
                        toast("Enter both a title and a message.");
                        return;
                    }
                    String targetType = target.getSelectedItemPosition() == 1 ? "TOURNAMENT"
                            : target.getSelectedItemPosition() == 2 ? "TEAM" : "ALL";
                    String targetIdValue = targetId.getText().toString().trim();
                    if (!"ALL".equals(targetType) && targetIdValue.isEmpty()) {
                        toast("Enter the target tournament or team ID.");
                        return;
                    }
                    long scheduledMillis = parseAnnouncementTime(scheduledAt.getText().toString().trim());
                    long expiresMillis = parseAnnouncementTime(expiresAt.getText().toString().trim());
                    if (!scheduledAt.getText().toString().trim().isEmpty() && scheduledMillis == 0L) {
                        toast("Use date format: 07 Sep 2026 20:30");
                        return;
                    }
                    if (!expiresAt.getText().toString().trim().isEmpty() && expiresMillis == 0L) {
                        toast("Use date format: 07 Sep 2026 20:30");
                        return;
                    }
                    if (scheduledMillis > 0L && expiresMillis > 0L && expiresMillis <= scheduledMillis) {
                        toast("Expiry must be after publish time.");
                        return;
                    }
                    FirebaseRepository.publishAnnouncement(titleValue, messageValue, targetType,
                                    targetIdValue, pin.isChecked(), scheduledMillis, expiresMillis,
                                    redirectField.get())
                            .addOnSuccessListener(u -> {
                                FirebaseRepository.logActivity("ANNOUNCEMENT_PUBLISHED", titleValue, targetType);
                                toast("Announcement published live.");
                            })
                            .addOnFailureListener(e -> toast(e.getMessage()));
                })
                .show();
    }

    private void loadAnalyticsPage() {
        clearHeaderActions();
        addHeaderMenu(new String[]{"Revenue dashboard"}, new Runnable[]{() -> showWorkspacePage("revenue")});
        workspaceContent.addView(pageText("Live metrics are read from Firebase. Pull down to refresh and get a current platform snapshot. Status bars make the distribution easier to scan."));

        LinearLayout grid = new LinearLayout(this);
        grid.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams gridParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        gridParams.topMargin = dp(10);
        grid.setLayoutParams(gridParams);
        workspaceContent.addView(grid);
        addAnalyticsMetricRow(grid, "USERS", FirebaseRepository.users(),
                "TOURNAMENTS", FirebaseRepository.tournaments());
        addAnalyticsMetricRow(grid, "MATCHES", FirebaseRepository.matches(),
                "TEAMS", FirebaseRepository.teams());
        addAnalyticsMetricRow(grid, "SUPPORT TICKETS", FirebaseRepository.support(),
                "REPORTS", FirebaseRepository.reports());
        addAnalyticsMetricRow(grid, "DISPUTES", FirebaseRepository.disputes(),
                "ACTIVITY EVENTS", FirebaseRepository.activityLogs());

        TextView registrationSummary = pageText("REGISTRATIONS: loading…");
        registrationSummary.setTextColor(getColor(R.color.accent_green));
        registrationSummary.setTypeface(null, android.graphics.Typeface.BOLD);
        workspaceContent.addView(registrationSummary);
        FirebaseRepository.tournaments().addListenerForSingleValueEvent(new ValueEventListener() {
            @Override public void onDataChange(DataSnapshot snapshot) {
                long registrations = 0;
                for (DataSnapshot child : snapshot.getChildren()) {
                    Object rawJoined = child.child("joinedSlots").getValue();
                    if (rawJoined instanceof Number) registrations += Math.max(0L, ((Number) rawJoined).longValue());
                    else if (rawJoined != null) { try { registrations += Math.max(0L, Long.parseLong(String.valueOf(rawJoined))); } catch (NumberFormatException ignored) { } }
                }
                registrationSummary.setText("REGISTRATIONS: " + registrations + "  •  FREE ENTRY ONLY");
            }
            @Override public void onCancelled(DatabaseError error) {
                registrationSummary.setText("REGISTRATIONS: unavailable");
            }
        });

        workspaceContent.addView(pageText("TOURNAMENT STATUS BREAKDOWN"));
        TextView tournamentStatus = pageText("Loading tournament statuses…");
        workspaceContent.addView(tournamentStatus);
        LinearLayout tournamentBars = new LinearLayout(this);
        tournamentBars.setOrientation(LinearLayout.VERTICAL);
        workspaceContent.addView(tournamentBars);
        FirebaseRepository.tournaments().addListenerForSingleValueEvent(new ValueEventListener() {
            @Override public void onDataChange(DataSnapshot snapshot) {
                Map<String, Integer> counts = new java.util.LinkedHashMap<>();
                for (DataSnapshot child : snapshot.getChildren()) {
                    String status = safeStatus(child);
                    counts.put(status, counts.containsKey(status) ? counts.get(status) + 1 : 1);
                }
                tournamentStatus.setText(formatCounts(counts, "No tournaments yet."));
                renderAnalyticsBars(tournamentBars, counts, R.color.blood_red);
            }
            @Override public void onCancelled(DatabaseError error) {
                tournamentStatus.setText("Tournament status data unavailable.");
            }
        });

        workspaceContent.addView(pageText("MATCH STATUS BREAKDOWN"));
        TextView matchStatus = pageText("Loading match statuses…");
        workspaceContent.addView(matchStatus);
        LinearLayout matchBars = new LinearLayout(this);
        matchBars.setOrientation(LinearLayout.VERTICAL);
        workspaceContent.addView(matchBars);
        FirebaseRepository.matches().addListenerForSingleValueEvent(new ValueEventListener() {
            @Override public void onDataChange(DataSnapshot snapshot) {
                Map<String, Integer> counts = new java.util.LinkedHashMap<>();
                for (DataSnapshot child : snapshot.getChildren()) {
                    String status = safeStatus(child);
                    counts.put(status, counts.containsKey(status) ? counts.get(status) + 1 : 1);
                }
                matchStatus.setText(formatCounts(counts, "No matches yet."));
                renderAnalyticsBars(matchBars, counts, R.color.accent_blue);
            }
            @Override public void onCancelled(DatabaseError error) {
                matchStatus.setText("Match status data unavailable.");
            }
        });
    }

    /** Reads a "status" field defensively: Firebase throws a runtime DatabaseException from
     *  getValue(String.class) the moment any one record has that field stored as a non-string
     *  (a number, boolean, etc — easy to end up with from older data or a manual console edit).
     *  That one bad record was enough to crash the whole Analytics page on open; going through
     *  the raw Object and String.valueOf (same defensive pattern as Match/Tournament's text()
     *  helpers) makes every record safe to count instead. */
    private String safeStatus(DataSnapshot child) {
        Object raw = child.child("status").getValue();
        String status = raw == null ? "" : String.valueOf(raw).trim();
        return status.isEmpty() ? "UNKNOWN" : status;
    }

    private void addAnalyticsMetricRow(LinearLayout grid, String leftLabel, DatabaseReference leftRef,
                                       String rightLabel, DatabaseReference rightRef) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams rowParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(82));
        rowParams.bottomMargin = dp(8);
        row.setLayoutParams(rowParams);
        TextView leftValue = analyticsValue();
        TextView rightValue = analyticsValue();
        addAnalyticsCard(row, leftLabel, leftValue, R.color.accent_blue);
        addAnalyticsCard(row, rightLabel, rightValue, R.color.accent_purple);
        grid.addView(row);
        loadAnalyticsCount(leftRef, leftValue);
        loadAnalyticsCount(rightRef, rightValue);
    }

    private TextView analyticsValue() {
        TextView value = new TextView(this);
        value.setText("…");
        value.setTextColor(getColor(R.color.text_primary));
        value.setTextSize(22);
        value.setTypeface(null, android.graphics.Typeface.BOLD);
        return value;
    }

    private void addAnalyticsCard(LinearLayout row, String label, TextView value, int accent) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setGravity(android.view.Gravity.CENTER_VERTICAL);
        card.setPadding(dp(14), dp(8), dp(14), dp(8));
        android.graphics.drawable.GradientDrawable background = new android.graphics.drawable.GradientDrawable();
        background.setColor(getColor(R.color.surface));
        background.setCornerRadius(dp(4));
        background.setStroke(dp(1), getColor(accent));
        card.setBackground(background);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f);
        params.setMargins(dp(3), 0, dp(3), 0);
        card.setLayoutParams(params);
        TextView title = pageText(label);
        title.setTextColor(getColor(accent));
        title.setTextSize(9);
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        card.addView(title);
        card.addView(value);
        row.addView(card);
    }

    private void loadAnalyticsCount(DatabaseReference reference, TextView value) {
        reference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override public void onDataChange(DataSnapshot snapshot) {
                value.setText(String.valueOf(snapshot.getChildrenCount()));
            }
            @Override public void onCancelled(DatabaseError error) {
                value.setText("—");
            }
        });
    }

    private String formatCounts(Map<String, Integer> counts, String emptyText) {
        if (counts.isEmpty()) return emptyText;
        StringBuilder text = new StringBuilder();
        for (Map.Entry<String, Integer> entry : counts.entrySet()) {
            if (text.length() > 0) text.append("   •   ");
            text.append(entry.getKey()).append(": ").append(entry.getValue());
        }
        return text.toString();
    }

    private void renderAnalyticsBars(LinearLayout container, Map<String, Integer> counts, int accent) {
        container.removeAllViews();
        int max = 0;
        for (Integer value : counts.values()) max = Math.max(max, value == null ? 0 : value);
        if (max == 0) {
            container.addView(pageText("No data to chart yet."));
            return;
        }
        for (Map.Entry<String, Integer> entry : counts.entrySet()) {
            LinearLayout row = new LinearLayout(this);
            row.setGravity(android.view.Gravity.CENTER_VERTICAL);
            TextView label = pageText(entry.getKey() + "  " + entry.getValue());
            label.setTextSize(11);
            label.setSingleLine(true);
            row.addView(label, new LinearLayout.LayoutParams(dp(124), dp(32)));
            View bar = new View(this);
            android.graphics.drawable.GradientDrawable background = new android.graphics.drawable.GradientDrawable();
            background.setColor(getColor(accent));
            background.setCornerRadius(dp(4));
            bar.setBackground(background);
            int width = Math.max(dp(12), dp(190) * entry.getValue() / max);
            row.addView(bar, new LinearLayout.LayoutParams(width, dp(10)));
            container.addView(row);
        }
    }

    private String formatAnnouncementTime(long millis) {
        return new SimpleDateFormat("dd MMM yyyy HH:mm", Locale.ENGLISH).format(new Date(millis));
    }

    private long parseAnnouncementTime(String value) {
        if (value == null || value.trim().isEmpty()) return 0L;
        try {
            Date parsed = new SimpleDateFormat("dd MMM yyyy HH:mm", Locale.ENGLISH).parse(value.trim());
            return parsed == null ? 0L : parsed.getTime();
        } catch (ParseException ignored) {
            return 0L;
        }
    }

    /** More > Banner Customer Support Link: every banner shown image-only, each with its own
     *  link box. The saved link is what the user app opens when that banner is tapped. */
    private void loadBannerLinksPage() {
        clearHeaderActions();
        LinearLayout holder = new LinearLayout(this);
        holder.setOrientation(LinearLayout.VERTICAL);
        workspaceContent.addView(holder, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        FirebaseRepository.banners().addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                if (isFinishing() || isDestroyed() || !holder.isAttachedToWindow()) return;
                List<Banner> all = new ArrayList<>();
                for (DataSnapshot child : snapshot.getChildren()) {
                    Object raw = child.getValue();
                    if (!(raw instanceof Map)) continue;
                    Banner banner = Banner.fromMap(child.getKey(), (Map<String, Object>) raw);
                    if (banner != null) all.add(banner);
                }
                java.util.Collections.sort(all, java.util.Comparator.comparingInt(Banner::getDisplayOrder));
                holder.removeAllViews();
                if (all.isEmpty()) {
                    holder.addView(pageText("No banners yet."));
                    return;
                }
                for (Banner banner : all) holder.addView(buildBannerLinkCard(banner));
            }

            @Override
            public void onCancelled(DatabaseError error) {
                FancyText.toast(AdminActivity.this, "Could not load banners: " + error.getMessage(), Toast.LENGTH_LONG).show();
            }
        });
    }

    private View buildBannerLinkCard(Banner banner) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setBackgroundResource(R.drawable.bg_admin_surface);
        card.setPadding(dp(10), dp(10), dp(10), dp(12));
        LinearLayout.LayoutParams cardParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        cardParams.topMargin = dp(10);
        card.setLayoutParams(cardParams);

        com.google.android.material.card.MaterialCardView frame = new com.google.android.material.card.MaterialCardView(this);
        frame.setRadius(dp(12));
        frame.setCardElevation(0);
        frame.setContentPadding(0, 0, 0, 0);
        ImageView image = new ImageView(this) {
            @Override protected void onMeasure(int widthSpec, int heightSpec) {
                super.onMeasure(widthSpec, heightSpec);
                int width = getMeasuredWidth();
                setMeasuredDimension(width, Math.round(width * 9f / 16f));
            }
        };
        image.setScaleType(ImageView.ScaleType.CENTER_CROP);
        image.setBackgroundResource(R.drawable.bg_banner);
        frame.addView(image, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        ImageLoader.load(image, banner.getImageUrl());
        card.addView(frame, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        EditText linkInput = field("Paste any link (https://t.me/..., wa.me/...)");
        linkInput.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        linkInput.setText(banner.getLinkUrl());
        ((LinearLayout.LayoutParams) linkInput.getLayoutParams()).topMargin = dp(10);
        card.addView(linkInput);

        MaterialButton save = new MaterialButton(this);
        save.setText("Save link");
        save.setTextColor(getColor(R.color.admin_blue));
        save.setTextSize(12);
        save.setTypeface(null, Typeface.BOLD);
        save.setAllCaps(false);
        save.setCornerRadius(dp(4));
        save.setBackgroundTintList(android.content.res.ColorStateList.valueOf(getColor(R.color.admin_blue_tint)));
        save.setStrokeColor(android.content.res.ColorStateList.valueOf(getColor(R.color.admin_blue)));
        save.setStrokeWidth(dp(1));
        save.setElevation(0f);
        save.setInsetTop(0);
        save.setInsetBottom(0);
        save.setOnClickListener(v -> {
            String raw = linkInput.getText().toString();
            String link = Banner.normalizeLink(raw);
            if (link == null) {
                linkInput.setError("Enter a valid link");
                return;
            }
            save.setEnabled(false);
            FirebaseRepository.saveBannerLink(banner.getId(), link)
                    .addOnSuccessListener(unused -> {
                        save.setEnabled(true);
                        linkInput.setText(link);
                        FancyText.toast(this, link.isEmpty() ? "Link removed" : "Link saved", Toast.LENGTH_SHORT).show();
                        FirebaseRepository.logActivity("BANNER_LINK_SAVED", banner.getId(), link);
                    })
                    .addOnFailureListener(e -> {
                        save.setEnabled(true);
                        FancyText.toast(this, "Could not save link: " + e.getMessage(), Toast.LENGTH_LONG).show();
                    });
        });
        LinearLayout.LayoutParams saveParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(44));
        saveParams.topMargin = dp(4);
        card.addView(save, saveParams);
        return card;
    }

    private void loadSettingsPage() {
        clearHeaderActions();
        addHeaderMenu(new String[]{"Match showing time", "Change app logo", "Support tickets", "Open dashboard settings", "Seed demo data",
                        "Revenue dashboard"},
                new Runnable[]{
                        this::showMatchShowTimeDialog,
                        this::showAppLogoDialog,
                        () -> {
                            Intent page = new Intent(this, SupportActivity.class);
                            page.putExtra("adminMode", true);
                            startActivity(page);
                        },
                        () -> showWorkspacePage("dashboard"),
                        this::confirmSeedDemoData,
                        () -> showWorkspacePage("revenue")});
        workspaceContent.addView(pageText("Tap ⋮ (top right) for match showing time, app logo, support tickets, dashboard settings and demo data."));
    }

    /** Admin setting: how many hours a FINISHED match stays visible to players (appConfig/matchShowHours). 0 = never hide. */
    private void showMatchShowTimeDialog() {
        LinearLayout form = new LinearLayout(this);
        form.setOrientation(LinearLayout.VERTICAL);
        form.setPadding(dp(24), dp(8), dp(24), dp(8));
        final EditText hoursInput = field("Hours (0 = hamesha dikhao)");
        hoursInput.setInputType(InputType.TYPE_CLASS_NUMBER);
        hoursInput.setText(String.valueOf(com.arenax.tournament.util.MatchShowTime.hours()));
        form.addView(hoursInput);
        FirebaseRepository.appConfig().child("matchShowHours").get().addOnSuccessListener(snap -> {
            Object raw = snap.getValue();
            if (raw instanceof Number) hoursInput.setText(String.valueOf(((Number) raw).intValue()));
        });
        final FullScreenDialog dialog = new FullScreenDialog.Builder(this)
                .setTitle("Match showing time")
                .setMessage("Match khatam (result publish / cancel) hone ke itne ghante baad wo match user app me dikhna band ho jayega. Default 2.")
                .setView(form)
                .setNegativeButton("CANCEL", null)
                .setPositiveButton("SAVE", null)
                .create();
        dialog.setOnShowListener(ignored -> dialog.getButton(Dialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            String raw = hoursInput.getText().toString().trim();
            int hours;
            try { hours = Integer.parseInt(raw); } catch (NumberFormatException e) { hours = -1; }
            if (hours < 0 || hours > com.arenax.tournament.util.MatchShowTime.MAX_HOURS) {
                FancyText.toast(this, "0 se " + com.arenax.tournament.util.MatchShowTime.MAX_HOURS + " ke beech number daalo.", Toast.LENGTH_LONG).show();
                return;
            }
            final int saved = hours;
            FirebaseRepository.appConfig().child("matchShowHours").setValue(saved)
                    .addOnSuccessListener(done -> {
                        FancyText.toast(this, "Match showing time: " + com.arenax.tournament.util.MatchShowTime.label(saved), Toast.LENGTH_SHORT).show();
                        FirebaseRepository.logActivity("Match showing time changed", "platform", com.arenax.tournament.util.MatchShowTime.label(saved));
                        dialog.dismiss();
                    })
                    .addOnFailureListener(error -> toast("Save failed: " + error.getMessage()));
        }));
        dialog.show();
    }

    /** Demo Data Requirement (master prompt): one confirm dialog, then a realistic non-financial
     *  seed — categories, 8 tournaments across Upcoming/Ongoing/Completed, 6 teams, matches in
     *  Live/Waiting/Room-Released states, a 20-row leaderboard, FAQ, an announcement and two
     *  support tickets — useful for demos and for exercising every screen with real-looking data. */
    private void confirmSeedDemoData() {
        new FullScreenDialog.Builder(this)
                .setTitle("Seed demo data?")
                .setMessage("This adds realistic sample tournaments, teams, matches, leaderboard rows, FAQ, an announcement and support tickets to this Firebase project. It will not remove any existing data, and adds nothing payment or wallet related.")
                .setNegativeButton("CANCEL", null)
                .setPositiveButton("SEED NOW", (dialog, which) ->
                        FirebaseRepository.seedDemoData()
                                .addOnSuccessListener(unused -> {
                                    FancyText.toast(this, "Demo data seeded — check Tournaments, Teams and Leaderboard.", Toast.LENGTH_LONG).show();
                                    FirebaseRepository.logActivity("Seeded demo data", "platform", "Categories, tournaments, teams, matches, leaderboard, FAQ, announcement, tickets");
                                })
                                .addOnFailureListener(error -> toast("Seeding failed: " + error.getMessage())))
                .show();
    }

    private void showAppLogoDialog() {
        selectedLogoImage = null;
        LinearLayout form = new LinearLayout(this);
        form.setOrientation(LinearLayout.VERTICAL);
        form.setPadding(dp(24), dp(8), dp(24), dp(8));

        EditText logoUrl = field("PNG/JPG logo URL (optional)");
        form.addView(logoUrl);

        MaterialButton chooseImage = new MaterialButton(this);
        chooseImage.setText("SELECT LOGO FROM DEVICE");
        chooseImage.setTextColor(getColor(R.color.text_primary));
        chooseImage.setMaxLines(1);
        LinearLayout.LayoutParams chooseParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        chooseParams.topMargin = dp(6);
        chooseParams.bottomMargin = dp(10);
        chooseImage.setLayoutParams(chooseParams);
        chooseImage.setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            intent.setType("image/*");
            startActivityForResult(intent, 7002);
        });
        form.addView(chooseImage);

        logoPreview = new ImageView(this);
        logoPreview.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(140)));
        logoPreview.setScaleType(ImageView.ScaleType.CENTER_CROP);
        logoPreview.setBackgroundResource(R.drawable.bg_game_card_blue);
        form.addView(logoPreview);

        logoDialog = new FullScreenDialog.Builder(this)
                .setTitle("Change app logo")
                .setMessage("This replaces the STARX24 logo shown on every user's home screen, live from Firebase.")
                .setView(form)
                .setNegativeButton("CANCEL", null)
                .setPositiveButton("SAVE LOGO", null)
                .create();
        logoDialog.setOnShowListener(ignored -> logoDialog.getButton(Dialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            String url = logoUrl.getText().toString().trim();
            if (selectedLogoImage == null && url.isEmpty()) {
                FancyText.toast(this, "Add a logo URL or select an image.", Toast.LENGTH_LONG).show();
                return;
            }
            if (selectedLogoImage == null) {
                saveAppLogo(url);
                return;
            }
            FancyText.toast(this, "Uploading logo securely…", Toast.LENGTH_SHORT).show();
            com.arenax.tournament.data.ImgBbUploader.uploadImage(this, selectedLogoImage,
                    new com.arenax.tournament.data.StorageUploader.Callback() {
                        @Override public void onSuccess(String fileUrl) { saveAppLogo(fileUrl); }
                        @Override public void onFailure(String message) {
                            showUploadErrorDialog("Logo upload failed", message);
                        }
                    });
        }));
        logoDialog.show();
    }

    private void saveAppLogo(String logoUrl) {
        FirebaseRepository.appConfig().child("branding").child("logoUrl").setValue(logoUrl)
                .addOnSuccessListener(unused -> {
                    FancyText.toast(this, "App logo updated live for all users.", Toast.LENGTH_SHORT).show();
                    if (logoDialog != null) logoDialog.dismiss();
                })
                .addOnFailureListener(error -> FancyText.toast(this, "Logo update failed: " + error.getMessage(), Toast.LENGTH_LONG).show());
    }

    private void toast(String message) {
        FancyText.toast(this, message == null ? "Action failed" : message, Toast.LENGTH_LONG).show();
    }

    /** A small persistent caption placed above a field. Hints alone aren't enough for edit
     *  forms: once an EditText is pre-filled with an existing value, its hint is hidden, so a
     *  field like "position" pre-filled with "1" would otherwise show as an unlabeled box. */
    /**
     * Builds a dialog with a fixed header, a height-capped scrollable form, and a footer
     * with CANCEL / positive buttons that are ALWAYS visible — regardless of how tall the
     * form content is. This replaces MaterialAlertDialogBuilder's default button bar, which
     * gets pushed off-screen (and disappears) when the form is longer than the screen.
     */
    private Dialog buildStickyFormDialog(String title, String subtitle, View scrollableForm,
                                          String positiveLabel, Runnable onPositive) {
        // Full-screen page (back arrow + title on top, big Cancel / action buttons pinned at the
        // bottom) instead of a small floating card. The action button does not auto-close;
        // callers dismiss the dialog themselves once saving succeeds.
        return FullScreenDialog.form(this, title, subtitle, scrollableForm, positiveLabel, onPositive);
    }

    private View dialogDivider() {
        View divider = new View(this);
        divider.setBackgroundColor(getColor(R.color.stroke));
        divider.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(1)));
        return divider;
    }

    private TextView fieldLabel(String text) {
        TextView label = new TextView(this);
        label.setText(text);
        label.setTextColor(getColor(R.color.text_secondary));
        label.setTextSize(11f);
        label.setTypeface(null, android.graphics.Typeface.BOLD);
        label.setLetterSpacing(0.02f);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        params.topMargin = dp(12);
        params.bottomMargin = dp(4);
        label.setLayoutParams(params);
        return label;
    }

    /** Coin-amount dropdown for entry fee / per-kill reward fields — replaces free-text
     *  number entry so the admin picks a value from a fixed, mistake-proof list instead of typing
     *  a raw number. Offers common denominations from 0 up to 10,000 instead of every single
     *  integer (which would make the list unusably long). If an existing match's value isn't one
     *  of the presets (e.g. it was set before this list existed), it's inserted into the list in
     *  sorted position so editing that match doesn't silently change its value.
     *  Whatever is selected here is written to entryFeeCoins / perKillCoins exactly, and that's
     *  the exact value the backend deducts from a player's wallet on /joinMatch. */
    private static final int[] COIN_AMOUNT_PRESETS = {
            0, 1, 2, 5, 10, 20, 25, 50, 75, 100, 150, 200, 250, 300, 400, 500,
            750, 1000, 1500, 2000, 2500, 3000, 4000, 5000, 7500, 10000
    };

    private Spinner coinAmountSpinner(int defaultValue) {
        java.util.List<Integer> values = new java.util.ArrayList<>();
        for (int preset : COIN_AMOUNT_PRESETS) values.add(preset);
        if (!values.contains(defaultValue)) {
            int insertAt = 0;
            while (insertAt < values.size() && values.get(insertAt) < defaultValue) insertAt++;
            values.add(insertAt, defaultValue);
        }
        String[] amounts = new String[values.size()];
        for (int i = 0; i < values.size(); i++) amounts[i] = String.valueOf(values.get(i));
        Spinner spinner = new Spinner(this);
        spinner.setAdapter(new android.widget.ArrayAdapter<>(this,
                android.R.layout.simple_spinner_dropdown_item, amounts));
        spinner.setSelection(values.indexOf(defaultValue));
        return spinner;
    }

    /** Populates the start-time dropdown for a chosen date. For today, only times from right
     *  now onward are offered, rounded up to the next 30-minute mark — e.g. at 9:42 the first
     *  option is 10:00, then 10:30 — so a match can never accidentally get scheduled in the
     *  past. For any future date, the whole day (12:00 AM through 11:30 PM) is offered. If the
     *  real clock has already passed the last slot of today (from 11:30 PM onward), the date
     *  itself rolls forward to tomorrow and its full-day slots are shown instead. */
    private void refreshMatchTimeSlots(Spinner timeSpinner, Calendar selectedDay, EditText dateField) {
        Calendar now = Calendar.getInstance();
        boolean isToday = now.get(Calendar.YEAR) == selectedDay.get(Calendar.YEAR)
                && now.get(Calendar.DAY_OF_YEAR) == selectedDay.get(Calendar.DAY_OF_YEAR);

        Calendar cursor = (Calendar) selectedDay.clone();
        if (isToday) {
            cursor.setTime(now.getTime());
            int minute = cursor.get(Calendar.MINUTE);
            cursor.set(Calendar.SECOND, 0);
            cursor.set(Calendar.MILLISECOND, 0);
            if (minute < 30) {
                cursor.set(Calendar.MINUTE, 30);
            } else {
                cursor.set(Calendar.MINUTE, 0);
                cursor.add(Calendar.HOUR_OF_DAY, 1);
            }
        } else {
            cursor.set(Calendar.HOUR_OF_DAY, 0);
            cursor.set(Calendar.MINUTE, 0);
            cursor.set(Calendar.SECOND, 0);
            cursor.set(Calendar.MILLISECOND, 0);
        }

        List<String> slots = new ArrayList<>();
        SimpleDateFormat formatter = new SimpleDateFormat("hh:mm a", Locale.ENGLISH);
        while (cursor.get(Calendar.DAY_OF_YEAR) == selectedDay.get(Calendar.DAY_OF_YEAR)
                && cursor.get(Calendar.YEAR) == selectedDay.get(Calendar.YEAR)) {
            slots.add(formatter.format(cursor.getTime()).toUpperCase(Locale.ENGLISH));
            cursor.add(Calendar.MINUTE, 30);
        }

        if (slots.isEmpty()) {
            // Past the last slot of today (11:30 PM onward) — roll the date to tomorrow.
            selectedDay.add(Calendar.DAY_OF_YEAR, 1);
            dateField.setText(new SimpleDateFormat("dd MMM yyyy", Locale.ENGLISH)
                    .format(selectedDay.getTime()).toUpperCase(Locale.ENGLISH));
            refreshMatchTimeSlots(timeSpinner, selectedDay, dateField);
            return;
        }

        timeSpinner.setAdapter(new android.widget.ArrayAdapter<>(this,
                android.R.layout.simple_spinner_dropdown_item, slots));
    }

    /** Team size -> index in the SOLO / DUO / SQUAD spinner (1, 2, 4); -1 = not allowed. */
    private static int matchTypeIndexForTeamSize(int size) {
        return size == 1 ? 0 : size == 2 ? 1 : size == 4 ? 2 : -1;
    }

    private EditText field(String hint) {
        EditText input = new EditText(this);
        input.setHint(hint);
        input.setTextColor(getColor(R.color.text_primary));
        input.setHintTextColor(getColor(R.color.text_secondary));
        input.setSingleLine(true);
        input.setBackgroundResource(R.drawable.bg_input);
        int hPad = dp(16);
        int vPad = dp(14);
        input.setPadding(hPad, vPad, hPad, vPad);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        params.topMargin = dp(6);
        params.bottomMargin = dp(6);
        input.setLayoutParams(params);
        return input;
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private int numberOrDefault(String value, int fallback) {
        try { return Integer.parseInt(value); } catch (NumberFormatException ignored) { return fallback; }
    }

    private long parseDateTime(String date, String time) {
        if (date == null || time == null || date.trim().isEmpty() || time.trim().isEmpty()
                || "TBA".equalsIgnoreCase(date) || "TBA".equalsIgnoreCase(time)) return 0L;
        String combined = date.trim() + " " + time.trim();
        String[] formats = {"dd MMM yyyy hh:mm a", "dd MMM yyyy HH:mm"};
        for (String format : formats) {
            try {
                Date parsed = new SimpleDateFormat(format, Locale.ENGLISH).parse(combined);
                if (parsed != null) return parsed.getTime();
            } catch (ParseException ignored) {
                // Keep the record publishable when an optional date is not parseable.
            }
        }
        return 0L;
    }

    private void publishNotice() {
        LinearLayout form = new LinearLayout(this);
        form.setOrientation(LinearLayout.VERTICAL);
        form.setPadding(dp(20), dp(4), dp(20), dp(4));
        EditText title = field("Notification title");
        EditText message = field("Message for all user devices");
        message.setMinLines(3);
        message.setGravity(Gravity.TOP);
        form.addView(title);
        form.addView(message);
        // Admin picks which user-panel content opens when the player taps this notification.
        final com.arenax.tournament.util.RedirectPickerDialog.Field redirectField =
                com.arenax.tournament.util.RedirectPickerDialog.addField(this, form);
        new FullScreenDialog.Builder(this)
                .setTitle("Send Device Notification")
                .setMessage("This will create a broadcast for the user devices.")
                .setView(form)
                .setNegativeButton("CANCEL", null)
                .setPositiveButton("SEND", (dialog, which) -> {
                    String heading = title.getText().toString().trim();
                    String body = message.getText().toString().trim();
                    if (heading.isEmpty() || body.isEmpty()) {
                        FancyText.toast(this, "Enter both title and message.", Toast.LENGTH_LONG).show();
                        return;
                    }
                    FirebaseRepository.publishNotification(heading, body, redirectField.get())
                            .addOnSuccessListener(unused -> FancyText.toast(this, "Notification queued for devices.", Toast.LENGTH_SHORT).show())
                            .addOnFailureListener(error -> FancyText.toast(this, error.getMessage(), Toast.LENGTH_LONG).show());
                }).show();
    }

    /** Publishes the sticky red notice strip shown above the home banner in the User app
     *  (appConfig/homeNotice) — separate from the one-off push notice above. */
    private void publishHomeNotice() {
        EditText noticeTitleInput = findViewById(R.id.admin_home_notice_title_input);
        EditText noticeInput = findViewById(R.id.admin_home_notice_input);
        SwitchMaterial noticeSwitch = findViewById(R.id.admin_home_notice_switch);
        if (noticeInput == null || noticeSwitch == null) return;
        String title = noticeTitleInput == null ? "" : noticeTitleInput.getText().toString().trim();
        String text = noticeInput.getText().toString().trim();
        boolean enabled = noticeSwitch.isChecked();
        if (enabled && text.isEmpty()) {
            FancyText.toast(this, "Enter the notice text before enabling it.", Toast.LENGTH_LONG).show();
            return;
        }
        Map<String, Object> notice = new HashMap<>();
        notice.put("title", title);
        notice.put("text", text);
        notice.put("enabled", enabled);
        FirebaseRepository.appConfig().child("homeNotice").setValue(notice)
                .addOnSuccessListener(unused -> FancyText.toast(this, "Home notice updated.", Toast.LENGTH_SHORT).show())
                .addOnFailureListener(error -> FancyText.toast(this, error.getMessage(), Toast.LENGTH_LONG).show());
    }

    private void saveProfileControls() {
        EditText name = findViewById(R.id.admin_profile_name_input);
        EditText terms = findViewById(R.id.admin_profile_terms_input);
        EditText privacy = findViewById(R.id.admin_profile_privacy_input);
        EditText support = findViewById(R.id.admin_profile_support_input);
        EditText telegram = findViewById(R.id.admin_profile_telegram_input);
        EditText youtube = findViewById(R.id.admin_profile_youtube_input);
        EditText instagram = findViewById(R.id.admin_profile_instagram_input);
        EditText download = findViewById(R.id.admin_profile_download_input);
        Map<String, Object> profile = new HashMap<>();
        profile.put("adminName", name == null ? "STARX24 admin" : name.getText().toString().trim());
        profile.put("termsUrl", terms == null ? "" : terms.getText().toString().trim());
        profile.put("privacyUrl", privacy == null ? "" : privacy.getText().toString().trim());
        profile.put("supportUrl", support == null ? "" : support.getText().toString().trim());
        profile.put("telegramUrl", telegram == null ? "" : telegram.getText().toString().trim());
        profile.put("youtubeUrl", youtube == null ? "" : youtube.getText().toString().trim());
        profile.put("instagramUrl", instagram == null ? "" : instagram.getText().toString().trim());
        profile.put("downloadUrl", download == null ? "" : download.getText().toString().trim());
        FirebaseRepository.appConfig().child("profile").updateChildren(profile)
                .addOnSuccessListener(unused -> FancyText.toast(this, "Profile controls saved.", Toast.LENGTH_SHORT).show())
                .addOnFailureListener(error -> FancyText.toast(this, error.getMessage(), Toast.LENGTH_LONG).show());
    }
}
