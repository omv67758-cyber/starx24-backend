package com.arenax.tournament.adapter;

import com.arenax.tournament.util.ImageLoader;
import android.graphics.drawable.GradientDrawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.arenax.tournament.R;
import com.arenax.tournament.model.Tournament;
import com.bumptech.glide.Glide;
import java.util.List;

/** Dense reference-style cards used only by the admin category match-management page. */
public final class AdminCategoryMatchAdapter extends RecyclerView.Adapter<AdminCategoryMatchAdapter.Holder> {
    public interface Action { void run(Tournament item); }
    private final List<Tournament> items;
    private final Action edit, delete, view;
    public AdminCategoryMatchAdapter(List<Tournament> items, Action edit, Action delete, Action view) {
        this.items = items; this.edit = edit; this.delete = delete; this.view = view;
    }
    @NonNull @Override public Holder onCreateViewHolder(@NonNull ViewGroup parent, int type) {
        return new Holder(LayoutInflater.from(parent.getContext()).inflate(R.layout.item_admin_category_match, parent, false));
    }
    @Override public void onBindViewHolder(@NonNull Holder h, int position) {
        Tournament t = items.get(position);
        h.title.setText(t.getTitle());
        h.subtitle.setText((t.getGameType() == null ? "BR" : t.getGameType()) + " • " + (t.getMatchType() == null ? "Solo" : t.getMatchType())
                + (t.isDailyMode() ? "  •  \uD83D\uDD01 DAILY" : "")
                + (!t.isVisibleBySchedule() ? "  •  \uD83D\uDE48 HIDDEN till " + new java.text.SimpleDateFormat("dd MMM, hh:mm a", java.util.Locale.ENGLISH).format(new java.util.Date(t.getShowAt())) : ""));
        h.date.setText("▣  " + safe(t.getDate()));
        h.time.setText("◷  " + safe(t.getTime()));
        h.entry.setText("₹" + t.getEntryFeeCoins());
        h.prize.setText("₹" + t.getPrizePoolCoins());
        h.players.setText("♟  " + t.getJoinedSlots() + "/" + t.getTotalSlots());
        String status = t.getEffectiveStatus();
        boolean live = Tournament.ONGOING.equals(status), complete = Tournament.COMPLETED.equals(status);
        h.status.setText(live ? "● Live" : complete ? "◷ Completed" : "◷ Upcoming");
        int fg = live ? R.color.admin_green : complete ? R.color.text_secondary : R.color.admin_blue;
        int bg = live ? R.color.admin_green_tint : complete ? R.color.surface_2 : R.color.admin_blue_tint;
        h.status.setTextColor(h.status.getContext().getColor(fg));
        GradientDrawable pill = new GradientDrawable(); pill.setColor(h.status.getContext().getColor(bg)); pill.setCornerRadius(40); h.status.setBackground(pill);
        ImageLoader.load(h.image, t.getBannerUrl());
        h.edit.setOnClickListener(v -> edit.run(t)); h.delete.setOnClickListener(v -> delete.run(t)); h.view.setOnClickListener(v -> view.run(t));
    }
    private static String safe(String v) { return v == null || v.trim().isEmpty() ? "TBA" : v; }
    @Override public int getItemCount() { return items.size(); }
    static final class Holder extends RecyclerView.ViewHolder {
        ImageView image; TextView title, subtitle, date, time, entry, prize, players, status; View edit, delete, view;
        Holder(View v) { super(v); image=v.findViewById(R.id.admin_category_match_image); title=v.findViewById(R.id.admin_category_match_title); subtitle=v.findViewById(R.id.admin_category_match_subtitle); date=v.findViewById(R.id.admin_category_match_date); time=v.findViewById(R.id.admin_category_match_time); entry=v.findViewById(R.id.admin_category_match_entry); prize=v.findViewById(R.id.admin_category_match_prize); players=v.findViewById(R.id.admin_category_match_players); status=v.findViewById(R.id.admin_category_match_status); edit=v.findViewById(R.id.admin_category_match_edit); delete=v.findViewById(R.id.admin_category_match_delete); view=v.findViewById(R.id.admin_category_match_view); }
    }
}
