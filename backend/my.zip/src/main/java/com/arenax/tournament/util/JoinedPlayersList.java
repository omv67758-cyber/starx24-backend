package com.arenax.tournament.util;

import android.content.Context;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.arenax.tournament.data.FirebaseRepository;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Live "Joined Players" list (slot no. and in-game name only; UID is never shown to players) read from
 * tournaments/{id}/participants. Used on both the match detail page (before joining)
 * and the match joined page (after joining). Call attach() in onCreate and detach() in onDestroy.
 */
public final class JoinedPlayersList {

    private final LinearLayout list;
    private final TextView countView;
    private final String tournamentId;
    private ValueEventListener listener;

    private static final class Row {
        int slot; String name; String gameUid;
    }

    public JoinedPlayersList(LinearLayout list, TextView countView, String tournamentId) {
        this.list = list;
        this.countView = countView;
        this.tournamentId = tournamentId;
    }

    public void attach() {
        if (tournamentId == null || tournamentId.isEmpty() || listener != null) return;
        listener = new ValueEventListener() {
            @Override public void onDataChange(@NonNull DataSnapshot snapshot) { render(snapshot); }
            @Override public void onCancelled(@NonNull DatabaseError error) { }
        };
        FirebaseRepository.tournamentParticipants(tournamentId).addValueEventListener(listener);
    }

    public void detach() {
        if (listener != null && tournamentId != null) {
            FirebaseRepository.tournamentParticipants(tournamentId).removeEventListener(listener);
        }
        listener = null;
    }

    private void render(DataSnapshot snapshot) {
        List<Row> rows = new ArrayList<>();
        for (DataSnapshot child : snapshot.getChildren()) {
            if ("RESERVING".equals(str(child.child("status").getValue()))) continue;
            boolean added = false;
            for (DataSnapshot p : child.child("players").getChildren()) {
                Row r = new Row();
                r.slot = toInt(p.child("slotNumber").getValue(), toInt(p.getKey(), 0));
                r.name = str(p.child("gameName").getValue());
                r.gameUid = str(p.child("gameUid").getValue());
                if (r.name.isEmpty()) r.name = str(child.child("gameName").getValue());
                rows.add(r);
                added = true;
            }
            if (!added) {
                Row r = new Row();
                r.slot = toInt(child.child("slotNumber").getValue(), 0);
                r.name = str(child.child("gameName").getValue());
                r.gameUid = str(child.child("gameUid").getValue());
                rows.add(r);
            }
        }
        Collections.sort(rows, (a, b) -> Integer.compare(a.slot, b.slot));

        Context c = list.getContext();
        list.removeAllViews();
        if (countView != null) countView.setText(String.valueOf(rows.size()));
        if (rows.isEmpty()) {
            TextView empty = text(c, "No players have joined yet", 12, "#68686D", false);
            empty.setPadding(0, dp(c, 8), 0, dp(c, 4));
            list.addView(empty);
            return;
        }
        for (int i = 0; i < rows.size(); i++) {
            Row r = rows.get(i);
            LinearLayout row = new LinearLayout(c);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(dp(c, 4), dp(c, 12), 0, dp(c, 12));

            // "1.  PlayerName" - sequential number + in-game name only (never the UID).
            TextView num = text(c, (i + 1) + ".", 15, "#1C1C1E", false);
            num.setGravity(Gravity.CENTER_VERTICAL | Gravity.START);
            row.addView(num, new LinearLayout.LayoutParams(dp(c, 34), ViewGroup.LayoutParams.WRAP_CONTENT));

            LinearLayout col = new LinearLayout(c);
            col.setOrientation(LinearLayout.VERTICAL);
            LinearLayout.LayoutParams colLp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
            colLp.setMarginStart(dp(c, 6));
            col.addView(text(c, r.name.isEmpty() ? "Player" : r.name, 15, "#1C1C1E", false));
            row.addView(col, colLp);
            list.addView(row);

            if (i < rows.size() - 1) {
                View div = new View(c);
                div.setBackgroundColor(0x1F000000);
                list.addView(div, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 1));
            }
        }
    }

    private static TextView text(Context c, String s, int sp, String color, boolean bold) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(android.graphics.Color.parseColor(color));
        t.setSingleLine(true);
        t.setEllipsize(android.text.TextUtils.TruncateAt.END);
        if (bold) t.setTypeface(t.getTypeface(), Typeface.BOLD);
        return t;
    }
    private static TextView text(Context c, String s, int sp, String color) { return text(c, s, sp, color, false); }

    private static int dp(Context c, int v) {
        return Math.round(v * c.getResources().getDisplayMetrics().density);
    }
    private static String str(Object o) { return o == null ? "" : String.valueOf(o).trim(); }
    private static int toInt(Object o, int def) {
        if (o == null) return def;
        if (o instanceof Number) return ((Number) o).intValue();
        try { return Integer.parseInt(String.valueOf(o).trim()); } catch (Exception e) { return def; }
    }
}
