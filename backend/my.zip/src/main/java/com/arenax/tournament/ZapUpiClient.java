package com.arenax.tournament;

import android.os.Handler;
import android.os.Looper;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import okhttp3.Call;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

/**
 * Creates a wallet payment through the private Render backend.
 *
 * The ZapUPI key is intentionally not present in this Android project. The
 * backend verifies the Firebase ID token before it creates an order.
 */
public final class ZapUpiClient {
    public interface Callback {
        void onSuccess(String paymentUrl, String orderId);
        void onError(String message);
    }

    public interface VerifyCallback {
        /** status is "credited", "pending" or "failed". */
        void onResult(String status);
        void onError(String message);
    }

    public interface JoinCallback {
        /** slotNumbers holds every slot the join claimed (length 1 for a normal
         *  single-slot join, 2+ for a multi-slot join); slotNumber is kept as the
         *  first entry so existing single-slot callers don't need to change. */
        void onSuccess(String status, int entryFeeCoins, int slotNumber, int[] slotNumbers);
        void onError(String message);
    }

    private static final MediaType JSON = MediaType.get("application/json; charset=utf-8");
    /*
     * Render services can sleep between requests. The default OkHttp timeout is
     * only 10 seconds, which makes a normal cold start look like a network
     * outage in the app. Order creation also waits for Firebase verification
     * and the ZapUPI response, so allow the complete operation enough time.
     */
    private static final OkHttpClient HTTP = new OkHttpClient.Builder()
            .connectTimeout(30, TimeUnit.SECONDS)
            .readTimeout(90, TimeUnit.SECONDS)
            .writeTimeout(30, TimeUnit.SECONDS)
            .callTimeout(120, TimeUnit.SECONDS)
            .retryOnConnectionFailure(true)
            .build();
    private static final Handler MAIN = new Handler(Looper.getMainLooper());

    /**
     * Fire-and-forget warm-up: call this as soon as the wallet screen opens (well before
     * the user taps "Add Money"). It wakes the Render backend, which can otherwise take many
     * seconds to cold-start on its first request, and primes Firebase's cached ID token so
     * createOrder() doesn't have to wait on either of those the moment the user pays.
     */
    public static void warmUp() {
        String baseUrl = BuildConfig.STARX_API_BASE_URL == null
                ? "" : BuildConfig.STARX_API_BASE_URL.trim();
        if (!baseUrl.isEmpty() && !baseUrl.contains("YOUR-SERVICE")) {
            String normalizedBaseUrl = baseUrl.endsWith("/")
                    ? baseUrl.substring(0, baseUrl.length() - 1) : baseUrl;
            Request warmupRequest = new Request.Builder()
                    .url(normalizedBaseUrl + "/health")
                    .get()
                    .build();
            HTTP.newCall(warmupRequest).enqueue(new okhttp3.Callback() {
                @Override public void onFailure(Call call, IOException error) {
                    // Best-effort only — createOrder() will still retry the real request.
                }
                @Override public void onResponse(Call call, Response response) {
                    response.close();
                }
            });
        }

        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        if (user != null) {
            user.getIdToken(false); // Primes the SDK's cached token; result not needed here.
        }
    }

    private ZapUpiClient() { }

    public static void createOrder(int amountInr, String customerMobile, Callback callback) {
        if (amountInr < 10 || amountInr > 10000) {
            callback.onError("Enter an amount between ₹10 and ₹10000");
            return;
        }

        String baseUrl = BuildConfig.STARX_API_BASE_URL == null
                ? "" : BuildConfig.STARX_API_BASE_URL.trim();
        if (baseUrl.isEmpty() || baseUrl.contains("YOUR-SERVICE")) {
            callback.onError("Payment backend is not configured. Add backend.base.url before building.");
            return;
        }

        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        if (user == null) {
            callback.onError("Please sign in before adding money.");
            return;
        }

        user.getIdToken(false)
                .addOnSuccessListener(result -> {
                    String idToken = result == null ? null : result.getToken();
                    if (idToken == null || idToken.trim().isEmpty()) {
                        MAIN.post(() -> callback.onError("Could not verify your Firebase session."));
                        return;
                    }
                    // One silent retry: a single transient blip (Render cold start, a dropped
                    // packet, a brief backend hiccup) self-heals here instead of ever reaching
                    // the user as an error dialog. Only the SECOND failure is shown.
                    sendCreateOrder(baseUrl, idToken, amountInr, customerMobile, 1, callback);
                })
                .addOnFailureListener(error ->
                        MAIN.post(() -> callback.onError("Could not verify your Firebase session.")));
    }

    private static void sendCreateOrder(
            String baseUrl,
            String idToken,
            int amountInr,
            String customerMobile,
            int retriesLeft,
            Callback callback
    ) {
        try {
            JSONObject payload = new JSONObject();
            payload.put("amount", String.valueOf(amountInr));
            if (customerMobile != null && !customerMobile.trim().isEmpty()) {
                payload.put("mobile", customerMobile.trim());
            }

            String normalizedBaseUrl = baseUrl.endsWith("/")
                    ? baseUrl.substring(0, baseUrl.length() - 1) : baseUrl;
            Request request = new Request.Builder()
                    .url(normalizedBaseUrl + "/createOrder")
                    .post(RequestBody.create(payload.toString(), JSON))
                    .addHeader("Authorization", "Bearer " + idToken)
                    .build();

            HTTP.newCall(request).enqueue(new okhttp3.Callback() {
                @Override public void onFailure(Call call, IOException error) {
                    if (retriesLeft > 0) {
                        retryAfterDelay(baseUrl, idToken, amountInr, customerMobile, retriesLeft, callback);
                        return;
                    }
                    String message = isTimeout(error)
                            ? "Payment server is waking up. Please try again in a few seconds."
                            : "Could not connect to the payment server. Please check your internet and try again.";
                    MAIN.post(() -> callback.onError(message));
                }

                @Override public void onResponse(Call call, Response response) {
                    try (Response bodyResponse = response) {
                        String body = bodyResponse.body() == null ? "" : bodyResponse.body().string();
                        if (!response.isSuccessful()) {
                            // 5xx is the backend/provider having a bad moment, not a real
                            // rejection (that's a 4xx) — worth one silent retry too.
                            if (response.code() >= 500 && retriesLeft > 0) {
                                retryAfterDelay(baseUrl, idToken, amountInr, customerMobile, retriesLeft, callback);
                                return;
                            }
                            MAIN.post(() -> callback.onError(readServerError(body, response.code())));
                            return;
                        }

                        JSONObject result = new JSONObject(body);
                        String paymentUrl = findPaymentUrl(result);
                        String orderId = result.optString("order_id", "").trim();
                        if (paymentUrl.isEmpty() || orderId.isEmpty()) {
                            MAIN.post(() -> callback.onError("Payment provider returned an incomplete order."));
                            return;
                        }
                        MAIN.post(() -> callback.onSuccess(paymentUrl, orderId));
                    } catch (Exception error) {
                        MAIN.post(() -> callback.onError("Invalid payment response from backend."));
                    }
                }
            });
        } catch (Exception error) {
            MAIN.post(() -> callback.onError("Could not create payment order."));
        }
    }

    private static void retryAfterDelay(
            String baseUrl,
            String idToken,
            int amountInr,
            String customerMobile,
            int retriesLeft,
            Callback callback
    ) {
        MAIN.postDelayed(() ->
                sendCreateOrder(baseUrl, idToken, amountInr, customerMobile, retriesLeft - 1, callback),
                800);
    }

    /**
     * Asks the backend to re-check this order with ZapUPI right now and credit the wallet
     * immediately if it succeeded, instead of waiting for ZapUPI's webhook to arrive. Call this
     * from onResume() as soon as the user comes back from the payment page, so coins land the
     * moment they return to the app rather than only whenever the webhook happens to fire.
     */
    public static void verifyOrder(String orderId, VerifyCallback callback) {
        String baseUrl = BuildConfig.STARX_API_BASE_URL == null
                ? "" : BuildConfig.STARX_API_BASE_URL.trim();
        if (baseUrl.isEmpty() || baseUrl.contains("YOUR-SERVICE")) {
            callback.onError("Payment backend is not configured.");
            return;
        }

        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        if (user == null) {
            callback.onError("Not signed in.");
            return;
        }

        user.getIdToken(false)
                .addOnSuccessListener(result -> {
                    String idToken = result == null ? null : result.getToken();
                    if (idToken == null || idToken.trim().isEmpty()) {
                        MAIN.post(() -> callback.onError("Could not verify your Firebase session."));
                        return;
                    }
                    sendVerifyOrder(baseUrl, idToken, orderId, callback);
                })
                .addOnFailureListener(error ->
                        MAIN.post(() -> callback.onError("Could not verify your Firebase session.")));
    }

    private static void sendVerifyOrder(String baseUrl, String idToken, String orderId, VerifyCallback callback) {
        try {
            JSONObject payload = new JSONObject();
            payload.put("order_id", orderId);

            String normalizedBaseUrl = baseUrl.endsWith("/")
                    ? baseUrl.substring(0, baseUrl.length() - 1) : baseUrl;
            Request request = new Request.Builder()
                    .url(normalizedBaseUrl + "/verifyOrder")
                    .post(RequestBody.create(payload.toString(), JSON))
                    .addHeader("Authorization", "Bearer " + idToken)
                    .build();

            HTTP.newCall(request).enqueue(new okhttp3.Callback() {
                @Override public void onFailure(Call call, IOException error) {
                    MAIN.post(() -> callback.onError("Could not reach payment server."));
                }

                @Override public void onResponse(Call call, Response response) {
                    try (Response bodyResponse = response) {
                        String body = bodyResponse.body() == null ? "" : bodyResponse.body().string();
                        if (!response.isSuccessful()) {
                            MAIN.post(() -> callback.onError(readServerError(body, response.code())));
                            return;
                        }
                        String status = new JSONObject(body).optString("status", "pending");
                        MAIN.post(() -> callback.onResult(status));
                    } catch (Exception error) {
                        MAIN.post(() -> callback.onError("Invalid response from backend."));
                    }
                }
            });
        } catch (Exception error) {
            callback.onError("Could not verify order.");
        }
    }

    /** Registers a player through the trusted backend so entry coins cannot be forged client-side.
     *  A26 — the caller no longer picks a slot up front: the server claims the next free slot
     *  atomically and returns it, so the slot is only known (and shown) after a successful join. */
    /** Single-slot join — kept for existing callers. Delegates to the multi-slot
     *  version below with a one-slot array. */
    public static void joinMatch(String tournamentId, int slotNumber, String gameUid,
                                 String gameName, JoinCallback callback) {
        joinMatch(tournamentId, slotNumber > 0 ? new int[]{slotNumber} : new int[0], gameUid, gameName, callback);
    }

    /** Joins with one or more specific slots at once (2+ slots = that many
     *  entry fees, charged and reserved atomically together on the server —
     *  never a flat per-join fee). Pass an empty array to let the server
     *  auto-assign a single free slot, same as before. Every slot uses the
     *  same Game UID/Name — use the per-slot-player overload below for a
     *  Duo/Squad team or any join where each slot is a different person. */
    public static void joinMatch(String tournamentId, int[] slotNumbers, String gameUid,
                                 String gameName, JoinCallback callback) {
        joinMatch(tournamentId, slotNumbers, null, null, gameUid, gameName, callback);
    }

    /** Joins with a separate Game UID + Game Name per slot — e.g. a Duo team
     *  where slot 3 is you and slot 9 is your teammate. gameUids/gameNames
     *  must be the same length as slotNumbers, in the same order. */
    public static void joinMatch(String tournamentId, int[] slotNumbers, String[] gameUids,
                                 String[] gameNames, JoinCallback callback) {
        joinMatch(tournamentId, slotNumbers, gameUids, gameNames,
                gameUids != null && gameUids.length > 0 ? gameUids[0] : "",
                gameNames != null && gameNames.length > 0 ? gameNames[0] : "", callback);
    }

    private static void joinMatch(String tournamentId, int[] slotNumbers, String[] gameUids, String[] gameNames,
                                 String gameUid, String gameName, JoinCallback callback) {
        String baseUrl = BuildConfig.STARX_API_BASE_URL == null ? "" : BuildConfig.STARX_API_BASE_URL.trim();
        if (baseUrl.isEmpty() || baseUrl.contains("YOUR-SERVICE")) { callback.onError("Match backend is not configured."); return; }
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        if (user == null) { callback.onError("Please sign in before joining."); return; }
        user.getIdToken(false).addOnSuccessListener(result -> {
            String token = result == null ? null : result.getToken();
            if (token == null || token.trim().isEmpty()) { callback.onError("Could not verify your Firebase session."); return; }
            try {
                JSONObject payload = new JSONObject();
                payload.put("tournamentId", tournamentId);
                if (slotNumbers != null && slotNumbers.length == 1) {
                    // Single slot: keep sending the legacy "slotNumber" field too,
                    // so an older backend deployment (pre multi-slot) still works.
                    payload.put("slotNumber", slotNumbers[0]);
                } else if (slotNumbers != null && slotNumbers.length > 1) {
                    JSONArray array = new JSONArray();
                    for (int slot : slotNumbers) array.put(slot);
                    payload.put("slotNumbers", array);
                }
                payload.put("gameUid", gameUid);
                payload.put("gameName", gameName);
                // Per-slot player details (Duo/Squad, or any multi-slot join): one
                // {slotNumber, gameUid, gameName} entry per slot, so the server can
                // tell slot 3's player apart from slot 9's instead of assuming
                // everyone in the join is the same person.
                if (slotNumbers != null && gameUids != null && gameNames != null
                        && slotNumbers.length == gameUids.length && slotNumbers.length == gameNames.length
                        && slotNumbers.length > 0) {
                    JSONArray players = new JSONArray();
                    for (int i = 0; i < slotNumbers.length; i++) {
                        JSONObject player = new JSONObject();
                        player.put("slotNumber", slotNumbers[i]);
                        player.put("gameUid", gameUids[i]);
                        player.put("gameName", gameNames[i]);
                        players.put(player);
                    }
                    payload.put("players", players);
                }
                String normalized = baseUrl.endsWith("/") ? baseUrl.substring(0, baseUrl.length() - 1) : baseUrl;
                Request request = new Request.Builder().url(normalized + "/joinMatch")
                        .post(RequestBody.create(payload.toString(), JSON))
                        .addHeader("Authorization", "Bearer " + token).build();
                HTTP.newCall(request).enqueue(new okhttp3.Callback() {
                    @Override public void onFailure(Call call, IOException error) { MAIN.post(() -> callback.onError("Could not connect to the match server.")); }
                    @Override public void onResponse(Call call, Response response) {
                        try (Response body = response) {
                            String raw = body.body() == null ? "" : body.body().string();
                            JSONObject json = new JSONObject(raw);
                            if (!response.isSuccessful()) { MAIN.post(() -> callback.onError(json.optString("error", "Could not join match."))); return; }
                            int firstSlot = json.optInt("slotNumber", 0);
                            JSONArray slotsJson = json.optJSONArray("slotNumbers");
                            int[] slots;
                            if (slotsJson != null && slotsJson.length() > 0) {
                                slots = new int[slotsJson.length()];
                                for (int i = 0; i < slotsJson.length(); i++) slots[i] = slotsJson.optInt(i, 0);
                            } else {
                                slots = firstSlot > 0 ? new int[]{firstSlot} : new int[0];
                            }
                            MAIN.post(() -> callback.onSuccess(json.optString("status", "registered"), json.optInt("entryFeeCoins", 0), firstSlot, slots));
                        } catch (Exception error) { MAIN.post(() -> callback.onError("Invalid match server response.")); }
                    }
                });
            } catch (Exception error) { callback.onError("Could not join match."); }
        }).addOnFailureListener(error -> callback.onError("Could not verify your Firebase session."));
    }

    private static String readServerError(String body, int statusCode) {
        try {
            JSONObject json = new JSONObject(body);
            String message = json.optString("error", "").trim();
            if (!message.isEmpty()) return message;
        } catch (Exception ignored) {
            // Use a generic message below so provider details are not shown in the app.
        }
        return "Payment order failed (HTTP " + statusCode + ").";
    }

    private static boolean isTimeout(IOException error) {
        Throwable current = error;
        while (current != null) {
            if (current instanceof java.net.SocketTimeoutException) return true;
            current = current.getCause();
        }
        return false;
    }

    private static String findPaymentUrl(Object value) {
        if (value instanceof JSONObject) {
            JSONObject object = (JSONObject) value;
            String[] keys = {"payment_url", "paymentUrl", "checkout_url", "redirect_url", "pay_url", "payment_link", "url"};
            for (String key : keys) {
                String candidate = object.optString(key, "").trim();
                if (candidate.startsWith("http://") || candidate.startsWith("https://")) return candidate;
            }
            java.util.Iterator<String> names = object.keys();
            while (names.hasNext()) {
                String candidate = findPaymentUrl(object.opt(names.next()));
                if (!candidate.isEmpty()) return candidate;
            }
        } else if (value instanceof JSONArray) {
            JSONArray array = (JSONArray) value;
            for (int i = 0; i < array.length(); i++) {
                String candidate = findPaymentUrl(array.opt(i));
                if (!candidate.isEmpty()) return candidate;
            }
        } else if (value instanceof String) {
            String text = ((String) value).trim();
            if (text.startsWith("http://") || text.startsWith("https://")) return text;
            if (text.startsWith("{") || text.startsWith("[")) {
                try {
                    return findPaymentUrl(new org.json.JSONTokener(text).nextValue());
                } catch (Exception ignored) {
                    // Not a JSON-encoded URL.
                }
            }
        }
        return "";
    }
}
