package com.arenax.tournament.data;

import android.content.Context;

import androidx.annotation.NonNull;

import com.arenax.tournament.model.Team;
import com.arenax.tournament.model.Tournament;
import com.google.android.gms.tasks.Task;
import com.google.android.gms.tasks.TaskCompletionSource;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ServerValue;

import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public final class FirebaseRepository {
    private FirebaseRepository() {}

    /**
     * DatabaseReference.runTransaction(...) returns void in the Firebase Android SDK, so it
     * cannot be chained with .continueWithTask(...) directly. This wraps it in a
     * TaskCompletionSource so transaction call sites can be composed like any other Task.
     * The task fails if the transaction was aborted (e.g. Transaction.abort()) or errored,
     * and succeeds with the final DataSnapshot when committed.
     */
    private static Task<DataSnapshot> runTransactionTask(DatabaseReference ref,
                                                           com.google.firebase.database.Transaction.Handler handler) {
        TaskCompletionSource<DataSnapshot> source = new TaskCompletionSource<>();
        ref.runTransaction(new com.google.firebase.database.Transaction.Handler() {
            @Override
            public com.google.firebase.database.Transaction.Result doTransaction(
                    com.google.firebase.database.MutableData currentData) {
                return handler.doTransaction(currentData);
            }

            @Override
            public void onComplete(DatabaseError error, boolean committed, DataSnapshot currentData) {
                handler.onComplete(error, committed, currentData);
                if (error != null) {
                    source.setException(error.toException());
                } else if (!committed) {
                    source.setException(new IllegalStateException("Transaction aborted"));
                } else {
                    source.setResult(currentData);
                }
            }
        });
        return source.getTask();
    }

    /** Returns true only when the Firebase SDK and generated options are usable. */
    public static boolean isReady(Context context) {
        return isFirebaseAvailable(context);
    }

    /** FirebaseAuth can throw when google-services metadata is incomplete; callers use this safely. */
    public static FirebaseUser currentUser() {
        try {
            return FirebaseAuth.getInstance().getCurrentUser();
        } catch (RuntimeException ignored) {
            return null;
        }
    }

    private static DatabaseReference root() {
        return FirebaseDatabase.getInstance().getReference();
    }

    /**
     * Checks and initializes the default Firebase app without allowing a
     * configuration problem to crash the login screen.
     */
    public static boolean isFirebaseAvailable(Context context) {
        try {
            Context appContext = context == null ? null : context.getApplicationContext();
            if (appContext == null) return false;
            if (FirebaseApp.getApps(appContext).isEmpty()
                    && FirebaseApp.initializeApp(appContext) == null) {
                return false;
            }
            FirebaseAuth.getInstance();
            FirebaseDatabase.getInstance();
            return true;
        } catch (RuntimeException ignored) {
            return false;
        }
    }

    /**
     * Keeps the small, public "shop window" data (banners, game categories, app config)
     * permanently synced to the local disk cache so Home opens instantly with real data.
     * Call after login (rules need auth). Safe to call repeatedly.
     * Deliberately NOT applied to wallet / orders / participants (live money data) or to the
     * whole tournaments tree (participants make it large) - those use the normal cache that
     * persistence builds from whatever the screens actually listen to.
     */
    public static void keepHomeDataSynced() {
        try {
            banners().keepSynced(true);
            gameModes().keepSynced(true);
            appConfig().keepSynced(true);
        } catch (RuntimeException ignored) { }
    }

    public static DatabaseReference tournaments() {
        return root().child("tournaments");
    }

    /**
     * Runs a Firebase multi-location update straight from the client (used by
     * FirebaseDirectJoinClient to claim slots + debit coins in one atomic write).
     * Exposed here since root() itself is private to this class.
     */
    public static void rootUpdate(java.util.Map<String, Object> update, DatabaseReference.CompletionListener listener) {
        root().updateChildren(update, listener);
    }

    public static DatabaseReference users() {
        return root().child("users");
    }

    // ---------- login by email / mobile number / username ----------
    public static DatabaseReference loginIndex() {
        return root().child("loginIndex");
    }

    /** Index key for a mobile number ("p_" + last 10 digits) or username ("u_" + lowercase). Null for an email or empty text. */
    public static String loginKey(String raw) {
        String v = raw == null ? "" : raw.trim();
        if (v.isEmpty() || v.contains("@")) return null;
        String digits = v.replaceAll("[\\s\\-()+]", "");
        if (digits.matches("\\d{10,13}")) return "p_" + digits.substring(digits.length() - 10);
        String user = v.toLowerCase(java.util.Locale.ROOT);
        return user.matches("[a-z0-9_.]{3,20}") ? "u_" + user : null;
    }

    public interface EmailLookup { void done(String email, boolean failed); }

    /** Finds the email behind a mobile number or username. email == null && !failed means "no such account". */
    public static void resolveLoginEmail(String raw, final EmailLookup callback) {
        String key = loginKey(raw);
        if (key == null) { callback.done(null, false); return; }
        loginIndex().child(key).child("email").addListenerForSingleValueEvent(new com.google.firebase.database.ValueEventListener() {
            @Override public void onDataChange(@NonNull DataSnapshot snapshot) {
                String email = snapshot.getValue(String.class);
                callback.done(email == null || email.trim().isEmpty() ? null : email.trim(), false);
            }
            @Override public void onCancelled(@NonNull DatabaseError error) { callback.done(null, true); }
        });
    }

    /** True when a username is still free. Fails open (true) if the lookup itself fails. */
    public static void usernameAvailable(String username, final java.util.function.Consumer<Boolean> callback) {
        String key = loginKey(username);
        if (key == null || !key.startsWith("u_")) { callback.accept(false); return; }
        loginIndex().child(key).addListenerForSingleValueEvent(new com.google.firebase.database.ValueEventListener() {
            @Override public void onDataChange(@NonNull DataSnapshot snapshot) { callback.accept(!snapshot.exists()); }
            @Override public void onCancelled(@NonNull DatabaseError error) { callback.accept(true); }
        });
    }

    /** Lets the signed-in user log in later with their mobile number and/or username. Best effort. */
    public static void saveLoginKeys(String uid, String email, String phone, String username) {
        try {
            if (uid == null || email == null) return;
            for (String raw : new String[]{phone, username}) {
                String key = loginKey(raw);
                if (key == null) continue;
                Map<String, Object> record = new HashMap<>();
                record.put("uid", uid);
                record.put("email", email);
                loginIndex().child(key).setValue(record);
            }
        } catch (Throwable ignored) { }
    }

    /** Accounts created before this feature get their mobile number indexed on their next email login. */
    public static void backfillLoginKeys(final String uid, final String email) {
        try {
            users().child(uid).child("phone").addListenerForSingleValueEvent(new com.google.firebase.database.ValueEventListener() {
                @Override public void onDataChange(@NonNull DataSnapshot snapshot) {
                    String phone = snapshot.getValue(String.class);
                    if (phone != null) saveLoginKeys(uid, email, phone, null);
                }
                @Override public void onCancelled(@NonNull DatabaseError error) { }
            });
        } catch (Throwable ignored) { }
    }

    public static DatabaseReference phoneIndex() {
        return root().child("phoneIndex");
    }

    /** Reserves a normalized phone number; Firebase rules reject a second owner. */
    public static Task<Void> reservePhone(String phone, String uid) {
        Map<String, Object> record = new HashMap<>();
        record.put("uid", uid);
        record.put("phone", phone);
        return phoneIndex().child(phone).setValue(record);
    }

    public static DatabaseReference gameModes() {
        return root().child("gameModes");
    }

    public static DatabaseReference appConfig() {
        return root().child("appConfig");
    }

    /** Saved default description / rules per category: categoryPresets/{categoryKey}/{description|rules}. */
    public static DatabaseReference categoryPresets() {
        return root().child("categoryPresets");
    }

    /** Firebase keys cannot contain . # $ [ ] / so a category id is cleaned before it is used as a key. */
    public static String categoryPresetKey(String categoryId) {
        return categoryId == null ? "" : categoryId.trim().replaceAll("[.#$\\[\\]/]", "_");
    }

    /** Saves one preset field. An empty value deletes it (the screen then falls back to its own default). */
    public static Task<Void> saveCategoryPreset(String categoryId, String field, String value) {
        String key = categoryPresetKey(categoryId);
        if (key.isEmpty()) {
            return com.google.android.gms.tasks.Tasks.<Void>forException(new IllegalStateException("Category not selected."));
        }
        DatabaseReference ref = categoryPresets().child(key).child(field);
        return value == null || value.trim().isEmpty() ? ref.removeValue() : ref.setValue(value.trim());
    }

    /** Public player cards (name, bio, photo ONLY) that every logged-in player may search.
     *  Email / phone / wallet stay in the private users/{uid} node. */
    public static DatabaseReference publicProfiles() {
        return root().child("publicProfiles");
    }

    /** Mirrors the player's public fields into publicProfiles/{uid}. Safe to call repeatedly. */
    public static Task<Void> syncPublicProfile(String uid, String name, String bio, String photoUrl) {
        if (uid == null || uid.isEmpty() || name == null || name.trim().isEmpty()) {
            return com.google.android.gms.tasks.Tasks.forResult(null);
        }
        String cleanName = name.trim();
        if (cleanName.length() > 119) cleanName = cleanName.substring(0, 119);
        String cleanBio = bio == null ? "" : bio.trim();
        if (cleanBio.length() > 150) cleanBio = cleanBio.substring(0, 150);
        Map<String, Object> card = new HashMap<>();
        card.put("name", cleanName);
        card.put("nameLower", cleanName.toLowerCase(java.util.Locale.ROOT));
        card.put("bio", cleanBio);
        card.put("photoUrl", photoUrl == null ? "" : photoUrl.trim());
        card.put("updatedAt", ServerValue.TIMESTAMP);
        return publicProfiles().child(uid).setValue(card);
    }

    public static DatabaseReference notifications() {
        return root().child("notifications");
    }

    public static DatabaseReference results() {
        return root().child("results");
    }

    public static DatabaseReference leaderboard() {
        return root().child("leaderboard");
    }

    public static DatabaseReference rewards() {
        return root().child("rewards");
    }

    public static DatabaseReference banners() {
        return root().child("banners");
    }

    public static DatabaseReference faq() {
        return root().child("faq");
    }

    /** Admin-editable text for Terms / Privacy / About Us screens (appContent/{terms|privacy|about}). */
    public static DatabaseReference appContent() {
        return root().child("appContent");
    }

    public static DatabaseReference support() {
        return root().child("support");
    }

    public static DatabaseReference coinRequests() {
        return root().child("coin_requests");
    }

    /** Manual admin coin add/remove log (written by the backend only). Query with orderByChild("uid"). */

    public static DatabaseReference manualCoinLog() {
        return root().child("manual_coin_log");
    }

    public static DatabaseReference coinHistory() {
        return root().child("coin_history");
    }

    public static DatabaseReference broadcastNotifications() {
        return root().child("broadcast_notifications");
    }

    public static DatabaseReference joinedUsers(String matchId) {
        return matches().child(matchId).child("joinedUsers");
    }

    /** Creates a new support ticket owned by the current signed-in user. */
    public static Task<Void> createTicket(String category, String subject, String description) {
        String uid = FirebaseAuth.getInstance().getUid();
        if (uid == null) {
            return com.google.android.gms.tasks.Tasks.forException(
                    new IllegalStateException("Authentication required"));
        }
        String id = support().push().getKey();
        Map<String, Object> ticket = new HashMap<>();
        ticket.put("userId", uid);
        ticket.put("category", category);
        ticket.put("subject", subject);
        ticket.put("description", description);
        ticket.put("status", "OPEN");
        ticket.put("createdAt", ServerValue.TIMESTAMP);
        ticket.put("reply", "");
        return support().child(id == null ? "ticket" : id).setValue(ticket);
    }

    public static Task<Void> replyToTicket(String ticketId, String reply, String status) {
        Map<String, Object> update = new HashMap<>();
        update.put("reply", reply);
        update.put("status", status);
        update.put("repliedAt", ServerValue.TIMESTAMP);
        return support().child(ticketId).updateChildren(update);
    }

    public static DatabaseReference tournamentParticipants(String tournamentId) {
        return tournaments().child(tournamentId).child("participants");
    }

    public static DatabaseReference matchParticipants(String matchId) {
        return matches().child(matchId).child("participants");
    }

    /**
     * A19 — Targeted room-release push. Reads the uid keys under a
     * tournament's or match's "participants" node, looks up each one's
     * saved /users/{uid}/fcmToken, and hands the resulting token list to
     * the callback — never "All Users", only whoever actually joined.
     * Pass tournamentParticipants(id) or matchParticipants(id) as participantsRef.
     */
    public static void collectParticipantFcmTokens(DatabaseReference participantsRef, ParticipantTokensCallback callback) {
        participantsRef.addListenerForSingleValueEvent(new com.google.firebase.database.ValueEventListener() {
            @Override public void onDataChange(@NonNull com.google.firebase.database.DataSnapshot snapshot) {
                java.util.List<String> uids = new java.util.ArrayList<>();
                for (com.google.firebase.database.DataSnapshot child : snapshot.getChildren()) {
                    uids.add(child.getKey());
                }
                if (uids.isEmpty()) {
                    callback.onTokens(new java.util.ArrayList<>());
                    return;
                }
                java.util.List<String> tokens = java.util.Collections.synchronizedList(new java.util.ArrayList<>());
                java.util.concurrent.atomic.AtomicInteger remaining = new java.util.concurrent.atomic.AtomicInteger(uids.size());
                for (String uid : uids) {
                    users().child(uid).child("fcmToken").addListenerForSingleValueEvent(new com.google.firebase.database.ValueEventListener() {
                        @Override public void onDataChange(@NonNull com.google.firebase.database.DataSnapshot tokenSnap) {
                            String token = tokenSnap.getValue(String.class);
                            if (token != null && !token.isEmpty()) tokens.add(token);
                            if (remaining.decrementAndGet() == 0) callback.onTokens(tokens);
                        }
                        @Override public void onCancelled(@NonNull com.google.firebase.database.DatabaseError error) {
                            if (remaining.decrementAndGet() == 0) callback.onTokens(tokens);
                        }
                    });
                }
            }
            @Override public void onCancelled(@NonNull com.google.firebase.database.DatabaseError error) {
                callback.onTokens(new java.util.ArrayList<>());
            }
        });
    }

    public interface ParticipantTokensCallback {
        void onTokens(java.util.List<String> fcmTokens);
    }

    public static Task<Void> saveTournament(Tournament tournament) {
        String id = tournament.getId();
        if (id == null || id.startsWith("local-")) {
            id = tournaments().push().getKey();
        }
        final boolean isNew = tournament.getId() == null || tournament.getId().startsWith("local-");
        Map<String, Object> map = tournament.toMap();
        // Room ID/password must NEVER sit in the player-readable tournaments node before release.
        // Keep the admin-typed values in matches/{id}/roomRelease (admin-only) until release time.
        if (!tournament.isRoomReleased()) {
            String pendingId = tournament.getRoomId() == null ? "" : tournament.getRoomId().trim();
            String pendingPass = tournament.getRoomPassword() == null ? "" : tournament.getRoomPassword().trim();
            map.put("roomId", "");
            map.put("roomPassword", "");
            if (!pendingId.isEmpty()) {
                Map<String, Object> pending = new HashMap<>();
                pending.put("roomId", pendingId);
                pending.put("roomPassword", pendingPass);
                matches().child(id).child("roomRelease").updateChildren(pending);
            }
        }
        if (isNew) {
            if (tournament.getShowAt() > 0L) {
                map.put("showAt", tournament.getShowAt());
            }
            // Daily mode chosen on the Add Match form: this first match becomes the series root.
            if (tournament.isDailyMode()) {
                map.put("dailyMode", true);
                map.put("dailySeriesId", id);
            }
            return tournaments().child(id).setValue(map);
        }
        // EXISTING match: merge, never replace. setValue() here used to wipe participants, slotIndex,
        // waitlist, editLogs... of a live match on every admin edit. joinedSlots is owned by the
        // backend (join/leave), so a stale admin copy must not overwrite it either.
        map.remove("joinedSlots");
        return tournaments().child(id).updateChildren(map);
    }

    // ------------------------------------------------------------------
    // DAILY MODE — the same match re-appears every day at the same time.
    // Fields live on tournaments/{id}: dailyMode, dailySeriesId, dailyNextId.
    // They are NOT part of Tournament.toMap(), so ordinary admin edits can never reset them.
    // The next day's copy gets the deterministic key "{seriesId}_{startAtMillis}", so the app
    // and the backend worker (backend/index.js processDailyMatches) can never create duplicates.
    // ------------------------------------------------------------------
    private static final long DAY_MS = 24L * 60L * 60L * 1000L;

    /** Turn daily mode on/off for a match. OFF stops the whole series (every match with the same series id). */
    public static Task<Void> setDailyMode(final Tournament t, final boolean on) {
        final TaskCompletionSource<Void> source = new TaskCompletionSource<>();
        if (t == null || t.getId() == null || t.getId().startsWith("local-")) {
            source.setException(new IllegalStateException("Save the match first."));
            return source.getTask();
        }
        final String seriesId = t.getDailySeriesId().isEmpty() ? t.getId() : t.getDailySeriesId();
        if (on) {
            Map<String, Object> updates = new HashMap<>();
            updates.put("dailyMode", true);
            updates.put("dailySeriesId", seriesId);
            tournaments().child(t.getId()).updateChildren(updates).addOnSuccessListener(done -> {
                t.setDailyMode(true);
                t.setDailySeriesId(seriesId);
                ensureDailyNext(t);
                source.setResult(null);
            }).addOnFailureListener(source::setException);
            return source.getTask();
        }
        tournaments().orderByChild("dailySeriesId").equalTo(seriesId)
                .addListenerForSingleValueEvent(new com.google.firebase.database.ValueEventListener() {
                    @Override public void onDataChange(@NonNull DataSnapshot snapshot) {
                        Map<String, Object> updates = new HashMap<>();
                        updates.put(t.getId() + "/dailyMode", false);
                        for (DataSnapshot child : snapshot.getChildren()) {
                            if (child.getKey() != null) updates.put(child.getKey() + "/dailyMode", false);
                        }
                        tournaments().updateChildren(updates).addOnSuccessListener(done -> {
                            t.setDailyMode(false);
                            source.setResult(null);
                        }).addOnFailureListener(source::setException);
                    }
                    @Override public void onCancelled(@NonNull DatabaseError error) {
                        source.setException(error.toException());
                    }
                });
        return source.getTask();
    }

    /**
     * Makes sure tomorrow's copy of a daily match exists. Called when daily mode is switched on and
     * whenever an admin opens a category list (backup for the server worker).
     * A copy is created once the match is within 24h of its start (or already started), so there is
     * always exactly one upcoming copy ready.
     */
    public static void ensureDailyNext(final Tournament t) {
        if (t == null || !t.isDailyMode() || !t.getDailyNextId().isEmpty()) return;
        if (t.getId() == null || t.getId().startsWith("local-") || !t.isActive() || t.isDraft()) return;
        final long start = t.getEffectiveStartAt();
        final long now = System.currentTimeMillis();
        if (start <= 0L || now < start - DAY_MS) return;
        long next = start + DAY_MS;
        while (next <= now) next += DAY_MS;
        final long nextStart = next;
        final String seriesId = t.getDailySeriesId().isEmpty() ? t.getId() : t.getDailySeriesId();
        final String nextId = seriesId + "_" + nextStart;

        Map<String, Object> copy = t.toMap();
        // Only the public #number changes for a new day; everything else is copied as it is.
        final String copyTitle = com.arenax.tournament.util.MatchNumber.retitleForCopy(t.getTitle(), nextId);
        copy.put("title", copyTitle);
        copy.put("joinedSlots", 0);
        copy.put("status", Tournament.UPCOMING);
        copy.put("registrationStatus", "OPEN");
        copy.put("roomId", "");
        copy.put("roomPassword", "");
        copy.put("roomReleased", false);
        copy.put("roomReleaseAt", 0L);
        copy.put("delayReason", "");
        copy.put("startAt", nextStart);
        copy.put("date", new java.text.SimpleDateFormat("dd MMM yyyy", java.util.Locale.ENGLISH)
                .format(new java.util.Date(nextStart)).toUpperCase(java.util.Locale.ROOT));
        copy.put("time", new java.text.SimpleDateFormat("hh:mm a", java.util.Locale.ENGLISH)
                .format(new java.util.Date(nextStart)).toUpperCase(java.util.Locale.ROOT));
        long regClose = t.getRegistrationCloseAt();
        copy.put("registrationCloseAt", regClose > 0L ? regClose + (nextStart - start) : 0L);
        copy.put("dailyMode", true);
        copy.put("dailySeriesId", seriesId);
        if (t.getShowAt() > 0L) copy.put("showAt", t.getShowAt() + (nextStart - start));
        copy.put("createdAt", ServerValue.TIMESTAMP);

        tournaments().child(nextId).runTransaction(new com.google.firebase.database.Transaction.Handler() {
            @NonNull @Override public com.google.firebase.database.Transaction.Result doTransaction(@NonNull com.google.firebase.database.MutableData data) {
                if (data.getValue() == null) data.setValue(copy);   // create only if it is not there yet
                return com.google.firebase.database.Transaction.success(data);
            }
            @Override public void onComplete(DatabaseError error, boolean committed, DataSnapshot snapshot) {
                if (error != null) return;
                tournaments().child(t.getId()).child("dailyNextId").setValue(nextId);
                // Same /matches mirror Add Match writes, so the messenger app lists the daily copy too.
                final Map<String, Object> mirror = new HashMap<>();
                mirror.put("tournamentTitle", copyTitle);
                mirror.put("name", copyTitle);
                mirror.put("category", t.getMode());
                mirror.put("imageUrl", t.getBannerUrl());
                mirror.put("scheduledAt", nextStart);
                mirror.put("roomId", "");
                mirror.put("roomPassword", "");
                mirror.put("roomReleased", false);
                mirror.put("status", "UPCOMING");
                mirror.put("participants", new HashMap<String, Object>());
                matches().child(nextId).runTransaction(new com.google.firebase.database.Transaction.Handler() {
                    @NonNull @Override public com.google.firebase.database.Transaction.Result doTransaction(@NonNull com.google.firebase.database.MutableData data) {
                        if (data.getValue() == null) data.setValue(mirror);
                        return com.google.firebase.database.Transaction.success(data);
                    }
                    @Override public void onComplete(DatabaseError e, boolean c, DataSnapshot snap) { }
                });
            }
        });
    }

    /**
     * Deleting a match wipes participants/slots but never refunds entry fees. So a PAID match that still
     * has joined players (and is not finished) cannot be deleted: players must leave (refund) or the
     * match must be completed first.
     */
    public static Task<Void> deleteTournament(String id) {
        return tournaments().child(id).get().continueWithTask(task -> {
            if (task.isSuccessful() && task.getResult() != null && task.getResult().exists()) {
                DataSnapshot snap = task.getResult();
                Long fee = snap.child("entryFeeCoins").getValue(Long.class);
                Long joined = snap.child("joinedSlots").getValue(Long.class);
                String status = String.valueOf(snap.child("status").getValue()).toUpperCase(java.util.Locale.ROOT);
                // Same notion of "finished" the card uses (getEffectiveStatus): result published/resulted also counts.
                boolean finished = "COMPLETED".equals(status) || "CANCELLED".equals(status)
                        || "RESULT_PUBLISHED".equals(status) || "RESULTED".equals(status);
                // Count only REAL registered players. The joinedSlots counter can be stale (ghost / "fake registered"
                // slots from failed or interrupted joins), and RESERVING records are unpaid, so neither may block a delete.
                int realPlayers = 0;
                for (DataSnapshot p : snap.child("participants").getChildren()) {
                    String ps = String.valueOf(p.child("status").getValue()).toUpperCase(java.util.Locale.ROOT);
                    if (!"RESERVING".equals(ps) && !"LEFT".equals(ps) && !"CANCELLED".equals(ps) && !"REMOVED".equals(ps)) realPlayers++;
                }
                if (fee != null && fee > 0 && realPlayers > 0 && !finished) {
                    return com.google.android.gms.tasks.Tasks.<Void>forException(new IllegalStateException(
                            "Paid match has " + realPlayers + " registered player(s). Pehle Refund do (Rank & Leaderboard > Rank Manage > Refund) ya match complete karo, phir delete."));
                }
            }
            // Remove the public match first; the /matches mirror is cleaned best-effort afterwards so a
            // leftover mirror (or its rules) can never make a finished match look "undeletable".
            return tournaments().child(id).removeValue().addOnSuccessListener(done -> {
                try { matches().child(id).removeValue(); } catch (Exception ignored) { }
            });
        });
    }


    // ------------------------------------------------------------------
    // Admin: duplicate a match to a new time, and shift match times in bulk.
    // ------------------------------------------------------------------
    private static String fmtDate(long ms) {
        return new java.text.SimpleDateFormat("dd MMM yyyy", java.util.Locale.ENGLISH)
                .format(new java.util.Date(ms)).toUpperCase(java.util.Locale.ROOT);
    }
    private static String fmtTime(long ms) {
        return new java.text.SimpleDateFormat("hh:mm a", java.util.Locale.ENGLISH)
                .format(new java.util.Date(ms)).toUpperCase(java.util.Locale.ROOT);
    }

    /** Copies a match (everything except players/room/result) to a new start time. Not part of any daily series. */
    public static Task<Void> duplicateTournament(final Tournament t, final long newStart) {
        final String newId = tournaments().push().getKey();
        if (newId == null) {
            return com.google.android.gms.tasks.Tasks.forException(new IllegalStateException("Could not create id"));
        }
        final long oldStart = t.getEffectiveStartAt();
        final long delta = oldStart > 0L ? newStart - oldStart : 0L;
        Map<String, Object> copy = t.toMap();
        final String copyTitle = com.arenax.tournament.util.MatchNumber.retitleForCopy(t.getTitle(), newId);
        copy.put("title", copyTitle);
        copy.put("joinedSlots", 0);
        copy.put("status", Tournament.UPCOMING);
        copy.put("registrationStatus", "OPEN");
        copy.put("roomId", "");
        copy.put("roomPassword", "");
        copy.put("roomReleased", false);
        copy.put("roomReleaseAt", 0L);
        copy.put("delayReason", "");
        copy.put("startAt", newStart);
        copy.put("date", fmtDate(newStart));
        copy.put("time", fmtTime(newStart));
        long regClose = t.getRegistrationCloseAt();
        copy.put("registrationCloseAt", regClose > 0L && oldStart > 0L ? regClose + delta : 0L);
        if (t.getShowAt() > 0L && oldStart > 0L) copy.put("showAt", t.getShowAt() + delta);
        copy.put("createdAt", ServerValue.TIMESTAMP);
        return tournaments().child(newId).setValue(copy).addOnSuccessListener(done -> {
            Map<String, Object> mirror = new HashMap<>();
            mirror.put("tournamentTitle", copyTitle);
            mirror.put("name", copyTitle);
            mirror.put("category", t.getMode());
            mirror.put("imageUrl", t.getBannerUrl());
            mirror.put("scheduledAt", newStart);
            mirror.put("roomId", "");
            mirror.put("roomPassword", "");
            mirror.put("roomReleased", false);
            mirror.put("status", "UPCOMING");
            mirror.put("participants", new HashMap<String, Object>());
            try { matches().child(newId).setValue(mirror); } catch (Exception ignored) { }
        });
    }

    /** Moves a not-yet-finished match by deltaMs (negative = earlier). Registration/room/show times move with it. */
    public static Task<Void> shiftTournament(final Tournament t, final long deltaMs) {
        long base = t.getEffectiveStartAt();
        if (base <= 0L) {
            return com.google.android.gms.tasks.Tasks.forException(new IllegalStateException("Match has no start time"));
        }
        final long newStart = base + deltaMs;
        Map<String, Object> up = new HashMap<>();
        up.put("startAt", newStart);
        up.put("date", fmtDate(newStart));
        up.put("time", fmtTime(newStart));
        if (t.getRegistrationCloseAt() > 0L) up.put("registrationCloseAt", t.getRegistrationCloseAt() + deltaMs);
        if (t.getRoomReleaseAt() > 0L) up.put("roomReleaseAt", t.getRoomReleaseAt() + deltaMs);
        if (t.getShowAt() > 0L) up.put("showAt", t.getShowAt() + deltaMs);
        return tournaments().child(t.getId()).updateChildren(up).addOnSuccessListener(done -> {
            try {
                matches().child(t.getId()).child("scheduledAt").setValue(newStart);
                matches().child(t.getId()).child("roomRelease").child("releaseAt").get().addOnSuccessListener(s -> {
                    Object v = s.getValue();
                    if (v instanceof Number && ((Number) v).longValue() > 0L) {
                        matches().child(t.getId()).child("roomRelease").child("releaseAt")
                                .setValue(((Number) v).longValue() + deltaMs);
                    }
                });
            } catch (Exception ignored) { }
        });
    }

    /** Cancels a match. Refused when paid players have joined (they need a refund first). */
    public static Task<Void> cancelTournament(final Tournament t, String reason) {
        if (t.getEntryFeeCoins() > 0 && t.getJoinedSlots() > 0) {
            return com.google.android.gms.tasks.Tasks.forException(new IllegalStateException(
                    "Paid match with joined players: refund them first."));
        }
        Map<String, Object> up = new HashMap<>();
        up.put("status", Tournament.CANCELLED);
        up.put("registrationStatus", "CLOSED");
        up.put("delayReason", reason == null ? "" : reason);
        return tournaments().child(t.getId()).updateChildren(up).addOnSuccessListener(done -> {
            try { matches().child(t.getId()).child("status").setValue("CANCELLED"); } catch (Exception ignored) { }
        });
    }

    /**
     * 1VS1 opponent never joined: close the match as Completed (players never see "Cancelled") so the admin can
     * publish a fully manual coin leaderboard. No coins move here — coins/refund are given from Rank Manage.
     */
    public static Task<Void> cancelNoOpponent(final String tournamentId) {
        Map<String, Object> up = new HashMap<>();
        up.put("status", Tournament.COMPLETED);
        up.put("registrationStatus", "CLOSED");
        up.put("noOpponent", true);
        up.put("noOpponentAt", System.currentTimeMillis());
        return tournaments().child(tournamentId).updateChildren(up).addOnSuccessListener(done -> {
            try { matches().child(tournamentId).child("status").setValue("COMPLETED"); } catch (Exception ignored) { }
        });
    }

    public static Task<Void> saveUserProfile(String uid, String email, String name, String phone, String photoUrl) {
        Map<String, Object> profile = new HashMap<>();
        profile.put("uid", uid);
        profile.put("email", email);
        profile.put("name", name);
        profile.put("phone", phone);
        profile.put("role", "USER");
        profile.put("createdAt", System.currentTimeMillis());
        profile.put("status", "ACTIVE");
        if (photoUrl != null && !photoUrl.trim().isEmpty()) profile.put("photoUrl", photoUrl);
        // FIX (2026-09-14): this used to leave users/{uid}/wallet completely unset.
        // Every balance-dependent read/write in the app (join-match debit, the
        // database.rules.json arithmetic, WalletActivity's display) assumes
        // wallet/balance exists as a number. A brand-new account with no wallet
        // node at all made the very first paid-match join fail (permission denied)
        // for reasons that had nothing to do with the match itself. Confirmed this
        // function is only ever called once, from LoginActivity.register() right
        // after account creation — never again on later sign-ins — so this can't
        // clobber a balance that's grown since signup.
        Map<String, Object> wallet = new HashMap<>();
        wallet.put("balance", 0);
        wallet.put("coinBonus", 0);
        profile.put("wallet", wallet);
        syncPublicProfile(uid, name, "", photoUrl);
        return users().child(uid).updateChildren(profile);
    }

    public static Task<Void> saveGameMode(String id, Map<String, Object> mode) {
        String key = id == null || id.trim().isEmpty() ? gameModes().push().getKey() : id;
        return gameModes().child(key == null ? "mode" : key).setValue(mode);
    }

    public static Task<Void> deleteGameMode(String id) {
        return gameModes().child(id).removeValue();
    }

    public static Task<Void> saveBanner(String id, Map<String, Object> banner) {
        String key = id == null || id.trim().isEmpty() ? banners().push().getKey() : id;
        return banners().child(key == null ? "banner" : key).setValue(banner);
    }

    /** Sets (or, when blank, clears) the customer-support link opened when a user taps this banner. */
    public static Task<Void> saveBannerLink(String id, String link) {
        DatabaseReference ref = banners().child(id).child("linkUrl");
        return link == null || link.trim().isEmpty() ? ref.removeValue() : ref.setValue(link.trim());
    }

    public static Task<Void> deleteBanner(String id) {
        return banners().child(id).removeValue();
    }

    /**
     * Free registration only. No financial or payment data is part of this app. The Firebase rules still decide whether a user
     * may create this participant record.
     */
    public static Task<Void> registerForTournament(String tournamentId, String teamName, int teamSize) {
        return registerForTournament(tournamentId, 0, "", "", teamName, teamSize);
    }

    /**
     * Registers a player in a fixed slot and mirrors the record to the match-shaped
     * nodes used by the results admin and the notification worker.
     */
    public static Task<Void> registerForTournament(String tournamentId, int slotNumber,
                                                    String gameUid, String gameName,
                                                    String teamName, int teamSize) {
        String uid = FirebaseAuth.getInstance().getUid();
        if (uid == null) {
            return com.google.android.gms.tasks.Tasks.forException(
                    new IllegalStateException("Authentication required"));
        }
        if (slotNumber < 0 || slotNumber > 48) {
            return com.google.android.gms.tasks.Tasks.forException(
                    new IllegalArgumentException("Choose a slot from 1 to 48"));
        }
        Map<String, Object> participant = new HashMap<>();
        participant.put("userId", uid);
        participant.put("teamName", teamName == null ? "" : teamName.trim());
        participant.put("teamSize", teamSize);
        participant.put("slotNumber", slotNumber);
        participant.put("gameUid", gameUid == null ? "" : gameUid.trim());
        participant.put("gameName", gameName == null ? "" : gameName.trim());
        participant.put("status", "REGISTERED");
        participant.put("createdAt", ServerValue.TIMESTAMP);

        Task<Void> reserveSlot = slotNumber == 0
                ? com.google.android.gms.tasks.Tasks.<Void>forResult(null)
                : runTransactionTask(tournaments().child(tournamentId).child("slotIndex")
                .child(String.valueOf(slotNumber)), new com.google.firebase.database.Transaction.Handler() {
                    @Override
                    public com.google.firebase.database.Transaction.Result doTransaction(
                            com.google.firebase.database.MutableData currentData) {
                        if (currentData.getValue() != null && !uid.equals(currentData.getValue(String.class))) {
                            return com.google.firebase.database.Transaction.abort();
                        }
                        currentData.setValue(uid);
                        return com.google.firebase.database.Transaction.success(currentData);
                    }

                    @Override
                    public void onComplete(DatabaseError error, boolean committed,
                                           DataSnapshot currentData) {
                    }
                }).continueWithTask(task -> {
                    if (!task.isSuccessful()) {
                        return com.google.android.gms.tasks.Tasks.forException(
                                new IllegalStateException("Could not reserve that slot"));
                    }
                    return tournaments().child(tournamentId).child("slotIndex")
                            .child(String.valueOf(slotNumber)).get().continueWithTask(check -> {
                                String reservedBy = check.getResult() == null
                                        ? null : check.getResult().getValue(String.class);
                                if (uid.equals(reservedBy)) {
                                    return com.google.android.gms.tasks.Tasks.<Void>forResult(null);
                                }
                                return com.google.android.gms.tasks.Tasks.forException(
                                        new IllegalStateException("That slot is already taken"));
                            });
                });

        Task<Void> saved = reserveSlot.continueWithTask(ignored -> {
            Map<String, Object> updates = new HashMap<>();
            updates.put("tournaments/" + tournamentId + "/participants/" + uid, participant);
            updates.put("matches/" + tournamentId + "/joinedUsers/" + uid, participant);
            updates.put("matches/" + tournamentId + "/participants/" + uid, participant);
            if (!participant.get("gameName").toString().isEmpty()) {
                updates.put("users/" + uid + "/lastGameName", participant.get("gameName"));
            }
            return root().updateChildren(updates);
        });
        // A5/A6 follow-up — a newly registered player becomes a participant on every match already
        // scheduled under this tournament, so match-level room reads (see database.rules.json) work
        // for them immediately, without an admin having to re-add them per match.
        saved.addOnSuccessListener(v -> addUserToTournamentMatches(tournamentId, uid));
        return saved;
    }

    public static Task<Void> saveRoomRelease(String matchId, String roomId, String roomPassword,
                                             long releaseAt) {
        Map<String, Object> release = new HashMap<>();
        release.put("roomId", roomId == null ? "" : roomId.trim());
        release.put("roomPassword", roomPassword == null ? "" : roomPassword.trim());
        release.put("releaseAt", releaseAt);
        release.put("released", false);
        release.put("pushSent", false);
        release.put("createdAt", ServerValue.TIMESTAMP);

        Map<String, Object> updates = new HashMap<>();
        updates.put("matches/" + matchId + "/roomRelease", release);
        // Credentials stay in matches/{id}/roomRelease (admin-only) until the release moment.
        updates.put("tournaments/" + matchId + "/roomId", "");
        updates.put("tournaments/" + matchId + "/roomPassword", "");
        updates.put("tournaments/" + matchId + "/roomReleaseAt", releaseAt);
        updates.put("tournaments/" + matchId + "/roomReleased", false);
        return root().updateChildren(updates);
    }

    /**
     * Admin taps "Push" after typing Room ID + Password: the room goes live IMMEDIATELY (no schedule).
     * One atomic multi-path write so every reader flips together:
     *  - tournaments/{id}: what MatchJoinedActivity / TournamentDetailActivity listen to live;
     *  - matches/{id}: what MyMatchesActivity reads (only touched when that node already exists,
     *    so an older tournament never gets a half-built match record);
     *  - matches/{id}/roomRelease marked released + pushSent, so a leftover alarm from an old
     *    schedule becomes a no-op in RoomReleaseAlarmReceiver.
     */
    public static Task<Void> pushRoomNow(String matchId, String roomId, String roomPassword) {
        final String id = roomId == null ? "" : roomId.trim();
        final String pass = roomPassword == null ? "" : roomPassword.trim();
        return matches().child(matchId).get().continueWithTask(task -> {
            boolean matchExists = task.isSuccessful() && task.getResult() != null && task.getResult().exists();
            long now = System.currentTimeMillis();
            Map<String, Object> updates = new HashMap<>();
            updates.put("tournaments/" + matchId + "/roomId", id);
            updates.put("tournaments/" + matchId + "/roomPassword", pass);
            updates.put("tournaments/" + matchId + "/roomReleased", true);
            updates.put("tournaments/" + matchId + "/roomReleaseAt", now);
            Map<String, Object> release = new HashMap<>();
            release.put("roomId", id);
            release.put("roomPassword", pass);
            release.put("releaseAt", now);
            release.put("released", true);
            release.put("pushSent", true);
            release.put("createdAt", ServerValue.TIMESTAMP);
            updates.put("matches/" + matchId + "/roomRelease", release);
            if (matchExists) {
                updates.put("matches/" + matchId + "/roomId", id);
                updates.put("matches/" + matchId + "/roomPassword", pass);
                updates.put("matches/" + matchId + "/roomReleased", true);
                updates.put("matches/" + matchId + "/roomReleasedAt", ServerValue.TIMESTAMP);
                updates.put("matches/" + matchId + "/status", com.arenax.tournament.model.Match.ROOM_RELEASED);
                updates.put("matches/" + matchId + "/delayReason", "");
            }
            return root().updateChildren(updates);
        });
    }

    public static Task<Void> sendBroadcastNotification(String title, String description) {
        return sendBroadcastNotification(title, description, null);
    }

    public static Task<Void> sendBroadcastNotification(String title, String description,
                                                       com.arenax.tournament.util.NotificationRedirect.Target redirect) {
        String id = broadcastNotifications().push().getKey();
        if (id == null) {
            return com.google.android.gms.tasks.Tasks.forException(
                    new IllegalStateException("Could not create notification"));
        }
        Map<String, Object> record = new HashMap<>();
        record.put("title", title == null ? "" : title.trim());
        record.put("description", description == null ? "" : description.trim());
        record.put("sentAt", ServerValue.TIMESTAMP);
        record.put("sentBy", currentUser() == null ? "admin" : currentUser().getUid());
        record.put("pushSent", false);
        if (redirect != null && !redirect.isNone()) record.putAll(redirect.toFields());
        return broadcastNotifications().child(id).setValue(record);
    }

    /** Backward-compatible overload — no placement recorded. */
    public static Task<Void> saveKillCount(String matchId, String uid, int kills, int coinsPerKill) {
        return saveKillCount(matchId, uid, kills, -1, coinsPerKill);
    }

    /**
     * Admin enters the *verified* kill count (and optionally a placement/rank) for one joined
     * player. Coin amount is always derived here — the admin never types a final coin number by
     * hand, so it can never drift from kills × per-kill rate.
     */
    public static Task<Void> saveKillCount(String matchId, String uid, int kills, int placement, int coinsPerKill) {
        if (kills < 0 || kills > 999) {
            return com.google.android.gms.tasks.Tasks.forException(
                    new IllegalArgumentException("Kills must be between 0 and 999"));
        }
        Map<String, Object> update = new HashMap<>();
        update.put("kills", kills);
        update.put("placement", placement > 0 ? placement : null);
        update.put("coinRequest/status", "PENDING");
        update.put("coinRequest/kills", kills);
        update.put("coinRequest/coinsPerKill", Math.max(0, coinsPerKill));
        update.put("coinRequest/amount", kills * Math.max(0, coinsPerKill));
        Task<Void> saved = joinedUsers(matchId).child(uid).updateChildren(update);
        saved.addOnSuccessListener(v -> logActivity("KILLS_UPDATED", matchId,
                "uid=" + uid + ", kills=" + kills + (placement > 0 ? ", placement=" + placement : "")));
        return saved;
    }

    /**
     * Marks a match complete and creates one pending coin request per joined user. This is the
     * normal, first-time publish path — it refuses to run again once a result already exists for
     * this match (see the 2-arg overload below for corrections). Credits are never issued here;
     * Results & Coins Admin must approve each row separately.
     */
    public static Task<Void> completeMatchAndCreateCoinRequests(String matchId, int coinsPerKill) {
        return publishMatchResult(matchId, coinsPerKill, false, "");
    }

    /**
     * Explicit correction path: republishes kills/coins for a match that already has a result.
     * A request that was already APPROVED (coins already credited) is left untouched — corrections
     * only ever affect PENDING/never-generated requests, so nobody can be paid twice for the same
     * kill count. Always pass a human-readable reason; it's written to the audit log.
     */
    public static Task<Void> editPublishedMatchResult(String matchId, int coinsPerKill, String correctionReason) {
        if (correctionReason == null || correctionReason.trim().isEmpty()) {
            return com.google.android.gms.tasks.Tasks.forException(
                    new IllegalArgumentException("A reason is required to correct a published result"));
        }
        return publishMatchResult(matchId, coinsPerKill, true, correctionReason.trim());
    }

    private static Task<Void> publishMatchResult(String matchId, int coinsPerKill, boolean isCorrection, String correctionReason) {
        return tournaments().child(matchId).child("status").get().continueWithTask(statusTask -> {
            String currentStatus = statusTask.getResult() == null ? null
                    : statusTask.getResult().getValue(String.class);
            boolean alreadyPublished = "COMPLETED".equals(currentStatus)
                    || "RESULT_PUBLISHED".equals(currentStatus) || "RESULTED".equals(currentStatus);
            if (alreadyPublished && !isCorrection) {
                // Result lock — running "Complete match" twice must never create a second round
                // of coin requests. Once published, only the explicit "Edit Result" path (with a
                // reason) may touch it again.
                return com.google.android.gms.tasks.Tasks.forException(new IllegalStateException(
                        "This match's result is already published. Use \"Edit Result\" to correct it."));
            }
            return joinedUsers(matchId).get().continueWithTask(joinedTask -> {
                if (!joinedTask.isSuccessful() || joinedTask.getResult() == null) {
                    return com.google.android.gms.tasks.Tasks.forException(
                            new IllegalStateException("Could not load joined users"));
                }
                DataSnapshot joined = joinedTask.getResult();
                return coinRequests().get().continueWithTask(existingTask -> {
                    DataSnapshot existingRequests = existingTask.getResult();
                    Map<String, Object> updates = new HashMap<>();
                    updates.put("matches/" + matchId + "/status", "COMPLETED");
                    // A category-match "matchId" is the tournament's own id (see registerForTournament,
                    // which writes joinedUsers under matches/{tournamentId}). Flip the Tournament's own
                    // status too so CategoryMatchesActivity's "Resulted" tab and the "VIEW RESULT" button
                    // pick this up immediately — without this the /matches status flip was invisible to
                    // players, who only ever read from /tournaments.
                    updates.put("tournaments/" + matchId + "/status", "COMPLETED");
                    updates.put("tournaments/" + matchId + "/resultPublishedAt", ServerValue.TIMESTAMP);
                    int totalPlayers = 0, totalKills = 0, totalCoins = 0;
                    int skippedAlreadyPaid = 0;
                    for (DataSnapshot child : joined.getChildren()) {
                        String uid = child.getKey();
                        if (uid == null) continue;
                        totalPlayers++;
                        int kills = child.child("kills").getValue(Integer.class) == null
                                ? 0 : child.child("kills").getValue(Integer.class);
                        int amount = kills * Math.max(0, coinsPerKill);
                        totalKills += kills;
                        String requestId = matchId + "_" + uid;
                        String existingStatus = existingRequests == null ? null
                                : existingRequests.child(requestId).child("status").getValue(String.class);
                        if ("APPROVED".equals(existingStatus)) {
                            // Coins for this player were already credited — never regenerate or
                            // overwrite a paid request, even on a correction.
                            skippedAlreadyPaid++;
                            continue;
                        }
                        totalCoins += amount;
                        Map<String, Object> request = new HashMap<>();
                        request.put("matchId", matchId);
                        request.put("uid", uid);
                        request.put("slotNumber", child.child("slotNumber").getValue(Integer.class));
                        request.put("gameUid", child.child("gameUid").getValue(String.class));
                        request.put("gameName", child.child("gameName").getValue(String.class));
                        request.put("kills", kills);
                        request.put("placement", child.child("placement").getValue(Integer.class));
                        request.put("coinsPerKill", Math.max(0, coinsPerKill));
                        request.put("amount", amount);
                        request.put("status", "PENDING");
                        request.put("createdAt", ServerValue.TIMESTAMP);
                        updates.put("coin_requests/" + requestId, request);
                        updates.put("matches/" + matchId + "/joinedUsers/" + uid + "/coinRequest", request);
                    }
                    Task<Void> write = root().updateChildren(updates);
                    int finalTotalPlayers = totalPlayers, finalTotalKills = totalKills,
                            finalTotalCoins = totalCoins, finalSkipped = skippedAlreadyPaid;
                    write.addOnSuccessListener(v -> logActivity(
                            isCorrection ? "RESULT_CORRECTED" : "RESULT_PUBLISHED", matchId,
                            "Players " + finalTotalPlayers + ", Total kills " + finalTotalKills
                                    + ", Total coins " + finalTotalCoins
                                    + (finalSkipped > 0 ? ", " + finalSkipped + " already-paid rows kept unchanged" : "")
                                    + (isCorrection ? ", Reason: " + correctionReason : "")));
                    return write;
                });
            });
        });
    }


    /** Admin: PENDING -> REJECTED. Idempotent — rejecting an already-resolved request fails cleanly. */
    public static Task<Void> rejectCoinRequest(String requestId, String reason) {
        return runTransactionTask(coinRequests().child(requestId).child("status"),
                new com.google.firebase.database.Transaction.Handler() {
                    @Override
                    public com.google.firebase.database.Transaction.Result doTransaction(
                            com.google.firebase.database.MutableData currentData) {
                        String status = currentData.getValue(String.class);
                        if (!"PENDING".equals(status)) {
                            return com.google.firebase.database.Transaction.abort();
                        }
                        currentData.setValue("REJECTED");
                        return com.google.firebase.database.Transaction.success(currentData);
                    }
                    @Override
                    public void onComplete(DatabaseError error, boolean committed, DataSnapshot currentData) { }
                }).continueWithTask(task -> {
                    if (!task.isSuccessful()) {
                        return com.google.android.gms.tasks.Tasks.forException(
                                new IllegalStateException("This request is already being processed"));
                    }
                    Map<String, Object> updates = new HashMap<>();
                    updates.put("coin_requests/" + requestId + "/rejectedAt", ServerValue.TIMESTAMP);
                    updates.put("coin_requests/" + requestId + "/rejectReason", reason == null ? "" : reason.trim());
                    Task<Void> write = root().updateChildren(updates);
                    write.addOnSuccessListener(v -> logActivity("COIN_REQUEST_REJECTED", requestId, reason));
                    return write;
                });
    }

    public static Task<Void> approveCoinRequest(String requestId, String uid, int amount,
                                                String matchId, int kills, String matchTitle) {
        return runTransactionTask(coinRequests().child(requestId).child("status"),
                new com.google.firebase.database.Transaction.Handler() {
                    @Override
                    public com.google.firebase.database.Transaction.Result doTransaction(
                            com.google.firebase.database.MutableData currentData) {
                        String status = currentData.getValue(String.class);
                        if ("APPROVED".equals(status) || "APPROVING".equals(status)) {
                            return com.google.firebase.database.Transaction.abort();
                        }
                        if (!"PENDING".equals(status)) {
                            return com.google.firebase.database.Transaction.abort();
                        }
                        currentData.setValue("APPROVING");
                        return com.google.firebase.database.Transaction.success(currentData);
                    }

                    @Override
                    public void onComplete(DatabaseError error, boolean committed,
                                           DataSnapshot currentData) {
                    }
                }).continueWithTask(task -> {
                    if (!task.isSuccessful()) {
                        return com.google.android.gms.tasks.Tasks.forException(
                                new IllegalStateException("This request is already being processed"));
                    }
                    return coinRequests().child(requestId).child("status").get()
                            .continueWithTask(statusTask -> {
                                String status = statusTask.getResult() == null ? null
                                        : statusTask.getResult().getValue(String.class);
                                if (!"APPROVING".equals(status)) {
                                    return com.google.android.gms.tasks.Tasks.forException(
                                            new IllegalStateException("This request is already being processed"));
                                }
                                return runTransactionTask(users().child(uid).child("wallet"),
                            new com.google.firebase.database.Transaction.Handler() {
                                @Override
                                public com.google.firebase.database.Transaction.Result doTransaction(
                                        com.google.firebase.database.MutableData currentData) {
                                    Map<String, Object> wallet = new HashMap<>();
                                    Object raw = currentData.getValue();
                                    if (raw instanceof Map) wallet.putAll((Map<String, Object>) raw);
                                    Object rawBalance = wallet.get("balance");
                                    long current = rawBalance instanceof Number ? ((Number) rawBalance).longValue() : 0L;
                                    wallet.put("balance", current + Math.max(0, amount));
                                    currentData.setValue(wallet);
                                    return com.google.firebase.database.Transaction.success(currentData);
                                }

                                @Override
                                public void onComplete(DatabaseError error, boolean committed,
                                                       DataSnapshot currentData) {
                                }
                            }).continueWithTask(creditTask -> {
                                if (!creditTask.isSuccessful()) {
                                    return com.google.android.gms.tasks.Tasks.forException(
                                            new IllegalStateException("Could not credit coins"));
                                }
                                Map<String, Object> history = new HashMap<>();
                                history.put("uid", uid);
                                history.put("matchId", matchId);
                                history.put("kills", kills);
                                history.put("amount", Math.max(0, amount));
                                history.put("title", "+" + Math.max(0, amount) + " Coins");
                                history.put("description", matchTitle + " — " + kills + " Kills — Approved");
                                history.put("status", "APPROVED");
                                history.put("approvedAt", ServerValue.TIMESTAMP);
                                String historyId = coinHistory().child(uid).push().getKey();
                                Map<String, Object> updates = new HashMap<>();
                                updates.put("coin_requests/" + requestId + "/status", "APPROVED");
                                updates.put("coin_requests/" + requestId + "/approvedAt", ServerValue.TIMESTAMP);
                                updates.put("coin_requests/" + requestId + "/pushSent", false);
                                updates.put("coin_history/" + uid + "/"
                                        + (historyId == null ? requestId : historyId), history);
                                updates.put("users/" + uid + "/wallet/transactions/" + requestId,
                                        walletTransaction("MATCH_REWARD", matchId, amount,
                                                "+" + Math.max(0, amount) + " coins • " + kills + " kills"));
                                // Root /notifications (not users/{uid}/notifications — the bell never reads that path).
                                updates.put("notifications/" + requestId,
                                        notification(uid, "Coins approved", "Your " + amount + " coins were approved."));
                                Task<Void> write = root().updateChildren(updates);
                                write.addOnSuccessListener(v -> logActivity("COIN_REQUEST_APPROVED", requestId,
                                        "uid=" + uid + ", matchId=" + matchId + ", kills=" + kills + ", coins=" + amount));
                                return write;
                            });
                            });
                });
    }

    private static Map<String, Object> notification(String uid, String title, String body) {
        Map<String, Object> notification = new HashMap<>();
        notification.put("userId", uid);
        notification.put("title", title);
        notification.put("message", body);
        notification.put("type", "COINS_APPROVED");
        notification.put("createdAt", ServerValue.TIMESTAMP);
        notification.put("read", false);
        return notification;
    }

    private static Map<String, Object> walletTransaction(String type, String matchId,
                                                         int amount, String description) {
        Map<String, Object> transaction = new HashMap<>();
        transaction.put("type", "MATCH_REWARD".equals(type) ? "WINNING_REWARD" : type);
        transaction.put("matchId", matchId);
        transaction.put("amount", Math.max(0, amount));
        transaction.put("title", description);
        transaction.put("description", description);
        transaction.put("timestamp", ServerValue.TIMESTAMP);
        transaction.put("status", "SUCCESS");
        return transaction;
    }

    /**
     * A5/A6 follow-up — propagates one participant into the `participants` sub-node of every match
     * under a tournament. Called (a) right after a user registers, and (b) right after an admin
     * creates a new match under a tournament that already has registered participants, so the two
     * entry points stay in sync regardless of order.
     */
    private static void addUserToTournamentMatches(String tournamentId, String uid) {
        matches().orderByChild("tournamentId").equalTo(tournamentId)
                .addListenerForSingleValueEvent(new com.google.firebase.database.ValueEventListener() {
                    @Override public void onDataChange(@NonNull com.google.firebase.database.DataSnapshot snapshot) {
                        for (com.google.firebase.database.DataSnapshot match : snapshot.getChildren()) {
                            matches().child(match.getKey()).child("participants").child(uid).setValue(true);
                        }
                    }
                    @Override public void onCancelled(@NonNull com.google.firebase.database.DatabaseError error) { }
                });
    }

    /** Mirror of {@link #addUserToTournamentMatches}, run once for every already-registered participant. */
    private static void seedMatchParticipantsFromTournament(String tournamentId, String matchId) {
        tournamentParticipants(tournamentId).addListenerForSingleValueEvent(new com.google.firebase.database.ValueEventListener() {
            @Override public void onDataChange(@NonNull com.google.firebase.database.DataSnapshot snapshot) {
                for (com.google.firebase.database.DataSnapshot participant : snapshot.getChildren()) {
                    matches().child(matchId).child("participants").child(participant.getKey()).setValue(true);
                }
            }
            @Override public void onCancelled(@NonNull com.google.firebase.database.DatabaseError error) { }
        });
    }

    // ---------------------------------------------------------------------
    // A8 / B32 — Registration Waitlist. Free entry only; no payment involved.
    // Activates automatically once a tournament's slots are full.
    // ---------------------------------------------------------------------
    public static DatabaseReference tournamentWaitlist(String tournamentId) {
        return tournaments().child(tournamentId).child("waitlist");
    }

    /** Places the signed-in user on the waitlist. Safe to call only after the caller has
     *  confirmed the tournament is full; duplicate entries are prevented by keying on uid. */
    public static Task<Void> joinWaitlist(String tournamentId) {
        String uid = FirebaseAuth.getInstance().getUid();
        if (uid == null) {
            return com.google.android.gms.tasks.Tasks.forException(
                    new IllegalStateException("Authentication required"));
        }
        Map<String, Object> entry = new HashMap<>();
        entry.put("userId", uid);
        entry.put("status", "WAITLISTED");
        entry.put("createdAt", ServerValue.TIMESTAMP);
        return tournamentWaitlist(tournamentId).child(uid).setValue(entry);
    }

    /** Admin action — moves the longest-waiting entry into `participants` and removes it from the
     *  waitlist, so the slot counter and the promoted user's status update automatically. */
    public static Task<Void> promoteNextFromWaitlist(String tournamentId) {
        com.google.android.gms.tasks.TaskCompletionSource<Void> result =
                new com.google.android.gms.tasks.TaskCompletionSource<>();
        // FIX (0-coin entry): promotion writes a REGISTERED participant with NO payment and NO slot.
        // On a paid match that is a free entry, so it is refused. Paid players must join normally
        // (coins are debited by the backend) when a slot opens.
        tournaments().child(tournamentId).child("entryFeeCoins").get().addOnCompleteListener(feeTask -> {
            Long fee = feeTask.isSuccessful() && feeTask.getResult() != null
                    ? feeTask.getResult().getValue(Long.class) : null;
            if (fee != null && fee > 0) {
                result.setException(new IllegalStateException(
                        "Paid match: waitlist promotion is blocked (it would give a free entry). Player must join normally."));
                return;
            }
            promoteNextFromWaitlistFree(tournamentId, result);
        });
        return result.getTask();
    }

    private static void promoteNextFromWaitlistFree(String tournamentId,
            com.google.android.gms.tasks.TaskCompletionSource<Void> result) {
        tournamentWaitlist(tournamentId).orderByChild("createdAt").limitToFirst(1)
                .addListenerForSingleValueEvent(new com.google.firebase.database.ValueEventListener() {
                    @Override public void onDataChange(@NonNull com.google.firebase.database.DataSnapshot snapshot) {
                        if (!snapshot.exists()) {
                            result.setException(new IllegalStateException("Waitlist is empty."));
                            return;
                        }
                        com.google.firebase.database.DataSnapshot first = snapshot.getChildren().iterator().next();
                        String uid = first.getKey();
                        Map<String, Object> participant = new HashMap<>();
                        participant.put("userId", uid);
                        participant.put("teamName", "");
                        participant.put("teamSize", 1);
                        participant.put("status", "REGISTERED");
                        participant.put("createdAt", ServerValue.TIMESTAMP);
                        tournamentParticipants(tournamentId).child(uid).setValue(participant)
                                .addOnSuccessListener(v -> tournamentWaitlist(tournamentId).child(uid).removeValue()
                                        .addOnSuccessListener(v2 -> {
                                            addUserToTournamentMatches(tournamentId, uid);
                                            result.setResult(null);
                                        })
                                        .addOnFailureListener(result::setException))
                                .addOnFailureListener(result::setException);
                    }
                    @Override public void onCancelled(@NonNull com.google.firebase.database.DatabaseError error) {
                        result.setException(error.toException());
                    }
                });
    }

    public static Task<Void> publishNotification(String title, String message) {
        return publishNotification(title, message, null);
    }

    /**
     * Same as above, but the notification also carries a redirect (see NotificationRedirect):
     * tapping the push or the inbox row opens that exact screen / match / category.
     */
    public static Task<Void> publishNotification(String title, String message,
                                                 com.arenax.tournament.util.NotificationRedirect.Target redirect) {
        String id = notifications().push().getKey();
        Map<String, Object> notification = new HashMap<>();
        notification.put("title", title);
        notification.put("message", message);
        notification.put("createdAt", System.currentTimeMillis());
        notification.put("type", "GLOBAL");
        String key = id == null ? "notice" : id;
        // Keep the in-app history and enqueue the same message for the
        // backend FCM worker. Previously this method only wrote /notifications
        // while the worker consumed /broadcast_notifications, so the admin
        // success toast did not result in a device push.
        Map<String, Object> broadcast = new HashMap<>();
        broadcast.put("title", title);
        broadcast.put("description", message);
        broadcast.put("createdAt", ServerValue.TIMESTAMP);
        broadcast.put("type", "GLOBAL");
        broadcast.put("pushSent", false);
        if (redirect != null && !redirect.isNone()) {
            notification.putAll(redirect.toFields());
            broadcast.putAll(redirect.toFields());
        }
        Map<String, Object> updates = new HashMap<>();
        updates.put("notifications/" + key, notification);
        updates.put("broadcast_notifications/" + key, broadcast);
        return root().updateChildren(updates);
    }

    // ---------------------------------------------------------------------
    // A17 — Announcement System with targeting, pin and expiry
    // ---------------------------------------------------------------------
    public static DatabaseReference announcements() {
        return root().child("announcements");
    }

    /**
     * targetType: ALL | TOURNAMENT | TEAM. targetId is required for TOURNAMENT/TEAM and ignored for ALL.
     * Always recorded in /announcements for the User App's announcement feed. Broadcast (ALL) announcements
     * also drop a /notifications record so the existing global Notification Center keeps working unchanged;
     * targeted ones are the foundation for future per-tournament/per-team push delivery.
     */
    public static Task<Void> publishAnnouncement(String title, String message, String targetType,
                                                  String targetId, boolean pinned, long expiresAt) {
        return publishAnnouncement(title, message, targetType, targetId, pinned, 0L, expiresAt);
    }

    /**
     * scheduledAt and expiresAt are epoch milliseconds. A zero value means "immediately" or
     * "never expires". The client filters inactive announcements after refresh, while the
     * existing notification fan-out is sent only for announcements that are active now.
     */
    public static Task<Void> publishAnnouncement(String title, String message, String targetType,
                                                  String targetId, boolean pinned, long scheduledAt,
                                                  long expiresAt) {
        return publishAnnouncement(title, message, targetType, targetId, pinned, scheduledAt, expiresAt, null);
    }

    public static Task<Void> publishAnnouncement(String title, String message, String targetType,
                                                  String targetId, boolean pinned, long scheduledAt,
                                                  long expiresAt,
                                                  com.arenax.tournament.util.NotificationRedirect.Target redirect) {
        String id = announcements().push().getKey();
        Map<String, Object> announcement = new HashMap<>();
        announcement.put("title", title);
        announcement.put("message", message);
        announcement.put("targetType", targetType);
        announcement.put("targetId", targetId == null ? "" : targetId);
        announcement.put("pinned", pinned);
        announcement.put("scheduledAt", scheduledAt);
        announcement.put("expiresAt", expiresAt);
        announcement.put("createdAt", ServerValue.TIMESTAMP);
        if (redirect != null && !redirect.isNone()) announcement.putAll(redirect.toFields());
        Task<Void> saved = announcements().child(id == null ? "announcement" : id).setValue(announcement);
        if ("ALL".equals(targetType) && (scheduledAt <= 0L || scheduledAt <= System.currentTimeMillis())) {
            publishNotification(title, message, redirect);
        }
        return saved;
    }

    public static Task<Void> deleteAnnouncement(String id) {
        return announcements().child(id).removeValue();
    }

    public static void signOut() {
        FirebaseAuth.getInstance().signOut();
    }

    // ---------------------------------------------------------------------
    // A9/B39 — Team Management
    // ---------------------------------------------------------------------
    public static DatabaseReference teams() {
        return root().child("teams");
    }

    /** Creates a team led by the current user. Matches database.rules.json: only the captain (or admin) can write it. */
    public static Task<Void> createTeam(String name, String displayName) {
        String uid = FirebaseAuth.getInstance().getUid();
        if (uid == null) {
            return com.google.android.gms.tasks.Tasks.forException(
                    new IllegalStateException("Authentication required"));
        }
        String id = teams().push().getKey();
        if (id == null) {
            return com.google.android.gms.tasks.Tasks.forException(new IllegalStateException("Could not create team id"));
        }
        Map<String, Object> team = new HashMap<>();
        team.put("name", name);
        team.put("logoUrl", "");
        team.put("captainId", uid);
        team.put("status", "ACTIVE");
        team.put("createdAt", System.currentTimeMillis());
        Map<String, Object> members = new HashMap<>();
        members.put(uid, displayName == null ? "Captain" : displayName);
        team.put("members", members);
        return teams().child(id).setValue(team);
    }

    /** Joins an existing team by its Team ID. Team object is fully owned by the captain, so this updates only the members child. */
    public static Task<Void> joinTeam(String teamId, String displayName) {
        String uid = FirebaseAuth.getInstance().getUid();
        if (uid == null) {
            return com.google.android.gms.tasks.Tasks.forException(
                    new IllegalStateException("Authentication required"));
        }
        return teams().child(teamId).child("members").child(uid)
                .setValue(displayName == null ? "Player" : displayName);
    }

    public static Task<Void> leaveTeam(String teamId) {
        String uid = FirebaseAuth.getInstance().getUid();
        if (uid == null) {
            return com.google.android.gms.tasks.Tasks.forException(
                    new IllegalStateException("Authentication required"));
        }
        return teams().child(teamId).child("members").child(uid).removeValue();
    }

    /** Admin-only: verify, disband or otherwise change a team's status (server rules enforce the admin claim). */
    public static Task<Void> setTeamStatus(String teamId, String status) {
        return teams().child(teamId).child("status").setValue(status);
    }

    public static Task<Void> disbandTeam(String teamId) {
        return teams().child(teamId).removeValue();
    }

    // ---------------------------------------------------------------------
    // A12/B36 — Match Results + A11/B37 Leaderboard
    // ---------------------------------------------------------------------
    /**
     * Admin enters kills + placement for a player in a tournament. Points are auto-calculated
     * from a simple configurable placement+kill table, written to /results and rolled into the
     * /leaderboard/allTime, /leaderboard/weekly/{weekKey} and /leaderboard/monthly/{monthKey}
     * nodes so LeaderboardFragment's Weekly / Monthly / All Time tabs all show live totals
     * without further wiring. Weekly and monthly buckets are keyed by the current ISO-ish
     * week/month string, so a new period simply starts as an empty node — no reset job needed.
     */
    public static Task<Void> publishResult(String tournamentId, String uid, String username,
                                            int kills, int placement) {
        if (kills < 0) {
            return com.google.android.gms.tasks.Tasks.forException(
                    new IllegalArgumentException("Kills cannot be negative."));
        }
        if (placement <= 0) {
            return com.google.android.gms.tasks.Tasks.forException(
                    new IllegalArgumentException("Placement must be greater than zero."));
        }
        int placementPoints = placementPoints(placement);
        int totalPoints = placementPoints + (kills * 1);
        String resultId = results().push().getKey();
        Map<String, Object> result = new HashMap<>();
        result.put("tournamentId", tournamentId);
        result.put("userId", uid);
        result.put("username", username);
        result.put("kills", kills);
        result.put("placement", placement);
        result.put("points", totalPoints);
        result.put("publishedAt", ServerValue.TIMESTAMP);
        if (resultId != null) results().child(resultId).setValue(result);

        return users().child(uid).child("photoUrl").get().continueWithTask(photoTask -> {
            String photoUrl = null;
            if (photoTask.isSuccessful() && photoTask.getResult() != null) {
                Object p = photoTask.getResult().getValue();
                if (p instanceof String && !((String) p).trim().isEmpty()) photoUrl = (String) p;
            }
            final String finalPhotoUrl = photoUrl;
            // This call always creates a brand-new /results row (see push() above), so it is
            // always a fresh match contribution — pass isNewMatch=true so the leaderboard adds
            // the full kills/points rather than a delta.
            Task<Void> allTime = rollUpLeaderboardRow(
                    leaderboard().child("allTime").child(uid), username, finalPhotoUrl, kills, totalPoints, true);
            Task<Void> weekly = rollUpLeaderboardRow(
                    leaderboard().child("weekly").child(currentWeekKey()).child(uid), username, finalPhotoUrl, kills, totalPoints, true);
            Task<Void> monthly = rollUpLeaderboardRow(
                    leaderboard().child("monthly").child(currentMonthKey()).child(uid), username, finalPhotoUrl, kills, totalPoints, true);
            return com.google.android.gms.tasks.Tasks.whenAll(allTime, weekly, monthly);
        });
    }

    /** One player's placement + kills for a single Rank Manage / Match Result save. */
    public static final class ResultEntry {
        public final String uid;
        public final String username;
        public final int kills;
        public final int placement;
        /** Coins to award. -1 = automatic (kills x per-kill); >= 0 = exact amount typed by the admin. */
        public final int coins;
        public ResultEntry(String uid, String username, int kills, int placement) {
            this(uid, username, kills, placement, -1);
        }
        public ResultEntry(String uid, String username, int kills, int placement, int coins) {
            this.uid = uid;
            this.username = username == null ? "Player" : username;
            this.kills = kills;
            this.placement = placement;
            this.coins = coins;
        }
    }

    /** Placement points for a live UI preview (e.g. the Rank Manage "Total" column), matching
     *  exactly what publishResult()/publishMatchResults() will award server-side. */
    public static int calculatePlacementPoints(int placement) {
        return placementPoints(placement);
    }

    /**
     * Batch publish/edit entry point for the admin "Rank Manage" screen: pass every joined
     * player's placement + kills for a tournament in one call. Unlike publishResult() above
     * (kept for the older single-row dialog, always additive across separate matches), this is
     * safe to press again and again for the SAME tournament — each player's /results row is
     * reused by a stable per-tournament key instead of duplicated, and only the point/kill
     * DELTA versus their previous entry is rolled into /leaderboard, so correcting a placement
     * or kill count later never double-counts that player's score.
     */
    public static Task<Void> publishMatchResults(String tournamentId, List<ResultEntry> rows) {
        if (tournamentId == null || tournamentId.trim().isEmpty()) {
            return com.google.android.gms.tasks.Tasks.forException(
                    new IllegalArgumentException("Missing tournament id."));
        }
        if (rows == null || rows.isEmpty()) {
            return com.google.android.gms.tasks.Tasks.forException(
                    new IllegalArgumentException("Enter at least one player's result."));
        }
        // Weekly/monthly buckets belong to the week/month the MATCH was played in, not the day an
        // admin later edits it — otherwise a correction next month would move points to the wrong bucket.
        return tournaments().child(tournamentId).child("startAt").get().continueWithTask(startTask ->
                tournaments().child(tournamentId).child("perKillCoins").get().continueWithTask(killTask -> {
            Object sv = startTask.isSuccessful() && startTask.getResult() != null ? startTask.getResult().getValue() : null;
            final long matchTime = sv instanceof Number ? ((Number) sv).longValue() : 0L;
            Object pk = killTask.isSuccessful() && killTask.getResult() != null ? killTask.getResult().getValue() : null;
            // 1 kill = perKillCoins coins  (kills x per-kill price = coins won by that player)
            final int perKill = pk instanceof Number ? Math.max(0, ((Number) pk).intValue()) : 0;
            final Map<String, Object> publicRows = new HashMap<>();
            final String weekKey = weekKeyAt(matchTime), monthKey = monthKeyAt(matchTime);
            return results().get().continueWithTask(existingTask -> {
            Map<String, String> resultKeyByUid = new HashMap<>();
            Map<String, Integer> oldKillsByUid = new HashMap<>();
            Map<String, Integer> oldPointsByUid = new HashMap<>();
            if (existingTask.isSuccessful() && existingTask.getResult() != null) {
                for (DataSnapshot row : existingTask.getResult().getChildren()) {
                    if (!tournamentId.equals(String.valueOf(row.child("tournamentId").getValue()))) continue;
                    Object uidVal = row.child("userId").getValue();
                    if (uidVal == null) continue;
                    String rowUid = String.valueOf(uidVal);
                    resultKeyByUid.put(rowUid, row.getKey());
                    Object k = row.child("kills").getValue();
                    Object p = row.child("points").getValue();
                    oldKillsByUid.put(rowUid, k instanceof Number ? ((Number) k).intValue() : 0);
                    oldPointsByUid.put(rowUid, p instanceof Number ? ((Number) p).intValue() : 0);
                }
            }
            List<Task<?>> tasks = new ArrayList<>();
            for (ResultEntry entry : rows) {
                if (entry == null || entry.uid == null || entry.placement <= 0 || entry.kills < 0) continue;
                int totalPoints = placementPoints(entry.placement) + entry.kills;
                // Admin may have typed the coins by hand; otherwise kills x per-kill.
                final int coinsAward = entry.coins >= 0 ? entry.coins : entry.kills * perKill;
                String existingKey = resultKeyByUid.get(entry.uid);
                boolean isNew = existingKey == null;
                String resultId = isNew ? results().push().getKey() : existingKey;
                if (resultId == null) continue;

                Map<String, Object> result = new HashMap<>();
                result.put("tournamentId", tournamentId);
                result.put("userId", entry.uid);
                result.put("username", entry.username);
                result.put("kills", entry.kills);
                result.put("placement", entry.placement);
                result.put("points", totalPoints);
                result.put("perKill", perKill);
                result.put("coins", coinsAward);
                result.put("publishedAt", ServerValue.TIMESTAMP);
                tasks.add(results().child(resultId).setValue(result));

                // Public copy players read (tournaments/{id}/results is readable by every signed-in user).
                Map<String, Object> pub = new HashMap<>();
                pub.put("username", entry.username);
                pub.put("kills", entry.kills);
                pub.put("placement", entry.placement);
                pub.put("points", totalPoints);
                pub.put("coins", coinsAward);
                publicRows.put(entry.uid, pub);

                int killsDelta = entry.kills - (isNew ? 0 : oldKillsByUid.get(entry.uid));
                int pointsDelta = totalPoints - (isNew ? 0 : oldPointsByUid.get(entry.uid));
                final boolean isNewMatch = isNew;
                tasks.add(users().child(entry.uid).child("photoUrl").get().continueWithTask(photoTask -> {
                    String photoUrl = null;
                    if (photoTask.isSuccessful() && photoTask.getResult() != null) {
                        Object p = photoTask.getResult().getValue();
                        if (p instanceof String && !((String) p).trim().isEmpty()) photoUrl = (String) p;
                    }
                    final String finalPhotoUrl = photoUrl;
                    Task<Void> allTime = rollUpLeaderboardRow(leaderboard().child("allTime").child(entry.uid),
                            entry.username, finalPhotoUrl, killsDelta, pointsDelta, isNewMatch);
                    Task<Void> weekly = rollUpLeaderboardRow(leaderboard().child("weekly").child(weekKey).child(entry.uid),
                            entry.username, finalPhotoUrl, killsDelta, pointsDelta, isNewMatch);
                    Task<Void> monthly = rollUpLeaderboardRow(leaderboard().child("monthly").child(monthKey).child(entry.uid),
                            entry.username, finalPhotoUrl, killsDelta, pointsDelta, isNewMatch);
                    return com.google.android.gms.tasks.Tasks.whenAll(allTime, weekly, monthly);
                }));
            }
            if (tasks.isEmpty()) {
                return com.google.android.gms.tasks.Tasks.forException(
                        new IllegalArgumentException("No valid rows to publish — check kills."));
            }
            tasks.add(tournaments().child(tournamentId).child("results").setValue(publicRows));
            return com.google.android.gms.tasks.Tasks.whenAll(tasks);
            });
        }));
    }

    // ---------------------------------------------------------------------
    // Rank & Leaderboard — draft / publish / edit-log helpers (admin control center)
    // ---------------------------------------------------------------------

    /** Admin-only working copy of the leaderboard. Nothing here is public until published. */
    public static Task<Void> saveRankDraft(String tournamentId, List<ResultEntry> rows) {
        Map<String, Object> draft = new HashMap<>();
        for (ResultEntry e : rows) {
            if (e == null || e.uid == null) continue;
            Map<String, Object> row = new HashMap<>();
            row.put("username", e.username);
            row.put("placement", e.placement);
            row.put("kills", e.kills);
            row.put("points", placementPoints(e.placement) + e.kills);
            if (e.coins >= 0) row.put("coins", e.coins);
            draft.put(e.uid, row);
        }
        // Admin-only node (tournaments/* is readable by every player, so a draft must not live there).
        Map<String, Object> update = new HashMap<>();
        update.put("rows", draft);
        update.put("savedAt", ServerValue.TIMESTAMP);
        return rankDrafts().child(tournamentId).setValue(update);
    }

    /** TEAM matches: stamps each player's public result row with their team name (shown on the player leaderboard). */
    public static Task<Void> publishTeamLabels(String tournamentId, Map<String, String> teamByUid) {
        if (teamByUid == null || teamByUid.isEmpty()) return com.google.android.gms.tasks.Tasks.forResult(null);
        Map<String, Object> update = new HashMap<>();
        for (Map.Entry<String, String> e : teamByUid.entrySet()) update.put(e.getKey() + "/teamName", e.getValue());
        return tournaments().child(tournamentId).child("results").updateChildren(update);
    }

    /** Flips the match to RESULT_PUBLISHED so it moves to players' Resulted tab (VIEW RESULT). */
    public static Task<Void> markResultPublished(String tournamentId) {
        Map<String, Object> update = new HashMap<>();
        update.put("status", "RESULT_PUBLISHED");
        update.put("resultPublishedAt", ServerValue.TIMESTAMP);
        return tournaments().child(tournamentId).updateChildren(update);
    }

    public static DatabaseReference rankDrafts() {
        return root().child("rank_drafts");
    }

    public static DatabaseReference editLogs(String tournamentId) {
        return tournaments().child(tournamentId).child("editLogs");
    }

    /** One row per leaderboard save/publish/edit — shown in the Rank & Leaderboard "Edit Logs" view. */
    public static void addEditLog(String tournamentId, String action, String details) {
        String id = editLogs(tournamentId).push().getKey();
        if (id == null) return;
        com.google.firebase.auth.FirebaseUser admin = currentUser();
        Map<String, Object> log = new HashMap<>();
        log.put("admin", admin == null ? "unknown" : (admin.getEmail() == null ? admin.getUid() : admin.getEmail()));
        log.put("action", action);
        log.put("details", details == null ? "" : details);
        log.put("timestamp", ServerValue.TIMESTAMP);
        editLogs(tournamentId).child(id).setValue(log);
    }

    /** Adds one match's kills/points delta onto an existing leaderboard row (creating it if
     *  absent). isNewMatch controls whether the "matches played" counter increments — pass
     *  false when this call is only correcting an already-counted match's numbers. */
    private static Task<Void> rollUpLeaderboardRow(DatabaseReference row, String username, String photoUrl,
                                                     int killsDelta, int pointsDelta, boolean isNewMatch) {
        return row.get().continueWithTask(task -> {
            long matches = 0, prevKills = 0, prevScore = 0;
            if (task.isSuccessful() && task.getResult() != null && task.getResult().exists()) {
                Object m = task.getResult().child("matches").getValue();
                Object k = task.getResult().child("kills").getValue();
                Object s = task.getResult().child("score").getValue();
                if (m instanceof Number) matches = ((Number) m).longValue();
                if (k instanceof Number) prevKills = ((Number) k).longValue();
                if (s instanceof Number) prevScore = ((Number) s).longValue();
            }
            long newKills = Math.max(0, prevKills + killsDelta);
            long newScore = Math.max(0, prevScore + pointsDelta);
            Map<String, Object> update = new HashMap<>();
            update.put("username", username);
            update.put("matches", matches + (isNewMatch ? 1 : 0));
            update.put("kills", newKills);
            update.put("score", newScore);
            update.put("winning", newScore + " PTS");
            update.put("updatedAt", ServerValue.TIMESTAMP);
            if (photoUrl != null) update.put("photoUrl", photoUrl);
            return row.updateChildren(update);
        });
    }

    /** Per-match leaderboard, sorted by admin-set coins — this is what Rank Manage and the
     *  player's Completed → View Result screen both read. */
    public static DatabaseReference matchLeaderboard(String matchId) {
        return matches().child(matchId).child("leaderboard");
    }

    /**
     * Admin "Rank Manage" direct-coin flow (pencil icon on a participant row): the admin types one
     * coin amount for a joined player — no kills/placement math, no pending-request step. This call:
     *  (1) writes that player's row into this match's own /leaderboard node (coins, sorted client-side),
     *  (2) credits/debits the player's wallet by only the DELTA versus whatever was set for them last
     *      time, so editing the same row again never double-pays, and
     *  (3) rolls that same delta into the running "daily" and "monthly" leaderboard buckets, so a
     *      whole-day or whole-month leaderboard builds itself with zero extra admin work.
     */
    public static Task<Void> setMatchPlayerCoins(String matchId, String matchTitle, String uid,
                                                  String username, String gameName, String gameUid,
                                                  int coins) {
        if (matchId == null || matchId.trim().isEmpty() || uid == null || uid.trim().isEmpty()) {
            return com.google.android.gms.tasks.Tasks.forException(
                    new IllegalArgumentException("Missing match or player id."));
        }
        final int newCoins = Math.max(0, coins);
        return joinedUsers(matchId).child(uid).child("adminCoins").get().continueWithTask(oldTask -> {
            long oldCoins = 0;
            if (oldTask.isSuccessful() && oldTask.getResult() != null) {
                Object v = oldTask.getResult().getValue();
                if (v instanceof Number) oldCoins = ((Number) v).longValue();
            }
            final long delta = newCoins - oldCoins;

            Map<String, Object> updates = new HashMap<>();
            updates.put("matches/" + matchId + "/joinedUsers/" + uid + "/adminCoins", newCoins);
            updates.put("matches/" + matchId + "/leaderboard/" + uid + "/username", username);
            updates.put("matches/" + matchId + "/leaderboard/" + uid + "/gameName", gameName);
            updates.put("matches/" + matchId + "/leaderboard/" + uid + "/gameUid", gameUid);
            updates.put("matches/" + matchId + "/leaderboard/" + uid + "/coins", newCoins);
            updates.put("matches/" + matchId + "/leaderboard/" + uid + "/updatedAt", ServerValue.TIMESTAMP);

            Task<Void> write = root().updateChildren(updates);
            if (delta == 0) return write;

            return write.continueWithTask(w -> runTransactionTask(users().child(uid).child("wallet"),
                    new com.google.firebase.database.Transaction.Handler() {
                        @Override public com.google.firebase.database.Transaction.Result doTransaction(
                                com.google.firebase.database.MutableData currentData) {
                            Map<String, Object> wallet = new HashMap<>();
                            Object raw = currentData.getValue();
                            if (raw instanceof Map) wallet.putAll((Map<String, Object>) raw);
                            Object rawBalance = wallet.get("balance");
                            long current = rawBalance instanceof Number ? ((Number) rawBalance).longValue() : 0L;
                            wallet.put("balance", Math.max(0, current + delta));
                            currentData.setValue(wallet);
                            return com.google.firebase.database.Transaction.success(currentData);
                        }
                        @Override public void onComplete(DatabaseError error, boolean committed,
                                                          DataSnapshot currentData) { }
                    })).continueWithTask(creditTask -> {
                        Map<String, Object> txUpdates = new HashMap<>();
                        String txId = "match_" + matchId + "_" + uid;
                        txUpdates.put("users/" + uid + "/wallet/transactions/" + txId,
                                walletTransaction("MATCH_REWARD", matchId, (int) Math.abs(delta),
                                        (delta > 0 ? "+" : "") + delta + " coins • " + matchTitle));
                        Task<Void> t = root().updateChildren(txUpdates);
                        t.addOnSuccessListener(v -> {
                            rollUpCoinRow(leaderboard().child("daily").child(currentDayKey()).child(uid), username, (int) delta);
                            rollUpCoinRow(leaderboard().child("monthly").child(currentMonthKey()).child(uid), username, (int) delta);
                            logActivity("MATCH_COINS_SET", matchTitle,
                                    "uid=" + uid + ", coins=" + newCoins + " (delta " + delta + ")");
                        });
                        return t;
                    });
        });
    }

    /** Adds a coin delta onto a daily/monthly leaderboard row, creating it if absent. */
    private static void rollUpCoinRow(DatabaseReference row, String username, int coinsDelta) {
        row.get().addOnSuccessListener(snap -> {
            long prev = 0;
            if (snap.exists()) {
                Object c = snap.child("coins").getValue();
                if (c instanceof Number) prev = ((Number) c).longValue();
            }
            Map<String, Object> update = new HashMap<>();
            update.put("username", username);
            update.put("coins", Math.max(0, prev + coinsDelta));
            update.put("updatedAt", ServerValue.TIMESTAMP);
            row.updateChildren(update);
        });
    }

    /** Current day bucket, e.g. "2026-09-26". Resets leaderboard/daily automatically at midnight. */
    private static String currentDayKey() {
        java.util.Calendar cal = java.util.Calendar.getInstance();
        return String.format(java.util.Locale.US, "%04d-%02d-%02d",
                cal.get(java.util.Calendar.YEAR), cal.get(java.util.Calendar.MONTH) + 1,
                cal.get(java.util.Calendar.DAY_OF_MONTH));
    }

    /**
     * Resolves the live leaderboard node for a period tab: "weekly" and "monthly" point at the
     * current week/month bucket (so each new period starts empty automatically), anything else
     * (e.g. "allTime") falls back to the running all-time totals.
     */
    public static DatabaseReference leaderboardForPeriod(String period) {
        if ("daily".equals(period)) return leaderboard().child("daily").child(currentDayKey());
        if ("weekly".equals(period)) return leaderboard().child("weekly").child(currentWeekKey());
        if ("monthly".equals(period)) return leaderboard().child("monthly").child(currentMonthKey());
        return leaderboard().child("allTime");
    }

    /** Current ISO-ish week bucket, e.g. "2026-W39". Monday-start week, resets leaderboard/weekly automatically. */
    private static String currentWeekKey() { return weekKeyAt(System.currentTimeMillis()); }

    private static String weekKeyAt(long millis) {
        java.util.Calendar cal = java.util.Calendar.getInstance();
        cal.setTimeInMillis(millis > 0 ? millis : System.currentTimeMillis());
        cal.setFirstDayOfWeek(java.util.Calendar.MONDAY);
        cal.setMinimalDaysInFirstWeek(4);
        int week = cal.get(java.util.Calendar.WEEK_OF_YEAR);
        int year = cal.get(java.util.Calendar.YEAR);
        return String.format(java.util.Locale.US, "%04d-W%02d", year, week);
    }

    /** Current month bucket, e.g. "2026-09". Resets leaderboard/monthly automatically at month start. */
    private static String currentMonthKey() { return monthKeyAt(System.currentTimeMillis()); }

    private static String monthKeyAt(long millis) {
        java.util.Calendar cal = java.util.Calendar.getInstance();
        cal.setTimeInMillis(millis > 0 ? millis : System.currentTimeMillis());
        return String.format(java.util.Locale.US, "%04d-%02d",
                cal.get(java.util.Calendar.YEAR), cal.get(java.util.Calendar.MONTH) + 1);
    }

    /** Simple, transparent placement point table: 1st=15, 2nd=12, 3rd=10, 4th-10th sliding, else 1. */
    private static int placementPoints(int placement) {
        int[] table = {15, 12, 10, 8, 6, 4, 3, 2, 1, 1};
        if (placement >= 1 && placement <= table.length) return table[placement - 1];
        return placement > 0 ? 1 : 0;
    }

    // ---------------------------------------------------------------------
    // A13/B43 — Result Disputes
    // ---------------------------------------------------------------------
    public static DatabaseReference disputes() {
        return root().child("disputes");
    }

    public static Task<Void> submitDispute(String tournamentId, String tournamentTitle,
                                            String reason, String description) {
        String uid = FirebaseAuth.getInstance().getUid();
        if (uid == null) {
            return com.google.android.gms.tasks.Tasks.forException(
                    new IllegalStateException("Authentication required"));
        }
        String id = disputes().push().getKey();
        Map<String, Object> dispute = new HashMap<>();
        dispute.put("userId", uid);
        dispute.put("tournamentId", tournamentId);
        dispute.put("tournamentTitle", tournamentTitle);
        dispute.put("reason", reason);
        dispute.put("description", description);
        dispute.put("status", "PENDING");
        dispute.put("createdAt", ServerValue.TIMESTAMP);
        return disputes().child(id == null ? "dispute" : id).setValue(dispute);
    }

    /** Admin: PENDING -> UNDER_REVIEW -> RESOLVED | REJECTED | CLOSED. */
    public static Task<Void> updateDisputeStatus(String disputeId, String status, String adminNote) {
        Map<String, Object> update = new HashMap<>();
        update.put("status", status);
        update.put("adminNote", adminNote == null ? "" : adminNote);
        update.put("resolvedAt", ServerValue.TIMESTAMP);
        return disputes().child(disputeId).updateChildren(update);
    }

    // ---------------------------------------------------------------------
    // A14/B43 — Reports & Moderation
    // ---------------------------------------------------------------------
    public static DatabaseReference reports() {
        return root().child("reports");
    }

    public static Task<Void> submitReport(String targetType, String targetId, String targetLabel,
                                           String reason, String description) {
        String uid = FirebaseAuth.getInstance().getUid();
        if (uid == null) {
            return com.google.android.gms.tasks.Tasks.forException(
                    new IllegalStateException("Authentication required"));
        }
        String id = reports().push().getKey();
        Map<String, Object> report = new HashMap<>();
        report.put("userId", uid);
        report.put("targetType", targetType);
        report.put("targetId", targetId == null ? "" : targetId);
        report.put("targetLabel", targetLabel == null ? "" : targetLabel);
        report.put("reason", reason);
        report.put("description", description);
        report.put("status", "PENDING");
        report.put("createdAt", ServerValue.TIMESTAMP);
        return reports().child(id == null ? "report" : id).setValue(report);
    }

    /** Leaderboard se player report: reporter + reported dono ke UID admin me dikhenge. */
    public static Task<Void> submitPlayerReport(String reportedUid, String reportedName,
                                                String reason, String description) {
        String uid = FirebaseAuth.getInstance().getUid();
        if (uid == null) {
            return com.google.android.gms.tasks.Tasks.forException(
                    new IllegalStateException("Authentication required"));
        }
        String id = reports().push().getKey();
        com.google.firebase.auth.FirebaseUser u = FirebaseAuth.getInstance().getCurrentUser();
        Map<String, Object> report = new HashMap<>();
        report.put("userId", uid);
        report.put("reporterName", u != null && u.getDisplayName() != null ? u.getDisplayName() : "");
        report.put("targetType", "PLAYER");
        report.put("targetId", reportedUid);
        report.put("reportedUid", reportedUid);
        report.put("targetLabel", reportedName == null ? "" : reportedName);
        report.put("source", "LEADERBOARD");
        report.put("reason", reason);
        report.put("description", description);
        report.put("status", "PENDING");
        report.put("createdAt", ServerValue.TIMESTAMP);
        return reports().child(id == null ? "report" : id).setValue(report);
    }

    public static Task<Void> updateReportStatus(String reportId, String status, String moderatorNote) {
        Map<String, Object> update = new HashMap<>();
        update.put("status", status);
        update.put("moderatorNote", moderatorNote == null ? "" : moderatorNote);
        update.put("resolvedAt", ServerValue.TIMESTAMP);
        return reports().child(reportId).updateChildren(update);
    }

    /** Admin moderation tool: WARN / RESTRICT / SUSPEND / BAN / ACTIVATE, written to users/{uid}/status. */
    public static Task<Void> setUserStatus(String uid, String status) {
        return setUserStatus(uid, status, null);
    }

    /** Same as above; for BANNED the admin's reason is stored in banReason and shown to the player on the ban notice screen. */
    public static Task<Void> setUserStatus(String uid, String status, String reason) {
        Map<String, Object> update = new HashMap<>();
        update.put("status", status);
        if ("BANNED".equals(status)) {
            update.put("banReason", reason == null ? "" : reason.trim());
            update.put("bannedAt", ServerValue.TIMESTAMP);
        } else {
            update.put("banReason", null);
            update.put("bannedAt", null);
        }
        return users().child(uid).updateChildren(update);
    }

    public static Task<Void> sendAdminNotice(String uid, String message, String playerName) {
        return sendAdminNotice(uid, message, playerName, "Fair-play warning", "ADMIN_NOTICE");
    }

    /**
     * Targeted admin notice (fair-play warning, withdrawal update, etc). Writes into the
     * SAME shared /notifications inbox that NotificationsActivity (the wallet bell) reads —
     * this used to write to users/{uid}/notifications instead, a path nothing ever read, so
     * the notice never reached the bell. Also fires a best-effort FCM push so the message
     * lands on the user's device as a real system notification, not just an in-app dot.
     */
    public static Task<Void> sendAdminNotice(String uid, String message, String playerName, String title, String type) {
        String resolvedTitle = title == null || title.trim().isEmpty() ? "Fair-play warning" : title;
        String resolvedMessage = message == null || message.trim().isEmpty()
                ? "Cheat use mat karo. Fair play follow karo, warna account permanently ban ho sakta hai." : message.trim();
        String key = notifications().push().getKey();
        Map<String, Object> notice = new HashMap<>();
        notice.put("userId", uid);
        notice.put("type", type == null ? "ADMIN_NOTICE" : type);
        notice.put("title", resolvedTitle);
        notice.put("message", resolvedMessage);
        notice.put("from", "STARX24 Admin");
        notice.put("playerName", playerName == null ? "" : playerName);
        notice.put("createdAt", System.currentTimeMillis());
        notice.put("read", false);
        Task<Void> dbWrite = notifications().child(key == null ? "notice" : key).setValue(notice);
        pushAdminNoticeToDevice(uid, resolvedTitle, resolvedMessage);
        return dbWrite;
    }

    /** Best-effort device push alongside the in-app notice above; a push failure never blocks or fails the DB write. */
    private static void pushAdminNoticeToDevice(String uid, String title, String body) {
        users().child(uid).child("fcmToken").addListenerForSingleValueEvent(new com.google.firebase.database.ValueEventListener() {
            @Override public void onDataChange(@NonNull DataSnapshot snap) {
                String token = snap.getValue(String.class);
                if (token == null || token.isEmpty()) return;
                new Thread(() -> {
                    try {
                        com.arenax.tournament.util.FcmSender.sendToToken(null, token, title, body, "");
                    } catch (Exception ignored) {
                        // Device push is best-effort; the in-app notice already reached the user's inbox.
                    }
                }).start();
            }
            @Override public void onCancelled(@NonNull DatabaseError error) { }
        });
    }

    // ---------------------------------------------------------------------
    // A24 — Payments: deposit & withdrawal request handling (Payment Admin role)
    // ---------------------------------------------------------------------
    public static DatabaseReference deposits() {
        return root().child("deposits");
    }

    public static DatabaseReference withdrawals() {
        return root().child("withdrawals");
    }

    /** Admin: PENDING -> APPROVED | REJECTED. */
    public static Task<Void> updateDepositStatus(String depositId, String status) {
        Map<String, Object> update = new HashMap<>();
        update.put("status", status);
        update.put("resolvedAt", ServerValue.TIMESTAMP);
        return deposits().child(depositId).updateChildren(update);
    }

    /** Admin: PENDING -> PAID | REJECTED. */
    public static Task<Void> updateWithdrawalStatus(String withdrawalId, String status) {
        Map<String, Object> update = new HashMap<>();
        update.put("status", status);
        update.put("resolvedAt", ServerValue.TIMESTAMP);
        return withdrawals().child(withdrawalId).updateChildren(update);
    }



    // ---------------------------------------------------------------------
    // A16/B41 — FAQ Management
    // ---------------------------------------------------------------------
    public static Task<Void> saveFaq(String id, String question, String answer, String category) {
        String key = id == null || id.trim().isEmpty() ? faq().push().getKey() : id;
        Map<String, Object> entry = new HashMap<>();
        entry.put("question", question);
        entry.put("answer", answer);
        entry.put("category", category == null ? "General" : category);
        entry.put("createdAt", System.currentTimeMillis());
        entry.put("published", true);
        return faq().child(key == null ? "faq" : key).setValue(entry);
    }

    public static Task<Void> deleteFaq(String id) {
        return faq().child(id).removeValue();
    }

    // ---------------------------------------------------------------------
    // A1 — Admin RBAC v2: Owner signs in with email+password (unchanged).
    // Every other admin signs in with a one-time KEY the owner generates
    // from the Roles page. The key maps to a role; no Firebase custom claim
    // or UID needs to be known/typed by the owner ahead of time.
    // ---------------------------------------------------------------------
    public static DatabaseReference adminKeys() {
        return root().child("admin_keys");
    }

    /** Live presence: one row per signed-in admin session, keyed by their (anonymous) auth uid. */
    public static DatabaseReference adminSessions() {
        return root().child("admin_sessions");
    }

    /** Readable, low-ambiguity key like SX-7F3K-QP2M. Not a push id — this is what the admin types in. */
    public static String generateReadableKey() {
        String chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"; // no 0/O/1/I confusion
        SecureRandom random = new SecureRandom();
        StringBuilder sb = new StringBuilder("SX-");
        for (int i = 0; i < 8; i++) {
            if (i == 4) sb.append('-');
            sb.append(chars.charAt(random.nextInt(chars.length())));
        }
        return sb.toString();
    }

    /** Owner-only (enforced by database.rules.json): mints a new admin key for the given role. */
    public static Task<Void> createAdminKey(String key, String label, String role) {
        Map<String, Object> record = new HashMap<>();
        record.put("label", label);
        record.put("role", role);
        record.put("active", true);
        record.put("createdAt", ServerValue.TIMESTAMP);
        return adminKeys().child(key).setValue(record);
    }

    /** Owner-only: mints a key for a work role together with the exact functions (perms) the admin may use.
     *  perms is stored as {functionId: true}; rules, backend and the app all read this same map. */
    public static Task<Void> createAdminKey(String key, String label, String role, java.util.Collection<String> perms) {
        Map<String, Object> record = new HashMap<>();
        record.put("label", label);
        record.put("role", role);
        record.put("active", true);
        record.put("createdAt", ServerValue.TIMESTAMP);
        Map<String, Object> permMap = new HashMap<>();
        if (perms != null) for (String id : perms) permMap.put(id, true);
        record.put("perms", permMap);
        return adminKeys().child(key).setValue(record);
    }

    /** Instantly locks the key out (session-side checks + rules stop honoring it) without losing history. */
    public static Task<Void> revokeAdminKey(String key) {
        return adminKeys().child(key).child("active").setValue(false);
    }

    public static Task<Void> deleteAdminKey(String key) {
        return adminKeys().child(key).removeValue();
    }

    /**
     * Call after the client has verified the typed key against {@link #adminKeys()} and is
     * signed in (anonymous auth is fine). Writes an online session row and arms onDisconnect
     * so the Roles page shows accurate online/offline status even on an app kill or crash.
     */
    public static void bindAdminPresence(String key, String role) {
        FirebaseUser user = currentUser();
        if (user == null) return;
        currentAdminKey = key;
        DatabaseReference sessionRef = adminSessions().child(user.getUid());

        Map<String, Object> online = new HashMap<>();
        online.put("key", key);
        online.put("role", role);
        online.put("online", true);
        online.put("lastSeen", ServerValue.TIMESTAMP);

        Map<String, Object> offline = new HashMap<>();
        offline.put("key", key);
        offline.put("role", role);
        offline.put("online", false);
        offline.put("lastSeen", ServerValue.TIMESTAMP);

        sessionRef.onDisconnect().setValue(offline);
        sessionRef.setValue(online);
    }

    /** Marks the current admin session offline immediately, e.g. on an explicit logout button. */
    public static Task<Void> clearAdminPresence() {
        currentAdminKey = null;
        FirebaseUser user = currentUser();
        if (user == null) return null;
        DatabaseReference sessionRef = adminSessions().child(user.getUid());
        sessionRef.onDisconnect().cancel();
        Map<String, Object> offline = new HashMap<>();
        offline.put("online", false);
        offline.put("lastSeen", ServerValue.TIMESTAMP);
        return sessionRef.updateChildren(offline);
    }

    // ---------------------------------------------------------------------
    // A5/A6/A7/B34/B35 — Match Management, Countdown, Room Control
    // ---------------------------------------------------------------------
    public static DatabaseReference matches() {
        return root().child("matches");
    }

    public static Task<Void> saveMatch(com.arenax.tournament.model.Match match) {
        String id = match.getId();
        boolean isNew = id == null || id.trim().isEmpty();
        if (isNew) id = matches().push().getKey();
        final String matchId = id == null ? "match" : id;
        Task<Void> saved = matches().child(matchId).setValue(match.toMap());
        // See addUserToTournamentMatches: keep a brand-new match's participant list in sync with
        // whoever is already registered for its tournament, so room access works without a
        // separate re-registration step.
        if (isNew && match.getTournamentId() != null && !match.getTournamentId().trim().isEmpty()) {
            saved.addOnSuccessListener(v -> seedMatchParticipantsFromTournament(match.getTournamentId(), matchId));
        }
        return saved;
    }

    public static Task<Void> deleteMatch(String matchId) {
        return matches().child(matchId).removeValue();
    }

    public static Task<Void> setMatchStatus(String matchId, String status) {
        return matches().child(matchId).child("status").setValue(status);
    }

    /** A7 — Release Room: writes room id/password + timestamp; user app updates instantly via listener. */
    /**
     * Publishes the room to players IMMEDIATELY. One atomic multi-path write updates both:
     *  - matches/{id}: admin/messenger side;
     *  - tournaments/{id}: what players' Match Joined / Tournament Detail pages listen to live.
     * (Previously only matches/ was written, so players saw "Hidden" until the match start time.)
     * tournaments/{id} is only touched when it already exists, so no half-built record is created.
     */
    public static Task<Void> releaseMatchRoom(String matchId, String roomId, String roomPassword) {
        final String id = roomId == null ? "" : roomId.trim();
        final String pass = roomPassword == null ? "" : roomPassword.trim();
        return tournaments().child(matchId).child("title").get().continueWithTask(task -> {
            boolean tournamentExists = task.isSuccessful() && task.getResult() != null && task.getResult().exists();
            Map<String, Object> updates = new HashMap<>();
            updates.put("matches/" + matchId + "/roomId", id);
            updates.put("matches/" + matchId + "/roomPassword", pass);
            updates.put("matches/" + matchId + "/roomReleased", true);
            updates.put("matches/" + matchId + "/roomReleasedAt", ServerValue.TIMESTAMP);
            updates.put("matches/" + matchId + "/status", com.arenax.tournament.model.Match.ROOM_RELEASED);
            updates.put("matches/" + matchId + "/delayReason", "");
            if (tournamentExists) {
                updates.put("tournaments/" + matchId + "/roomId", id);
                updates.put("tournaments/" + matchId + "/roomPassword", pass);
                updates.put("tournaments/" + matchId + "/roomReleased", true);
                updates.put("tournaments/" + matchId + "/roomReleaseAt", System.currentTimeMillis());
            }
            return root().updateChildren(updates);
        });
    }

    public static Task<Void> hideMatchRoom(String matchId) {
        Map<String, Object> updates = new HashMap<>();
        updates.put("matches/" + matchId + "/roomReleased", false);
        updates.put("matches/" + matchId + "/status", com.arenax.tournament.model.Match.WAITING);
        // Also hide it from players' live page (only if the tournament node exists).
        return tournaments().child(matchId).child("title").get().continueWithTask(task -> {
            if (task.isSuccessful() && task.getResult() != null && task.getResult().exists()) {
                updates.put("tournaments/" + matchId + "/roomReleased", false);
            }
            return root().updateChildren(updates);
        });
    }

    /** A7 — Delay: sets reason + new expected time and flips status so the user sees "MATCH DELAYED". */
    public static Task<Void> setMatchDelay(String matchId, String reason, long newExpectedAt) {
        Map<String, Object> update = new HashMap<>();
        update.put("delayReason", reason == null ? "" : reason);
        update.put("delayExpectedAt", newExpectedAt);
        update.put("status", com.arenax.tournament.model.Match.DELAYED);
        return matches().child(matchId).updateChildren(update);
    }

    public static Task<Void> clearMatchDelay(String matchId) {
        Map<String, Object> update = new HashMap<>();
        update.put("delayReason", "");
        update.put("status", com.arenax.tournament.model.Match.WAITING);
        return matches().child(matchId).updateChildren(update);
    }

    // ---------------------------------------------------------------------
    // A22 — Admin Activity Log
    // ---------------------------------------------------------------------
    public static DatabaseReference activityLogs() {
        return root().child("activity_logs");
    }

    /** Key this admin signed in with (set by bindAdminPresence) - stamped on every activity log. */
    private static volatile String currentAdminKey;

    /** Fire-and-forget audit trail for every meaningful admin mutation. */
    public static void logActivity(String action, String target, String details) {
        String id = activityLogs().push().getKey();
        if (id == null) return;
        com.google.firebase.auth.FirebaseUser admin = currentUser();
        Map<String, Object> log = new HashMap<>();
        log.put("admin", admin == null ? "unknown" : (admin.getEmail() == null ? admin.getUid() : admin.getEmail()));
        log.put("action", action);
        log.put("target", target == null ? "" : target);
        log.put("details", details == null ? "" : details);
        log.put("timestamp", ServerValue.TIMESTAMP);
        if (admin != null) log.put("adminUid", admin.getUid());
        if (currentAdminKey != null && !currentAdminKey.isEmpty()) log.put("adminKey", currentAdminKey);
        activityLogs().child(id).setValue(log);
    }

    // ---------------------------------------------------------------------
    // Demo Data Requirement (master prompt) — one-tap realistic seed data for
    // Sample data: categories, tournaments across every status, teams,
    // matches in every room state, a populated leaderboard, FAQ, an
    // announcement and both an open and a resolved support ticket. Uses a
    // single atomic multi-path update() from the database root (Firebase
    // RTDB treats "/"-joined keys passed to updateChildren as full paths),
    // so it either fully seeds or fails cleanly — never a half-written state.
    // Synthetic player/team ids are used for leaderboard + tickets since no
    // real auth accounts exist yet on a fresh project; nothing here touches
    // any payment/wallet/coin field, matching the prompt's hard constraint.
    // ---------------------------------------------------------------------
    public static Task<Void> seedDemoData() {
        Map<String, Object> update = new HashMap<>();
        long now = System.currentTimeMillis();
        long day = 24L * 60 * 60 * 1000;

        String[][] categories = {
                {"cat_solo", "Solo Showdown", "Every player for themselves."},
                {"cat_duo", "Duo Clash", "Pair up and push for the crown."},
                {"cat_squad", "Squad Battle", "Four-player squads, full map."},
                {"cat_clash", "Clash Squad", "Fast-paced 4v4 round-based mode."},
                {"cat_custom", "Custom Room", "Private custom lobbies."},
        };
        for (int i = 0; i < categories.length; i++) {
            Map<String, Object> cat = new HashMap<>();
            cat.put("title", categories[i][1]);
            cat.put("imageUrl", "");
            cat.put("description", categories[i][2]);
            cat.put("displayOrder", i);
            cat.put("createdAt", now);
            cat.put("active", true);
            update.put("gameModes/" + categories[i][0], cat);
        }

        String[] maps = {"Bermuda", "Purgatory", "Kalahari", "Alpine", "Nexterra"};
        // Each row: id, title, categoryId, mode, map, status, registrationStatus,
        // hoursFromNow (negative = already started/finished), totalSlots, joinedSlots, prizeInfo.
        Object[][] rows = {
                {"demo_t1", "Bermuda Solo Cup", "cat_solo", "SOLO", maps[0], "UPCOMING", "OPEN", 48, 60, 22, "500 Diamonds"},
                {"demo_t2", "Duo Purgatory Series", "cat_duo", "DUO", maps[1], "UPCOMING", "OPEN", 24, 40, 18, "Bundle + Badge"},
                {"demo_t3", "Kalahari Squad Wars", "cat_squad", "SQUAD", maps[2], "UPCOMING", "OPEN", 6, 20, 20, "1000 Diamonds"},
                {"demo_t4", "Alpine Clash Squad Rush", "cat_clash", "CLASH SQUAD", maps[3], "ONGOING", "CLOSED", -2, 16, 16, "Emote + Badge"},
                {"demo_t5", "Nexterra Booyah League", "cat_squad", "SQUAD", maps[4], "ONGOING", "CLOSED", -6, 20, 20, "1500 Diamonds"},
                {"demo_t6", "Bermuda Weekly Solo", "cat_solo", "SOLO", maps[0], "COMPLETED", "CLOSED", -72, 60, 60, "300 Diamonds"},
                {"demo_t7", "Purgatory Duo Finals", "cat_duo", "DUO", maps[1], "COMPLETED", "CLOSED", -96, 40, 40, "Winner Bundle"},
                {"demo_t8", "Kalahari Grand Slam", "cat_squad", "SQUAD", maps[2], "COMPLETED", "CLOSED", -120, 20, 20, "2000 Diamonds"},
        };
        java.text.SimpleDateFormat dateFmt = new java.text.SimpleDateFormat("dd MMM yyyy", java.util.Locale.ENGLISH);
        java.text.SimpleDateFormat timeFmt = new java.text.SimpleDateFormat("hh:mm a", java.util.Locale.ENGLISH);
        for (Object[] r : rows) {
            String id = (String) r[0];
            long startAt = now + ((int) r[7]) * 60L * 60L * 1000L;
            java.util.Date startDate = new java.util.Date(startAt);
            Map<String, Object> tour = new HashMap<>();
            tour.put("title", r[1]);
            tour.put("mode", r[3]);
            tour.put("categoryId", r[2]);
            tour.put("bannerUrl", "");
            tour.put("description", "Official " + r[1] + " — check in early, read the rules tab, and be ready before the room drops.");
            tour.put("date", dateFmt.format(startDate));
            tour.put("time", timeFmt.format(startDate));
            tour.put("startAt", startAt);
            tour.put("registrationCloseAt", startAt - (30L * 60 * 1000));
            tour.put("roomReleaseAt", startAt - (10L * 60 * 1000));
            tour.put("prizeInfo", r[10]);
            tour.put("totalSlots", r[8]);
            tour.put("joinedSlots", r[9]);
            tour.put("teamSize", "SOLO".equals(r[3]) ? 1 : ("DUO".equals(r[3]) ? 2 : 4));
            tour.put("map", r[4]);
            tour.put("matchType", r[3]);
            tour.put("rules", "No teaming, no emulator abuse, no smurfing. Screenshot your result screen.");
            tour.put("prizeDistribution", "");
            tour.put("roomId", "COMPLETED".equals(r[5]) || "ONGOING".equals(r[5]) ? String.valueOf(100000 + id.hashCode() % 900000) : "");
            tour.put("roomPassword", "COMPLETED".equals(r[5]) || "ONGOING".equals(r[5]) ? "ff" + Math.abs(id.hashCode() % 1000) : "");
            tour.put("roomReleased", "COMPLETED".equals(r[5]) || "ONGOING".equals(r[5]));
            tour.put("delayReason", "");
            tour.put("status", r[5]);
            tour.put("registrationStatus", r[6]);
            tour.put("active", true);
            tour.put("accentColor", android.graphics.Color.rgb(237, 47, 62));
            update.put("tournaments/" + id, tour);
        }

        String[][] teams = {
                {"demo_team1", "Ghost Riders"}, {"demo_team2", "Crimson Wolves"},
                {"demo_team3", "Neon Sharks"}, {"demo_team4", "Iron Falcons"},
                {"demo_team5", "Shadow Kings"}, {"demo_team6", "Blaze Squad"},
        };
        for (String[] team : teams) {
            Map<String, Object> t = new HashMap<>();
            t.put("name", team[1]);
            t.put("logoUrl", "");
            t.put("captainId", "demo_captain_" + team[0]);
            t.put("status", "ACTIVE");
            t.put("createdAt", now);
            Map<String, Object> members = new HashMap<>();
            members.put("demo_captain_" + team[0], team[1] + " (Captain)");
            t.put("members", members);
            update.put("teams/" + team[0], t);
        }

        // Matches under demo_t4 (ONGOING) covering every room state the prompt calls out.
        Map<String, Object> liveMatch = new HashMap<>();
        liveMatch.put("tournamentId", "demo_t4");
        liveMatch.put("tournamentTitle", "Alpine Clash Squad Rush");
        liveMatch.put("name", "Round 1 — Group A");
        liveMatch.put("round", 1);
        liveMatch.put("map", maps[3]);
        liveMatch.put("mode", "CLASH SQUAD");
        liveMatch.put("scheduledAt", now - (30L * 60 * 1000));
        liveMatch.put("maxSlots", 16);
        liveMatch.put("rules", "Best of 3 rounds, no revives.");
        liveMatch.put("status", "LIVE");
        liveMatch.put("roomId", "482913");
        liveMatch.put("roomPassword", "ff482");
        liveMatch.put("roomReleased", true);
        liveMatch.put("roomReleasedAt", now - (35L * 60 * 1000));
        liveMatch.put("delayReason", "");
        liveMatch.put("delayExpectedAt", 0L);
        update.put("matches/demo_m_live", liveMatch);

        Map<String, Object> waitingMatch = new HashMap<>();
        waitingMatch.put("tournamentId", "demo_t1");
        waitingMatch.put("tournamentTitle", "Bermuda Solo Cup");
        waitingMatch.put("name", "Qualifier — Round 1");
        waitingMatch.put("round", 1);
        waitingMatch.put("map", maps[0]);
        waitingMatch.put("mode", "SOLO");
        waitingMatch.put("scheduledAt", now - (2L * 60 * 1000));
        waitingMatch.put("maxSlots", 48);
        waitingMatch.put("rules", "Solo only, no teaming.");
        waitingMatch.put("status", "WAITING");
        waitingMatch.put("roomId", "");
        waitingMatch.put("roomPassword", "");
        waitingMatch.put("roomReleased", false);
        waitingMatch.put("roomReleasedAt", 0L);
        waitingMatch.put("delayReason", "");
        waitingMatch.put("delayExpectedAt", 0L);
        update.put("matches/demo_m_waiting", waitingMatch);

        Map<String, Object> releasedMatch = new HashMap<>();
        releasedMatch.put("tournamentId", "demo_t2");
        releasedMatch.put("tournamentTitle", "Duo Purgatory Series");
        releasedMatch.put("name", "Round 2 — Group B");
        releasedMatch.put("round", 2);
        releasedMatch.put("map", maps[1]);
        releasedMatch.put("mode", "DUO");
        releasedMatch.put("scheduledAt", now + (10L * 60 * 1000));
        releasedMatch.put("maxSlots", 40);
        releasedMatch.put("rules", "Duo only, both members must be registered.");
        releasedMatch.put("status", "ROOM_RELEASED");
        releasedMatch.put("roomId", "657204");
        releasedMatch.put("roomPassword", "ff657");
        releasedMatch.put("roomReleased", true);
        releasedMatch.put("roomReleasedAt", now - (1L * 60 * 1000));
        releasedMatch.put("delayReason", "");
        releasedMatch.put("delayExpectedAt", 0L);
        update.put("matches/demo_m_released", releasedMatch);

        // Populated leaderboard — 20 demo players with realistic score spread.
        String[] names = {
                "ShadowReaper", "NightHawk_FF", "ProGamerX", "BlazeQueen", "IronViper",
                "GhostSniper", "TurboKill", "SilentAssassin", "NovaStrike", "CrimsonAce",
                "DesertWolf", "SkyFallHero", "ZeroCool99", "VenomStrike", "RapidFireX",
                "PhantomEdge", "StormBreaker", "IceColdKiller", "RogueSquad", "ApexPredatorFF",
        };
        for (int i = 0; i < names.length; i++) {
            int kills = 180 - (i * 6);
            int matches = 40 - i;
            int score = 900 - (i * 30);
            Map<String, Object> row = new HashMap<>();
            row.put("username", names[i]);
            row.put("matches", matches);
            row.put("kills", kills);
            row.put("score", score);
            row.put("winning", score + " PTS");
            row.put("updatedAt", now);
            update.put("leaderboard/allTime/demo_player_" + i, row);
        }

        // FAQ
        String[][] faqs = {
                {"demo_faq1", "How do I join a tournament?", "Open the tournament, read the rules, and tap Register — all tournaments are free entry."},
                {"demo_faq2", "When do I get the Room ID and Password?", "Room details unlock shortly before the scheduled start once the admin releases them. You'll see \"WAIT FOR ROOM ID & PASSWORD\" until then."},
                {"demo_faq3", "What do I do if a match is delayed?", "The match card will show \"MATCH DELAYED\" with the reason — keep the app open, no action needed from you."},
                {"demo_faq4", "How are points calculated?", "Points combine your placement and kills using the tournament's published points table, shown on the Leaderboard tab."},
        };
        for (int i = 0; i < faqs.length; i++) {
            Map<String, Object> f = new HashMap<>();
            f.put("question", faqs[i][1]);
            f.put("answer", faqs[i][2]);
            f.put("order", i);
            f.put("published", true);
            update.put("faq/" + faqs[i][0], f);
        }

        // Announcement (targeted: ALL)
        Map<String, Object> announcement = new HashMap<>();
        announcement.put("title", "Alpine Clash Squad Rush is LIVE now!");
        announcement.put("message", "Round 1 rooms are live — jump into My Matches to grab your Room ID and Password.");
        announcement.put("target", "ALL");
        announcement.put("targetId", "");
        announcement.put("pinned", true);
        announcement.put("createdAt", now);
        update.put("announcements/demo_ann1", announcement);

        // Support tickets: one open, one resolved.
        Map<String, Object> openTicket = new HashMap<>();
        openTicket.put("uid", "demo_user_1");
        openTicket.put("category", "Room ID/Password");
        openTicket.put("subject", "Room details not showing");
        openTicket.put("description", "My match started 5 minutes ago but I still don't see the room card.");
        openTicket.put("status", "OPEN");
        openTicket.put("createdAt", now - (10L * 60 * 1000));
        update.put("support/demo_ticket_open", openTicket);

        Map<String, Object> resolvedTicket = new HashMap<>();
        resolvedTicket.put("uid", "demo_user_2");
        resolvedTicket.put("category", "Result Problem");
        resolvedTicket.put("subject", "My kills weren't counted");
        resolvedTicket.put("description", "I had 6 kills in the Bermuda Weekly Solo but the leaderboard shows fewer.");
        resolvedTicket.put("status", "RESOLVED");
        resolvedTicket.put("createdAt", now - (3L * day));
        update.put("support/demo_ticket_resolved", resolvedTicket);

        return root().updateChildren(update);
    }
}
