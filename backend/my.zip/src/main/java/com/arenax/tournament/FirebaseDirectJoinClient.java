package com.arenax.tournament;

import com.arenax.tournament.BuildConfig;
import com.arenax.tournament.model.Tournament;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

import java.util.concurrent.TimeUnit;

import org.json.JSONArray;
import org.json.JSONObject;

import okhttp3.Call;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

/**
 * Match join client. Every join — free or paid — goes through the backend's
 * POST /joinMatch (admin SDK). The backend atomically reserves the slot(s)
 * and, if the match's entryFeeCoins > 0, debits the wallet exactly once in
 * the same transaction; for a free match (entryFeeCoins == 0 or unset) it
 * just skips the debit step and registers the player — no separate
 * "free join" code path needed on the client.
 *
 * A previous version of this class tried to skip the backend entirely for
 * free matches by writing straight to Firebase, gated purely by
 * database.rules.json. That worked for free matches but meant paid matches
 * needed a second, different code path (and database.rules.json only ever
 * allowed the direct-write path for entryFeeCoins == 0 in the first place —
 * a regular, non-admin user was never allowed to self-write a paid match's
 * participant/slot record directly). Routing everything through the backend
 * removes that split: one path, one source of truth for the real balance
 * and the real entry fee, no client-side balance pre-check that can drift
 * from what the server actually sees.
 */
public final class FirebaseDirectJoinClient {

    public interface JoinCallback {
        void onSuccess(int[] slotNumbers, int entryFeeCoins);
        void onAlreadyRegistered();
        void onError(String message);
    }

    private static final int MAX_SLOTS_PER_JOIN = 4;

    /** True when a backend base URL is baked into this build. */
    private static boolean hasBackend() {
        String url = BuildConfig.STARX_API_BASE_URL;
        return url != null && !url.trim().isEmpty() && !url.trim().contains("YOUR-SERVICE");
    }

    private FirebaseDirectJoinClient() { }

    public static void joinMatch(Tournament tournament, int[] requestedSlots,
                                  String[] gameUids, String[] gameNames, JoinCallback callback) {
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        if (user == null) { callback.onError("Please sign in before joining."); return; }

        if (requestedSlots == null || requestedSlots.length == 0) {
            callback.onError("Please select at least one slot.");
            return;
        }
        if (requestedSlots.length > MAX_SLOTS_PER_JOIN) {
            callback.onError("You can join with at most " + MAX_SLOTS_PER_JOIN + " slots at a time.");
            return;
        }
        if (!hasBackend()) {
            callback.onError("Backend is not configured. Add backend.base.url before building.");
            return;
        }

        joinViaBackend(tournament.getId(), requestedSlots, gameUids, gameNames, callback);
    }

    /** Verifies the Firebase session, then calls the backend's /joinMatch
     *  (admin SDK) which atomically reserves the slot(s) and — only if the
     *  match actually has an entry fee — debits the wallet exactly once.
     *  Mirrors WithdrawalApiClient's shape (same base URL, same Bearer auth,
     *  same Render cold-start timeouts). */
    private static void joinViaBackend(String matchId, int[] requestedSlots,
            String[] gameUids, String[] gameNames, JoinCallback callback) {
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        if (user == null) { callback.onError("Please sign in before joining."); return; }
        user.getIdToken(false)
                .addOnSuccessListener(result -> {
                    String token = result == null ? null : result.getToken();
                    if (token == null || token.trim().isEmpty()) {
                        callback.onError("Could not verify your Firebase session.");
                        return;
                    }
                    sendJoinRequest(matchId, requestedSlots, gameUids, gameNames, token, callback);
                })
                .addOnFailureListener(error -> callback.onError("Could not verify your Firebase session."));
    }

    private static final MediaType JSON = MediaType.get("application/json; charset=utf-8");
    private static final OkHttpClient JOIN_HTTP = new OkHttpClient.Builder()
            .connectTimeout(30, TimeUnit.SECONDS)
            .readTimeout(90, TimeUnit.SECONDS)
            .writeTimeout(30, TimeUnit.SECONDS)
            .callTimeout(120, TimeUnit.SECONDS)
            .retryOnConnectionFailure(true)
            .build();
    private static final android.os.Handler JOIN_MAIN = new android.os.Handler(android.os.Looper.getMainLooper());

    private static void sendJoinRequest(String matchId, int[] requestedSlots, String[] gameUids,
            String[] gameNames, String idToken, JoinCallback callback) {
        String baseUrl = BuildConfig.STARX_API_BASE_URL == null ? "" : BuildConfig.STARX_API_BASE_URL.trim();
        if (baseUrl.isEmpty() || baseUrl.contains("YOUR-SERVICE")) {
            callback.onError("Backend is not configured. Add backend.base.url before building.");
            return;
        }
        String normalizedBaseUrl = baseUrl.endsWith("/") ? baseUrl.substring(0, baseUrl.length() - 1) : baseUrl;

        JSONObject payload = new JSONObject();
        try {
            payload.put("tournamentId", matchId);
            JSONArray slotArr = new JSONArray();
            JSONArray playersArr = new JSONArray();
            for (int i = 0; i < requestedSlots.length; i++) {
                slotArr.put(requestedSlots[i]);
                JSONObject player = new JSONObject();
                player.put("slotNumber", requestedSlots[i]);
                player.put("gameUid", gameUids[i]);
                player.put("gameName", gameNames[i]);
                playersArr.put(player);
            }
            payload.put("slotNumbers", slotArr);
            payload.put("players", playersArr);
        } catch (Exception e) {
            callback.onError("Could not build join request.");
            return;
        }

        Request request = new Request.Builder()
                .url(normalizedBaseUrl + "/joinMatch")
                .post(RequestBody.create(payload.toString(), JSON))
                .addHeader("Authorization", "Bearer " + idToken)
                .build();

        JOIN_HTTP.newCall(request).enqueue(new okhttp3.Callback() {
            @Override public void onFailure(Call call, java.io.IOException error) {
                boolean timeout = error instanceof java.net.SocketTimeoutException;
                String message = timeout
                        ? "Server is waking up. Please try again in a few seconds."
                        : "Could not connect to the server. Please check your internet and try again.";
                JOIN_MAIN.post(() -> callback.onError(message));
            }

            @Override public void onResponse(Call call, Response response) {
                try (Response bodyResponse = response) {
                    String body = bodyResponse.body() == null ? "" : bodyResponse.body().string();
                    boolean successHttp = response.isSuccessful();
                    int code = response.code();

                    // Parse JSON in its own try/catch, separate from the
                    // isSuccessful() check below. Previously a non-2xx
                    // response with a non-JSON body (Railway's HTML 502
                    // page when the server crashes mid-request, a proxy
                    // timeout page, etc.) threw here BEFORE the status
                    // code was ever looked at, so the real "Request
                    // failed (502)" message was replaced by an unhelpful
                    // generic "Invalid response from server." with no way
                    // to tell what actually happened.
                    JSONObject result;
                    try {
                        result = body.isEmpty() ? new JSONObject() : new JSONObject(body);
                    } catch (Exception parseError) {
                        String snippet = body.length() > 160 ? body.substring(0, 160) + "..." : body;
                        String message = successHttp
                                ? "Server sent an unexpected response. Please try again."
                                : "Request failed (" + code + "). " + (snippet.isEmpty() ? "" : snippet);
                        JOIN_MAIN.post(() -> callback.onError(message));
                        return;
                    }

                    if (!successHttp) {
                        String message = result.optString("error", "Request failed (" + code + ")");
                        JOIN_MAIN.post(() -> callback.onError(message));
                        return;
                    }
                    String status = result.optString("status", "");
                    if ("already_registered".equals(status)) {
                        JOIN_MAIN.post(callback::onAlreadyRegistered);
                        return;
                    }
                    int entryFeeCoins = result.optInt("entryFeeCoins", 0);
                    JSONArray slotsResult = result.optJSONArray("slotNumbers");
                    int[] finalSlots;
                    if (slotsResult != null && slotsResult.length() > 0) {
                        finalSlots = new int[slotsResult.length()];
                        for (int i = 0; i < slotsResult.length(); i++) finalSlots[i] = slotsResult.optInt(i);
                    } else {
                        finalSlots = new int[]{ result.optInt("slotNumber", 0) };
                    }
                    JOIN_MAIN.post(() -> callback.onSuccess(finalSlots, entryFeeCoins));
                } catch (Exception error) {
                    JOIN_MAIN.post(() -> callback.onError("Invalid response from server."));
                }
            }
        });
    }
}
