package com.arenax.tournament.util;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.View;

/**
 * Small phone-shaped wireframe of a user-panel screen. The admin sees these in the
 * "Redirect content" picker so they can tell at a glance which screen a notification will open
 * (Home, Wallet, Leaderboard, a category, a match ...). Everything is drawn with Canvas, so no
 * image assets are needed and it scales to any size.
 */
public class ScreenPreviewView extends View {

    private static final int BODY = 0xFF0F172A;      // phone body
    private static final int SCREEN = 0xFFFFFFFF;
    private static final int BLUE = 0xFF2563EB;
    private static final int BLUE_SOFT = 0xFFDBEAFE;
    private static final int CARD = 0xFFF1F5F9;
    private static final int LINE = 0xFFCBD5E1;
    private static final int TEXT = 0xFF94A3B8;
    private static final int COIN = 0xFFF5B301;
    private static final int GREEN = 0xFF16A34A;
    private static final int PURPLE = 0xFF7C3AED;

    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rect = new RectF();
    private final RectF screen = new RectF();

    private String type = NotificationRedirect.TYPE_NONE;
    private String caption = "";

    public ScreenPreviewView(Context context) {
        super(context);
        // Soft phone shadow (setShadowLayer needs a software layer; views are tiny).
        setLayerType(LAYER_TYPE_SOFTWARE, null);
    }

    public void setScreen(String type, String caption) {
        this.type = type == null ? NotificationRedirect.TYPE_NONE : type;
        this.caption = caption == null ? "" : caption;
        invalidate();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        currentCanvas = canvas;
        float w = getWidth();
        float h = getHeight();
        if (w <= 0 || h <= 0) return;

        // Phone body with a soft shadow (no outline stroke).
        float pad = w * 0.06f;
        float bodyW = w - pad * 2;
        float bodyH = h - pad * 2;
        // Keep a phone-like 9:18 shape even if the view is given a different box.
        float wantH = bodyW * 2.0f;
        if (wantH < bodyH) bodyH = wantH; else bodyW = bodyH / 2.0f;
        float left = (w - bodyW) / 2f;
        float top = (h - bodyH) / 2f;
        float radius = bodyW * 0.13f;

        paint.setStyle(Paint.Style.FILL);
        paint.setColor(BODY);
        paint.setShadowLayer(pad * 0.9f, 0, pad * 0.35f, 0x55000000);
        rect.set(left, top, left + bodyW, top + bodyH);
        canvas.drawRoundRect(rect, radius, radius, paint);
        paint.clearShadowLayer();

        float inset = bodyW * 0.045f;
        screen.set(left + inset, top + inset, left + bodyW - inset, top + bodyH - inset);
        paint.setColor(SCREEN);
        canvas.drawRoundRect(screen, radius * 0.78f, radius * 0.78f, paint);

        // Notch.
        paint.setColor(BODY);
        block(0.36f, 0.012f, 0.28f, 0.022f, BODY, 0.5f);

        drawContent();
    }

    // ---------------------------------------------------------------------------------
    // Per-screen wireframes. All coordinates are fractions (0..1) of the phone screen.
    // ---------------------------------------------------------------------------------

    private void drawContent() {
        switch (type) {
            case NotificationRedirect.TYPE_HOME:
                header(false);
                block(0.06f, 0.15f, 0.88f, 0.17f, BLUE, 0.12f);          // banner
                for (int i = 0; i < 4; i++) {                              // 2x2 category grid
                    float x = 0.06f + (i % 2) * 0.45f;
                    float y = 0.35f + (i / 2) * 0.20f;
                    block(x, y, 0.43f, 0.17f, CARD, 0.12f);
                    block(x + 0.04f, y + 0.115f, 0.22f, 0.02f, LINE, 0.5f);
                }
                nav(0);
                break;
            case NotificationRedirect.TYPE_LEADERBOARD:
                header(true);
                block(0.30f, 0.17f, 0.18f, 0.12f, BLUE_SOFT, 0.1f);       // podium
                block(0.52f, 0.13f, 0.18f, 0.16f, BLUE, 0.1f);
                block(0.08f, 0.21f, 0.18f, 0.08f, BLUE_SOFT, 0.1f);
                rows(0.34f, 6, 0.085f);
                nav(1);
                break;
            case NotificationRedirect.TYPE_WALLET:
                header(true);
                block(0.06f, 0.15f, 0.88f, 0.17f, BLUE, 0.12f);          // balance card
                coin(0.16f, 0.235f, 0.045f);
                block(0.26f, 0.225f, 0.30f, 0.025f, 0xCCFFFFFF, 0.5f);
                block(0.06f, 0.35f, 0.42f, 0.07f, BLUE_SOFT, 0.2f);      // add / withdraw
                block(0.52f, 0.35f, 0.42f, 0.07f, CARD, 0.2f);
                rows(0.46f, 5, 0.085f);
                nav(2);
                break;
            case NotificationRedirect.TYPE_ADD_MONEY:
                header(true);
                block(0.06f, 0.15f, 0.88f, 0.09f, CARD, 0.15f);          // amount input
                for (int i = 0; i < 6; i++) {                              // amount chips
                    float x = 0.06f + (i % 3) * 0.30f;
                    float y = 0.28f + (i / 3) * 0.09f;
                    block(x, y, 0.27f, 0.07f, i == 1 ? BLUE : BLUE_SOFT, 0.3f);
                }
                block(0.06f, 0.52f, 0.88f, 0.07f, BLUE, 0.3f);          // pay button
                break;
            case NotificationRedirect.TYPE_PROFILE:
                header(true);
                circle(0.5f, 0.2f, 0.07f, BLUE_SOFT);                      // avatar
                block(0.32f, 0.30f, 0.36f, 0.025f, LINE, 0.5f);
                rows(0.37f, 6, 0.08f);
                nav(3);
                break;
            case NotificationRedirect.TYPE_NOTIFICATIONS:
                header(true);
                for (int i = 0; i < 5; i++) {
                    float y = 0.15f + i * 0.13f;
                    block(0.06f, y, 0.88f, 0.11f, i == 0 ? BLUE_SOFT : CARD, 0.15f);
                    circle(0.15f, y + 0.055f, 0.035f, i % 2 == 0 ? BLUE : PURPLE);
                    block(0.25f, y + 0.03f, 0.45f, 0.02f, LINE, 0.5f);
                    block(0.25f, y + 0.065f, 0.3f, 0.015f, LINE, 0.5f);
                }
                break;
            case NotificationRedirect.TYPE_MY_UPCOMING:
            case NotificationRedirect.TYPE_MY_ONGOING:
            case NotificationRedirect.TYPE_MY_COMPLETED:
                header(true);
                matchCards(0.15f, 3);
                // status chip tells upcoming / ongoing / completed apart
                int chip = NotificationRedirect.TYPE_MY_UPCOMING.equals(type) ? BLUE
                        : NotificationRedirect.TYPE_MY_ONGOING.equals(type) ? GREEN : PURPLE;
                block(0.06f, 0.115f, 0.30f, 0.025f, chip, 0.5f);
                break;
            case NotificationRedirect.TYPE_MATCH_HISTORY:
                header(true);
                rows(0.15f, 7, 0.11f);
                break;
            case NotificationRedirect.TYPE_GALLERY:
                header(true);
                for (int i = 0; i < 6; i++) {
                    float x = 0.06f + (i % 2) * 0.45f;
                    float y = 0.15f + (i / 2) * 0.21f;
                    block(x, y, 0.43f, 0.18f, i % 3 == 0 ? BLUE_SOFT : CARD, 0.12f);
                }
                break;
            case NotificationRedirect.TYPE_SUPPORT:
                header(true);
                circle(0.5f, 0.22f, 0.08f, BLUE_SOFT);
                block(0.25f, 0.34f, 0.5f, 0.025f, LINE, 0.5f);
                block(0.06f, 0.42f, 0.88f, 0.09f, CARD, 0.15f);
                block(0.06f, 0.54f, 0.88f, 0.09f, CARD, 0.15f);
                block(0.06f, 0.66f, 0.88f, 0.07f, BLUE, 0.3f);
                break;
            case NotificationRedirect.TYPE_SUPPORT_CHAT:
                header(true);
                block(0.06f, 0.16f, 0.55f, 0.07f, CARD, 0.3f);           // chat bubbles
                block(0.38f, 0.26f, 0.56f, 0.07f, BLUE, 0.3f);
                block(0.06f, 0.36f, 0.45f, 0.07f, CARD, 0.3f);
                block(0.44f, 0.46f, 0.50f, 0.07f, BLUE, 0.3f);
                block(0.06f, 0.90f, 0.70f, 0.06f, CARD, 0.5f);           // input bar
                circle(0.86f, 0.93f, 0.045f, BLUE);
                break;
            case NotificationRedirect.TYPE_FAQ:
                header(true);
                for (int i = 0; i < 6; i++) {
                    float y = 0.15f + i * 0.11f;
                    block(0.06f, y, 0.88f, 0.085f, i == 0 ? BLUE_SOFT : CARD, 0.2f);
                    block(0.10f, y + 0.032f, 0.5f, 0.018f, LINE, 0.5f);
                }
                break;
            case NotificationRedirect.TYPE_ABOUT:
                header(true);
                block(0.06f, 0.15f, 0.88f, 0.16f, BLUE, 0.12f);
                for (int i = 0; i < 6; i++) block(0.06f, 0.36f + i * 0.05f, i % 3 == 2 ? 0.5f : 0.88f, 0.018f, LINE, 0.5f);
                break;
            case NotificationRedirect.TYPE_CATEGORY:
                header(true);
                block(0.06f, 0.14f, 0.28f, 0.05f, BLUE, 0.5f);           // Ongoing / Upcoming / Resulted
                block(0.37f, 0.14f, 0.28f, 0.05f, CARD, 0.5f);
                block(0.68f, 0.14f, 0.26f, 0.05f, CARD, 0.5f);
                matchCards(0.23f, 3);
                break;
            case NotificationRedirect.TYPE_MATCH:
                header(true);
                block(0.06f, 0.14f, 0.88f, 0.20f, BLUE, 0.12f);          // match banner
                block(0.06f, 0.37f, 0.5f, 0.025f, LINE, 0.5f);
                for (int i = 0; i < 3; i++) block(0.06f + i * 0.30f, 0.43f, 0.27f, 0.08f, CARD, 0.2f);
                block(0.06f, 0.55f, 0.88f, 0.012f, LINE, 0.5f);
                block(0.06f, 0.58f, 0.7f, 0.012f, LINE, 0.5f);
                block(0.06f, 0.88f, 0.88f, 0.07f, BLUE, 0.3f);           // JOIN NOW
                break;
            case NotificationRedirect.TYPE_RESULT:
                header(true);
                block(0.30f, 0.17f, 0.18f, 0.12f, BLUE_SOFT, 0.1f);
                block(0.52f, 0.13f, 0.18f, 0.16f, BLUE, 0.1f);
                block(0.08f, 0.21f, 0.18f, 0.08f, BLUE_SOFT, 0.1f);
                rows(0.34f, 6, 0.085f);
                break;
            default:
                // "No redirect": empty screen with an app-open hint.
                circle(0.5f, 0.45f, 0.12f, CARD);
                block(0.30f, 0.60f, 0.40f, 0.02f, LINE, 0.5f);
                block(0.36f, 0.65f, 0.28f, 0.015f, LINE, 0.5f);
        }
    }

    private void header(boolean withBack) {
        if (withBack) circle(0.11f, 0.085f, 0.03f, CARD);
        block(withBack ? 0.20f : 0.06f, 0.075f, 0.34f, 0.022f, LINE, 0.5f);
        circle(0.89f, 0.085f, 0.03f, BLUE_SOFT);
    }

    private void rows(float y0, int count, float step) {
        for (int i = 0; i < count; i++) {
            float y = y0 + i * step;
            block(0.06f, y, 0.88f, step * 0.82f, CARD, 0.18f);
            circle(0.14f, y + step * 0.41f, step * 0.26f, i == 0 ? BLUE : BLUE_SOFT);
            block(0.24f, y + step * 0.26f, 0.38f, step * 0.14f, LINE, 0.5f);
            block(0.24f, y + step * 0.50f, 0.24f, step * 0.11f, LINE, 0.5f);
        }
    }

    private void matchCards(float y0, int count) {
        for (int i = 0; i < count; i++) {
            float y = y0 + i * 0.235f;
            block(0.06f, y, 0.88f, 0.21f, CARD, 0.1f);
            block(0.10f, y + 0.03f, 0.40f, 0.022f, LINE, 0.5f);
            block(0.10f, y + 0.07f, 0.28f, 0.016f, LINE, 0.5f);
            circle(0.78f, y + 0.055f, 0.03f, COIN);
            block(0.10f, y + 0.135f, 0.80f, 0.045f, BLUE, 0.4f);       // JOIN NOW
        }
    }

    private void nav(int selected) {
        block(0.0f, 0.925f, 1f, 0.075f, 0xFFF8FAFC, 0f);
        for (int i = 0; i < 4; i++) {
            float cx = 0.125f + i * 0.25f;
            circle(cx, 0.955f, 0.022f, i == selected ? BLUE : LINE);
        }
    }

    // ---------------------------------------------------------------------------------
    // Drawing helpers
    // ---------------------------------------------------------------------------------

    private void block(float fx, float fy, float fw, float fh, int color, float radiusFrac) {
        float sw = screen.width();
        float sh = screen.height();
        rect.set(screen.left + fx * sw, screen.top + fy * sh,
                screen.left + (fx + fw) * sw, screen.top + (fy + fh) * sh);
        paint.setColor(color);
        float r = Math.min(rect.width(), rect.height()) * radiusFrac;
        if (r <= 0f) canvas().drawRect(rect, paint); else canvas().drawRoundRect(rect, r, r, paint);
    }

    private void circle(float fcx, float fcy, float fr, int color) {
        float sw = screen.width();
        float sh = screen.height();
        paint.setColor(color);
        canvas().drawCircle(screen.left + fcx * sw, screen.top + fcy * sh, fr * sw, paint);
    }

    private void coin(float fcx, float fcy, float fr) {
        circle(fcx, fcy, fr, COIN);
        circle(fcx, fcy, fr * 0.62f, 0xFFFFD866);
    }

    // Canvas is only valid inside onDraw; onDraw stores it here for the helper methods.
    private Canvas currentCanvas;

    private Canvas canvas() { return currentCanvas; }
}
