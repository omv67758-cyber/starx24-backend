package com.arenax.tournament;


import com.arenax.tournament.util.FancyText;
import android.animation.ValueAnimator;
import android.app.Activity;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorFilter;
import android.graphics.LinearGradient;
import android.graphics.Matrix;
import android.graphics.Outline;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.RadialGradient;
import android.graphics.Rect;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.LayerDrawable;
import android.graphics.drawable.RippleDrawable;
import android.graphics.drawable.StateListDrawable;
import android.os.Build;
import android.os.Bundle;
import android.text.InputType;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.style.ForegroundColorSpan;
import android.view.Gravity;
import android.view.View;
import android.view.ViewOutlineProvider;
import android.view.animation.LinearInterpolator;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.arenax.tournament.data.FirebaseRepository;
import com.arenax.tournament.util.InputValidation;
import com.arenax.tournament.util.SecureCredentialStore;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;

/**
 * Admin login deliberately uses only platform views (no XML layout, no drawable
 * resources). This avoids a crash while moving from the launcher into a
 * Material/XML login layout on devices where the theme or generated Firebase
 * resources are not ready yet. All the STARX24 "glass card" styling below is
 * therefore built with GradientDrawable/LayerDrawable in code rather than
 * loaded from res/drawable, so it carries zero resource-load risk.
 */
public class AdminLoginActivity extends Activity {

    @Override
    protected void onPostCreate(android.os.Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
        com.arenax.tournament.util.FancyText.attach(getWindow());
    }

    @Override
    protected void attachBaseContext(android.content.Context newBase) {
        super.attachBaseContext(com.arenax.tournament.util.ScreenFit.wrap(newBase));
    }

    private static final String PREFS = "arenax_admin_login_saved";
    /** Owner account: same email as database.rules.json / backend MASTER_EMAIL. No custom claim needed. */
    private static final String OWNER_EMAIL = "mitakarmakar117@gmail.com";
    private static final String KEY_EMAIL = "email";
    private static final String KEY_REMEMBER_EMAIL = "remember_email";
    private static final int MAX_LOGIN_FAILURES = 5;
    private static final long LOCKOUT_MS = 30_000L;

    // Black & white palette, matched to the redesigned user login screen
    // (white card, soft black shadow, black gradient actions).
    private static final int SCREEN_BASE = Color.parseColor("#FFFFFF");
    private static final int SCREEN_WASH = Color.parseColor("#DADADF");
    private static final int CIRCLE_SOFT = Color.parseColor("#22000000");
    private static final int CIRCLE_MID = Color.parseColor("#0C000000");
    private static final int CIRCLE_DEEP = Color.parseColor("#2A000000");
    private static final int CARD_STROKE = Color.TRANSPARENT;
    private static final int ACCENT_INK = Color.parseColor("#0A0A0A");
    private static final int TEXT_PRIMARY = Color.parseColor("#0A0A0A");
    private static final int TEXT_SECONDARY = Color.parseColor("#68686D");
    private static final int TEXT_MUTED = Color.parseColor("#8E8E93");
    private static final int INPUT_FILL = Color.parseColor("#F5F5F7");
    private static final int INPUT_STROKE = Color.parseColor("#0A0A0A");
    private static final int BTN_RIPPLE = Color.parseColor("#44FFFFFF");
    private static final int BTN_DARK_1 = Color.parseColor("#3E3E42");
    private static final int BTN_DARK_2 = Color.parseColor("#1A1A1D");
    private static final int BTN_DARK_3 = Color.parseColor("#000000");

    private FirebaseAuth auth;
    private boolean firebaseAvailable;
    private EditText emailInput;
    private EditText passwordInput;
    private EditText keyInput;
    private Button loginButton;
    private CheckBox rememberEmail;
    private TextView passwordToggle;
    private TextView ownerTab;
    private TextView adminTab;
    private LinearLayout ownerFields;
    private LinearLayout adminFields;
    private TextView noteLabel;
    private boolean keyLoginInFlight;
    private boolean passwordVisible;
    private boolean ownerMode = true;
    private int failedAttempts;
    private long lockedUntil;
    private ValueAnimator subtitleRgbAnimator;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            buildLoginScreen();
            initializeFirebaseSafely();
        } catch (Throwable error) {
            firebaseAvailable = false;
            buildFallbackScreen();
            FancyText.toast(this, "Admin login screen loaded. Check Firebase setup.", Toast.LENGTH_LONG).show();
        }
    }

    private void buildLoginScreen() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackground(loginBackground());
        // Android 15+ (targetSdk 35) edge-to-edge: keep the "‹ BACK" link and login card
        // clear of the status bar's clock, battery and notification icons.
        androidx.core.view.ViewCompat.setOnApplyWindowInsetsListener(scroll, (view, insets) -> {
            androidx.core.graphics.Insets bars = insets.getInsets(
                    androidx.core.view.WindowInsetsCompat.Type.systemBars());
            view.setPadding(bars.left, bars.top, bars.right, bars.bottom);
            return insets;
        });

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setPadding(dp(18), dp(24), dp(18), dp(24));
        scroll.addView(root, new ScrollView.LayoutParams(-1, -1));

        TextView back = label("‹  BACK", 12, TEXT_PRIMARY, true);
        back.setPadding(dp(8), 0, 0, dp(14));
        root.addView(back, params(-1, dp(46), 0));
        back.setOnClickListener(v -> finish());

        // Wrapper that carries the soft black card shadow (10dp room on the sides/top, 14dp below).
        FrameLayout shadowWrap = new FrameLayout(this);
        shadowWrap.setBackground(cardShadowDrawable());
        shadowWrap.setPadding(dp(10), dp(10), dp(10), dp(14));
        root.addView(shadowWrap, params(-1, -2, 0));
        // Gentle entrance: card fades in while sliding up a few dp.
        shadowWrap.setAlpha(0f);
        shadowWrap.setTranslationY(dp(22));
        shadowWrap.animate().alpha(1f).translationY(0f).setDuration(380).start();

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setBackground(glassPanelDrawable());
        card.setPadding(dp(22), dp(28), dp(22), dp(26));
        shadowWrap.addView(card, new FrameLayout.LayoutParams(-1, -2));

        ImageView logo = new ImageView(this);
        logo.setImageResource(R.drawable.starx24_logo);
        logo.setVisibility(View.GONE);
        logo.setContentDescription(getString(R.string.app_name));
        card.addView(logo, params(dp(76), dp(76), 0));
        ((LinearLayout.LayoutParams) logo.getLayoutParams()).gravity = Gravity.CENTER_HORIZONTAL;

        TextView brand = label("STARX24", 18, ACCENT_INK, true);
        brand.setVisibility(View.GONE);
        brand.setGravity(Gravity.CENTER);
        brand.setLetterSpacing(0.16f);
        card.addView(brand, params(-1, -2, dp(10)));

        // Black badge with a white monogram -- the admin identity mark.
        TextView badge = label("SX", 20, Color.WHITE, true);
        badge.setGravity(Gravity.CENTER);
        badge.setLetterSpacing(0.08f);
        GradientDrawable badgeBg = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{BTN_DARK_1, BTN_DARK_2, BTN_DARK_3});
        badgeBg.setCornerRadius(dp(16));
        badge.setBackground(badgeBg);
        applyRoundOutline(badge, 16);
        blackShadow(badge, 8);
        card.addView(badge, params(dp(64), dp(64), 0));
        ((LinearLayout.LayoutParams) badge.getLayoutParams()).gravity = Gravity.CENTER_HORIZONTAL;

        TextView title = new TextView(this);
        setStyledTitle(title, "Admin Panel");
        title.setTextSize(31);
        title.setTypeface(null, Typeface.BOLD);
        title.setGravity(Gravity.CENTER_HORIZONTAL);
        card.addView(title, params(-1, -2, dp(16)));

        TextView welcome = label("Welcome Back", 16, Color.parseColor("#3A3A3F"), false);
        welcome.setGravity(Gravity.CENTER_HORIZONTAL);
        card.addView(welcome, params(-1, -2, dp(8)));
        TextView subtitle = label("Login to your account to continue", 13, TEXT_SECONDARY, false);
        subtitle.setGravity(Gravity.CENTER_HORIZONTAL);
        card.addView(subtitle, params(-1, -2, dp(4)));
        startSubtitleRgbAnimation(subtitle);

        // A1 RBAC v2 — segmented tab: OWNER (real Firebase email+password account) vs
        // ADMIN KEY (a code the owner generates from the Roles page for everyone else).
        LinearLayout tabRow = new LinearLayout(this);
        tabRow.setOrientation(LinearLayout.HORIZONTAL);
        GradientDrawable track = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{Color.parseColor("#E8E8EC"), Color.parseColor("#F1F1F4")});
        track.setCornerRadius(dp(12));
        tabRow.setBackground(track);
        tabRow.setPadding(dp(4), dp(4), dp(4), dp(4));
        ownerTab = tabButton("OWNER");
        adminTab = tabButton("ADMIN KEY");
        tabRow.addView(ownerTab, new LinearLayout.LayoutParams(0, -1, 1));
        tabRow.addView(adminTab, new LinearLayout.LayoutParams(0, -1, 1));
        card.addView(tabRow, params(-1, dp(52), dp(20)));
        ownerTab.setOnClickListener(v -> setOwnerMode(true));
        adminTab.setOnClickListener(v -> setOwnerMode(false));

        ownerFields = new LinearLayout(this);
        ownerFields.setOrientation(LinearLayout.VERTICAL);
        card.addView(ownerFields, params(-1, -2, 0));

        emailInput = field("Gmail address", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS, R.drawable.ic_field_email);
        passwordInput = field("Password", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD, R.drawable.ic_field_lock);
        loadSavedCredentials();
        ownerFields.addView(emailInput, params(-1, dp(62), dp(4)));
        ownerFields.addView(passwordInput, params(-1, dp(62), dp(10)));

        LinearLayout passwordActions = new LinearLayout(this);
        passwordActions.setGravity(Gravity.CENTER_VERTICAL);
        passwordActions.setPadding(dp(4), 0, dp(4), 0);
        passwordToggle = label("SHOW PASSWORD", 11, ACCENT_INK, true);
        passwordToggle.setGravity(Gravity.CENTER_VERTICAL);
        passwordToggle.setOnClickListener(v -> togglePasswordVisibility());
        passwordActions.addView(passwordToggle, new LinearLayout.LayoutParams(0, dp(36), 1));
        TextView forgot = label("FORGOT PASSWORD?", 11, ACCENT_INK, true);
        forgot.setGravity(Gravity.CENTER_VERTICAL | Gravity.RIGHT);
        forgot.setOnClickListener(v -> sendPasswordReset());
        passwordActions.addView(forgot, new LinearLayout.LayoutParams(0, dp(36), 1));
        ownerFields.addView(passwordActions, params(-1, dp(38), dp(2)));

        rememberEmail = new CheckBox(this);
        rememberEmail.setText("Remember email on this device");
        rememberEmail.setTextColor(TEXT_SECONDARY);
        rememberEmail.setTextSize(12);
        rememberEmail.setButtonTintList(new ColorStateList(
                new int[][]{new int[]{android.R.attr.state_checked}, new int[]{}},
                new int[]{ACCENT_INK, TEXT_SECONDARY}));
        rememberEmail.setChecked(getSharedPreferences(PREFS, MODE_PRIVATE)
                .getBoolean(KEY_REMEMBER_EMAIL, true));
        ownerFields.addView(rememberEmail, params(-1, dp(42), dp(2)));

        adminFields = new LinearLayout(this);
        adminFields.setOrientation(LinearLayout.VERTICAL);
        adminFields.setVisibility(View.GONE);
        card.addView(adminFields, params(-1, -2, 0));

        keyInput = field("Access key (e.g. SX-7F3K-QP2M)", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS, R.drawable.ic_field_lock);
        adminFields.addView(keyInput, params(-1, dp(62), dp(4)));
        TextView keyHint = label("Ask the owner for a key from the Roles page.", 11, TEXT_MUTED, false);
        adminFields.addView(keyHint, params(-1, -2, dp(8)));

        loginButton = new Button(this);
        loginButton.setText("LOGIN  →");
        loginButton.setTextColor(Color.WHITE);
        loginButton.setTextSize(14);
        loginButton.setTypeface(null, Typeface.BOLD);
        loginButton.setAllCaps(false);
        loginButton.setBackground(primaryButtonDrawable());
        loginButton.setForeground(new RippleDrawable(ColorStateList.valueOf(BTN_RIPPLE), null, null));
        applyRoundOutline(loginButton, 10);
        blackShadow(loginButton, 8);
        card.addView(loginButton, params(-1, dp(56), dp(22)));
        loginButton.setOnClickListener(v -> {
            if (ownerMode) signIn(); else signInWithKey();
        });

        noteLabel = label("Only the authorized owner account can enter.", 11, TEXT_MUTED, false);
        noteLabel.setGravity(Gravity.CENTER_HORIZONTAL);
        card.addView(noteLabel, params(-1, -2, dp(16)));

        setContentView(scroll);
        setOwnerMode(true);
    }

    private TextView tabButton(String text) {
        TextView tab = label(text, 12, TEXT_SECONDARY, true);
        tab.setGravity(Gravity.CENTER);
        tab.setLetterSpacing(0.04f);
        applyRoundOutline(tab, 10);
        tab.setBackground(tabInactiveDrawable());
        return tab;
    }

    /** Active tab: black gradient pill (lifted with a black shadow in setOwnerMode). */
    private Drawable tabActiveDrawable() {
        GradientDrawable active = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{BTN_DARK_1, BTN_DARK_2, BTN_DARK_3});
        active.setCornerRadius(dp(10));
        return active;
    }

    /** Inactive tab: transparent, sits flat on the silver track. */
    private Drawable tabInactiveDrawable() {
        GradientDrawable inactive = new GradientDrawable();
        inactive.setColor(Color.TRANSPARENT);
        inactive.setCornerRadius(dp(10));
        return inactive;
    }

    /** Swaps the visible fields/button copy between the OWNER (email+password) and ADMIN KEY tabs. */
    private void setOwnerMode(boolean owner) {
        ownerMode = owner;
        ownerFields.setVisibility(owner ? View.VISIBLE : View.GONE);
        adminFields.setVisibility(owner ? View.GONE : View.VISIBLE);
        ownerTab.setBackground(owner ? tabActiveDrawable() : tabInactiveDrawable());
        adminTab.setBackground(!owner ? tabActiveDrawable() : tabInactiveDrawable());
        ownerTab.setElevation(owner ? dp(3) : 0);
        adminTab.setElevation(!owner ? dp(3) : 0);
        ownerTab.setTextColor(owner ? Color.WHITE : TEXT_SECONDARY);
        adminTab.setTextColor(!owner ? Color.WHITE : TEXT_SECONDARY);
        loginButton.setText(owner ? "LOGIN  →" : "ENTER WITH KEY  →");
        noteLabel.setText(owner ? "Only the authorized owner account can enter."
                : "Your role is set by whoever generated this key.");
    }

    /** Title in black with the last word in softer grey, matching the login/register screens. */
    private void setStyledTitle(TextView target, String lowerCaseText) {
        SpannableString styled = new SpannableString(lowerCaseText);
        int lastWordStart = lowerCaseText.lastIndexOf(' ') + 1;
        styled.setSpan(new ForegroundColorSpan(Color.parseColor("#5A5A60")),
                lastWordStart, lowerCaseText.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        target.setText(styled);
        target.setTextColor(ACCENT_INK);
    }

    /** Animates a moving grey -> black -> grey sheen across the subtitle text. */
    private void startSubtitleRgbAnimation(TextView target) {
        target.post(() -> {
            int width = target.getWidth();
            if (width <= 0) return;
            int[] colors = {Color.parseColor("#8E8E93"), Color.parseColor("#0A0A0A"), Color.parseColor("#5A5A60"), Color.parseColor("#8E8E93")};
            LinearGradient gradient = new LinearGradient(
                    0, 0, width * 2f, 0, colors, null, Shader.TileMode.MIRROR);
            target.getPaint().setShader(gradient);

            if (subtitleRgbAnimator != null) subtitleRgbAnimator.cancel();
            subtitleRgbAnimator = ValueAnimator.ofFloat(0f, width * 2f);
            subtitleRgbAnimator.setDuration(2400);
            subtitleRgbAnimator.setRepeatCount(ValueAnimator.INFINITE);
            subtitleRgbAnimator.setInterpolator(new LinearInterpolator());
            subtitleRgbAnimator.addUpdateListener(animation -> {
                float translate = (float) animation.getAnimatedValue();
                Matrix matrix = new Matrix();
                matrix.setTranslate(translate, 0);
                gradient.setLocalMatrix(matrix);
                target.invalidate();
            });
            subtitleRgbAnimator.start();
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (subtitleRgbAnimator != null) subtitleRgbAnimator.cancel();
    }

    private void buildFallbackScreen() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setPadding(dp(24), dp(24), dp(24), dp(24));
        // Plain color only here: this is the fallback for when the fancier
        // background failed above, so it must never depend on a resource
        // that could fail to load in the same way.
        root.setBackgroundColor(Color.parseColor("#F0F2F7"));
        TextView message = label("ADMIN LOGIN\n\nFirebase configuration is unavailable.", 18, TEXT_PRIMARY, true);
        message.setGravity(Gravity.CENTER);
        root.addView(message, params(-1, -2, 0));
        Button back = new Button(this);
        back.setText("BACK");
        back.setOnClickListener(v -> finish());
        root.addView(back, params(-1, dp(54), dp(24)));
        setContentView(root);
    }

    private void initializeFirebaseSafely() {
        firebaseAvailable = false;
        try {
            firebaseAvailable = FirebaseRepository.isFirebaseAvailable(this);
            if (firebaseAvailable) auth = FirebaseAuth.getInstance();
            // Always keep the login page visible. The saved fields are loaded
            // above, and the user explicitly taps LOGIN to continue.
            // Do not auto-redirect based on an old Firebase session.
        } catch (Throwable ignored) {
            auth = null;
            firebaseAvailable = false;
        }
    }

    private void loadSavedCredentials() {
        SharedPreferences saved = getSharedPreferences(PREFS, MODE_PRIVATE);
        if (saved.getBoolean(KEY_REMEMBER_EMAIL, true)) {
            emailInput.setText(saved.getString(KEY_EMAIL, ""));
            passwordInput.setText(SecureCredentialStore.loadPassword(this));
        }
    }

    private void saveCredentials(String email, String password) {
        SharedPreferences.Editor editor = getSharedPreferences(PREFS, MODE_PRIVATE).edit();
        // Never persist an admin password on the device. Firebase Auth keeps
        // the authenticated session; only the convenience email is optional.
        boolean remember = rememberEmail == null || rememberEmail.isChecked();
        editor.putBoolean(KEY_REMEMBER_EMAIL, remember);
        if (remember) editor.putString(KEY_EMAIL, email);
        else editor.remove(KEY_EMAIL);
        editor.apply();
        if (remember) SecureCredentialStore.savePassword(this, password);
        else SecureCredentialStore.clear(this);
    }

    private void signIn() {
        if (System.currentTimeMillis() < lockedUntil) {
            long seconds = Math.max(1L, (lockedUntil - System.currentTimeMillis() + 999L) / 1000L);
            toast("Too many failed attempts. Try again in " + seconds + " seconds.");
            return;
        }
        if (!firebaseAvailable || auth == null) {
            toast("Firebase configuration is unavailable. Check google-services.json.");
            return;
        }
        String email = emailInput.getText() == null ? "" : emailInput.getText().toString().trim();
        String password = passwordInput.getText() == null ? "" : passwordInput.getText().toString();
        if (!InputValidation.email(emailInput) || !InputValidation.password(passwordInput)) {
            toast("Check the highlighted admin login fields");
            return;
        }
        saveCredentials(email, password);
        loginButton.setEnabled(false);
        try {
            auth.signInWithEmailAndPassword(email, password)
                    .addOnSuccessListener(result -> verifyAdminEmail())
                    .addOnFailureListener(error -> {
                        loginButton.setEnabled(true);
                        failedAttempts++;
                        if (failedAttempts >= MAX_LOGIN_FAILURES) {
                            lockedUntil = System.currentTimeMillis() + LOCKOUT_MS;
                            failedAttempts = 0;
                        }
                        toast(error.getMessage() == null ? "Admin login failed." : error.getMessage());
                    });
        } catch (Throwable error) {
            loginButton.setEnabled(true);
            toast("Admin login could not start. Please try again.");
        }
    }

    /** A1 RBAC v2 — ADMIN KEY tab: validates the typed key against admin_keys/{key}, signs the
     *  device in anonymously (so Firebase rules/presence have a uid to work with), then opens
     *  AdminActivity with whatever role the owner assigned that key and marks it online. */
    private void signInWithKey() {
        if (System.currentTimeMillis() < lockedUntil) {
            long seconds = Math.max(1L, (lockedUntil - System.currentTimeMillis() + 999L) / 1000L);
            toast("Too many failed attempts. Try again in " + seconds + " seconds.");
            return;
        }
        if (!firebaseAvailable || auth == null) {
            toast("Firebase configuration is unavailable. Check google-services.json.");
            return;
        }
        if (keyLoginInFlight) return;
        String key = keyInput.getText() == null ? "" : keyInput.getText().toString().trim().toUpperCase();
        if (key.isEmpty()) {
            toast("Enter the access key your owner gave you.");
            return;
        }
        keyLoginInFlight = true;
        loginButton.setEnabled(false);

        // A stray owner session on the same device must not leak into an admin-key session.
        if (auth.getCurrentUser() != null && !auth.getCurrentUser().isAnonymous()) auth.signOut();

        Runnable lookup = () -> FirebaseRepository.adminKeys().child(key).get()
                .addOnSuccessListener(this::handleKeyLookup)
                .addOnFailureListener(error -> {
                    keyLoginInFlight = false;
                    loginButton.setEnabled(true);
                    String msg = String.valueOf(error.getMessage());
                    if (msg.toLowerCase().contains("permission")) {
                        toast("Key check blocked by database rules. Owner: run deploy_rules.sh to publish the latest database.rules.json.");
                    } else {
                        toast("Could not check that key. Check your connection and try again.");
                    }
                });

        if (auth.getCurrentUser() == null) {
            auth.signInAnonymously()
                    .addOnSuccessListener(result -> lookup.run())
                    .addOnFailureListener(error -> {
                        keyLoginInFlight = false;
                        loginButton.setEnabled(true);
                        toast(error.getMessage() == null ? "Could not start admin session." : error.getMessage());
                    });
        } else {
            lookup.run();
        }
    }

    private void handleKeyLookup(DataSnapshot snapshot) {
        keyLoginInFlight = false;
        loginButton.setEnabled(true);
        String key = keyInput.getText() == null ? "" : keyInput.getText().toString().trim().toUpperCase();
        boolean active = snapshot.exists() && !Boolean.FALSE.equals(snapshot.child("active").getValue());
        if (!active) {
            failedAttempts++;
            if (failedAttempts >= MAX_LOGIN_FAILURES) {
                lockedUntil = System.currentTimeMillis() + LOCKOUT_MS;
                failedAttempts = 0;
            }
            toast(snapshot.exists() ? "This key has been revoked." : "Invalid access key.");
            return;
        }
        failedAttempts = 0;
        String role = String.valueOf(snapshot.child("role").getValue());
        FirebaseRepository.bindAdminPresence(key, role);
        if (AdminRoles.isWorkRole(role)) {
            // Work-role key: the owner decided exactly which functions this admin gets (perms map).
            java.util.ArrayList<String> perms = new java.util.ArrayList<>();
            for (DataSnapshot p : snapshot.child("perms").getChildren()) {
                if (Boolean.TRUE.equals(p.getValue())) perms.add(p.getKey());
            }
            Object labelVal = snapshot.child("label").getValue();
            openWorkHub(role, perms, labelVal == null ? "" : String.valueOf(labelVal));
            return;
        }
        openAdmin(role);
    }

    /** Key-holder landing: the unique Admin Panel, showing only the works the owner assigned. */
    private void openWorkHub(String role, java.util.ArrayList<String> perms, String adminName) {
        try {
            Intent intent = new Intent(this, AdminWorkHubActivity.class);
            intent.putExtra(AdminWorkHubActivity.EXTRA_OWNER, false);
            intent.putExtra("adminRole", role);
            intent.putStringArrayListExtra("adminPerms", perms);
            intent.putExtra("adminName", adminName);
            startActivity(intent);
            finish();
        } catch (Throwable error) {
            toast("Admin panel could not open. Please try again.");
        }
    }

    private void verifyAdminEmail() {
        loginButton.setEnabled(true);
        failedAttempts = 0;
        FirebaseUser user = auth == null ? null : auth.getCurrentUser();
        if (user == null) {
            toast("This account is not authorized for admin access.");
            return;
        }
        user.getIdToken(true).addOnSuccessListener(result -> {
            Object admin = result.getClaims().get("admin");
            Object tokenEmail = result.getClaims().get("email");
            boolean isOwner = tokenEmail != null
                    && OWNER_EMAIL.equalsIgnoreCase(String.valueOf(tokenEmail).trim());
            if (isOwner || Boolean.TRUE.equals(admin)) resolveRoleAndOpen(user.getUid());
            else {
                auth.signOut();
                toast("This account is not authorized for admin access.");
            }
        }).addOnFailureListener(error -> {
            auth.signOut();
            toast("Could not verify admin permissions.");
        });
    }

    private void togglePasswordVisibility() {
        passwordVisible = !passwordVisible;
        int cursor = passwordInput.getSelectionStart();
        passwordInput.setInputType(InputType.TYPE_CLASS_TEXT
                | (passwordVisible ? InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
                : InputType.TYPE_TEXT_VARIATION_PASSWORD));
        passwordInput.setSelection(Math.max(0, cursor));
        passwordToggle.setText(passwordVisible ? "HIDE PASSWORD" : "SHOW PASSWORD");
    }

    private void sendPasswordReset() {
        if (!firebaseAvailable || auth == null) {
            toast("Firebase configuration is unavailable. Check google-services.json.");
            return;
        }
        String email = emailInput.getText() == null ? "" : emailInput.getText().toString().trim();
        if (email.isEmpty() || !android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            toast("Enter a valid admin email first.");
            return;
        }
        auth.sendPasswordResetEmail(email)
                .addOnSuccessListener(unused -> toast("Password reset email sent if this account exists."))
                .addOnFailureListener(error -> toast("Could not send password reset email."));
    }

    /** A1 RBAC v2 — the email+password tab is the OWNER account only (the one hardcoded in
     *  database.rules.json). The owner is always SUPER_ADMIN; every other admin now signs in
     *  from the ADMIN KEY tab below with a key the owner generates on the Roles page. */
    private void resolveRoleAndOpen(String uid) {
        openAdmin("SUPER_ADMIN");
    }

    private void openAdmin(String role) {
        try {
            // Always land on the existing full dashboard. The role-workspace
            // chooser is not useful after login and hides Add Category, Add
            // Match, and the Roles management controls from the owner.
            Intent intent = new Intent(this, AdminActivity.class);
            intent.putExtra("adminRole", dashboardRole(role));
            startActivity(intent);
            finish();
        } catch (Throwable error) {
            toast("Admin dashboard could not open. Please try again.");
        }
    }

    /** Converts the newer key labels to the permission labels used by the full dashboard. */
    private String dashboardRole(String role) {
        if (role == null) return "SUPPORT_AGENT";
        switch (role) {
            case "MASTER_ADMIN": return "SUPER_ADMIN";
            case "MATCH_OPERATIONS_ADMIN": return "TOURNAMENT_MANAGER";
            case "RESULTS_COINS_ADMIN": return "MODERATOR";
            case "CUSTOMER_SUPPORT_ADMIN": return "SUPPORT_AGENT";
            default: return role;
        }
    }

    private EditText field(String hint, int inputType, int iconRes) {
        EditText field = new EditText(this);
        field.setHint(hint);
        field.setTextColor(TEXT_PRIMARY);
        field.setHintTextColor(TEXT_MUTED);
        field.setTextSize(14);
        field.setSingleLine(true);
        field.setInputType(inputType);
        field.setPadding(dp(16), 0, dp(16), 0);
        field.setBackground(inputFieldDrawable());
        try {
            Drawable icon = getResources().getDrawable(iconRes, getTheme());
            if (icon != null) {
                field.setCompoundDrawablesRelativeWithIntrinsicBounds(icon, null, null, null);
                field.setCompoundDrawablePadding(dp(12));
            }
        } catch (Throwable ignored) {
            // Icon is cosmetic only -- never let it break the login screen.
        }
        return field;
    }

    /** Lifts a view with a visible black elevation shadow (spot/ambient tint on API 28+). */
    private void blackShadow(View view, int elevationDp) {
        view.setElevation(dp(elevationDp));
        if (Build.VERSION.SDK_INT >= 28) {
            view.setOutlineSpotShadowColor(Color.BLACK);
            view.setOutlineAmbientShadowColor(Color.BLACK);
        }
    }

    private TextView label(String text, int size, int color, boolean bold) {
        TextView view = new TextView(this);
        view.setText(text);
        view.setTextSize(size);
        view.setTextColor(color);
        view.setTypeface(null, bold ? Typeface.BOLD : Typeface.NORMAL);
        return view;
    }

    private LinearLayout.LayoutParams params(int width, int height, int top) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(width, height);
        p.topMargin = top;
        return p;
    }

    /** Ensures the native elevation shadow follows the view's rounded-rect shape, not a plain rectangle. */
    private void applyRoundOutline(View view, int radiusDp) {
        view.setOutlineProvider(new ViewOutlineProvider() {
            @Override
            public void getOutline(View v, Outline outline) {
                outline.setRoundRect(0, 0, v.getWidth(), v.getHeight(), dp(radiusDp));
            }
        });
        view.setClipToOutline(false);
    }

    /** Input (corner radius 10dp): light silver fill lifted by a clearly visible soft black shadow
     *  (stacked translucent layers, heavier at the bottom). Focused: white fill, black ring. */
    private StateListDrawable inputFieldDrawable() {
        StateListDrawable states = new StateListDrawable();
        states.addState(new int[]{android.R.attr.state_focused}, inputLayers(true));
        states.addState(new int[]{}, inputLayers(false));
        return states;
    }

    private Drawable inputLayers(boolean focused) {
        int[] alphas = focused ? new int[]{0x14, 0x22, 0x30} : new int[]{0x10, 0x1A, 0x26};
        int[] radii = {14, 13, 12};
        int[] sides = {0, 1, 2};
        int[] bottoms = {0, 1, 2};

        GradientDrawable fill;
        if (focused) {
            fill = new GradientDrawable();
            fill.setColor(Color.WHITE);
            fill.setStroke((int) (1.5f * getResources().getDisplayMetrics().density), INPUT_STROKE);
        } else {
            fill = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                    new int[]{Color.parseColor("#FAFAFB"), Color.parseColor("#F0F0F3")});
        }
        fill.setCornerRadius(dp(10));

        Drawable[] layers = new Drawable[alphas.length + 1];
        for (int i = 0; i < alphas.length; i++) {
            GradientDrawable shadow = new GradientDrawable();
            shadow.setColor(Color.argb(alphas[i], 0, 0, 0));
            shadow.setCornerRadius(dp(radii[i]));
            layers[i] = shadow;
        }
        layers[alphas.length] = fill;

        LayerDrawable layered = new LayerDrawable(layers);
        for (int i = 0; i < alphas.length; i++) {
            layered.setLayerInset(i, dp(sides[i]), dp(3), dp(sides[i]), dp(bottoms[i]));
        }
        layered.setLayerInset(alphas.length, dp(3), 0, dp(3), dp(5));
        return layered;
    }

    /** Black CTA: charcoal -> pure black gradient, no outline (shadow comes from elevation). */
    private Drawable primaryButtonDrawable() {
        GradientDrawable fill = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                new int[]{BTN_DARK_1, BTN_DARK_2, BTN_DARK_3});
        fill.setCornerRadius(dp(10));
        return fill;
    }

    /** White card with a faint top-to-bottom silver gradation, no outline. */
    private Drawable glassPanelDrawable() {
        GradientDrawable fill = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{Color.WHITE, Color.parseColor("#F7F7F9")});
        fill.setCornerRadius(dp(14));
        return fill;
    }

    /** Soft BLACK drop shadow behind the card: stacked translucent rounded rects (same
     *  technique as bg_login_card_glow.xml on the user login screen), built in code so it
     *  needs no drawable resource. Heavier toward the bottom. */
    private Drawable cardShadowDrawable() {
        int[] alphas = {0x0D, 0x12, 0x1A, 0x22, 0x2B};
        int[] radii = {24, 22, 20, 18, 16};
        int[] sides = {0, 2, 4, 6, 8};
        int[] tops = {4, 5, 6, 7, 8};
        int[] bottoms = {0, 1, 3, 5, 8};

        Drawable[] layers = new Drawable[alphas.length];
        for (int i = 0; i < alphas.length; i++) {
            GradientDrawable shape = new GradientDrawable();
            shape.setColor(Color.argb(alphas[i], 0, 0, 0));
            shape.setCornerRadius(dp(radii[i]));
            layers[i] = shape;
        }
        LayerDrawable layered = new LayerDrawable(layers);
        for (int i = 0; i < alphas.length; i++) {
            layered.setLayerInset(i, dp(sides[i]), dp(tops[i]), dp(sides[i]), dp(bottoms[i]));
        }
        return layered;
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    /**
     * Built in code instead of loaded from a drawable resource so it can
     * never throw Resources.NotFoundException at the launcher boundary,
     * regardless of what the packaging toolchain does with XML drawables.
     * Black & white version of the user login canvas: white-to-silver
     * gradient with soft grey glows in the corners, same as
     * bg_login_screen.xml.
     */
    private Drawable loginBackground() {
        return new CirclesBackgroundDrawable();
    }

    /** Black & white canvas: white fading to silver-grey, with soft grey glows in two corners. */
    private static class CirclesBackgroundDrawable extends Drawable {
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);

        @Override
        public void draw(Canvas canvas) {
            Rect bounds = getBounds();
            if (bounds.isEmpty()) return;
            float w = bounds.width();
            float h = bounds.height();

            // Base: white -> light grey -> silver (top to bottom).
            paint.setShader(new LinearGradient(0, 0, 0, h,
                    new int[]{Color.parseColor("#FFFFFF"), Color.parseColor("#F4F4F6"), Color.parseColor("#DADADF")},
                    new float[]{0f, 0.45f, 1f}, Shader.TileMode.CLAMP));
            canvas.drawRect(0, 0, w, h, paint);

            // Soft grey glow, top left.
            float r1 = Math.max(w, h) * 0.42f;
            paint.setShader(new RadialGradient(-w * 0.05f, -h * 0.03f, r1,
                    new int[]{Color.parseColor("#22000000"), Color.parseColor("#0C000000"), Color.parseColor("#00000000")},
                    new float[]{0f, 0.5f, 1f}, Shader.TileMode.CLAMP));
            canvas.drawRect(0, 0, w, h, paint);

            // Soft grey glow, bottom right.
            float r2 = Math.max(w, h) * 0.5f;
            paint.setShader(new RadialGradient(w * 1.02f, h * 1.02f, r2,
                    new int[]{Color.parseColor("#2A000000"), Color.parseColor("#10000000"), Color.parseColor("#00000000")},
                    new float[]{0f, 0.5f, 1f}, Shader.TileMode.CLAMP));
            canvas.drawRect(0, 0, w, h, paint);
            paint.setShader(null);
        }

        @Override
        public void setAlpha(int alpha) {
            paint.setAlpha(alpha);
        }

        @Override
        public void setColorFilter(ColorFilter colorFilter) {
            paint.setColorFilter(colorFilter);
        }

        @Override
        public int getOpacity() {
            return PixelFormat.OPAQUE;
        }
    }

    private void toast(String message) {
        FancyText.toast(this, message, Toast.LENGTH_LONG).show();
    }
}
