package com.arenax.tournament;


import com.arenax.tournament.util.FancyText;
import com.arenax.tournament.util.ImageLoader;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import com.arenax.tournament.data.FirebaseRepository;
import com.arenax.tournament.data.ImgBbUploader;
import com.arenax.tournament.data.StorageUploader;
import com.arenax.tournament.model.GameMode;
import com.bumptech.glide.Glide;
import com.google.android.material.button.MaterialButton;

import java.util.HashMap;
import java.util.Map;

/**
 * Full-screen "Add / Edit category" page, styled as a set of labelled cards
 * (Category Name / Category Image / Image URL / Slot Position / Live Preview)
 * ending in a full-width "CREATE CATEGORY" action — matches the reference
 * mock supplied for this screen. Replaces the previous plain-list layout.
 */
public class CategoryEditorActivity extends BaseActivity {

    public static final String EXTRA_CATEGORY = "category";
    public static final String EXTRA_NEXT_POSITION = "next_position";

    private GameMode existing;
    private boolean editMode;
    private int nextPosition;

    private ImageView imagePreview;
    private EditText nameField;
    private EditText urlField;
    private EditText positionField;

    private ImageView livePreviewImage;
    private TextView livePreviewName;
    private TextView livePreviewSlot;

    private Uri selectedImageUri;
    private String currentImageUrl = "";

    // Fields dropped from this screen's UI (kept as sensible defaults so
    // existing categories aren't reset when re-saved through this page).
    private int existingTotalUsers = 0;
    private boolean existingOnline = true;

    private final ActivityResultLauncher<String> pickImage =
            registerForActivityResult(new ActivityResultContracts.GetContent(), uri -> {
                if (uri != null) {
                    selectedImageUri = uri;
                    imagePreview.setImageURI(uri);
                    livePreviewImage.setImageURI(uri);
                }
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (android.os.Build.VERSION.SDK_INT >= 33) {
            existing = getIntent().getSerializableExtra(EXTRA_CATEGORY, GameMode.class);
        } else {
            existing = (GameMode) getIntent().getSerializableExtra(EXTRA_CATEGORY);
        }
        editMode = existing != null;
        nextPosition = getIntent().getIntExtra(EXTRA_NEXT_POSITION, 1);
        buildUi();
    }

    // ------------------------------------------------------------------
    // Theme helpers
    // ------------------------------------------------------------------

    private int dp(float v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private TextView label(String text, float sizeSp, boolean bold, String hex) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextSize(sizeSp);
        tv.setTypeface(null, bold ? Typeface.BOLD : Typeface.NORMAL);
        tv.setTextColor(Color.parseColor(hex));
        return tv;
    }

    private GradientDrawable roundedFill(String fillHex, String strokeHex, float radiusDp, float strokeDp) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(Color.parseColor(fillHex));
        if (strokeHex != null) d.setStroke(dp(strokeDp), Color.parseColor(strokeHex));
        d.setCornerRadius(dp(radiusDp));
        return d;
    }

    /** A labelled card shell: icon chip + bold title + gray description. Returns the card
     *  so the caller can add its own body content (inputs, previews, etc.) below the header. */
    private LinearLayout card(String iconGlyph, String iconHex, String iconBgHex, String title,
                               String description, boolean tintedCard, String cardFillHex, String cardStrokeHex) {
        LinearLayout cardView = new LinearLayout(this);
        cardView.setOrientation(LinearLayout.VERTICAL);
        cardView.setBackground(roundedFill(
                tintedCard ? cardFillHex : "#FFFFFF",
                tintedCard ? cardStrokeHex : "#374151", 14f, 1f));
        cardView.setPadding(dp(14), dp(14), dp(14), dp(14));
        LinearLayout.LayoutParams cardParams = new LinearLayout.LayoutParams(-1, -2);
        cardParams.topMargin = dp(12);
        cardView.setLayoutParams(cardParams);

        LinearLayout headerRow = new LinearLayout(this);
        headerRow.setOrientation(LinearLayout.HORIZONTAL);
        headerRow.setGravity(Gravity.CENTER_VERTICAL);

        TextView icon = new TextView(this);
        icon.setText(iconGlyph);
        icon.setTextSize(15f);
        icon.setGravity(Gravity.CENTER);
        icon.setTextColor(Color.parseColor(iconHex));
        icon.setBackground(roundedFill(iconBgHex, null, 9f, 0f));
        headerRow.addView(icon, new LinearLayout.LayoutParams(dp(30), dp(30)));

        TextView titleView = label(title, 14.5f, true, "#1C1C1E");
        LinearLayout.LayoutParams titleParams = new LinearLayout.LayoutParams(0, -2, 1f);
        titleParams.leftMargin = dp(10);
        titleView.setLayoutParams(titleParams);
        headerRow.addView(titleView);
        cardView.addView(headerRow);

        TextView desc = label(description, 11.5f, false, "#68686D");
        LinearLayout.LayoutParams descParams = new LinearLayout.LayoutParams(-1, -2);
        descParams.topMargin = dp(4);
        desc.setLayoutParams(descParams);
        desc.setLineSpacing(dp(1.5f), 1f);
        cardView.addView(desc, descParams);

        return cardView;
    }

    private EditText field(String hint) {
        EditText input = new EditText(this);
        input.setHint(hint);
        input.setTextColor(Color.parseColor("#1C1C1E"));
        input.setHintTextColor(Color.parseColor("#A6A4A0"));
        input.setBackground(roundedFill("#FFFFFF", "#374151", 10f, 1f));
        int hPad = dp(14), vPad = dp(13);
        input.setPadding(hPad, vPad, hPad, vPad);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.topMargin = dp(12);
        input.setLayoutParams(p);
        input.setTextSize(13.5f);
        return input;
    }

    // ------------------------------------------------------------------
    // Page
    // ------------------------------------------------------------------

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.parseColor("#F5F4F1"));

        // ---- Top bar ----
        LinearLayout topBar = new LinearLayout(this);
        topBar.setOrientation(LinearLayout.HORIZONTAL);
        topBar.setGravity(Gravity.CENTER_VERTICAL);
        topBar.setPadding(dp(14), dp(14), dp(14), dp(14));
        topBar.setBackgroundColor(Color.parseColor("#FFFFFF"));

        TextView back = new TextView(this);
        back.setText("←");
        back.setTextSize(20f);
        back.setTypeface(null, Typeface.BOLD);
        back.setTextColor(Color.parseColor("#1C1C1E"));
        back.setGravity(Gravity.CENTER);
        back.setBackgroundResource(R.drawable.bg_admin_nav_item);
        back.setLayoutParams(new LinearLayout.LayoutParams(dp(40), dp(40)));
        back.setOnClickListener(v -> finish());
        topBar.addView(back);

        LinearLayout titleCol = new LinearLayout(this);
        titleCol.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams titleColParams = new LinearLayout.LayoutParams(0, -2, 1f);
        titleColParams.leftMargin = dp(12);
        titleCol.setLayoutParams(titleColParams);
        TextView catTitle = label(editMode ? "Edit Category" : "Add Category", 21f, true, "#1C1C1E");
        catTitle.setTag("nofancy");
        catTitle.setText(com.arenax.tournament.util.FancyText.heading(editMode ? "Edit Category" : "Add Category"));
        catTitle.setLetterSpacing(0.01f);
        titleCol.addView(catTitle);
        topBar.addView(titleCol);
        root.addView(topBar);

        View divider = new View(this);
        divider.setBackgroundColor(Color.parseColor("#E5E3DE"));
        root.addView(divider, new LinearLayout.LayoutParams(-1, dp(1)));

        // ---- Body ----
        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(dp(14), dp(4), dp(14), dp(16));

        // Card 1 — Category Name
        LinearLayout nameCard = card("🏷", "#2F6FE0", "#E8F1FF", "Category Name",
                "Enter the name of the category (e.g. Solo, Duo, Squad).", false, null, null);
        nameField = field("Enter category name");
        nameCard.addView(nameField);
        body.addView(nameCard);

        // Card 2 — Category Image
        LinearLayout imageCard = card("🖼", "#2F6FE0", "#E8F1FF", "Category Image",
                "Upload a square image (JPG/PNG). Recommended size: 512x512.", false, null, null);
        LinearLayout imageRow = new LinearLayout(this);
        imageRow.setOrientation(LinearLayout.HORIZONTAL);
        imageRow.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams imageRowParams = new LinearLayout.LayoutParams(-1, -2);
        imageRowParams.topMargin = dp(12);
        imageRow.setLayoutParams(imageRowParams);

        imagePreview = new ImageView(this);
        imagePreview.setScaleType(ImageView.ScaleType.CENTER_CROP);
        imagePreview.setBackground(roundedFill("#F0EFEB", "#374151", 10f, 1f));
        imageRow.addView(imagePreview, new LinearLayout.LayoutParams(dp(64), dp(64)));

        LinearLayout uploadCol = new LinearLayout(this);
        uploadCol.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams uploadColParams = new LinearLayout.LayoutParams(0, -2, 1f);
        uploadColParams.leftMargin = dp(12);
        uploadCol.setLayoutParams(uploadColParams);

        MaterialButton chooseImage = new MaterialButton(this);
        chooseImage.setText("⭱  Upload Image");
        chooseImage.setTextColor(Color.parseColor("#2F6FE0"));
        chooseImage.setAllCaps(false);
        chooseImage.setTextSize(13f);
        chooseImage.setTypeface(null, Typeface.BOLD);
        chooseImage.setBackground(roundedFill("#E8F1FF", null, 10f, 0f));
        chooseImage.setElevation(0f);
        chooseImage.setInsetTop(0);
        chooseImage.setInsetBottom(0);
        chooseImage.setOnClickListener(v -> pickImage.launch("image/*"));
        uploadCol.addView(chooseImage, new LinearLayout.LayoutParams(-1, dp(42)));

        TextView uploadCaption = label("Tap to select an image from your device", 10.5f, false, "#68686D");
        LinearLayout.LayoutParams captionParams = new LinearLayout.LayoutParams(-1, -2);
        captionParams.topMargin = dp(6);
        uploadCol.addView(uploadCaption, captionParams);
        imageRow.addView(uploadCol);
        imageCard.addView(imageRow);
        body.addView(imageCard);

        // Card 3 — Image URL (optional)
        LinearLayout urlCard = card("🔗", "#2F6FE0", "#E8F1FF", "Image URL (Optional)",
                "Paste a public image URL (PNG/JPG) from the internet.", false, null, null);
        urlField = field("https://example.com/image.jpg");
        urlCard.addView(urlField);
        body.addView(urlCard);

        // Card 4 — Slot Position
        LinearLayout slotCard = card("☰", "#2F6FE0", "#E8F1FF", "Slot Position",
                "Set the position in the category list (1, 2, 3…).", false, null, null);
        positionField = field("1");
        positionField.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        slotCard.addView(positionField);
        body.addView(slotCard);

        // Card 5 — Live Preview
        LinearLayout previewCard = card("👁", "#059669", "#D7F3E3", "Live Preview",
                "This is how your category will appear.", true, "#ECFDF5", "#BEE9D2");
        LinearLayout previewRow = new LinearLayout(this);
        previewRow.setOrientation(LinearLayout.HORIZONTAL);
        previewRow.setGravity(Gravity.CENTER_VERTICAL);
        previewRow.setBackground(roundedFill("#FFFFFF", "#374151", 12f, 1f));
        previewRow.setPadding(dp(10), dp(10), dp(10), dp(10));
        LinearLayout.LayoutParams previewRowParams = new LinearLayout.LayoutParams(-1, -2);
        previewRowParams.topMargin = dp(12);
        previewRow.setLayoutParams(previewRowParams);

        livePreviewImage = new ImageView(this);
        livePreviewImage.setScaleType(ImageView.ScaleType.CENTER_CROP);
        livePreviewImage.setBackground(roundedFill("#1C1C1E", null, 10f, 0f));
        previewRow.addView(livePreviewImage, new LinearLayout.LayoutParams(dp(46), dp(46)));

        LinearLayout previewTextCol = new LinearLayout(this);
        previewTextCol.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams previewTextParams = new LinearLayout.LayoutParams(0, -2, 1f);
        previewTextParams.leftMargin = dp(12);
        previewTextCol.setLayoutParams(previewTextParams);
        livePreviewName = label("Category Name", 14f, true, "#1C1C1E");
        previewTextCol.addView(livePreviewName);
        livePreviewSlot = new TextView(this);
        livePreviewSlot.setText("Slot " + nextPosition);
        livePreviewSlot.setTextSize(10.5f);
        livePreviewSlot.setTypeface(null, Typeface.BOLD);
        livePreviewSlot.setTextColor(Color.parseColor("#2F6FE0"));
        livePreviewSlot.setBackground(roundedFill("#E8F1FF", null, 8f, 0f));
        livePreviewSlot.setPadding(dp(8), dp(3), dp(8), dp(3));
        LinearLayout.LayoutParams slotBadgeParams = new LinearLayout.LayoutParams(-2, -2);
        slotBadgeParams.topMargin = dp(5);
        previewTextCol.addView(livePreviewSlot, slotBadgeParams);
        previewRow.addView(previewTextCol);
        previewCard.addView(previewRow);
        body.addView(previewCard);

        // Live-update the preview as the admin types / picks an image.
        nameField.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) {
                livePreviewName.setText(s.toString().trim().isEmpty() ? "Category Name" : s.toString());
            }
            @Override public void afterTextChanged(Editable s) {}
        });
        positionField.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) {
                livePreviewSlot.setText("Slot " + parseIntOr(s.toString().trim(), nextPosition));
            }
            @Override public void afterTextChanged(Editable s) {}
        });
        urlField.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) {
                String url = s.toString().trim();
                if (!url.isEmpty() && selectedImageUri == null) {
                    currentImageUrl = url;
                    ImageLoader.load(imagePreview, url);
                    ImageLoader.load(livePreviewImage, url);
                }
            }
            @Override public void afterTextChanged(Editable s) {}
        });

        // Pre-fill for edit mode
        if (editMode) {
            nameField.setText(existing.getTitle());
            livePreviewName.setText(existing.getTitle());
            positionField.setText(String.valueOf(existing.getDisplayOrder()));
            livePreviewSlot.setText("Slot " + existing.getDisplayOrder());
            existingTotalUsers = existing.getTotalUsers();
            existingOnline = existing.isOnline();
            currentImageUrl = existing.getImageUrl();
            if (currentImageUrl != null && !currentImageUrl.isEmpty()) {
                urlField.setText(currentImageUrl);
                ImageLoader.load(imagePreview, currentImageUrl);
                ImageLoader.load(livePreviewImage, currentImageUrl);
            }
        } else {
            positionField.setText(String.valueOf(nextPosition));
        }

        ScrollView scroll = new ScrollView(this);
        scroll.addView(body);
        scroll.setLayoutParams(new LinearLayout.LayoutParams(-1, 0, 1f));
        root.addView(scroll);

        // ---- Pinned CREATE CATEGORY action ----
        LinearLayout bottomBar = new LinearLayout(this);
        bottomBar.setOrientation(LinearLayout.VERTICAL);
        bottomBar.setPadding(dp(14), dp(12), dp(14), dp(14));
        bottomBar.setBackgroundColor(Color.parseColor("#FFFFFF"));
        View topStroke = new View(this);
        topStroke.setBackgroundColor(Color.parseColor("#E5E3DE"));
        bottomBar.addView(topStroke, new LinearLayout.LayoutParams(-1, dp(1)));

        MaterialButton createButton = new MaterialButton(this);
        createButton.setText(editMode ? "＋  SAVE CATEGORY" : "＋  CREATE CATEGORY");
        createButton.setTextColor(Color.WHITE);
        createButton.setAllCaps(false);
        createButton.setTextSize(14f);
        createButton.setTypeface(null, Typeface.BOLD);
        createButton.setBackground(roundedFill("#22A06B", null, 12f, 0f));
        createButton.setElevation(0f);
        createButton.setInsetTop(0);
        createButton.setInsetBottom(0);
        createButton.setOnClickListener(v -> save());
        LinearLayout.LayoutParams createParams = new LinearLayout.LayoutParams(-1, dp(50));
        createParams.topMargin = dp(12);
        bottomBar.addView(createButton, createParams);
        root.addView(bottomBar);

        setContentView(root);
    }

    // ------------------------------------------------------------------
    // Save — publishes straight to Firebase, same as the old dialog did.
    // ------------------------------------------------------------------

    private void save() {
        String title = nameField.getText().toString().trim();
        if (title.isEmpty()) {
            nameField.setError("Enter a category name");
            return;
        }
        int position = parseIntOr(positionField.getText().toString().trim(), nextPosition);
        int totalUsers = existingTotalUsers;
        boolean online = existingOnline;

        String id = editMode ? existing.getId() : FirebaseRepository.gameModes().push().getKey();
        if (id == null) {
            FancyText.toast(this, "Could not create category key.", Toast.LENGTH_LONG).show();
            return;
        }

        if (selectedImageUri != null) {
            FancyText.toast(this, "Uploading image securely…", Toast.LENGTH_SHORT).show();
            ImgBbUploader.uploadImage(this, selectedImageUri, new StorageUploader.Callback() {
                @Override public void onSuccess(String fileUrl) {
                    persist(id, title, fileUrl, position, online, totalUsers);
                }
                @Override public void onFailure(String message) {
                    FancyText.toast(CategoryEditorActivity.this, "Image upload failed: " + message, Toast.LENGTH_LONG).show();
                }
            });
        } else {
            persist(id, title, currentImageUrl, position, online, totalUsers);
        }
    }

    private void persist(String id, String title, String imageUrl, int position, boolean online, int totalUsers) {
        long createdAt = editMode ? existing.getCreatedAt() : System.currentTimeMillis();
        Map<String, Object> mode = new HashMap<>();
        mode.put("title", title.toUpperCase());
        mode.put("imageUrl", imageUrl);
        mode.put("displayOrder", position);
        mode.put("createdAt", createdAt);
        mode.put("active", true);
        mode.put("online", online);
        mode.put("totalUsers", totalUsers);
        FirebaseRepository.saveGameMode(id, mode)
                .addOnSuccessListener(unused -> {
                    FancyText.toast(this, editMode ? "Category updated." : "Category published. Slot #" + position + ".",
                            Toast.LENGTH_SHORT).show();
                    FirebaseRepository.logActivity(editMode ? "CATEGORY_UPDATED" : "CATEGORY_CREATED",
                            title, "slot #" + position);
                    setResult(RESULT_OK);
                    finish();
                })
                .addOnFailureListener(error ->
                        FancyText.toast(this, "Category save failed: " + error.getMessage(), Toast.LENGTH_LONG).show());
    }

    private int parseIntOr(String raw, int fallback) {
        if (raw == null || raw.isEmpty()) return fallback;
        try {
            return Integer.parseInt(raw);
        } catch (NumberFormatException e) {
            return fallback;
        }
    }
}
