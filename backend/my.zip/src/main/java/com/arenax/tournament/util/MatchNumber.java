package com.arenax.tournament.util;

import java.util.Locale;

/** Creates the same six-digit public match number everywhere from the Firebase key. */
public final class MatchNumber {
    private MatchNumber() { }

    public static String fromId(String id) {
        if (id == null || id.trim().isEmpty()) return "000000";
        String value = id.trim();
        // Daily-mode copies use the key "{seriesId}_{startAtMillis}"; the trailing digits are just a
        // round timestamp (many copies would share them), so hash the whole key for a unique code.
        if (value.contains("_")) {
            return String.format(Locale.ROOT, "%06d", Math.floorMod(value.hashCode(), 1_000_000));
        }
        String digits = value.replaceAll("[^0-9]", "");
        if (digits.length() >= 6) {
            return digits.substring(digits.length() - 6);
        }
        // Firebase push keys are stable but may contain fewer than six digits. Hashing
        // the complete key gives a stable numeric fallback without exposing the key.
        return String.format(Locale.ROOT, "%06d", Math.floorMod(value.hashCode(), 1_000_000));
    }

    public static String label(String id) {
        return "#" + fromId(id);
    }

    private static final java.util.regex.Pattern TRAILING_CODE = java.util.regex.Pattern.compile("\\s*#\\d{6}\\s*$");

    /** True when a stored title already ends with a "#123456" code. */
    public static boolean hasCode(String title) {
        return title != null && TRAILING_CODE.matcher(title).find();
    }

    /** Title without a trailing "#123456" code (so the id-based number is the only one ever shown). */
    public static String stripCode(String title) {
        return title == null ? "" : TRAILING_CODE.matcher(title).replaceAll("").trim();
    }

    /** Title for a daily copy: a "#code" typed into the old title is replaced by the copy's own new number. */
    public static String retitleForCopy(String title, String newId) {
        if (!hasCode(title)) return title == null ? "" : title;
        return stripCode(title) + "  " + label(newId);
    }
}
