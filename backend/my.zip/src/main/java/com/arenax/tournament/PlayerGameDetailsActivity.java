package com.arenax.tournament;


import com.arenax.tournament.util.FancyText;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.arenax.tournament.data.FirebaseRepository;
import com.arenax.tournament.model.Tournament;
import com.arenax.tournament.util.InputValidation;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;

/**
 * Page shown right after slot selection — same layout as the reference screenshot
 * ("Joining Match" header, wallet balance / entry fee / total payable rows, a
 * "Player Game Details" card with inGameName + inGameId fields, CANCEL / SAVE bar)
 * but re-skinned so the section header uses the app's red palette instead of blue.
 *
 * Launched from JoinMatchActivity with:
 *   EXTRA_TOURNAMENT, EXTRA_UID, EXTRA_SLOTS (int[] of the slots already picked).
 */
public class PlayerGameDetailsActivity extends BaseActivity {

    public static final String EXTRA_TOURNAMENT = "tournament";
    public static final String EXTRA_UID = "uid";
    public static final String EXTRA_SLOTS = "slots";
    public static final String EXTRA_PREFILL_NAMES = "prefillNames";
    public static final String EXTRA_PREFILL_IDS = "prefillIds";

    private Tournament tournament;
    private String uid;
    private int[] slots;
    private String[] prefillNames;
    private String[] prefillIds;
    private long currentBalance = 0;
    private TextView balanceValue;
    private DatabaseReference balanceRef;
    private ValueEventListener balanceListener;
    private MaterialButton saveButton;
    private final java.util.Map<Integer, EditText[]> playerFields = new java.util.LinkedHashMap<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        tournament = getIntentTournament();
        uid = getIntent().getStringExtra(EXTRA_UID);
        slots = getIntent().getIntArrayExtra(EXTRA_SLOTS);
        if (tournament == null || uid == null || slots == null || slots.length == 0) {
            finish();
            return;
        }
        prefillNames = getIntent().getStringArrayExtra(EXTRA_PREFILL_NAMES);
        prefillIds = getIntent().getStringArrayExtra(EXTRA_PREFILL_IDS);
        buildUi();
        listenBalance();
    }

    private Tournament getIntentTournament() {
        if (android.os.Build.VERSION.SDK_INT >= 33) {
            return getIntent().getSerializableExtra(EXTRA_TOURNAMENT, Tournament.class);
        }
        return (Tournament) getIntent().getSerializableExtra(EXTRA_TOURNAMENT);
    }

    private int dp(float v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private TextView redText(String text, float sizeSp, boolean bold, String hexColor) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextSize(sizeSp);
        tv.setTypeface(null, bold ? Typeface.BOLD : Typeface.NORMAL);
        tv.setTextColor(Color.parseColor(hexColor));
        return tv;
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundResource(R.drawable.bg_page_navy);

        // ---- Top bar: back arrow + "Joining Match" ----
        LinearLayout topBar = new LinearLayout(this);
        topBar.setOrientation(LinearLayout.HORIZONTAL);
        topBar.setGravity(Gravity.CENTER_VERTICAL);
        topBar.setPadding(dp(14), dp(14), dp(14), dp(14));
        topBar.setBackgroundResource(R.drawable.bg_match_header);

        TextView back = new TextView(this);
        back.setBackgroundResource(R.drawable.bg_section_pill_navy);
        back.setCompoundDrawablesWithIntrinsicBounds(R.drawable.ic_arrow_back, 0, 0, 0);
        back.setPadding(dp(12), dp(10), dp(12), dp(10));
        back.setOnClickListener(v -> finish());
        topBar.addView(back, new LinearLayout.LayoutParams(-2, -2));

        TextView title = redText("Joining Match", 19f, true, "#FFFFFF");
        title.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams titleParams = new LinearLayout.LayoutParams(0, -2, 1f);
        titleParams.leftMargin = dp(8);
        title.setLayoutParams(titleParams);
        topBar.addView(title);
        root.addView(topBar);

        // ---- Scrollable body ----
        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(dp(20), dp(20), dp(20), dp(20));

        // Wallet row: icon + balance / fee / total
        LinearLayout walletRow = new LinearLayout(this);
        walletRow.setOrientation(LinearLayout.HORIZONTAL);
        walletRow.setGravity(Gravity.CENTER_VERTICAL);

        TextView walletIcon = new TextView(this);
        walletIcon.setCompoundDrawablesWithIntrinsicBounds(R.drawable.ic_wallet_outline, 0, 0, 0);
        LinearLayout.LayoutParams iconParams = new LinearLayout.LayoutParams(dp(56), dp(56));
        iconParams.rightMargin = dp(14);
        walletIcon.setLayoutParams(iconParams);
        walletIcon.setBackgroundResource(R.drawable.background_wallet);
        walletIcon.setGravity(Gravity.CENTER);
        walletRow.addView(walletIcon);

        LinearLayout walletTextCol = new LinearLayout(this);
        walletTextCol.setOrientation(LinearLayout.VERTICAL);
        walletTextCol.setLayoutParams(new LinearLayout.LayoutParams(0, -2, 1f));

        int perSlotFee = tournament.getEntryFeeCoins();
        int totalFee = perSlotFee * slots.length;

        balanceValue = redText("Your Current Balance : \uD83E\uDE99 …", 15f, false, "#F2F5FC");
        walletTextCol.addView(balanceValue);

        TextView feeRow = redText("Entry Fee Per Person : \uD83E\uDE99 " + perSlotFee, 15f, false, "#F2F5FC");
        LinearLayout.LayoutParams feeParams = new LinearLayout.LayoutParams(-1, -2);
        feeParams.topMargin = dp(10);
        feeRow.setLayoutParams(feeParams);
        walletTextCol.addView(feeRow);

        TextView totalRow = redText("Total Payable Amount : \uD83E\uDE99 " + totalFee, 15f, false, "#F2F5FC");
        LinearLayout.LayoutParams totalParams = new LinearLayout.LayoutParams(-1, -2);
        totalParams.topMargin = dp(10);
        totalRow.setLayoutParams(totalParams);
        walletTextCol.addView(totalRow);

        walletRow.addView(walletTextCol);
        body.addView(walletRow);

        // Player Game Details card(s) — one per selected slot
        String lastGameName = getSharedPreferences("arenax_profile", MODE_PRIVATE)
                .getString("last_game_name", "");
        java.util.Arrays.sort(slots);
        for (int i = 0; i < slots.length; i++) {
            final int slot = slots[i];
            LinearLayout card = new LinearLayout(this);
            card.setOrientation(LinearLayout.VERTICAL);
            card.setBackgroundResource(R.drawable.bg_card_navy);
            LinearLayout.LayoutParams cardParams = new LinearLayout.LayoutParams(-1, -2);
            cardParams.topMargin = dp(22);
            card.setLayoutParams(cardParams);

            // Header bar — red instead of blue.
            TextView header = redText(slots.length > 1
                    ? "Player Game Details — Slot " + slot : "Player Game Details", 17f, true, "#FFFFFF");
            header.setGravity(Gravity.CENTER);
            header.setBackgroundResource(R.drawable.bg_section_header_red);
            header.setPadding(dp(14), dp(14), dp(14), dp(14));
            card.addView(header);

            LinearLayout inner = new LinearLayout(this);
            inner.setOrientation(LinearLayout.VERTICAL);
            inner.setPadding(dp(14), dp(16), dp(14), dp(14));

            inner.addView(redText("inGameName", 13f, false, "#B39EA5"));
            EditText nameField = new EditText(this);
            nameField.setTextColor(Color.parseColor("#F2F5FC"));
            nameField.setPadding(dp(4), dp(10), dp(4), dp(10));
            nameField.setBackgroundResource(android.R.color.transparent);
            String prefillName = (prefillNames != null && i < prefillNames.length && prefillNames[i] != null
                    && !prefillNames[i].isEmpty()) ? prefillNames[i]
                    : (i == 0 ? lastGameName : "");
            if (!prefillName.isEmpty()) nameField.setText(prefillName);
            LinearLayout.LayoutParams nameParams = new LinearLayout.LayoutParams(-1, -2);
            nameParams.topMargin = dp(4);
            nameParams.bottomMargin = dp(16);
            nameField.setLayoutParams(nameParams);
            inner.addView(nameField);
            inner.addView(dividerLine());

            LinearLayout.LayoutParams idLabelParams = new LinearLayout.LayoutParams(-1, -2);
            idLabelParams.topMargin = dp(16);
            TextView idLabel = redText("inGameId", 13f, false, "#B39EA5");
            idLabel.setLayoutParams(idLabelParams);
            inner.addView(idLabel);
            EditText idField = new EditText(this);
            idField.setTextColor(Color.parseColor("#F2F5FC"));
            idField.setPadding(dp(4), dp(10), dp(4), dp(10));
            idField.setBackgroundResource(android.R.color.transparent);
            LinearLayout.LayoutParams idParams = new LinearLayout.LayoutParams(-1, -2);
            idParams.topMargin = dp(4);
            idField.setLayoutParams(idParams);
            String prefillId = (prefillIds != null && i < prefillIds.length && prefillIds[i] != null)
                    ? prefillIds[i] : "";
            if (!prefillId.isEmpty()) idField.setText(prefillId);
            inner.addView(idField);
            inner.addView(dividerLine());

            card.addView(inner);
            body.addView(card);
            playerFields.put(slot, new EditText[]{nameField, idField});
        }

        TextView note = redText("Make sure you have entered correct inGameName & inGameId",
                13.5f, false, "#F2F5FC");
        LinearLayout.LayoutParams noteParams = new LinearLayout.LayoutParams(-1, -2);
        noteParams.topMargin = dp(20);
        note.setLayoutParams(noteParams);
        body.addView(note);

        ScrollView scroll = new ScrollView(this);
        scroll.addView(body);
        scroll.setLayoutParams(new LinearLayout.LayoutParams(-1, 0, 1f));
        root.addView(scroll);

        // ---- Bottom CANCEL / SAVE bar ----
        LinearLayout bottomBar = new LinearLayout(this);
        bottomBar.setOrientation(LinearLayout.HORIZONTAL);
        bottomBar.setGravity(Gravity.CENTER_VERTICAL);
        bottomBar.setPadding(dp(20), dp(16), dp(20), dp(20));

        MaterialButton cancelButton = new MaterialButton(this);
        cancelButton.setText("CANCEL");
        cancelButton.setTextColor(Color.WHITE);
        cancelButton.setAllCaps(false);
        cancelButton.setTypeface(null, Typeface.BOLD);
        cancelButton.setBackgroundResource(R.drawable.bg_button_cancel_pink);
        cancelButton.setElevation(0f);
        cancelButton.setInsetTop(0);
        cancelButton.setInsetBottom(0);
        LinearLayout.LayoutParams cancelParams = new LinearLayout.LayoutParams(0, dp(52), 1f);
        cancelParams.rightMargin = dp(10);
        cancelButton.setLayoutParams(cancelParams);
        cancelButton.setOnClickListener(v -> {
            setResult(RESULT_CANCELED);
            finish();
        });
        bottomBar.addView(cancelButton);

        saveButton = new MaterialButton(this);
        saveButton.setText("SAVE");
        saveButton.setTextColor(Color.WHITE);
        saveButton.setAllCaps(false);
        saveButton.setTypeface(null, Typeface.BOLD);
        saveButton.setBackgroundResource(R.drawable.bg_button_green);
        saveButton.setElevation(0f);
        saveButton.setInsetTop(0);
        saveButton.setInsetBottom(0);
        LinearLayout.LayoutParams saveParams = new LinearLayout.LayoutParams(0, dp(52), 1f);
        saveParams.leftMargin = dp(10);
        saveButton.setLayoutParams(saveParams);
        saveButton.setOnClickListener(v -> attemptSave());
        bottomBar.addView(saveButton);

        root.addView(bottomBar);
        setContentView(root);
    }

    private android.view.View dividerLine() {
        android.view.View line = new android.view.View(this);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, dp(1));
        line.setLayoutParams(p);
        line.setBackgroundColor(Color.parseColor("#4A1C26"));
        return line;
    }

    private void listenBalance() {
        balanceRef = FirebaseRepository.users().child(uid).child("wallet").child("balance");
        balanceListener = new ValueEventListener() {
            @Override public void onDataChange(DataSnapshot snap) {
                Long bal = snap.getValue(Long.class);
                currentBalance = bal == null ? 0 : bal;
                balanceValue.setText("Your Current Balance : \uD83E\uDE99 " + currentBalance);
            }
            @Override public void onCancelled(DatabaseError error) {
                balanceValue.setText("Your Current Balance : unavailable");
            }
        };
        balanceRef.addValueEventListener(balanceListener);
    }

    private void attemptSave() {
        java.util.Arrays.sort(slots);
        String[] namesToJoin = new String[slots.length];
        String[] uidsToJoin = new String[slots.length];
        boolean missing = false;
        for (int i = 0; i < slots.length; i++) {
            EditText[] fields = playerFields.get(slots[i]);
            String nameValue = fields == null ? "" : InputValidation.value(fields[0]);
            String idValue = fields == null ? "" : InputValidation.value(fields[1]);
            if (nameValue.isEmpty()) {
                if (fields != null) fields[0].setError("Required");
                missing = true;
            }
            if (idValue.isEmpty()) {
                if (fields != null) fields[1].setError("Required");
                missing = true;
            }
            namesToJoin[i] = nameValue;
            uidsToJoin[i] = idValue;
        }
        if (missing) {
            FancyText.toast(this, "Please fill inGameName & inGameId for every slot.", Toast.LENGTH_SHORT).show();
            return;
        }
        saveButton.setEnabled(false);
        saveButton.setText("SAVING…");
        final String primaryName = namesToJoin[0];
        FirebaseDirectJoinClient.joinMatch(tournament, slots, uidsToJoin, namesToJoin,
                new FirebaseDirectJoinClient.JoinCallback() {
                    @Override public void onSuccess(int[] slotNumbers, int entryFeeCoins) {
                        getSharedPreferences("arenax_profile", MODE_PRIVATE)
                                .edit().putString("last_game_name", primaryName).apply();
                        setResult(RESULT_OK);
                        FancyText.toast(PlayerGameDetailsActivity.this,
                                "You're in! " + entryFeeCoins + " coins deducted.", Toast.LENGTH_LONG).show();
                        Intent detailsIntent = new Intent(PlayerGameDetailsActivity.this, MatchJoinedActivity.class)
                                .putExtra(EXTRA_TOURNAMENT, tournament);
                        startActivity(detailsIntent);
                        finish();
                    }

                    @Override public void onAlreadyRegistered() {
                        setResult(RESULT_OK);
                        FancyText.toast(PlayerGameDetailsActivity.this,
                                "You're already registered for this match.", Toast.LENGTH_LONG).show();
                        Intent detailsIntent = new Intent(PlayerGameDetailsActivity.this, MatchJoinedActivity.class)
                                .putExtra(EXTRA_TOURNAMENT, tournament);
                        startActivity(detailsIntent);
                        finish();
                    }

                    @Override public void onError(String message) {
                        saveButton.setEnabled(true);
                        saveButton.setText("SAVE");
                        final String reason = message == null ? "Could not register right now." : message;
                        MaterialAlertDialogBuilder builder =
                                new FancyText.MaterialBuilder(PlayerGameDetailsActivity.this)
                                        .setTitle("Could not join match")
                                        .setMessage(reason)
                                        .setPositiveButton("OK", null);
                        if (reason.toLowerCase(java.util.Locale.ROOT).contains("but need")) {
                            builder.setNegativeButton("ADD COINS", (d, which) ->
                                    startActivity(new Intent(PlayerGameDetailsActivity.this, WalletActivity.class)));
                        }
                        builder.show();
                    }
                });
    }

    @Override
    protected void onDestroy() {
        if (balanceRef != null && balanceListener != null) {
            balanceRef.removeEventListener(balanceListener);
        }
        super.onDestroy();
    }
}
