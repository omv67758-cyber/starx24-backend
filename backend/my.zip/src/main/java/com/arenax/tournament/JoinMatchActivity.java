package com.arenax.tournament;


import com.arenax.tournament.util.FancyText;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.style.ForegroundColorSpan;
import android.widget.ImageView;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.arenax.tournament.data.FirebaseRepository;
import com.arenax.tournament.model.Tournament;
import com.arenax.tournament.util.InputValidation;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;

/**
 * Single combined slot screen — tick a slot, then fill the in-game name + UID. Fixed page (no
 * page scroll): the slot list and the game-details card each scroll inside their own card.
 * Same light / dark-halo look as the Contest Details page (no outlines, dark shadows).
 *
 * Launched from TournamentDetailActivity with:
 *   putExtra("tournament", tournament) and putExtra("uid", uid).
 */
public class JoinMatchActivity extends BaseActivity {

    public static final String EXTRA_TOURNAMENT = "tournament";
    public static final String EXTRA_UID = "uid";

    private Tournament tournament;
    private String uid;
    private boolean isTeamMode;
    private int selectionCap;
    private int perSlotFee;

    private LinearLayout teamListContainer;
    private LinearLayout playerDetailsContainer;
    private TextView counterPill;
    private MaterialButton joinNowButton;

    private long currentBalance = 0;
    private boolean balanceLoaded = false;
    private DatabaseReference balanceRef;
    private ValueEventListener balanceListener;

    private final java.util.List<Integer> selectedSlots = new java.util.ArrayList<>();
    private final java.util.Map<Integer, EditText[]> playerFields = new java.util.LinkedHashMap<>();
    private final java.util.Map<Integer, String[]> savedPlayerValues = new java.util.LinkedHashMap<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // The payment/match backend (Render free tier) can go to sleep after a few
        // minutes idle and take 20-50s to wake on the next request. Waking it here,
        // the moment the join screen opens, means it's usually already warm by the
        // time the player finishes picking slots and taps JOIN NOW.
        ZapUpiClient.warmUp();
        if (!FirebaseRepository.isReady(this)) {
            FancyText.toast(this, "Live services are unavailable. Please try again later.", Toast.LENGTH_LONG).show();
            finish();
            return;
        }
        tournament = getIntentTournament();
        if (tournament == null) {
            finish();
            return;
        }
        if (tournament.hasStarted()) {
            FancyText.toast(this, "Match has started. Joining is closed.", Toast.LENGTH_LONG).show();
            finish();
            return;
        }
        uid = getIntent().getStringExtra(EXTRA_UID);
        if (uid == null || uid.isEmpty()) {
            FancyText.toast(this, "Please sign in before joining.", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }
        int teamSize = Math.max(1, tournament.getTeamSize());
        isTeamMode = teamSize > 1;
        // SOLO = exactly 1 slot, DUO = 1 to 2, SQUAD = 1 to 4 (the match team size is the cap).
        selectionCap = teamSize;
        perSlotFee = tournament.getEntryFeeCoins();
        buildUi();
        loadTakenSlots();
        listenBalance();
    }

    private Tournament getIntentTournament() {
        if (android.os.Build.VERSION.SDK_INT >= 33) {
            return getIntent().getSerializableExtra(EXTRA_TOURNAMENT, Tournament.class);
        }
        return (Tournament) getIntent().getSerializableExtra(EXTRA_TOURNAMENT);
    }

    // ------------------------------------------------------------------
    // UI helpers
    // ------------------------------------------------------------------

    private int dp(float v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private static final int INK = 0xFF1B1446;
    private static final int MUTED = 0xFF7A7FA3;
    private static final int VIOLET = 0xFF6D4AFF;

    private int col(int colorRes) {
        return ContextCompat.getColor(this, colorRes);
    }

    private TextView text(String value, float sizeSp, boolean bold, int colorRes) {
        TextView tv = new TextView(this);
        tv.setText(value);
        tv.setTextSize(sizeSp);
        tv.setTypeface(null, bold ? Typeface.BOLD : Typeface.NORMAL);
        tv.setTextColor(col(colorRes));
        return tv;
    }

    private View divider() {
        View line = new View(this);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(1));
        lp.leftMargin = dp(12);
        lp.rightMargin = dp(12);
        line.setLayoutParams(lp);
        line.setBackgroundColor(0xFFE6E4FA);
        return line;
    }

    /** ScrollView that never grows taller than maxHeightPx (used so the game-details card
     *  scrolls inside itself instead of pushing the whole page). */
    private static class MaxHeightScrollView extends ScrollView {
        private int maxHeightPx = Integer.MAX_VALUE;

        MaxHeightScrollView(android.content.Context context) {
            super(context);
        }

        void setMaxHeightPx(int px) {
            maxHeightPx = px;
        }

        @Override
        protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
            int mode = View.MeasureSpec.getMode(heightMeasureSpec);
            int size = View.MeasureSpec.getSize(heightMeasureSpec);
            int capped = mode == View.MeasureSpec.UNSPECIFIED ? maxHeightPx : Math.min(size, maxHeightPx);
            super.onMeasure(widthMeasureSpec,
                    View.MeasureSpec.makeMeasureSpec(capped, View.MeasureSpec.AT_MOST));
        }
    }

    /** White rounded card, NO outline - a dark halo shadow is baked into bg_cd_card.
     *  20dp padding = 4dp halo + 16dp content; 12dp side margin keeps the visible edge 16dp from the screen. */
    private LinearLayout haloCard() {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setBackgroundResource(R.drawable.bg_join_card);
        card.setPadding(dp(20), dp(20), dp(20), dp(20));
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, -2);
        params.setMargins(dp(12), dp(8), dp(12), 0);
        card.setLayoutParams(params);
        return card;
    }

    private void tintIcon(ImageView icon, int colorRes) {
        icon.setImageTintList(ColorStateList.valueOf(col(colorRes)));
    }

    // ------------------------------------------------------------------
    // Page layout - fixed screen (no page scroll). Only the slot list and the
    // game-details card scroll, each inside its own card.
    // ------------------------------------------------------------------

    private View headerView;

    private void buildUi() {
        getWindow().setStatusBarColor(0xFF5B21D9);
        getWindow().setNavigationBarColor(0xFF2C7BF3);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundResource(R.drawable.bg_login_screen);

        headerView = buildHeader();
        root.addView(headerView);
        root.addView(buildSelectPositionCard());
        root.addView(buildPlayerDetailsCard());
        root.addView(buildBottomBar());

        // Keep the header below the status bar and lift the whole page above the keyboard /
        // navigation bar, so the fields being typed in are never covered.
        ViewCompat.setOnApplyWindowInsetsListener(root, (v, insets) -> {
            Insets bars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            Insets ime = insets.getInsets(WindowInsetsCompat.Type.ime());
            headerView.setPadding(dp(12), bars.top + dp(10), dp(16), dp(6));
            v.setPadding(0, 0, 0, Math.max(ime.bottom, bars.bottom));
            return insets;
        });

        rebuildPlayerDetailsUi();
        refreshJoinLabel();
        setContentView(root);
        ViewCompat.requestApplyInsets(root);
    }

    /** Only a back button - the old "Join Tournament" title + subtitle are gone. */
    private View buildHeader() {
        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(dp(12), dp(34), dp(16), dp(6));
        header.setLayoutParams(new LinearLayout.LayoutParams(-1, -2));

        ImageView back = new ImageView(this);
        back.setLayoutParams(new LinearLayout.LayoutParams(dp(46), dp(46)));
        back.setBackgroundResource(R.drawable.bg_join_back);
        back.setElevation(dp(4));
        back.setImageResource(R.drawable.ic_cd_back);
        back.setImageTintList(ColorStateList.valueOf(VIOLET));
        back.setPadding(dp(14), dp(14), dp(14), dp(14));
        back.setContentDescription("Back");
        back.setOnClickListener(v -> finish());
        header.addView(back);
        return header;
    }

    /** "Select Match Position" card. Takes all the free height of the screen; the slot rows
     *  scroll INSIDE this card. */
    private View buildSelectPositionCard() {
        LinearLayout card = haloCard();
        LinearLayout.LayoutParams cardParams = new LinearLayout.LayoutParams(-1, 0, 1f);
        cardParams.setMargins(dp(12), dp(8), dp(12), 0);
        card.setLayoutParams(cardParams);

        LinearLayout headerRow = new LinearLayout(this);
        headerRow.setOrientation(LinearLayout.HORIZONTAL);
        headerRow.setGravity(Gravity.CENTER_VERTICAL);

        ImageView icon = new ImageView(this);
        icon.setImageResource(R.drawable.ic_cd_target);
        LinearLayout.LayoutParams iconParams = new LinearLayout.LayoutParams(dp(24), dp(24));
        iconParams.rightMargin = dp(12);
        icon.setLayoutParams(iconParams);
        headerRow.addView(icon);

        TextView label = text("Select Match Position", 16f, true, R.color.cd_ink);
        label.setTextColor(INK);
        label.setLayoutParams(new LinearLayout.LayoutParams(0, -2, 1f));
        headerRow.addView(label);

        counterPill = text("0/" + selectionCap, 12f, true, R.color.cd_blue);
        counterPill.setTextColor(0xFFFFFFFF);
        counterPill.setBackgroundResource(R.drawable.bg_join_pill);
        counterPill.setPadding(dp(12), dp(5), dp(12), dp(5));
        headerRow.addView(counterPill);
        card.addView(headerRow);

        View topLine = new View(this);
        LinearLayout.LayoutParams lineParams = new LinearLayout.LayoutParams(-1, dp(1));
        lineParams.topMargin = dp(14);
        topLine.setLayoutParams(lineParams);
        topLine.setBackgroundColor(0xFFE6E4FA);
        card.addView(topLine);

        ScrollView slotScroll = new ScrollView(this);
        slotScroll.setLayoutParams(new LinearLayout.LayoutParams(-1, 0, 1f));
        slotScroll.setVerticalScrollBarEnabled(true);
        slotScroll.setVerticalFadingEdgeEnabled(true);
        slotScroll.setFadingEdgeLength(dp(24));
        slotScroll.setOverScrollMode(View.OVER_SCROLL_NEVER);

        teamListContainer = new LinearLayout(this);
        teamListContainer.setOrientation(LinearLayout.VERTICAL);
        teamListContainer.setPadding(0, dp(6), 0, dp(6));
        slotScroll.addView(teamListContainer, new ViewGroup.LayoutParams(-1, -2));
        card.addView(slotScroll);
        return card;
    }

    /** "Player Game Details" card: header + fields for each ticked slot (scrolls inside the card
     *  once more than ~2 slots are ticked) + a small reminder line. */
    private View buildPlayerDetailsCard() {
        LinearLayout card = haloCard();

        LinearLayout headerRow = new LinearLayout(this);
        headerRow.setOrientation(LinearLayout.HORIZONTAL);
        headerRow.setGravity(Gravity.CENTER_VERTICAL);

        ImageView icon = new ImageView(this);
        icon.setBackgroundResource(R.drawable.bg_join_icon_circle);
        icon.setImageResource(R.drawable.ic_cd_gamepad);
        icon.setPadding(dp(8), dp(8), dp(8), dp(8));
        icon.setImageTintList(ColorStateList.valueOf(VIOLET));
        LinearLayout.LayoutParams iconParams = new LinearLayout.LayoutParams(dp(36), dp(36));
        iconParams.rightMargin = dp(12);
        icon.setLayoutParams(iconParams);
        headerRow.addView(icon);

        LinearLayout titleCol = new LinearLayout(this);
        titleCol.setOrientation(LinearLayout.VERTICAL);
        TextView detailsTitle = text("Player Game Details", 16f, true, R.color.cd_ink);
        detailsTitle.setTextColor(INK);
        titleCol.addView(detailsTitle);
        TextView sub = text("Enter your in-game name & UID", 12f, false, R.color.cd_muted);
        LinearLayout.LayoutParams subParams = new LinearLayout.LayoutParams(-2, -2);
        subParams.topMargin = dp(1);
        sub.setLayoutParams(subParams);
        titleCol.addView(sub);
        headerRow.addView(titleCol);
        card.addView(headerRow);

        MaxHeightScrollView detailsScroll = new MaxHeightScrollView(this);
        detailsScroll.setMaxHeightPx(Math.min(dp(230), (int) (getResources().getDisplayMetrics().heightPixels * 0.34f)));
        detailsScroll.setVerticalScrollBarEnabled(true);
        detailsScroll.setVerticalFadingEdgeEnabled(true);
        detailsScroll.setFadingEdgeLength(dp(20));
        detailsScroll.setOverScrollMode(View.OVER_SCROLL_NEVER);
        LinearLayout.LayoutParams scrollParams = new LinearLayout.LayoutParams(-1, -2);
        scrollParams.topMargin = dp(14);
        detailsScroll.setLayoutParams(scrollParams);

        playerDetailsContainer = new LinearLayout(this);
        playerDetailsContainer.setOrientation(LinearLayout.VERTICAL);
        detailsScroll.addView(playerDetailsContainer, new ViewGroup.LayoutParams(-1, -2));
        card.addView(detailsScroll);

        TextView note = text("Make sure your in-game name & UID are correct", 11f, false, R.color.cd_muted);
        LinearLayout.LayoutParams noteParams = new LinearLayout.LayoutParams(-2, -2);
        noteParams.topMargin = dp(10);
        note.setLayoutParams(noteParams);
        card.addView(note);
        return card;
    }

    /** JOIN NOW (dark pill, full width). The extra CANCEL button was removed - the top-left back arrow already exits. */
    private View buildBottomBar() {
        LinearLayout bottomBar = new LinearLayout(this);
        bottomBar.setOrientation(LinearLayout.HORIZONTAL);
        bottomBar.setGravity(Gravity.CENTER_VERTICAL);
        bottomBar.setPadding(dp(12), dp(10), dp(12), dp(10));

        FrameLayout joinWrap = new FrameLayout(this);
        joinWrap.setBackgroundResource(R.drawable.bg_join_button_halo);
        joinWrap.setPadding(dp(4), dp(4), dp(4), dp(4));
        joinWrap.setLayoutParams(new LinearLayout.LayoutParams(-1, -2));

        joinNowButton = new MaterialButton(this);
        joinNowButton.setText("JOIN NOW");
        joinNowButton.setTextColor(0xFFFFFFFF);
        joinNowButton.setBackgroundTintList(null);
        joinNowButton.setAllCaps(false);
        joinNowButton.setTypeface(null, Typeface.BOLD);
        joinNowButton.setBackgroundResource(R.drawable.bg_join_button);
        joinNowButton.setElevation(0f);
        joinNowButton.setInsetTop(0);
        joinNowButton.setInsetBottom(0);
        joinNowButton.setLayoutParams(new FrameLayout.LayoutParams(-1, dp(54)));
        joinNowButton.setOnClickListener(v -> attemptJoin());
        joinWrap.addView(joinNowButton);
        bottomBar.addView(joinWrap);

        return bottomBar;
    }

    /** "JOIN NOW" or "JOIN NOW  •  92 coins" (price in accent blue) once slots are ticked. */
    private void refreshJoinLabel() {
        if (joinNowButton == null) return;
        int count = selectedSlots.size();
        String head = "JOIN NOW";
        if (count == 0) {
            joinNowButton.setText(head);
            return;
        }
        long total = (long) perSlotFee * count;
        String sep = "  \u2022  ";
        String tail = total > 0 ? total + " coins" : "FREE";
        SpannableString label = new SpannableString(head + sep + tail);
        label.setSpan(new ForegroundColorSpan(0xFFFFE066),
                head.length() + sep.length(), label.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        joinNowButton.setText(label);
    }

    // ------------------------------------------------------------------
    // Team / slot list
    // ------------------------------------------------------------------

    private void loadTakenSlots() {
        FirebaseRepository.tournaments().child(tournament.getId()).child("slotIndex").get()
                .addOnSuccessListener(slotSnapshot -> {
                    java.util.Set<Integer> takenSlots = new java.util.HashSet<>();
                    for (com.google.firebase.database.DataSnapshot child : slotSnapshot.getChildren()) {
                        try {
                            takenSlots.add(Integer.parseInt(child.getKey()));
                        } catch (NumberFormatException ignored) {
                        }
                    }
                    buildSlotGrid(takenSlots);
                })
                .addOnFailureListener(error -> buildSlotGrid(new java.util.HashSet<>()));
    }

    private void buildSlotGrid(final java.util.Set<Integer> takenSlots) {
        if (teamListContainer == null) return;
        teamListContainer.removeAllViews();
        selectedSlots.clear();
        int totalSlots = Math.max(1, tournament.getTotalSlots());

        for (int slot = 1; slot <= totalSlots; slot++) {
            if (slot > 1) teamListContainer.addView(divider());
            final boolean taken = takenSlots.contains(slot);
            teamListContainer.addView(buildTeamRow(slot, taken));
        }
        updateCounterAndTotal();
    }

    /** One slot row: name, (team size), and a round tick. Tap anywhere on the row to tick it. */
    private View buildTeamRow(final int slot, final boolean taken) {
        int teamSize = Math.max(1, tournament.getTeamSize());
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(12), dp(12), dp(12), dp(12));

        TextView label = text((isTeamMode ? "Team " : "Slot ") + slot, 15f, true,
                taken ? R.color.cd_muted : R.color.cd_ink);
        label.setTextColor(taken ? MUTED : INK);
        label.setLayoutParams(new LinearLayout.LayoutParams(0, -2, 1f));
        row.addView(label);

        if (isTeamMode) {
            ImageView people = new ImageView(this);
            people.setImageResource(R.drawable.ic_cd_users);
            tintIcon(people, R.color.cd_muted);
            LinearLayout.LayoutParams peopleParams = new LinearLayout.LayoutParams(dp(16), dp(16));
            peopleParams.rightMargin = dp(4);
            people.setLayoutParams(peopleParams);
            row.addView(people);

            TextView count = text(String.valueOf(teamSize), 14f, true, R.color.cd_muted);
            LinearLayout.LayoutParams countParams = new LinearLayout.LayoutParams(-2, -2);
            countParams.rightMargin = dp(14);
            count.setLayoutParams(countParams);
            row.addView(count);
        }

        if (taken) {
            TextView takenTag = text("TAKEN", 10f, true, R.color.cd_muted);
            takenTag.setLetterSpacing(0.06f);
            LinearLayout.LayoutParams tagParams = new LinearLayout.LayoutParams(-2, -2);
            tagParams.rightMargin = dp(10);
            takenTag.setLayoutParams(tagParams);
            row.addView(takenTag);
        }

        final View tick = new View(this);
        tick.setLayoutParams(new LinearLayout.LayoutParams(dp(28), dp(28)));
        row.addView(tick);

        if (taken) {
            tick.setBackgroundResource(R.drawable.bg_cd_tick_taken);
        } else {
            boolean picked = selectedSlots.contains(slot);
            tick.setBackgroundResource(picked ? R.drawable.bg_join_tick_on : R.drawable.bg_join_tick_off);
            row.setBackgroundResource(picked ? R.drawable.bg_join_row_selected : R.drawable.bg_join_row);
            row.setOnClickListener(v -> {
                if (selectedSlots.contains(slot)) {
                    selectedSlots.remove((Integer) slot);
                    tick.setBackgroundResource(R.drawable.bg_join_tick_off);
                    row.setBackgroundResource(R.drawable.bg_join_row);
                } else {
                    if (selectedSlots.size() >= selectionCap) {
                        FancyText.toast(this, teamSize == 1
                                        ? "This is a SOLO match - only 1 slot is allowed."
                                        : "This is a " + (teamSize == 2 ? "DUO" : "SQUAD") + " match - you can select 1 to " + teamSize + " slots.",
                                Toast.LENGTH_SHORT).show();
                        return;
                    }
                    selectedSlots.add(slot);
                    tick.setBackgroundResource(R.drawable.bg_join_tick_on);
                    row.setBackgroundResource(R.drawable.bg_join_row_selected);
                }
                updateCounterAndTotal();
                rebuildPlayerDetailsUi();
            });
        }
        return row;
    }

    private void updateCounterAndTotal() {
        if (counterPill != null) counterPill.setText(selectedSlots.size() + "/" + selectionCap);
        refreshJoinLabel();
    }

    // ------------------------------------------------------------------
    // Player Game Details - one block (name + UID) per currently-ticked slot
    // ------------------------------------------------------------------

    private void rebuildPlayerDetailsUi() {
        if (playerDetailsContainer == null) return;

        // Preserve anything already typed before we throw the old EditTexts away.
        for (java.util.Map.Entry<Integer, EditText[]> entry : playerFields.entrySet()) {
            EditText[] fields = entry.getValue();
            savedPlayerValues.put(entry.getKey(),
                    new String[]{InputValidation.value(fields[0]), InputValidation.value(fields[1])});
        }
        playerFields.clear();
        playerDetailsContainer.removeAllViews();

        if (selectedSlots.isEmpty()) {
            TextView msg = text("Tick a slot above to enter your game details", 13f, false, R.color.cd_muted);
            msg.setGravity(Gravity.CENTER);
            msg.setPadding(0, dp(18), 0, dp(10));
            playerDetailsContainer.addView(msg, new LinearLayout.LayoutParams(-1, -2));
            return;
        }

        String lastGameName = getSharedPreferences("arenax_profile", MODE_PRIVATE)
                .getString("last_game_name", "");
        java.util.List<Integer> sortedSlots = new java.util.ArrayList<>(selectedSlots);
        java.util.Collections.sort(sortedSlots);

        for (int i = 0; i < sortedSlots.size(); i++) {
            final int slot = sortedSlots.get(i);

            LinearLayout block = new LinearLayout(this);
            block.setOrientation(LinearLayout.VERTICAL);
            LinearLayout.LayoutParams blockParams = new LinearLayout.LayoutParams(-1, -2);
            blockParams.topMargin = i == 0 ? 0 : dp(16);
            block.setLayoutParams(blockParams);

            TextView tag = text((isTeamMode ? "Team " : "Slot ") + slot, 12f, true, R.color.cd_blue);
            tag.setTextColor(0xFFFFFFFF);
            tag.setBackgroundResource(R.drawable.bg_join_pill);
            tag.setPadding(dp(12), dp(4), dp(12), dp(4));
            LinearLayout.LayoutParams tagParams = new LinearLayout.LayoutParams(-2, -2);
            tagParams.bottomMargin = dp(10);
            tag.setLayoutParams(tagParams);
            block.addView(tag);

            String[] saved = savedPlayerValues.get(slot);
            String prefillName = saved != null ? saved[0] : (i == 0 ? lastGameName : "");

            EditText nameField = fieldInput("In-game name", R.drawable.ic_cd_person);
            nameField.setImeOptions(EditorInfo.IME_ACTION_NEXT);
            if (prefillName != null && !prefillName.isEmpty()) nameField.setText(prefillName);
            LinearLayout.LayoutParams nameParams = new LinearLayout.LayoutParams(-1, -2);
            nameParams.bottomMargin = dp(10);
            nameField.setLayoutParams(nameParams);
            block.addView(nameField);

            EditText idField = fieldInput("In-game UID", R.drawable.ic_cd_badge);
            idField.setImeOptions(EditorInfo.IME_ACTION_DONE);
            String prefillId = saved != null ? saved[1] : "";
            if (prefillId != null && !prefillId.isEmpty()) idField.setText(prefillId);
            idField.setLayoutParams(new LinearLayout.LayoutParams(-1, -2));
            block.addView(idField);

            playerDetailsContainer.addView(block);
            playerFields.put(slot, new EditText[]{nameField, idField});
        }
    }

    /** Filled rounded input with a leading icon; focus is shown with a dark halo, not an outline. */
    private EditText fieldInput(String hint, int iconRes) {
        EditText field = new EditText(this);
        field.setHint(hint);
        field.setHintTextColor(0xFF9A9EC2);
        field.setTextColor(INK);
        field.setSingleLine(true);
        field.setBackgroundResource(R.drawable.bg_join_input);
        field.setPadding(dp(16), dp(13), dp(16), dp(13));
        field.setTextSize(15f);
        Drawable icon = ContextCompat.getDrawable(this, iconRes).mutate();
        icon.setBounds(0, 0, dp(20), dp(20));
        field.setCompoundDrawablesRelative(icon, null, null, null);
        field.setCompoundDrawablePadding(dp(12));
        field.setCompoundDrawableTintList(ColorStateList.valueOf(VIOLET));
        return field;
    }

    // ------------------------------------------------------------------
    // Wallet balance
    // ------------------------------------------------------------------

    private void listenBalance() {
        balanceRef = FirebaseRepository.users().child(uid).child("wallet").child("balance");
        balanceListener = new ValueEventListener() {
            @Override public void onDataChange(DataSnapshot snap) {
                Long bal = snap.getValue(Long.class);
                currentBalance = bal == null ? 0 : bal;
                balanceLoaded = true;
            }
            @Override public void onCancelled(DatabaseError error) {
            }
        };
        balanceRef.addValueEventListener(balanceListener);
    }

    // ------------------------------------------------------------------
    // Join submission — identical validation + ZapUpiClient/FirebaseDirectJoinClient flow
    // as the old two-screen version, just triggered from this single page's JOIN NOW button.
    // ------------------------------------------------------------------

    private void attemptJoin() {
        int teamSize = Math.max(1, tournament.getTeamSize());
        if (selectedSlots.isEmpty()) {
            FancyText.toast(this, "Please select at least one slot.", Toast.LENGTH_SHORT).show();
            return;
        }
        if (selectedSlots.size() > selectionCap) {
            FancyText.toast(this, "You can select up to " + selectionCap + " slots for this match.",
                    Toast.LENGTH_SHORT).show();
            return;
        }

        java.util.List<Integer> sortedSlots = new java.util.ArrayList<>(selectedSlots);
        java.util.Collections.sort(sortedSlots);
        int[] slotsToJoin = new int[sortedSlots.size()];
        String[] namesToJoin = new String[sortedSlots.size()];
        String[] uidsToJoin = new String[sortedSlots.size()];
        boolean missing = false;
        for (int i = 0; i < sortedSlots.size(); i++) {
            int slot = sortedSlots.get(i);
            slotsToJoin[i] = slot;
            EditText[] fields = playerFields.get(slot);
            String nameValue = fields == null ? "" : InputValidation.value(fields[0]);
            String idValue = fields == null ? "" : InputValidation.value(fields[1]);
            if (nameValue.isEmpty()) {
                if (fields != null) fields[0].setError("Required");
                missing = true;
            }
            if (idValue.isEmpty()) {
                if (fields != null) fields[1].setError("Required");
                missing = true;
            }
            namesToJoin[i] = nameValue;
            uidsToJoin[i] = idValue;
        }
        if (missing) {
            FancyText.toast(this, "Please fill inGameName & inGameId for every selected slot.", Toast.LENGTH_SHORT).show();
            return;
        }

        // 0-coin guard: a paid match needs perSlotFee x slots in the wallet. Stop here -
        // no request, no slot taken, nothing counted. (Backend enforces the same rule.)
        long totalCost = (long) perSlotFee * slotsToJoin.length;
        if (totalCost > 0 && balanceLoaded && currentBalance < totalCost) {
            new FancyText.MaterialBuilder(JoinMatchActivity.this)
                    .setTitle("Not enough coins")
                    .setMessage("You have " + currentBalance + " coins but need " + totalCost
                            + " to join with " + slotsToJoin.length + " slot(s).")
                    .setPositiveButton("OK", null)
                    .setNegativeButton("ADD COINS", (d, which) ->
                            startActivity(new Intent(JoinMatchActivity.this, WalletActivity.class)))
                    .show();
            return;
        }

        // The slot grid was fetched with a ONE-TIME read when this screen opened
        // (see loadSlots()) and is never refreshed after that — so if someone
        // else grabs one of the slots the player already ticked while they're
        // still filling in their game details, the grid keeps showing it as
        // free right up until JOIN NOW is tapped, and the backend's "Slot X is
        // already taken" rejection lands as a confusing surprise. Re-check the
        // live slotIndex right before submitting: if any selected slot was
        // taken in the meantime, stop here with a clear message and refresh
        // the grid instead of sending a request we already know will fail.
        joinNowButton.setEnabled(false);
        joinNowButton.setText("JOINING\u2026");
        FirebaseRepository.tournaments().child(tournament.getId()).child("slotIndex").get()
                .addOnSuccessListener(slotSnapshot -> {
                    java.util.List<Integer> justTaken = new java.util.ArrayList<>();
                    for (int slot : slotsToJoin) {
                        if (slotSnapshot.child(String.valueOf(slot)).exists()) justTaken.add(slot);
                    }
                    if (!justTaken.isEmpty()) {
                        joinNowButton.setEnabled(true);
                        refreshJoinLabel();
                        java.util.Set<Integer> takenNow = new java.util.HashSet<>();
                        for (com.google.firebase.database.DataSnapshot child : slotSnapshot.getChildren()) {
                            try { takenNow.add(Integer.parseInt(child.getKey())); } catch (NumberFormatException ignored) { }
                        }
                        for (int slot : justTaken) selectedSlots.remove((Integer) slot);
                        buildSlotGrid(takenNow);
                        String label = justTaken.size() == 1 ? "Slot " + justTaken.get(0) : "Slots " + justTaken;
                        new FancyText.MaterialBuilder(JoinMatchActivity.this)
                                .setTitle("Could not join match")
                                .setMessage(label + " got taken by another player just now. Please pick a different slot.")
                                .setPositiveButton("OK", null)
                                .show();
                        return;
                    }
                    submitJoin(slotsToJoin, uidsToJoin, namesToJoin);
                })
                .addOnFailureListener(error -> submitJoin(slotsToJoin, uidsToJoin, namesToJoin));
    }

    private void submitJoin(int[] slotsToJoin, String[] uidsToJoin, String[] namesToJoin) {
        final String primaryName = namesToJoin[0];
        FirebaseDirectJoinClient.joinMatch(tournament, slotsToJoin, uidsToJoin, namesToJoin,
                new FirebaseDirectJoinClient.JoinCallback() {
                    @Override public void onSuccess(int[] slotNumbers, int entryFeeCoins) {
                        getSharedPreferences("arenax_profile", MODE_PRIVATE)
                                .edit().putString("last_game_name", primaryName).apply();
                        setResult(RESULT_OK);
                        String joinMsg = entryFeeCoins > 0
                                ? "You're in! " + entryFeeCoins + " coins deducted."
                                : "You're in! Joined for free.";
                        FancyText.toast(JoinMatchActivity.this, joinMsg, Toast.LENGTH_LONG).show();
                        Intent detailsIntent = new Intent(JoinMatchActivity.this, MatchJoinedActivity.class)
                                .putExtra(EXTRA_TOURNAMENT, tournament);
                        startActivity(detailsIntent);
                        finish();
                    }

                    @Override public void onAlreadyRegistered() {
                        setResult(RESULT_OK);
                        FancyText.toast(JoinMatchActivity.this,
                                "You're already registered for this match.", Toast.LENGTH_LONG).show();
                        Intent detailsIntent = new Intent(JoinMatchActivity.this, MatchJoinedActivity.class)
                                .putExtra(EXTRA_TOURNAMENT, tournament);
                        startActivity(detailsIntent);
                        finish();
                    }

                    @Override public void onError(String message) {
                        joinNowButton.setEnabled(true);
                        refreshJoinLabel();
                        final String reason = message == null ? "Could not register right now." : message;
                        MaterialAlertDialogBuilder builder =
                                new FancyText.MaterialBuilder(JoinMatchActivity.this)
                                        .setTitle("Could not join match")
                                        .setMessage(reason)
                                        .setPositiveButton("OK", null);
                        if (reason.toLowerCase(java.util.Locale.ROOT).contains("but need")) {
                            builder.setNegativeButton("ADD COINS", (d, which) ->
                                    startActivity(new Intent(JoinMatchActivity.this, WalletActivity.class)));
                        }
                        builder.show();
                    }
                });
    }

    @Override
    protected void onDestroy() {
        if (balanceRef != null && balanceListener != null) {
            balanceRef.removeEventListener(balanceListener);
        }
        super.onDestroy();
    }
}
