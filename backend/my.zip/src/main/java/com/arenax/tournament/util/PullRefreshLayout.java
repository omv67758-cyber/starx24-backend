package com.arenax.tournament.util;

import android.animation.ValueAnimator;
import android.content.Context;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.animation.DecelerateInterpolator;
import android.widget.FrameLayout;
import android.widget.ProgressBar;

/**
 * Dependency-free pull-to-refresh wrapper. Put ONE scrollable child (ScrollView) inside it.
 * Pull down from the very top of the content to refresh; the content follows the finger,
 * a spinner appears and {@link OnRefreshListener#onRefresh()} fires once on release.
 * Call {@link #setRefreshing(boolean)} with false to close it.
 */
public class PullRefreshLayout extends FrameLayout {

    public interface OnRefreshListener { void onRefresh(); }

    private final int touchSlop;
    private final float triggerPx;
    private final float holdPx;
    private final float maxPx;
    private final ProgressBar spinner;

    private OnRefreshListener listener;
    private boolean refreshing;
    private boolean dragging;
    private float downX;
    private float downY;
    private float pull;
    private ValueAnimator settle;

    public PullRefreshLayout(Context context) { this(context, null); }

    public PullRefreshLayout(Context context, AttributeSet attrs) {
        super(context, attrs);
        float d = context.getResources().getDisplayMetrics().density;
        touchSlop = ViewConfiguration.get(context).getScaledTouchSlop();
        triggerPx = 72 * d;
        holdPx = 56 * d;
        maxPx = 140 * d;
        spinner = new ProgressBar(context);
        spinner.setIndeterminate(true);
        spinner.setVisibility(INVISIBLE);
        LayoutParams lp = new LayoutParams((int) (30 * d), (int) (30 * d));
        lp.gravity = android.view.Gravity.TOP | android.view.Gravity.CENTER_HORIZONTAL;
        lp.topMargin = (int) (12 * d);
        addView(spinner, 0, lp); // index 0 = drawn underneath the content
    }

    public void setOnRefreshListener(OnRefreshListener l) { listener = l; }

    public boolean isRefreshing() { return refreshing; }

    public void setRefreshing(boolean value) {
        if (refreshing == value) return;
        refreshing = value;
        if (value) {
            spinner.setVisibility(VISIBLE);
            animateTo(holdPx);
        } else {
            animateTo(0f);
        }
    }

    private View content() {
        for (int i = 0; i < getChildCount(); i++) {
            View c = getChildAt(i);
            if (c != spinner) return c;
        }
        return null;
    }

    private boolean canPull() {
        View c = content();
        return c != null && c.getVisibility() == VISIBLE && !c.canScrollVertically(-1);
    }

    @Override
    public boolean onInterceptTouchEvent(MotionEvent ev) {
        if (!isEnabled() || refreshing || !canPull()) return false;
        switch (ev.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                downX = ev.getX();
                downY = ev.getY();
                dragging = false;
                break;
            case MotionEvent.ACTION_MOVE:
                float dy = ev.getY() - downY;
                float dx = Math.abs(ev.getX() - downX);
                if (dy > touchSlop && dy > dx) {
                    dragging = true;
                    downY = ev.getY() - touchSlop; // start pulling from here, no jump
                }
                break;
            case MotionEvent.ACTION_CANCEL:
            case MotionEvent.ACTION_UP:
                dragging = false;
                break;
            default:
                break;
        }
        return dragging;
    }

    @Override
    public boolean onTouchEvent(MotionEvent ev) {
        if (!dragging) return false;
        switch (ev.getActionMasked()) {
            case MotionEvent.ACTION_MOVE:
                float raw = ev.getY() - downY;
                pull = Math.max(0f, Math.min(maxPx, raw * 0.5f));
                applyPull(pull);
                return true;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                dragging = false;
                if (ev.getActionMasked() == MotionEvent.ACTION_UP && pull >= triggerPx) {
                    refreshing = true;
                    animateTo(holdPx);
                    if (listener != null) listener.onRefresh();
                } else {
                    animateTo(0f);
                }
                return true;
            default:
                return true;
        }
    }

    private void applyPull(float value) {
        pull = value;
        View c = content();
        if (c != null) c.setTranslationY(value);
        if (value > 0f) {
            spinner.setVisibility(VISIBLE);
            spinner.setAlpha(Math.min(1f, value / triggerPx));
        } else if (!refreshing) {
            spinner.setVisibility(INVISIBLE);
        }
    }

    private void animateTo(float target) {
        if (settle != null) settle.cancel();
        settle = ValueAnimator.ofFloat(pull, target);
        settle.setDuration(200);
        settle.setInterpolator(new DecelerateInterpolator());
        settle.addUpdateListener(a -> applyPull((Float) a.getAnimatedValue()));
        settle.start();
    }

    @Override
    protected void onDetachedFromWindow() {
        if (settle != null) settle.cancel();
        super.onDetachedFromWindow();
    }
}
