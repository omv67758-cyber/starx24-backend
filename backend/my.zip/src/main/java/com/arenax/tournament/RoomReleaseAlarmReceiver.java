package com.arenax.tournament;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import androidx.annotation.NonNull;

import com.arenax.tournament.data.FirebaseRepository;
import com.arenax.tournament.util.FcmSender;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;
import java.util.Map;

/**
 * Fires at a match's exact scheduled room-release time (matches/{matchId}/roomRelease/releaseAt,
 * see RoomReleaseScheduler), even if the app is closed. Re-reads the schedule fresh from Firebase
 * — an admin may have already released or hidden the room manually, or changed the room id/password,
 * since the alarm was set — then does exactly what a manual "RELEASE ROOM" tap does in AdminActivity:
 * writes roomId/roomPassword/roomReleased on the match, and pushes ONLY to that match's joined
 * participants (never "All Users").
 */
public class RoomReleaseAlarmReceiver extends BroadcastReceiver {

    public static final String EXTRA_MATCH_ID = "matchId";

    @Override
    public void onReceive(Context context, Intent intent) {
        String matchId = intent.getStringExtra(EXTRA_MATCH_ID);
        if (matchId == null || matchId.trim().isEmpty()) return;

        final Context appContext = context.getApplicationContext();
        // Keeps this receiver alive long enough for the async Firebase reads + FCM network call below.
        final PendingResult pendingResult = goAsync();

        DatabaseReference matchRef = FirebaseRepository.matches().child(matchId);
        matchRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (!snapshot.exists()) { pendingResult.finish(); return; }

                // Admin already released (or hid) manually before the alarm fired — nothing to do.
                Boolean alreadyReleased = snapshot.child("roomReleased").getValue(Boolean.class);
                if (Boolean.TRUE.equals(alreadyReleased)) { pendingResult.finish(); return; }

                DataSnapshot schedule = snapshot.child("roomRelease");
                Boolean scheduleAlreadySent = schedule.child("released").getValue(Boolean.class);
                if (Boolean.TRUE.equals(scheduleAlreadySent)) { pendingResult.finish(); return; }

                String roomId = schedule.child("roomId").getValue(String.class);
                String roomPassword = schedule.child("roomPassword").getValue(String.class);
                if (roomId == null || roomId.trim().isEmpty()) {
                    // Nothing was ever entered for this schedule — skip silently, don't release an empty room.
                    pendingResult.finish();
                    return;
                }

                releaseAndNotify(appContext, matchId, roomId.trim(),
                        roomPassword == null ? "" : roomPassword.trim(), pendingResult);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                pendingResult.finish();
            }
        });
    }

    private void releaseAndNotify(Context context, String matchId, String roomId, String roomPassword,
                                   PendingResult pendingResult) {
        // Same DB writes a manual "RELEASE ROOM" tap performs (see AdminActivity#showMatchRoomDialog),
        // so MyMatchesActivity / the match info screen flips to showing the room instantly.
        FirebaseRepository.releaseMatchRoom(matchId, roomId, roomPassword);
        FirebaseRepository.matches().child(matchId).child("roomRelease").child("released").setValue(true);
        FirebaseRepository.matches().child(matchId).child("roomRelease").child("pushSent").setValue(true);
        FirebaseRepository.logActivity("MATCH_ROOM_AUTO_RELEASED", matchId, "Room " + roomId);

        String title = "Room Released!";
        String body = "Room ID: " + roomId + " | Password: " + roomPassword;
        // The durable inbox row lives in /notifications, which every signed-in user can read, so it must
        // NOT contain the credentials. Players see them in the match screen; the push below still carries them.
        persistForJoinedUsers(matchId, title, "Your Room ID and password are now available. Open My Matches to view them.");
        FirebaseRepository.collectParticipantFcmTokens(FirebaseRepository.matchParticipants(matchId), tokens -> {
            if (tokens.isEmpty()) { pendingResult.finish(); return; }

            new Thread(() -> {
                try {
                    FcmSender.sendToAllTokens(null, tokens, title, body, "",
                            (successCount, total, errorLog) -> pendingResult.finish());
                } catch (Exception e) {
                    pendingResult.finish();
                }
            }).start();
        });
    }

    /** Writes a durable inbox row per joined user; it remains visible after the match ends. */
    private void persistForJoinedUsers(String matchId, String title, String body) {
        FirebaseRepository.matchParticipants(matchId).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override public void onDataChange(@NonNull DataSnapshot snapshot) {
                for (DataSnapshot participant : snapshot.getChildren()) {
                    String uid = participant.getKey();
                    if (uid == null || uid.trim().isEmpty()) continue;
                    Map<String, Object> row = new HashMap<>();
                    row.put("userId", uid);
                    row.put("title", title);
                    row.put("message", body);
                    row.put("type", "MATCH_ROOM_RELEASED");
                    row.put("matchId", matchId);
                    row.put("createdAt", System.currentTimeMillis());
                    row.put("read", false);
                    FirebaseRepository.notifications().push().setValue(row);
                }
            }
            @Override public void onCancelled(@NonNull DatabaseError error) { }
        });
    }
}
