package com.arenax.tournament.fragment;


import com.arenax.tournament.util.FancyText;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.arenax.tournament.AboutUsActivity;
import com.arenax.tournament.FaqActivity;
import com.arenax.tournament.LoginActivity;
import com.arenax.tournament.PrivacyPolicyActivity;
import com.arenax.tournament.R;
import com.arenax.tournament.TermsActivity;
import com.arenax.tournament.data.FirebaseRepository;
import com.arenax.tournament.util.BadgeTier;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.resource.bitmap.CircleCrop;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.ValueEventListener;

public class ProfileFragment extends Fragment {
    private ValueEventListener configListener;
    private ValueEventListener statsListener;
    private ValueEventListener scoreListener;
    private TextView name;
    private TextView adminLabel;
    private TextView statWallet;
    private TextView statMatches;
    private TextView statWins;
    private ImageView avatar;
    private FrameLayout badgeRing;
    private ImageView badgeIcon;
    private TextView badgeLabel;
    private TextView cardName, cardEmail, cardPhone, cardHint, bioText;
    private View bioCard;
    private String currentBio = "";
    /** Last name|bio|photo pushed to publicProfiles, so we only write when something changed. */
    private String lastSyncKey = "";

    /** Profile photo is editable (together with the bio). Name / email / phone are NOT. */
    private final androidx.activity.result.ActivityResultLauncher<String> photoPicker =
            registerForActivityResult(new androidx.activity.result.contract.ActivityResultContracts.GetContent(), uri -> {
                if (uri != null) uploadAvatar(uri);
            });

    private void uploadAvatar(@NonNull Uri uri) {
        final String uid = FirebaseAuth.getInstance().getUid();
        if (uid == null || !isAdded()) return;
        if (avatar != null) {
            avatar.setPadding(0, 0, 0, 0);
            Glide.with(this).load(uri).transform(new CircleCrop()).into(avatar); // instant preview
        }
        FancyText.toast(requireContext(), "Uploading photo...", Toast.LENGTH_SHORT).show();
        com.arenax.tournament.data.ImgBbUploader.uploadImage(requireContext(), uri,
                new com.arenax.tournament.data.StorageUploader.Callback() {
                    @Override public void onSuccess(String url) {
                        FirebaseRepository.users().child(uid).child("photoUrl").setValue(url)
                                .addOnSuccessListener(v -> {
                                    if (!isAdded()) return;
                                    FancyText.toast(requireContext(), "Photo updated", Toast.LENGTH_SHORT).show();
                                    loadPlayer(); // refreshes card + publicProfiles
                                })
                                .addOnFailureListener(e -> {
                                    if (isAdded()) FancyText.toast(requireContext(), "Could not save photo. Try again.", Toast.LENGTH_SHORT).show();
                                });
                    }
                    @Override public void onFailure(String message) {
                        if (isAdded()) FancyText.toast(requireContext(), "Photo upload failed: " + message, Toast.LENGTH_LONG).show();
                    }
                });
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle state) {
        View view = inflater.inflate(R.layout.fragment_profile, container, false);
        name = view.findViewById(R.id.profile_name);
        adminLabel = view.findViewById(R.id.profile_admin_label);
        statWallet = view.findViewById(R.id.profile_stat_wallet);
        statMatches = view.findViewById(R.id.profile_stat_matches);
        statWins = view.findViewById(R.id.profile_stat_wins);
        avatar = view.findViewById(R.id.profile_avatar);
        badgeRing = view.findViewById(R.id.profile_badge_ring);
        badgeIcon = view.findViewById(R.id.profile_badge_icon);
        badgeLabel = view.findViewById(R.id.profile_badge_label);
        cardName = view.findViewById(R.id.profile_card_name);
        cardEmail = view.findViewById(R.id.profile_card_email);
        cardPhone = view.findViewById(R.id.profile_card_phone);
        cardHint = view.findViewById(R.id.profile_card_hint);
        bioText = view.findViewById(R.id.profile_bio_text);
        bioCard = view.findViewById(R.id.profile_bio_card);
        // The profile card no longer opens the old name/phone editor. It only reveals the
        // bio section; name, email, and phone remain display-only on this page.
        view.findViewById(R.id.profile_card).setOnClickListener(v -> {
            if (bioCard != null) bioCard.setVisibility(View.VISIBLE);
        });
        view.findViewById(R.id.profile_bio_edit).setOnClickListener(v -> showBioEditor());
        // Tap the profile picture to change it.
        if (avatar != null) avatar.setOnClickListener(v -> photoPicker.launch("image/*"));
        // Tapping the "BIO" row in the card opens the bio editor too.
        if (cardHint != null) cardHint.setOnClickListener(v -> showBioEditor());
        // Player search sits at the very top of the Profile tab (name + bio + logo only).
        View profileCardView = view.findViewById(R.id.profile_card);
        ViewGroup cardParent = (ViewGroup) profileCardView.getParent();
        com.arenax.tournament.util.PlayerSearchView searchView =
                new com.arenax.tournament.util.PlayerSearchView(requireContext(), FirebaseAuth.getInstance().getUid());
        searchView.openGlobalSearchOnTap();
        android.widget.LinearLayout.LayoutParams searchParams = new android.widget.LinearLayout.LayoutParams(-1, -2);
        searchParams.topMargin = Math.round(4 * getResources().getDisplayMetrics().density);
        cardParent.addView(searchView, cardParent.indexOfChild(profileCardView), searchParams);
        com.google.firebase.auth.FirebaseUser authUser = FirebaseAuth.getInstance().getCurrentUser();
        if (authUser != null && authUser.getEmail() != null) cardEmail.setText(authUser.getEmail());

        view.findViewById(R.id.profile_back).setOnClickListener(v -> requireActivity().onBackPressed());
        // Both the top icon row and the menu-list row now point at the real screens
        // instead of the old placeholder Toasts ("managed by STARX24" etc.) that made
        // the profile page look broken.
        // Do not expose MyProfileActivity: it contains the legacy name/phone editor.
        View profileSettings = view.findViewById(R.id.profile_settings);
        if (profileSettings != null) profileSettings.setVisibility(View.GONE);
        // Full inbox (every notification, colorful real icon per type, light theme).
        view.findViewById(R.id.profile_notifications).setOnClickListener(v ->
                com.arenax.tournament.NotificationsActivity.openAll(requireContext()));
        view.findViewById(R.id.profile_customer_support).setOnClickListener(v -> open(com.arenax.tournament.CustomerSupportActivity.class));
        view.findViewById(R.id.profile_support_agent).setOnClickListener(v -> open(com.arenax.tournament.SupportChatActivity.class));
        view.findViewById(R.id.profile_faq).setOnClickListener(v -> open(FaqActivity.class));
        view.findViewById(R.id.profile_faq_row).setOnClickListener(v -> open(FaqActivity.class));
        view.findViewById(R.id.profile_match_history).setOnClickListener(v -> open(com.arenax.tournament.MatchHistoryActivity.class));
        view.findViewById(R.id.profile_terms).setOnClickListener(v -> open(TermsActivity.class));
        view.findViewById(R.id.profile_privacy).setOnClickListener(v -> open(PrivacyPolicyActivity.class));
        view.findViewById(R.id.profile_about).setOnClickListener(v -> open(AboutUsActivity.class));
        view.findViewById(R.id.profile_developer).setOnClickListener(v -> open(com.arenax.tournament.DeveloperProfileActivity.class));
        view.findViewById(R.id.profile_logout).setOnClickListener(v -> signOut());
        ((TextView) view.findViewById(R.id.profile_language_value))
                .setText(com.arenax.tournament.util.LanguageManager.currentLabel(requireContext()));
        view.findViewById(R.id.profile_language).setOnClickListener(v ->
                com.arenax.tournament.util.LanguageManager.showPicker(requireActivity()));

        loadPlayer();
        loadLiveStats();
        loadBadge();
        listenToProfileConfig();
        return view;
    }

    private void loadPlayer() {
        if (!FirebaseRepository.isReady(requireContext())) return;
        if (FirebaseAuth.getInstance().getCurrentUser() == null) return;
        String uid = FirebaseAuth.getInstance().getUid();
        FirebaseRepository.users().child(uid).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (!isAdded()) return;
                name.setText(text(snapshot.child("name").getValue(), "STARX24 PLAYER"));
                bindCard(snapshot);
                String photoUrl = text(snapshot.child("photoUrl").getValue(), "");
                if (avatar != null && !photoUrl.isEmpty()) {
                    avatar.setPadding(0, 0, 0, 0);
                    Glide.with(ProfileFragment.this).load(photoUrl).transform(new CircleCrop()).into(avatar);
                }
            }
            @Override public void onCancelled(@NonNull DatabaseError error) { }
        });
    }

    /** Current score badge: highest tier the player's leaderboard score qualifies for.
     *  A fresh account with no leaderboard row yet simply shows no badge. */
    private void loadBadge() {
        if (!FirebaseRepository.isReady(requireContext())) return;
        if (FirebaseAuth.getInstance().getCurrentUser() == null) return;
        String uid = FirebaseAuth.getInstance().getUid();
        scoreListener = new ValueEventListener() {
            @Override public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (!isAdded() || badgeRing == null) return;
                Long score = snapshot.child("score").getValue(Long.class);
                BadgeTier tier = BadgeTier.forScore(score == null ? 0 : score);
                if (tier == null) {
                    badgeRing.setVisibility(View.GONE);
                    badgeLabel.setVisibility(View.GONE);
                    return;
                }
                badgeRing.setBackgroundResource(tier.neonRingRes);
                badgeIcon.setImageResource(tier.iconRes);
                badgeLabel.setText(tier.label);
                badgeRing.setVisibility(View.VISIBLE);
                badgeLabel.setVisibility(View.GONE); // tier text (e.g. "Rookie") intentionally hidden
            }
            @Override public void onCancelled(@NonNull DatabaseError error) { }
        };
        FirebaseRepository.leaderboard().child("allTime").child(uid).addValueEventListener(scoreListener);
    }

    private void listenToProfileConfig() {
        if (!FirebaseRepository.isReady(requireContext())) return;
        configListener = new ValueEventListener() {
            @Override public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (!isAdded()) return;
                DataSnapshot profile = snapshot.child("profile");
                String adminName = text(profile.child("adminName").getValue(), "STARX24 admin");
                adminLabel.setText("Managed by " + adminName);
                // The "Arena notice" card (dark brown bg_profile_notice block) has been
                // removed from the Profile page per request; the admin notice is still
                // shown to users via the home-tab notice bar / notifications inbox.
            }
            @Override public void onCancelled(@NonNull DatabaseError error) { }
        };
        FirebaseRepository.appConfig().addValueEventListener(configListener);
    }

    /** Live player stats strip: wallet balance, joined matches count, total wins.
     *  Single listener on the user node keeps the strip fresh everywhere. */
    private void loadLiveStats() {
        if (!FirebaseRepository.isReady(requireContext())) return;
        com.google.firebase.auth.FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        if (user == null) return;
        statsListener = new ValueEventListener() {
            @Override public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (!isAdded()) return;
                Long balance = snapshot.child("wallet").child("balance").getValue(Long.class);
                Long joined = snapshot.child("stats").child("joinedMatches").getValue(Long.class);
                Long wins = snapshot.child("stats").child("wins").getValue(Long.class);
                if (statWallet != null) statWallet.setText("\u20b9" + (balance == null ? 0 : balance));
                if (statMatches != null) statMatches.setText(String.valueOf(joined == null ? 0 : joined));
                if (statWins != null) statWins.setText(String.valueOf(wins == null ? 0 : wins));
                bindCard(snapshot);
            }
            @Override public void onCancelled(@NonNull DatabaseError error) { }
        };
        FirebaseRepository.users().child(user.getUid()).addValueEventListener(statsListener);
    }

    /** Fills the profile card (read-only name / email / phone) and the bio from the user node. */
    private void bindCard(@NonNull DataSnapshot snapshot) {
        if (cardName == null) return;
        cardName.setText(text(snapshot.child("name").getValue(), "STARX24 PLAYER"));
        com.google.firebase.auth.FirebaseUser u = FirebaseAuth.getInstance().getCurrentUser();
        String email = u != null && u.getEmail() != null ? u.getEmail() : text(snapshot.child("email").getValue(), "");
        cardEmail.setText(email);
        cardEmail.setVisibility(email.isEmpty() ? View.GONE : View.VISIBLE);
        View emailRow = (View) cardEmail.getParent();
        emailRow.setVisibility(email.isEmpty() ? View.GONE : View.VISIBLE);
        String phone = text(snapshot.child("phone").getValue(), "");
        cardPhone.setText(phone);
        cardPhone.setVisibility(phone.isEmpty() ? View.GONE : View.VISIBLE);
        View phoneRow = (View) cardPhone.getParent();
        phoneRow.setVisibility(phone.isEmpty() ? View.GONE : View.VISIBLE);
        currentBio = text(snapshot.child("bio").getValue(), "");
        if (currentBio.isEmpty()) {
            bioText.setText("No bio yet. Tap the pencil to add one.");
            cardHint.setText("Tap to add bio  \u203a");
            cardHint.setTextColor(0xFF2F6FED);
        } else {
            bioText.setText(FancyText.plain(currentBio));
            // Bio shows directly inside the profile card.
            cardHint.setText(FancyText.plain(currentBio));
            cardHint.setTextColor(0xFF1C1C1E);
        }
        syncPublicCard(snapshot);
    }

    /** Keeps publicProfiles/{uid} (name, bio, photo only) in step with the private user node. */
    private void syncPublicCard(@NonNull DataSnapshot snapshot) {
        String uid = FirebaseAuth.getInstance().getUid();
        String publicName = text(snapshot.child("name").getValue(), "");
        String photo = text(snapshot.child("photoUrl").getValue(), "");
        String key = publicName + "\u0001" + currentBio + "\u0001" + photo;
        if (uid == null || publicName.isEmpty() || key.equals(lastSyncKey)) return;
        if (!FirebaseRepository.isReady(requireContext())) return;
        lastSyncKey = key;
        FirebaseRepository.syncPublicProfile(uid, publicName, currentBio, photo);
    }

    private void toggleBio() {
        boolean show = bioCard.getVisibility() != View.VISIBLE;
        bioCard.setVisibility(show ? View.VISIBLE : View.GONE);
        // bio now lives inside the profile card itself; hint text is managed by bindCard()
    }

    /** Bio is the only editable profile field (max 150 chars, saved to users/{uid}/bio). */
    private void showBioEditor() {
        if (!isAdded()) return;
        final android.widget.EditText input = new android.widget.EditText(requireContext());
        input.setText(currentBio);
        input.setSelection(input.getText().length());
        input.setHint("Write something about yourself");
        input.setMinLines(3);
        input.setMaxLines(6);
        input.setGravity(android.view.Gravity.TOP | android.view.Gravity.START);
        input.setInputType(android.text.InputType.TYPE_CLASS_TEXT
                | android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE
                | android.text.InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        input.setFilters(new android.text.InputFilter[]{new android.text.InputFilter.LengthFilter(150)});
        int pad = Math.round(20 * getResources().getDisplayMetrics().density);
        android.widget.FrameLayout box = new android.widget.FrameLayout(requireContext());
        box.setPadding(pad, pad / 2, pad, 0);
        box.addView(input);
        new FancyText.MaterialBuilder(requireContext())
                .setTitle("Edit bio")
                .setView(box)
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Save", (d, w) -> saveBio(input.getText().toString().trim()))
                .show();
    }

    private void saveBio(String bio) {
        if (!FirebaseRepository.isReady(requireContext())) return;
        if (FirebaseAuth.getInstance().getCurrentUser() == null) return;
        String uid = FirebaseAuth.getInstance().getUid();
        FirebaseRepository.users().child(uid).child("bio").setValue(bio)
                .addOnSuccessListener(v -> {
                    if (isAdded()) FancyText.toast(requireContext(), "Bio saved", Toast.LENGTH_SHORT).show();
                })
                .addOnFailureListener(e -> {
                    if (isAdded()) FancyText.toast(requireContext(), "Could not save bio. Try again.", Toast.LENGTH_SHORT).show();
                });
    }

    private void open(Class<?> activity) {
        startActivity(new Intent(requireContext(), activity));
    }

    private void openConfiguredLink(String key, String fallback) {
        if (!FirebaseRepository.isReady(requireContext())) {
            openUrl(fallback);
            return;
        }
        FirebaseRepository.appConfig().child("profile").child(key).get()
                .addOnSuccessListener(snapshot -> openUrl(text(snapshot.getValue(), fallback)))
                .addOnFailureListener(error -> openUrl(fallback));
    }

    private void openUrl(String raw) {
        try {
            String url = raw == null || raw.trim().isEmpty() ? "https://arenax.example" : raw.trim();
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
        } catch (RuntimeException error) {
            FancyText.toast(requireContext(), "Link is not available right now.", Toast.LENGTH_SHORT).show();
        }
    }

    private void signOut() {
        FirebaseRepository.signOut();
        startActivity(new Intent(requireContext(), LoginActivity.class)
                .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK));
        requireActivity().finish();
    }

    private static String text(Object value, String fallback) {
        return value == null || String.valueOf(value).trim().isEmpty() ? fallback : String.valueOf(value);
    }

    @Override public void onDestroyView() {
        if (configListener != null && FirebaseRepository.isReady(requireContext())) {
            FirebaseRepository.appConfig().removeEventListener(configListener);
        }
        if (statsListener != null && FirebaseRepository.isReady(requireContext())) {
            com.google.firebase.auth.FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
            if (user != null) {
                FirebaseRepository.users().child(user.getUid()).removeEventListener(statsListener);
            }
        }
        if (scoreListener != null && FirebaseRepository.isReady(requireContext())) {
            com.google.firebase.auth.FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
            if (user != null) {
                FirebaseRepository.leaderboard().child("allTime").child(user.getUid()).removeEventListener(scoreListener);
            }
        }
        super.onDestroyView();
    }
}
