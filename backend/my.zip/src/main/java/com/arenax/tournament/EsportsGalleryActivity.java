package com.arenax.tournament;


import com.arenax.tournament.util.FancyText;
import android.os.Bundle;
import android.view.View;
import android.view.animation.AnimationUtils;
import android.view.animation.LayoutAnimationController;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.arenax.tournament.adapter.GameModeAdapter;
import com.arenax.tournament.data.FirebaseRepository;
import com.arenax.tournament.model.GameMode;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class EsportsGalleryActivity extends BaseActivity {
    private final List<GameMode> games = new ArrayList<>();
    private ValueEventListener listener;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        setContentView(R.layout.activity_esports_gallery);
        findViewById(R.id.gallery_back).setOnClickListener(v -> finish());

        RecyclerView list = findViewById(R.id.gallery_game_list);
        list.setLayoutManager(new GridLayoutManager(this, 2));
        list.setHasFixedSize(false);
        list.setAdapter(new GameModeAdapter(games, false, null, mode -> {
            android.content.Intent intent = new android.content.Intent(this, CategoryMatchesActivity.class);
            intent.putExtra("categoryId", mode.getId());
            intent.putExtra("categoryTitle", mode.getTitle());
            startActivity(intent);
        }));
        LayoutAnimationController animation = new LayoutAnimationController(
                AnimationUtils.loadAnimation(this, android.R.anim.fade_in), 0.12f);
        animation.setOrder(LayoutAnimationController.ORDER_NORMAL);
        list.setLayoutAnimation(animation);

        listener = new ValueEventListener() {
            @Override public void onDataChange(@NonNull DataSnapshot snapshot) {
                games.clear();
                for (DataSnapshot child : snapshot.getChildren()) {
                    Object raw = child.getValue();
                    if (!(raw instanceof java.util.Map)) continue;
                    GameMode game = GameMode.fromMap(child.getKey(), (java.util.Map<String, Object>) raw);
                    if (game != null && game.isActive()) games.add(game);
                }
                Collections.sort(games, Comparator.comparingInt(GameMode::getDisplayOrder));
                RecyclerView.Adapter<?> adapter = list.getAdapter();
                if (adapter != null) adapter.notifyDataSetChanged();
                TextView count = findViewById(R.id.gallery_count);
                count.setText(games.size() + " GAMES");
                list.scheduleLayoutAnimation();
            }
            @Override public void onCancelled(@NonNull DatabaseError error) {
                if (!isFinishing()) FancyText.toast(EsportsGalleryActivity.this,
                        "Games unavailable right now", android.widget.Toast.LENGTH_SHORT).show();
            }
        };
        FirebaseRepository.gameModes().addValueEventListener(listener);
    }

    @Override protected void onDestroy() {
        if (listener != null) FirebaseRepository.gameModes().removeEventListener(listener);
        super.onDestroy();
    }
}
