package com.arenax.tournament.util;

import android.app.Activity;
import android.content.Intent;

import com.arenax.tournament.BannedActivity;
import com.arenax.tournament.data.FirebaseRepository;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

import java.util.Locale;

/**
 * Blocks banned players. Reads users/{uid}/status (a player may always read their own profile).
 * If BANNED: signs out and opens the "You're banned" notice with the admin's reason.
 */
public final class BanGuard {
    private BanGuard() {}

    public interface Callback { void onResult(boolean banned); }

    public static void check(Activity activity, Callback callback) {
        FirebaseUser user;
        try { user = FirebaseAuth.getInstance().getCurrentUser(); }
        catch (Throwable t) { callback.onResult(false); return; }
        if (user == null) { callback.onResult(false); return; }
        FirebaseRepository.users().child(user.getUid()).get().addOnCompleteListener(task -> {
            if (activity.isFinishing() || activity.isDestroyed()) return;
            if (!task.isSuccessful() || task.getResult() == null) { callback.onResult(false); return; }
            String status = String.valueOf(task.getResult().child("status").getValue()).toUpperCase(Locale.ENGLISH);
            if (!"BANNED".equals(status)) { callback.onResult(false); return; }
            Object reason = task.getResult().child("banReason").getValue();
            try { FirebaseAuth.getInstance().signOut(); } catch (Throwable ignored) { }
            Intent intent = new Intent(activity, BannedActivity.class);
            intent.putExtra(BannedActivity.EXTRA_REASON, reason == null ? "" : String.valueOf(reason));
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            activity.startActivity(intent);
            activity.finish();
            callback.onResult(true);
        });
    }
}
