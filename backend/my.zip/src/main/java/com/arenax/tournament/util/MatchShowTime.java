package com.arenax.tournament.util;

import androidx.annotation.NonNull;

import com.arenax.tournament.data.FirebaseRepository;
import com.arenax.tournament.model.Tournament;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.ValueEventListener;

import java.util.Locale;

/**
 * "Match showing time" — admin setting (appConfig/matchShowHours).
 * A finished match (result published / completed / cancelled) stays visible to players for this many
 * hours, then disappears from the player lists. 0 = never hide. Default = 2 hours.
 */
public final class MatchShowTime {
    public static final int DEFAULT_HOURS = 2;
    public static final int MAX_HOURS = 720;
    private static volatile int hours = DEFAULT_HOURS;

    private MatchShowTime() { }

    public static int hours() { return hours; }

    /** Live listener: keeps the cached value fresh and calls onChange so the screen can re-filter. Remove it in onDestroy. */
    public static ValueEventListener listen(final Runnable onChange) {
        ValueEventListener listener = new ValueEventListener() {
            @Override public void onDataChange(@NonNull DataSnapshot snapshot) {
                Object raw = snapshot.getValue();
                hours = raw instanceof Number ? Math.max(0, Math.min(MAX_HOURS, ((Number) raw).intValue())) : DEFAULT_HOURS;
                if (onChange != null) onChange.run();
            }
            @Override public void onCancelled(@NonNull DatabaseError error) { }
        };
        FirebaseRepository.appConfig().child("matchShowHours").addValueEventListener(listener);
        return listener;
    }

    public static void unlisten(ValueEventListener listener) {
        if (listener != null) FirebaseRepository.appConfig().child("matchShowHours").removeEventListener(listener);
    }

    /** True when this match must no longer be shown to players. */
    public static boolean isHidden(Tournament t) {
        if (t == null || hours <= 0) return false;
        String status = t.getEffectiveStatus();
        boolean finished = Tournament.COMPLETED.equals(status) || Tournament.CANCELLED.equals(status);
        if (!finished) return false;
        long endedAt = t.getResultPublishedAt();
        if (endedAt <= 0L) endedAt = t.getEffectiveStartAt();   // older matches without a result timestamp
        if (endedAt <= 0L) return false;
        return System.currentTimeMillis() >= endedAt + hours * 60L * 60L * 1000L;
    }

    public static String label(int h) {
        return h <= 0 ? "OFF (always show)" : String.format(Locale.ENGLISH, "%d hour%s", h, h == 1 ? "" : "s");
    }
}
