package com.arenax.tournament;


import com.arenax.tournament.util.FancyText;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.TextUtils;
import android.text.style.ForegroundColorSpan;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.arenax.tournament.data.FirebaseRepository;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * STARX24 "Admin Panel" - the role / work page.
 *
 * OWNER mode  (EXTRA_OWNER = true): pick a work (Withdrawal / Match & Banner / Profile & System /
 *   Custom), type the admin's name, tick the functions, and a key is generated. Existing keys are
 *   listed below with Copy / Edit / Revoke / Delete.
 * ADMIN mode  (key login): shows ONLY the works the owner assigned to this key. Tapping a work opens
 *   the matching workspace in AdminActivity, which itself only unlocks the assigned functions.
 *
 * Every function id lives in {@link AdminRoles#FUNCTIONS}; add one line there to add a new option.
 */
public class AdminWorkHubActivity extends BaseActivity {
    public static final String EXTRA_OWNER = "hubOwnerMode";

    // ---- palette (matches the reference admin-panel design) ----
    private static final int BG = 0xFFF4F8FF;
    private static final int INK = 0xFF16254A;
    private static final int MUTED = 0xFF64748F;
    private static final int BLUE = 0xFF2F6FEB;
    private static final int GREEN = 0xFF22A35A;
    private static final int RED = 0xFFE5384D;

    private static final int[] CARD_FROM = {0xFFEAF4FF, 0xFFF3EEFF, 0xFFFFF6DC, 0xFFFFEBF0};
    private static final int[] CARD_TO = {0xFFF9FCFF, 0xFFFCFAFF, 0xFFFFFDF4, 0xFFFFF8F9};
    private static final int[] CARD_STROKE = {0xFFD3E6FF, 0xFFE3D6FF, 0xFFF9E3AE, 0xFFFFD3DC};
    private static final int[] ACCENT = {0xFF2F7DF6, 0xFF8250E8, 0xFFF0A202, 0xFFE8475F};
    private static final int[] ICON = {R.drawable.ic_hub_wallet, R.drawable.ic_hub_game, R.drawable.ic_hub_user, R.drawable.ic_hub_gear};

    private boolean ownerMode;
    private String adminName = "";
    private final Set<String> myPerms = new LinkedHashSet<>();
    private String myRole = AdminRoles.CUSTOM_MANAGER;

    private LinearLayout page;
    private LinearLayout keysContainer;
    private TextView onlineText;
    private View onlineDot;

    private DatabaseReference keysRef;
    private ValueEventListener keysListener;
    private DatabaseReference sessionsRef;
    private ValueEventListener sessionsListener;
    private DatabaseReference connectedRef;
    private ValueEventListener connectedListener;
    private DataSnapshot lastKeys;
    private final Set<String> onlineKeys = new HashSet<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ownerMode = getIntent().getBooleanExtra(EXTRA_OWNER, false);
        if (!ownerMode) {
            ArrayList<String> perms = getIntent().getStringArrayListExtra("adminPerms");
            if (perms != null) myPerms.addAll(perms);
            String name = getIntent().getStringExtra("adminName");
            adminName = name == null ? "" : name;
            String role = getIntent().getStringExtra("adminRole");
            if (role != null) myRole = role;
        }
        buildUi();
        watchConnection();
        if (ownerMode) watchKeys();
    }

    // ================================================================ UI

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(BG);
        scroll.setFillViewport(true);
        scroll.setVerticalScrollBarEnabled(false);
        scroll.setClipToPadding(false);
        ViewCompat.setOnApplyWindowInsetsListener(scroll, (view, insets) -> {
            Insets bars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            view.setPadding(bars.left, bars.top, bars.right, bars.bottom);
            return insets;
        });

        page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(14), dp(8), dp(14), dp(20));
        scroll.addView(page, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));

        page.addView(buildHeader());
        if (ownerMode) page.addView(buildGenerateBanner(), lp(-1, dp(72), 12));

        List<Work> works = buildWorks();
        page.addView(buildSectionHeader(works.size()), lp(-1, -2, 14));
        if (works.isEmpty()) {
            TextView none = tv("No work has been assigned to this key yet. Ask the owner to add functions.",
                    12, MUTED, false);
            page.addView(none, lp(-1, -2, 10));
        }
        for (int i = 0; i < works.size(); i++) page.addView(buildWorkCard(works.get(i)), lp(-1, -2, 8));

        if (ownerMode) {
            page.addView(buildFooterGenerate(), lp(-1, -2, 14));
            keysContainer = new LinearLayout(this);
            keysContainer.setOrientation(LinearLayout.VERTICAL);
            page.addView(keysContainer, lp(-1, -2, 10));
        } else {
            page.addView(buildLogout(), lp(-1, dp(40), 14));
        }
        setContentView(scroll);
    }

    private View buildHeader() {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);

        android.widget.ImageView shield = symbol(R.drawable.ic_hub_shield, Color.WHITE, 8);
        GradientDrawable shieldBg = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{0xFF3B82F6, 0xFF1D4ED8});
        shieldBg.setCornerRadius(dp(8));
        shield.setBackground(shieldBg);
        row.addView(shield, new LinearLayout.LayoutParams(dp(38), dp(42)));

        LinearLayout titles = new LinearLayout(this);
        titles.setOrientation(LinearLayout.VERTICAL);
        titles.setPadding(dp(10), 0, dp(6), 0);
        TextView title = tv("ADMIN ROLE", 20, INK, true);
        title.setTag("nofancy");
        String partA = FancyText.heading("ADMIN ").toString();
        String partB = FancyText.heading("ROLE").toString();
        SpannableString spannable = new SpannableString(partA + partB);
        spannable.setSpan(new ForegroundColorSpan(BLUE), partA.length(), spannable.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        title.setText(spannable);
        title.setLetterSpacing(0.02f);
        title.setSingleLine(true);
        title.setMaxLines(1);
        androidx.core.widget.TextViewCompat.setAutoSizeTextTypeUniformWithConfiguration(
                title, 12, 20, 1, android.util.TypedValue.COMPLEX_UNIT_SP);
        titles.addView(title);
        row.addView(titles, new LinearLayout.LayoutParams(0, -2, 1f));

        LinearLayout pill = new LinearLayout(this);
        pill.setOrientation(LinearLayout.HORIZONTAL);
        pill.setGravity(Gravity.CENTER_VERTICAL);
        pill.setPadding(dp(9), dp(5), dp(10), dp(5));
        pill.setBackground(shape(0xFFE3F8EE, 10, 0, 0));
        onlineDot = new View(this);
        onlineDot.setBackground(shape(GREEN, 5, 0, 0));
        pill.addView(onlineDot, new LinearLayout.LayoutParams(dp(7), dp(7)));
        onlineText = tv("Online", 12, INK, true);
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(-2, -2);
        tp.leftMargin = dp(5);
        pill.addView(onlineText, tp);
        row.addView(pill, new LinearLayout.LayoutParams(-2, -2));
        return row;
    }

    private View buildGenerateBanner() {
        LinearLayout banner = new LinearLayout(this);
        banner.setOrientation(LinearLayout.HORIZONTAL);
        banner.setGravity(Gravity.CENTER_VERTICAL);
        banner.setPadding(dp(14), dp(6), dp(12), dp(6));
        GradientDrawable bg = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                new int[]{0xFF0F9D8A, 0xFF2563EB, 0xFF6D4AE0});
        bg.setCornerRadius(dp(10));
        banner.setBackground(bg);
        banner.setElevation(dp(3));

        android.widget.ImageView key = symbol(R.drawable.ic_hub_key, Color.WHITE, 10);
        banner.addView(key, new LinearLayout.LayoutParams(dp(46), dp(46)));

        LinearLayout text = new LinearLayout(this);
        text.setOrientation(LinearLayout.VERTICAL);
        text.setPadding(dp(10), 0, dp(6), 0);
        text.addView(tv("Generate Admin Key", 16, Color.WHITE, true));
        text.addView(tv("Create a new key for role access", 11.5f, 0xE6FFFFFF, false));
        banner.addView(text, new LinearLayout.LayoutParams(0, -2, 1f));

        banner.addView(arrowCircle(Color.WHITE, 0xFF2563EB, 32));
        banner.setOnClickListener(v -> chooseWorkThenKey());
        return banner;
    }

    private View buildSectionHeader(int total) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        TextView grid = tv("\u25A6", 17, BLUE, true);
        row.addView(grid, new LinearLayout.LayoutParams(-2, -2));
        TextView title = headingTv("Select Work", 18);
        title.setPadding(dp(8), 0, 0, 0);
        row.addView(title, new LinearLayout.LayoutParams(0, -2, 1f));

        TextView chip = new TextView(this);
        SpannableString text = new SpannableString("Total  " + total + (total == 1 ? " Role" : " Roles"));
        text.setSpan(new ForegroundColorSpan(MUTED), 0, 5, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        text.setSpan(new ForegroundColorSpan(BLUE), 7, text.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        chip.setText(text);
        chip.setTextSize(11.5f);
        chip.setTypeface(null, Typeface.BOLD);
        chip.setPadding(dp(10), dp(5), dp(10), dp(5));
        chip.setBackground(shape(0xFFEEF3FC, 8, 0, 0));
        row.addView(chip, new LinearLayout.LayoutParams(-2, -2));
        return row;
    }

    /** One work card: number badge + title, subtitle, up to two tick chips, round arrow button. */
    private View buildWorkCard(final Work work) {
        final int i = work.index;
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.HORIZONTAL);
        card.setGravity(Gravity.CENTER_VERTICAL);
        card.setPadding(dp(10), dp(10), dp(12), dp(10));
        GradientDrawable bg = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{CARD_FROM[i], CARD_TO[i]});
        bg.setCornerRadius(dp(12));
        bg.setStroke(dp(1), CARD_STROKE[i]);
        card.setBackground(bg);
        card.setElevation(dp(2));

        android.widget.ImageView icon = symbol(ICON[i], ACCENT[i], 12);
        icon.setBackground(shape(0xCCFFFFFF, 14, 0, 0));
        card.addView(icon, new LinearLayout.LayoutParams(dp(48), dp(48)));

        LinearLayout mid = new LinearLayout(this);
        mid.setOrientation(LinearLayout.VERTICAL);
        mid.setPadding(dp(10), 0, dp(6), 0);

        LinearLayout titleRow = new LinearLayout(this);
        titleRow.setOrientation(LinearLayout.HORIZONTAL);
        titleRow.setGravity(Gravity.CENTER_VERTICAL);
        TextView badge = tv(String.valueOf(i + 1), 10.5f, Color.WHITE, true);
        badge.setGravity(Gravity.CENTER);
        badge.setBackground(shape(ACCENT[i], 6, 0, 0));
        titleRow.addView(badge, new LinearLayout.LayoutParams(dp(19), dp(19)));
        TextView title = tv(AdminRoles.workTitle(work.role), 14, INK, true);
        title.setPadding(dp(6), 0, 0, 0);
        title.setSingleLine(true);
        title.setEllipsize(TextUtils.TruncateAt.END);
        titleRow.addView(title, new LinearLayout.LayoutParams(0, -2, 1f));
        mid.addView(titleRow);

        TextView sub = tv(AdminRoles.workSubtitle(work.role), 11, MUTED, false);
        sub.setSingleLine(true);
        sub.setEllipsize(TextUtils.TruncateAt.END);
        mid.addView(sub, lp(-1, -2, 2));

        LinearLayout chips = new LinearLayout(this);
        chips.setOrientation(LinearLayout.HORIZONTAL);
        int shown = Math.min(2, work.functions.size());
        for (int c = 0; c < shown; c++) {
            AdminRoles.Fn fn = AdminRoles.FUNCTIONS.get(work.functions.get(c));
            if (fn == null) continue;
            LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(0, -2, 1f);
            if (c > 0) cp.leftMargin = dp(4);
            chips.addView(chip(fn.label), cp);
        }
        int extra = work.functions.size() - shown;
        if (extra > 0) {
            TextView more = tv("+" + extra, 10, MUTED, true);
            more.setGravity(Gravity.CENTER);
            more.setPadding(dp(7), dp(4), dp(7), dp(4));
            more.setBackground(shape(0xCCFFFFFF, 7, 0xFFDCEBE0, 1));
            LinearLayout.LayoutParams mp = new LinearLayout.LayoutParams(-2, -2);
            mp.leftMargin = dp(4);
            chips.addView(more, mp);
        }
        if (work.functions.isEmpty()) {
            chips.addView(chip(ownerMode ? "Flexible Control" : "No function yet"));
        }
        mid.addView(chips, lp(-1, -2, 6));
        card.addView(mid, new LinearLayout.LayoutParams(0, -2, 1f));

        card.addView(arrowCircle(ACCENT[i], Color.WHITE, 30));
        card.setOnClickListener(v -> {
            if (ownerMode) openKeyDialog(work.role, null, "", null);
            else openWorkspace(work);
        });
        return card;
    }

    private TextView chip(String label) {
        SpannableString text = new SpannableString("\u2713  " + label);
        text.setSpan(new ForegroundColorSpan(GREEN), 0, 1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        text.setSpan(new ForegroundColorSpan(INK), 3, text.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        TextView chip = new TextView(this);
        chip.setText(text);
        chip.setTextSize(10f);
        chip.setSingleLine(true);
        chip.setEllipsize(TextUtils.TruncateAt.END);
        chip.setGravity(Gravity.CENTER_VERTICAL);
        chip.setPadding(dp(7), dp(4), dp(7), dp(4));
        chip.setBackground(shape(0xDDFFFFFF, 7, 0xFFDCEBE0, 1));
        return chip;
    }

    private View arrowCircle(int fill, int arrowColor, int sizeDp) {
        TextView arrow = tv("\u203A", sizeDp * 0.62f, arrowColor, true);
        arrow.setGravity(Gravity.CENTER);
        arrow.setIncludeFontPadding(false);
        arrow.setBackground(shape(fill, Math.max(8, sizeDp / 3), 0, 0));
        arrow.setLayoutParams(new LinearLayout.LayoutParams(dp(sizeDp), dp(sizeDp)));
        return arrow;
    }

    private View buildFooterGenerate() {
        TextView button = tv("Generate Key", 15, Color.WHITE, true);
        android.graphics.drawable.Drawable keyIcon = getDrawable(R.drawable.ic_hub_key).mutate();
        keyIcon.setTint(Color.WHITE);
        keyIcon.setBounds(0, 0, dp(20), dp(20));
        button.setCompoundDrawablesRelative(keyIcon, null, null, null);
        button.setCompoundDrawablePadding(dp(8));
        button.setGravity(Gravity.CENTER);
        button.setPadding(dp(14), dp(11), dp(14), dp(11));
        GradientDrawable bg = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                new int[]{0xFF2F7DF6, 0xFF1C9BEA});
        bg.setCornerRadius(dp(12));
        button.setBackground(bg);
        button.setOnClickListener(v -> chooseWorkThenKey());
        return button;
    }

    private View buildLogout() {
        TextView logout = tv("Logout", 13, RED, true);
        logout.setGravity(Gravity.CENTER);
        logout.setBackground(shape(0xFFFFFFFF, 12, 0xFFFFD3DA, 1));
        logout.setOnClickListener(v -> logout());
        return logout;
    }

    // ================================================================ works shown on the page

    private static final class Work {
        final int index;
        final String role;
        final List<String> functions;
        Work(int index, String role, List<String> functions) {
            this.index = index; this.role = role; this.functions = functions;
        }
    }

    /** Owner: the 4 preset works. Key-holder: only works that contain something the owner assigned. */
    private List<Work> buildWorks() {
        List<Work> works = new ArrayList<>();
        if (ownerMode) {
            for (int i = 0; i < AdminRoles.WORK_ROLES.length; i++) {
                String role = AdminRoles.WORK_ROLES[i];
                works.add(new Work(i, role, new ArrayList<>(AdminRoles.defaultFunctions(role))));
            }
            return works;
        }
        Set<String> used = new HashSet<>();
        for (int i = 0; i < 3; i++) {
            String role = AdminRoles.WORK_ROLES[i];
            List<String> mine = new ArrayList<>();
            for (String fn : AdminRoles.defaultFunctions(role)) {
                if (myPerms.contains(fn)) { mine.add(fn); used.add(fn); }
            }
            if (!mine.isEmpty()) works.add(new Work(i, role, mine));
        }
        List<String> extras = new ArrayList<>();
        for (String fn : myPerms) {
            if (!used.contains(fn) && AdminRoles.FUNCTIONS.containsKey(fn)) extras.add(fn);
        }
        if (!extras.isEmpty()) works.add(new Work(3, AdminRoles.CUSTOM_MANAGER, extras));
        return works;
    }

    /** Key-holder taps a work: open AdminActivity on that work's page. It only unlocks the assigned perms. */
    private void openWorkspace(Work work) {
        Intent intent = new Intent(this, AdminActivity.class);
        intent.putExtra("adminRole", AdminRoles.isWorkRole(myRole) ? myRole : AdminRoles.CUSTOM_MANAGER);
        intent.putStringArrayListExtra("adminPerms", new ArrayList<>(myPerms));
        intent.putExtra("openPage", AdminRoles.landingPage(new LinkedHashSet<>(work.functions)));
        startActivity(intent);
    }

    private void logout() {
        try {
            FirebaseRepository.clearAdminPresence();
        } catch (Throwable ignored) { }
        FirebaseRepository.signOut();
        Intent intent = new Intent(this, AdminLoginActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();
    }

    // ================================================================ owner: generate / edit key

    private void chooseWorkThenKey() {
        final String[] roles = AdminRoles.WORK_ROLES;
        String[] titles = new String[roles.length];
        for (int i = 0; i < roles.length; i++) titles[i] = (i + 1) + ".  " + AdminRoles.workTitle(roles[i]);
        new FancyText.PlatformBuilder(this)
                .setTitle("Select work for the new key")
                .setItems(titles, (d, which) -> openKeyDialog(roles[which], null, "", null))
                .setNegativeButton("Cancel", null)
                .show();
    }

    /**
     * existingKey == null -> create a new key. Otherwise edit that key's functions in place.
     * The checklist is pre-ticked with the work's default functions; the owner can tick / untick anything.
     */
    private void openKeyDialog(final String role, final String existingKey, String existingName,
                               Set<String> existingPerms) {
        final boolean editing = existingKey != null;
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(22), dp(10), dp(22), dp(6));

        final EditText nameField = new EditText(this);
        nameField.setHint("Admin name (e.g. Rahul)");
        nameField.setSingleLine(true);
        nameField.setText(existingName);
        nameField.setEnabled(!editing);
        box.addView(nameField, new LinearLayout.LayoutParams(-1, -2));

        TextView label = tv("This admin will only see the ticked functions:", 13, MUTED, true);
        box.addView(label, lp(-1, -2, 14));

        Set<String> preset = existingPerms != null ? existingPerms
                : new HashSet<>(AdminRoles.defaultFunctions(role));
        final Map<String, CheckBox> boxes = new LinkedHashMap<>();
        for (AdminRoles.Fn fn : AdminRoles.FUNCTIONS.values()) {
            CheckBox cb = new CheckBox(this);
            SpannableString text = new SpannableString(fn.label + "\n" + fn.hint);
            text.setSpan(new ForegroundColorSpan(MUTED), fn.label.length() + 1, text.length(),
                    Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            cb.setText(text);
            cb.setTextSize(14);
            cb.setChecked(preset.contains(fn.id));
            boxes.put(fn.id, cb);
            box.addView(cb, lp(-1, -2, 4));
        }
        ScrollView scroll = new ScrollView(this);
        scroll.addView(box);

        final AlertDialog dialog = new FancyText.PlatformBuilder(this)
                .setTitle((editing ? "Edit  " : "New key  \u2022  ") + AdminRoles.workTitle(role))
                .setView(scroll)
                .setPositiveButton(editing ? "Save" : "Generate Key", null)
                .setNegativeButton("Cancel", null)
                .create();
        dialog.setOnShowListener(d -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            String name = nameField.getText() == null ? "" : nameField.getText().toString().trim();
            if (name.isEmpty()) { toast("Enter the admin's name first."); return; }
            final List<String> chosen = new ArrayList<>();
            for (Map.Entry<String, CheckBox> e : boxes.entrySet()) {
                if (e.getValue().isChecked()) chosen.add(e.getKey());
            }
            if (chosen.isEmpty()) { toast("Tick at least one function."); return; }
            v.setEnabled(false);
            if (editing) saveEdit(dialog, v, existingKey, name, chosen);
            else createKey(dialog, v, role, name, chosen);
        }));
        dialog.show();
    }

    private void createKey(final AlertDialog dialog, final View button, final String role,
                           final String name, final List<String> perms) {
        final String key = FirebaseRepository.generateReadableKey();
        FirebaseRepository.createAdminKey(key, name, role, perms)
                .addOnSuccessListener(unused -> {
                    FirebaseRepository.logActivity("ADMIN_KEY_CREATED", name, role + " " + perms);
                    dialog.dismiss();
                    showKeyCreated(key, name, role, perms);
                })
                .addOnFailureListener(error -> {
                    button.setEnabled(true);
                    toast(error.getMessage() == null ? "Could not create the key." : error.getMessage());
                });
    }

    private void saveEdit(final AlertDialog dialog, final View button, final String key,
                          final String name, final List<String> perms) {
        Map<String, Object> permMap = new HashMap<>();
        for (String id : perms) permMap.put(id, true);
        FirebaseRepository.adminKeys().child(key).child("perms").setValue(permMap)
                .addOnSuccessListener(unused -> {
                    FirebaseRepository.logActivity("ADMIN_KEY_UPDATED", name, perms.toString());
                    dialog.dismiss();
                    toast("Functions updated. The admin sees them on next login.");
                })
                .addOnFailureListener(error -> {
                    button.setEnabled(true);
                    toast(error.getMessage() == null ? "Could not save." : error.getMessage());
                });
    }

    private void showKeyCreated(final String key, String name, String role, List<String> perms) {
        StringBuilder fns = new StringBuilder();
        for (String id : perms) {
            AdminRoles.Fn fn = AdminRoles.FUNCTIONS.get(id);
            if (fns.length() > 0) fns.append(", ");
            fns.append(fn == null ? id : fn.label);
        }
        final String share = "STARX24 Admin Key for " + name + "\n" + key
                + "\n\nOpen the admin login, choose the ADMIN KEY tab and enter this key.";
        new FancyText.PlatformBuilder(this)
                .setTitle("Key ready")
                .setMessage("Admin: " + name + "\nWork: " + AdminRoles.workTitle(role)
                        + "\nFunctions: " + fns + "\n\nAccess key:\n" + key
                        + "\n\nGive this key to the admin. They sign in with it from the ADMIN KEY tab.")
                .setPositiveButton("Copy key", (d, w) -> copy(key))
                .setNeutralButton("Share", (d, w) -> {
                    Intent send = new Intent(Intent.ACTION_SEND);
                    send.setType("text/plain");
                    send.putExtra(Intent.EXTRA_TEXT, share);
                    startActivity(Intent.createChooser(send, "Share key"));
                })
                .setNegativeButton("Done", null)
                .show();
    }

    // ================================================================ owner: key list

    private void watchKeys() {
        keysRef = FirebaseRepository.adminKeys();
        keysListener = new ValueEventListener() {
            @Override public void onDataChange(DataSnapshot snapshot) { lastKeys = snapshot; renderKeys(); }
            @Override public void onCancelled(DatabaseError error) {
                if (keysContainer == null) return;
                keysContainer.removeAllViews();
                keysContainer.addView(tv("Keys unavailable: " + error.getMessage(), 13, RED, false));
            }
        };
        keysRef.addValueEventListener(keysListener);

        sessionsRef = FirebaseRepository.adminSessions();
        sessionsListener = new ValueEventListener() {
            @Override public void onDataChange(DataSnapshot snapshot) {
                onlineKeys.clear();
                for (DataSnapshot s : snapshot.getChildren()) {
                    Object k = s.child("key").getValue();
                    if (k != null && Boolean.TRUE.equals(s.child("online").getValue())) onlineKeys.add(String.valueOf(k));
                }
                renderKeys();
            }
            @Override public void onCancelled(DatabaseError error) { }
        };
        sessionsRef.addValueEventListener(sessionsListener);
    }

    private void renderKeys() {
        if (keysContainer == null || lastKeys == null) return;
        keysContainer.removeAllViews();
        if (!lastKeys.exists() || lastKeys.getChildrenCount() == 0) {
            return;
        }
        keysContainer.addView(headingTv("Key History", 16), lp(-2, -2, 4));
        for (DataSnapshot child : lastKeys.getChildren()) keysContainer.addView(keyRow(child), lp(-1, -2, 10));
    }

    private View keyRow(DataSnapshot child) {
        final String key = child.getKey();
        Object labelVal = child.child("label").getValue();
        final String label = labelVal == null ? "Unnamed" : String.valueOf(labelVal);
        Object roleVal = child.child("role").getValue();
        final String role = roleVal == null ? "" : String.valueOf(roleVal);
        final boolean active = !Boolean.FALSE.equals(child.child("active").getValue());
        boolean online = onlineKeys.contains(key);

        final Set<String> perms = new LinkedHashSet<>();
        StringBuilder fns = new StringBuilder();
        for (DataSnapshot p : child.child("perms").getChildren()) {
            if (!Boolean.TRUE.equals(p.getValue())) continue;
            perms.add(p.getKey());
            AdminRoles.Fn fn = AdminRoles.FUNCTIONS.get(p.getKey());
            if (fns.length() > 0) fns.append("  \u2022  ");
            fns.append(fn == null ? p.getKey() : fn.label);
        }
        final boolean workKey = AdminRoles.isWorkRole(role);

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(12), dp(10), dp(12), dp(9));
        card.setBackground(shape(Color.WHITE, 12, 0xFFE6EDF8, 1));
        card.setOnClickListener(v -> com.arenax.tournament.util.AdminKeyHistory.show(this, key, label,
                AdminRoles.isWorkRole(role) ? AdminRoles.workTitle(role) : AdminRoles.label(role)));

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        TextView name = tv(label, 14, INK, true);
        top.addView(name, new LinearLayout.LayoutParams(0, -2, 1f));
        String statusText = !active ? "REVOKED" : online ? "\u25CF ONLINE" : "\u25CF OFFLINE";
        int statusColor = !active ? RED : online ? GREEN : MUTED;
        TextView status = tv(statusText, 10, statusColor, true);
        status.setPadding(dp(8), dp(3), dp(8), dp(3));
        status.setBackground(shape(!active ? 0xFFFFE6EA : online ? 0xFFE3F8EE : 0xFFEEF1F6, 8, 0, 0));
        top.addView(status, new LinearLayout.LayoutParams(-2, -2));
        card.addView(top);

        card.addView(tv(workKey ? AdminRoles.workTitle(role) : AdminRoles.label(role) + " (legacy role)",
                13, MUTED, false), lp(-1, -2, 2));
        if (fns.length() > 0) card.addView(tv(fns.toString(), 11, INK, false), lp(-1, -2, 6));
        card.addView(tv("Tap to see full history", 10, MUTED, false), lp(-1, -2, 4));
        TextView code = tv(key, 13, BLUE, true);
        code.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        card.addView(code, lp(-1, -2, 8));

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        actions.addView(smallButton("COPY", BLUE, v -> copy(key)));
        if (active && workKey) {
            actions.addView(smallButton("EDIT", 0xFF8250E8, v -> openKeyDialog(role, key, label, perms)));
        }
        if (active) {
            actions.addView(smallButton("REVOKE", 0xFFE08A00, v -> confirm("Revoke " + label + "?",
                    "This admin is locked out immediately and cannot sign in with this key again.", () ->
                            FirebaseRepository.revokeAdminKey(key)
                                    .addOnSuccessListener(u -> FirebaseRepository.logActivity("ADMIN_KEY_REVOKED", label, role))
                                    .addOnFailureListener(e -> toast(e.getMessage())))));
        } else {
            actions.addView(smallButton("DELETE", RED, v -> confirm("Delete this key?",
                    label + "'s key will be removed permanently.", () ->
                            FirebaseRepository.deleteAdminKey(key)
                                    .addOnSuccessListener(u -> FirebaseRepository.logActivity("ADMIN_KEY_DELETED", label, role))
                                    .addOnFailureListener(e -> toast(e.getMessage())))));
        }
        card.addView(actions, lp(-1, -2, 10));
        return card;
    }

    private TextView smallButton(String label, int color, View.OnClickListener click) {
        TextView button = tv(label, 11, color, true);
        button.setGravity(Gravity.CENTER);
        button.setPadding(dp(11), dp(6), dp(11), dp(6));
        button.setBackground(shape(Color.WHITE, 9, color, 1));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-2, -2);
        p.rightMargin = dp(8);
        button.setLayoutParams(p);
        button.setOnClickListener(click);
        return button;
    }

    private void confirm(String title, String message, final Runnable onYes) {
        new FancyText.PlatformBuilder(this)
                .setTitle(title)
                .setMessage(message)
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Confirm", (d, w) -> onYes.run())
                .show();
    }

    // ================================================================ connection pill

    private void watchConnection() {
        try {
            connectedRef = FirebaseRepository.adminKeys().getRoot().child(".info/connected");
            connectedListener = new ValueEventListener() {
                @Override public void onDataChange(DataSnapshot snapshot) {
                    boolean on = Boolean.TRUE.equals(snapshot.getValue(Boolean.class));
                    if (onlineText != null) onlineText.setText(on ? "Online" : "Offline");
                    if (onlineDot != null) onlineDot.setBackground(shape(on ? GREEN : 0xFF9AA5B8, 6, 0, 0));
                }
                @Override public void onCancelled(DatabaseError error) { }
            };
            connectedRef.addValueEventListener(connectedListener);
        } catch (Throwable ignored) { }
    }

    @Override
    protected void onDestroy() {
        if (keysRef != null && keysListener != null) keysRef.removeEventListener(keysListener);
        if (sessionsRef != null && sessionsListener != null) sessionsRef.removeEventListener(sessionsListener);
        if (connectedRef != null && connectedListener != null) connectedRef.removeEventListener(connectedListener);
        super.onDestroy();
    }

    // ================================================================ small helpers

    private void copy(String text) {
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("admin key", text));
        toast("Key copied.");
    }

    private void toast(String message) {
        FancyText.toast(this, message == null ? "Something went wrong." : message, Toast.LENGTH_SHORT).show();
    }

    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    /** A tinted vector symbol (replaces emoji so it looks the same on every phone). */
    private android.widget.ImageView symbol(int res, int tint, int paddingDp) {
        android.widget.ImageView v = new android.widget.ImageView(this);
        v.setImageResource(res);
        v.setColorFilter(tint);
        v.setScaleType(android.widget.ImageView.ScaleType.FIT_CENTER);
        v.setPadding(dp(paddingDp), dp(paddingDp), dp(paddingDp), dp(paddingDp));
        return v;
    }

    /** Premium heading: sans-bold alphabet, kept out of the generic FancyText pass. */
    private TextView headingTv(String text, float sp) {
        TextView view = tv(text, sp, INK, true);
        view.setTag("nofancy");
        view.setText(FancyText.heading(text));
        view.setLetterSpacing(0.01f);
        return view;
    }

    private TextView tv(String text, float sp, int color, boolean bold) {
        TextView view = new TextView(this);
        view.setText(text);
        view.setTextSize(sp);
        view.setTextColor(color);
        if (bold) view.setTypeface(null, Typeface.BOLD);
        return view;
    }

    private GradientDrawable shape(int color, int radiusDp, int strokeColor, int strokeDp) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radiusDp));
        if (strokeDp > 0) d.setStroke(dp(strokeDp), strokeColor);
        return d;
    }

    /** LayoutParams with a top margin in dp. width/height: -1 match, -2 wrap, otherwise pixels. */
    private LinearLayout.LayoutParams lp(int width, int height, int topDp) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(width, height);
        p.topMargin = dp(topDp);
        return p;
    }
}
