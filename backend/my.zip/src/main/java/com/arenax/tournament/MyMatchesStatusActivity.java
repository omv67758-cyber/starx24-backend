package com.arenax.tournament;


import com.arenax.tournament.util.FancyText;
import com.arenax.tournament.util.ImageLoader;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.Outline;
import android.graphics.drawable.GradientDrawable;
import android.view.View;
import android.view.ViewOutlineProvider;
import android.widget.FrameLayout;
import android.widget.ImageView;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import android.os.Bundle;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.arenax.tournament.data.FirebaseRepository;
import com.arenax.tournament.model.Match;
import com.arenax.tournament.model.Tournament;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.ValueEventListener;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Opened from the home page's Upcoming / Ongoing / Completed tiles.
 *
 * Shows only matches the player has actually joined (same "am I in
 * tournamentParticipants" check used by MyMatchesActivity's stats view) — a
 * match the player never joined never shows up here. Each joined match is
 * bucketed using {@link Match#getEffectiveStatus()}:
 *   COMPLETED                        -> Completed
 *   LIVE / ROOM_RELEASED / WAITING / DELAYED -> Ongoing (already started)
 *   UPCOMING (default, not started yet)      -> Upcoming
 *   CANCELLED                        -> left out of all three tabs
 */
public class MyMatchesStatusActivity extends BaseActivity {

    public static final String EXTRA_STATUS = "status";
    public static final String STATUS_UPCOMING = "upcoming";
    public static final String STATUS_ONGOING = "ongoing";
    public static final String STATUS_COMPLETED = "completed";

    private LinearLayout content;
    private String status;
    private final List<Row> rows = new ArrayList<>();
    private final AtomicInteger pending = new AtomicInteger(0);

    private static class Row {
        String tournamentId;
        String title;
        String map;
        String mode;
        long scheduledAt;
        String effectiveStatus;
        Tournament tournament; // full match info for the card (banner, coins, type, map ...)
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (!FirebaseRepository.isReady(this)) {
            FancyText.toast(this, "Live services are unavailable. Please try again later.", Toast.LENGTH_LONG).show();
            finish();
            return;
        }

        status = getIntent().getStringExtra(EXTRA_STATUS);
        if (status == null) status = STATUS_UPCOMING;

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.parseColor("#F5F8FE"));

        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(12), dp(18), dp(16), dp(10));
        TextView back = text("‹", 26, "#1C1C1E", true);
        back.setPadding(dp(4), 0, dp(14), 0);
        back.setOnClickListener(v -> finish());
        bar.addView(back);
        TextView title = text(titleFor(status), 19, "#1C1C1E", true);
        LinearLayout.LayoutParams titleLp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        title.setGravity(Gravity.CENTER);
        bar.addView(title, titleLp);
        TextView spacer = text("", 22, "#1C1C1E", false);
        spacer.setWidth(dp(28));
        bar.addView(spacer);
        root.addView(bar);

        ScrollView scroll = new ScrollView(this);
        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(12), dp(4), dp(12), dp(24));
        scroll.addView(content);
        root.addView(scroll, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        setContentView(root);

        content.addView(pageText("Loading your matches…"));
        load();
    }

    private String titleFor(String s) {
        if (STATUS_ONGOING.equals(s)) return "Ongoing Matches";
        if (STATUS_COMPLETED.equals(s)) return "Completed Matches";
        return "Upcoming Matches";
    }

    // Matches whose effective status falls under this tab.
    private boolean belongs(String effectiveStatus) {
        if (Match.CANCELLED.equals(effectiveStatus)) return false;
        if (Match.COMPLETED.equals(effectiveStatus)) return STATUS_COMPLETED.equals(status);
        if (Match.LIVE.equals(effectiveStatus) || Match.ROOM_RELEASED.equals(effectiveStatus)
                || Match.WAITING.equals(effectiveStatus) || Match.DELAYED.equals(effectiveStatus)) {
            return STATUS_ONGOING.equals(status);
        }
        // Match.UPCOMING (default, not started)
        return STATUS_UPCOMING.equals(status);
    }

    private void load() {
        String uid = FirebaseRepository.currentUser() == null ? null : FirebaseRepository.currentUser().getUid();
        if (uid == null) {
            content.removeAllViews();
            content.addView(pageText("Sign in to see your matches."));
            return;
        }
        FirebaseRepository.tournaments().addListenerForSingleValueEvent(new ValueEventListener() {
            @Override public void onDataChange(@NonNull DataSnapshot snapshot) {
                List<DataSnapshot> all = new ArrayList<>();
                for (DataSnapshot t : snapshot.getChildren()) all.add(t);
                checkNext(all, 0, new ArrayList<>(), uid);
            }
            @Override public void onCancelled(@NonNull DatabaseError error) {
                content.removeAllViews();
                content.addView(pageText("Could not load your tournaments."));
            }
        });
    }

    private void checkNext(List<DataSnapshot> all, int index, List<String> myTournamentIds, String uid) {
        if (index >= all.size()) {
            if (myTournamentIds.isEmpty()) {
                content.removeAllViews();
                content.addView(pageText("You haven't joined any tournament yet. Join one to see it here."));
                return;
            }
            for (String tid : myTournamentIds) {
                pending.incrementAndGet();
                loadMatchesForTournament(tid);
            }
            return;
        }
        DataSnapshot t = all.get(index);
        FirebaseRepository.tournamentParticipants(t.getKey()).child(uid).get()
                .addOnSuccessListener(p -> {
                    if (p.exists()) myTournamentIds.add(t.getKey());
                    checkNext(all, index + 1, myTournamentIds, uid);
                })
                .addOnFailureListener(e -> checkNext(all, index + 1, myTournamentIds, uid));
    }

    private void loadMatchesForTournament(String tournamentId) {
        FirebaseRepository.tournaments().child(tournamentId).get().addOnCompleteListener(tTask -> {
            Tournament tour = null;
            if (tTask.isSuccessful() && tTask.getResult() != null && tTask.getResult().getValue() != null) {
                @SuppressWarnings("unchecked")
                java.util.Map<String, Object> v = (java.util.Map<String, Object>) tTask.getResult().getValue();
                tour = Tournament.fromMap(tournamentId, v);
            }
            final Tournament tournament = tour;

            // Admin published the leaderboard (Rank & Leaderboard) -> whole match is Completed,
            // whatever its sub-round records say. One card, tapping it opens the result.
            if (tournament != null && Tournament.COMPLETED.equals(tournament.getEffectiveStatus())) {
                if (STATUS_COMPLETED.equals(status)) {
                    Row row = new Row();
                    row.tournamentId = tournamentId;
                    row.title = tournament.getTitle();
                    row.map = tournament.getMap();
                    row.mode = tournament.getMode();
                    row.scheduledAt = tournament.getEffectiveStartAt();
                    row.effectiveStatus = Match.COMPLETED;
                    row.tournament = tournament;
                    synchronized (rows) { rows.add(row); }
                }
                maybeFinish();
                return;
            }

            FirebaseRepository.matches().orderByChild("tournamentId").equalTo(tournamentId).get()
                    .addOnCompleteListener(mTask -> {
                        if (mTask.isSuccessful() && mTask.getResult() != null && mTask.getResult().exists()) {
                            for (DataSnapshot child : mTask.getResult().getChildren()) {
                                @SuppressWarnings("unchecked")
                                Match m = Match.fromMap(child.getKey(), (java.util.Map<String, Object>) child.getValue());
                                if (m == null) continue;
                                String effective = m.getEffectiveStatus();
                                if (!belongs(effective)) continue;
                                Row row = new Row();
                                row.tournamentId = tournamentId;
                                row.title = tournament != null && !tournament.getTitle().isEmpty()
                                        ? tournament.getTitle()
                                        : (m.getTournamentTitle().isEmpty() ? m.getName() : m.getTournamentTitle());
                                row.map = m.getMap();
                                row.mode = m.getMode();
                                row.scheduledAt = m.getScheduledAt();
                                row.effectiveStatus = effective;
                                row.tournament = tournament;
                                synchronized (rows) { rows.add(row); }
                            }
                        }
                        maybeFinish();
                    });
        });
    }

    private void maybeFinish() {
        if (pending.decrementAndGet() <= 0) {
            Collections.sort(rows, (a, b) -> Long.compare(a.scheduledAt, b.scheduledAt));
            render();
        }
    }

    private void render() {
        content.removeAllViews();
        if (rows.isEmpty()) {
            content.addView(pageText("No matches here yet."));
            return;
        }
        for (Row row : rows) content.addView(card(row));
    }

    private static final String BLUE = "#2674EC";
    private static final String NAVY = "#14284B";
    private static final String MUTED = "#68686D";

    /** Rich white-theme match card: banner, title, time, coins row, info row and an action button. */
    private LinearLayout card(Row row) {
        final Tournament t = row.tournament;
        final boolean completed = Match.COMPLETED.equals(row.effectiveStatus);

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.WHITE);
        bg.setCornerRadius(dp(18));
        bg.setStroke(dp(2), Color.parseColor(BLUE));
        card.setBackground(bg);
        card.setElevation(dp(3));
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        cp.topMargin = dp(6);
        cp.bottomMargin = dp(12);
        cp.leftMargin = dp(2);
        cp.rightMargin = dp(2);
        card.setLayoutParams(cp);
        card.setClickable(true);
        card.setFocusable(true);
        View.OnClickListener open = v -> {
            if (completed) {
                startActivity(new Intent(this, MatchResultActivity.class).putExtra("tournamentId", row.tournamentId));
                return;
            }
            Intent i = new Intent(this, MyMatchesActivity.class);
            i.putExtra(MyMatchesActivity.EXTRA_TOURNAMENT_ID, row.tournamentId);
            startActivity(i);
        };
        card.setOnClickListener(open);

        // ---- banner (16:9, rounded, with the status pill floating on top) ----
        FrameLayout banner = new FrameLayout(this) {
            @Override protected void onMeasure(int w, int h) {
                int width = MeasureSpec.getSize(w);
                super.onMeasure(MeasureSpec.makeMeasureSpec(width, MeasureSpec.EXACTLY),
                        MeasureSpec.makeMeasureSpec(width * 9 / 16, MeasureSpec.EXACTLY));
            }
        };
        LinearLayout.LayoutParams bnp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        bnp.setMargins(dp(10), dp(10), dp(10), 0);
        banner.setLayoutParams(bnp);
        GradientDrawable bnBg = new GradientDrawable();
        bnBg.setColor(Color.parseColor("#E9EFFB"));
        bnBg.setCornerRadius(dp(12));
        banner.setBackground(bnBg);
        banner.setClipToOutline(true);
        banner.setOutlineProvider(new ViewOutlineProvider() {
            @Override public void getOutline(View view, Outline outline) {
                outline.setRoundRect(0, 0, view.getWidth(), view.getHeight(), dp(12));
            }
        });
        ImageView image = new ImageView(this);
        image.setScaleType(ImageView.ScaleType.CENTER_CROP);
        String url = t == null ? null : t.getBannerUrl();
        ImageLoader.load(image, url);
        banner.addView(image, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        TextView pill = statusPill(row.effectiveStatus);
        FrameLayout.LayoutParams pl = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.TOP | Gravity.END);
        pl.setMargins(0, dp(10), dp(10), 0);
        pill.setLayoutParams(pl);
        banner.addView(pill);
        card.addView(banner);

        // ---- title + time ----
        String title = row.title == null || row.title.isEmpty() ? "Match" : row.title;
        TextView titleView = text(title, 18, NAVY, true);
        titleView.setMaxLines(3);
        titleView.setEllipsize(android.text.TextUtils.TruncateAt.END);
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        tp.setMargins(dp(14), dp(14), dp(14), 0);
        card.addView(titleView, tp);

        String when;
        if (t != null && t.getDate() != null && !t.getDate().isEmpty()) when = t.getDate() + " at " + t.getTime();
        else if (row.scheduledAt > 0) when = new SimpleDateFormat("dd/MM/yyyy 'at' hh:mm a", Locale.ENGLISH).format(new Date(row.scheduledAt));
        else when = "";
        if (!when.isEmpty()) {
            TextView time = text("Time : " + when, 13, MUTED, false);
            LinearLayout.LayoutParams tmp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            tmp.setMargins(dp(14), dp(4), dp(14), 0);
            card.addView(time, tmp);
        }

        card.addView(divider());

        // ---- PRIZE POOL / PER KILL / ENTRY FEE ----
        LinearLayout coins = new LinearLayout(this);
        coins.setOrientation(LinearLayout.HORIZONTAL);
        coins.addView(statColumn("PRIZE POOL", t == null ? "0" : String.valueOf(t.getPrizePoolCoins()), true));
        coins.addView(statColumn("PER KILL", t == null ? "0" : String.valueOf(t.getPerKillCoins()), true));
        coins.addView(statColumn("ENTRY FEE", t == null ? "0" : String.valueOf(t.getEntryFeeCoins()), true));
        LinearLayout.LayoutParams cop = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        cop.setMargins(dp(10), dp(12), dp(10), 0);
        card.addView(coins, cop);

        // ---- TYPE / ENTRY PER PLAYER / MAP ----
        String type = t != null && t.getGameType() != null && !t.getGameType().isEmpty() ? t.getGameType()
                : (row.mode == null || row.mode.isEmpty() ? "-" : row.mode);
        String map = row.map == null || row.map.isEmpty() ? "-" : row.map;
        LinearLayout info = new LinearLayout(this);
        info.setOrientation(LinearLayout.HORIZONTAL);
        info.addView(statColumn("TYPE", type.toUpperCase(Locale.ROOT), false));
        info.addView(statColumn("ENTRY PER PLAYER", t == null ? "0" : String.valueOf(t.getEntryFeeCoins()), false));
        info.addView(statColumn("MAP", map.toUpperCase(Locale.ROOT), false));
        LinearLayout.LayoutParams inp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        inp.setMargins(dp(10), dp(14), dp(10), 0);
        card.addView(info, inp);

        // ---- action button ----
        TextView button = text(completed ? "VIEW RESULT" : "VIEW MATCH", 14, "#FFFFFF", true);
        button.setGravity(Gravity.CENTER);
        button.setLetterSpacing(0.06f);
        GradientDrawable bb = new GradientDrawable();
        bb.setColor(Color.parseColor(BLUE));
        bb.setCornerRadius(dp(12));
        button.setBackground(bb);
        button.setOnClickListener(open);
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(46));
        bp.setMargins(dp(14), dp(16), dp(14), dp(14));
        card.addView(button, bp);
        return card;
    }

    private View divider() {
        View v = new View(this);
        v.setBackgroundColor(Color.parseColor("#E5E9F2"));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(1));
        lp.setMargins(dp(14), dp(14), dp(14), 0);
        v.setLayoutParams(lp);
        return v;
    }

    /** One small "LABEL over value" column. coinValue = big number with the coin icon in front. */
    private LinearLayout statColumn(String label, String value, boolean coinValue) {
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setGravity(Gravity.CENTER_HORIZONTAL);
        col.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        TextView l = text(label, 10, MUTED, true);
        l.setLetterSpacing(0.06f);
        l.setGravity(Gravity.CENTER);
        col.addView(l);
        TextView v = text(value, coinValue ? 20 : 13, NAVY, true);
        v.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams vp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        vp.topMargin = dp(coinValue ? 4 : 6);
        if (coinValue) {
            v.setCompoundDrawablesWithIntrinsicBounds(CoinEmoji.drawable(this, 24), null, null, null);
            v.setCompoundDrawablePadding(dp(6));
        }
        col.addView(v, vp);
        return col;
    }

    private TextView statusPill(String effective) {
        String bg, fg, label;
        if (Match.COMPLETED.equals(effective)) {
            bg = "#ECECEE"; fg = "#68686D"; label = "COMPLETED";
        } else if (Match.LIVE.equals(effective)) {
            bg = "#FDE9E9"; fg = "#D9342C"; label = "LIVE NOW";
        } else if (Match.ROOM_RELEASED.equals(effective)) {
            bg = "#DFF5E8"; fg = "#1FAA59"; label = "ROOM RELEASED";
        } else if (Match.WAITING.equals(effective)) {
            bg = "#FFF3DF"; fg = "#C2820B"; label = "WAITING FOR ROOM";
        } else if (Match.DELAYED.equals(effective)) {
            bg = "#FFF3DF"; fg = "#C2820B"; label = "DELAYED";
        } else {
            bg = "#E4EEFF"; fg = "#2F6FE4"; label = "UPCOMING";
        }
        TextView pill = text(label, 11, fg, true);
        pill.setPadding(dp(12), dp(6), dp(12), dp(6));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        pill.setLayoutParams(lp);
        GradientDrawable pbg = new GradientDrawable();
        pbg.setCornerRadius(dp(20));
        pbg.setColor(Color.parseColor(bg));
        pbg.setStroke(dp(1), Color.parseColor(fg));
        pill.setBackground(pbg);
        return pill;
    }

    private TextView text(String value, int sizeSp, String colorHex, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(sizeSp);
        t.setTextColor(Color.parseColor(colorHex));
        if (bold) t.setTypeface(null, Typeface.BOLD);
        return t;
    }

    private TextView pageText(String value) {
        TextView t = text(value, 12, "#68686D", false);
        t.setPadding(0, dp(4), 0, dp(4));
        return t;
    }

    private int dp(int value) { return Math.round(value * getResources().getDisplayMetrics().density); }
}
