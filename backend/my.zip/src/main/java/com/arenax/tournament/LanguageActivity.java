package com.arenax.tournament;

import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import com.arenax.tournament.util.AppTranslator;
import com.arenax.tournament.util.FancyText;
import com.arenax.tournament.util.LanguageManager;
import com.arenax.tournament.util.LanguageManager.Lang;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Full-screen language page (Profile -> Language): searchable list of raised cards,
 *  the selected language shown as a blue card. */
public class LanguageActivity extends BaseActivity {

    private final List<Lang> shown = new ArrayList<>();
    private BaseAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        LanguageManager.init(this);
        shown.addAll(LanguageManager.all());

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.parseColor("#F6F5F2"));
        root.setPadding(dp(18), dp(18), dp(18), 0);

        // ---- header: round back button + two-line title (same look as Help Center)
        TextView back = label("\u2039", 30, Color.parseColor("#1C1C1E"), true);
        back.setTag(FancyText.NO_FANCY);
        back.setGravity(Gravity.CENTER);
        GradientDrawable backBg = new GradientDrawable();
        backBg.setShape(GradientDrawable.OVAL);
        backBg.setColor(Color.WHITE);
        back.setBackground(backBg);
        back.setElevation(dp(3));
        back.setOnClickListener(v -> finish());
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(dp(40), dp(40));
        bp.bottomMargin = dp(14);
        root.addView(back, bp);

        root.addView(label("Choose", 25, Color.parseColor("#1C1C1E"), true));
        root.addView(label("Language", 25, Color.parseColor("#2563EB"), true));
        TextView sub = label("Pick the language you want the whole app in.", 13,
                Color.parseColor("#68686D"), false);
        sub.setPadding(0, dp(6), 0, dp(14));
        root.addView(sub);

        // ---- search
        EditText search = new EditText(this);
        search.setHint("Search language");
        search.setSingleLine(true);
        search.setTextSize(15);
        search.setTextColor(Color.parseColor("#1C1C1E"));
        search.setHintTextColor(Color.parseColor("#9A9AA0"));
        search.setPadding(dp(16), 0, dp(16), 0);
        GradientDrawable sbg = new GradientDrawable();
        sbg.setColor(Color.WHITE);
        sbg.setCornerRadius(dp(14));
        sbg.setStroke(dp(1), Color.parseColor("#E2E5EC"));
        search.setBackground(sbg);
        root.addView(search, new LinearLayout.LayoutParams(-1, dp(48)));

        // ---- list
        ListView list = new ListView(this);
        list.setDivider(null);
        list.setDividerHeight(0);
        list.setClipToPadding(false);
        list.setPadding(0, dp(10), 0, dp(24));
        list.setVerticalScrollBarEnabled(false);
        adapter = new BaseAdapter() {
            @Override public int getCount() { return shown.size(); }
            @Override public Object getItem(int i) { return shown.get(i); }
            @Override public long getItemId(int i) { return i; }
            @Override public View getView(int i, View convert, ViewGroup parent) {
                return row(shown.get(i));
            }
        };
        list.setAdapter(adapter);
        list.setOnItemClickListener((p, v, pos, id) -> LanguageManager.choose(this, shown.get(pos)));
        root.addView(list, new LinearLayout.LayoutParams(-1, 0, 1));

        search.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) {
                String q = s == null ? "" : s.toString().trim().toLowerCase(Locale.ROOT);
                shown.clear();
                for (Lang l : LanguageManager.all()) {
                    if (q.isEmpty() || l.nativeName.toLowerCase(Locale.ROOT).contains(q)
                            || l.englishName.toLowerCase(Locale.ROOT).contains(q)
                            || l.code.toLowerCase(Locale.ROOT).startsWith(q)) {
                        shown.add(l);
                    }
                }
                adapter.notifyDataSetChanged();
            }
            @Override public void afterTextChanged(Editable s) {}
        });

        setContentView(root);
    }

    private View row(Lang l) {
        boolean selected = l.code.equals(LanguageManager.code());

        FrameLayout wrap = new FrameLayout(this);
        wrap.setPadding(dp(4), dp(5), dp(4), dp(5));
        wrap.setClipChildren(false);
        wrap.setClipToPadding(false);

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.HORIZONTAL);
        card.setGravity(Gravity.CENTER_VERTICAL);
        card.setPadding(dp(18), dp(14), dp(18), dp(14));
        GradientDrawable bg = new GradientDrawable();
        bg.setCornerRadius(dp(16));
        if (selected) {
            bg.setOrientation(GradientDrawable.Orientation.TOP_BOTTOM);
            bg.setColors(new int[]{Color.parseColor("#4F8BFF"), Color.parseColor("#2358D6")});
        } else {
            bg.setColor(Color.WHITE);
        }
        card.setBackground(bg);
        card.setElevation(dp(selected ? 6 : 3));

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);

        TextView nat = label(l.nativeName, 17, selected ? Color.WHITE : Color.parseColor("#1C1C1E"), true);
        nat.setTag(FancyText.NO_FANCY);
        col.addView(nat);

        String sub = l.englishName;
        if (!AppTranslator.isSupported(l.code)) sub += "  \u2022  setup needed";
        TextView eng = label(sub, 12, selected ? Color.parseColor("#DCE8FF") : Color.parseColor("#68686D"), false);
        eng.setTag(FancyText.NO_FANCY);
        col.addView(eng);

        card.addView(col, new LinearLayout.LayoutParams(0, -2, 1));

        if (selected) {
            TextView tick = label("\u2713", 20, Color.WHITE, true);
            tick.setTag(FancyText.NO_FANCY);
            card.addView(tick);
        }
        wrap.addView(card, new FrameLayout.LayoutParams(-1, -2));
        return wrap;
    }

    private TextView label(String text, float size, int color, boolean bold) {
        TextView v = new TextView(this);
        v.setText(text);
        v.setTextSize(size);
        v.setTextColor(color);
        v.setTypeface(null, bold ? Typeface.BOLD : Typeface.NORMAL);
        return v;
    }

    private int dp(float value) { return Math.round(value * getResources().getDisplayMetrics().density); }

    @Override
    protected void onResume() {
        super.onResume();
        if (adapter != null) adapter.notifyDataSetChanged();
    }
}
