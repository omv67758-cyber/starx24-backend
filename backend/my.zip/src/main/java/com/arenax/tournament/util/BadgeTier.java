package com.arenax.tournament.util;

import com.arenax.tournament.R;

/**
 * Maps a player's leaderboard score (leaderboard/allTime/{uid}/score) to a badge tier.
 * A brand-new account has no score row yet, so {@link #forScore(long)} returns null and
 * the profile screen simply shows no badge until the player's first published result.
 *
 * Thresholds are a starting point tuned to the existing placement+kill point table in
 * FirebaseRepository.publishResult (15/12/10... placement points + 1 per kill) — adjust
 * the numbers below any time without touching the display code.
 */
public enum BadgeTier {
    BRONZE("Rookie", 1, R.drawable.badge_ring_bronze, R.drawable.p2_ic_shield, R.color.badge_bronze_neon),
    SILVER("Contender", 300, R.drawable.badge_ring_silver, R.drawable.p2_ic_star, R.color.badge_silver_neon),
    GOLD("Champion", 800, R.drawable.badge_ring_gold, R.drawable.p2_ic_crown, R.color.badge_gold_neon),
    PLATINUM("Elite", 2000, R.drawable.badge_ring_platinum, R.drawable.p2_ic_fire, R.color.badge_platinum_neon),
    DIAMOND("Legend", 5000, R.drawable.badge_ring_diamond, R.drawable.ic_trophy, R.color.badge_diamond_neon);

    public final String label;
    public final int minScore;
    public final int neonRingRes;
    public final int iconRes;
    public final int neonColorRes;

    BadgeTier(String label, int minScore, int neonRingRes, int iconRes, int neonColorRes) {
        this.label = label;
        this.minScore = minScore;
        this.neonRingRes = neonRingRes;
        this.iconRes = iconRes;
        this.neonColorRes = neonColorRes;
    }

    /** Returns the highest tier the score qualifies for, or null for a fresh/zero-score account. */
    public static BadgeTier forScore(long score) {
        BadgeTier earned = null;
        for (BadgeTier tier : values()) {
            if (score >= tier.minScore) earned = tier;
        }
        return earned;
    }
}
