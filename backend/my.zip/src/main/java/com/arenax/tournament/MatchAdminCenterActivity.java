package com.arenax.tournament;


import com.arenax.tournament.util.FancyText;
import com.arenax.tournament.util.FullScreenDialog;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager2.widget.ViewPager2;

import com.arenax.tournament.data.FirebaseRepository;
import com.arenax.tournament.model.Match;
import com.arenax.tournament.model.Tournament;
import com.arenax.tournament.util.FcmSender;
import com.arenax.tournament.util.RoomReleaseScheduler;
import com.google.android.material.button.MaterialButton;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * One-screen admin match control center, replacing the separate room-control dialog and the
 * long scrolling "Results & Coins" list with three swipeable pages that each fit the screen
 * with no vertical page scroll — only the participant/leaderboard rows scroll inside their own
 * fixed list area, the page chrome around them never does:
 *   1. OVERVIEW    — room ID/password, quick schedule, release + a short notification to send.
 *   2. PARTICIPANTS — joined player, game name & game UID (as given at join time); tap the
 *      pencil to type a coin amount directly — no kills/placement math needed.
 *   3. RANK MANAGE  — the live leaderboard those coin entries build automatically.
 * Entering a coin amount also credits the player's wallet by the delta and rolls into the
 * running daily + monthly leaderboards, so a whole-day/whole-month leaderboard needs no extra work.
 */
public class MatchAdminCenterActivity extends BaseActivity {

    public static final String EXTRA_TOURNAMENT = "tournament";
    public static final String EXTRA_MATCH = "match";

    private Tournament tournament;
    private Match match;
    private boolean matchMode;
    private String recordId;
    private String recordTitle;

    private EditText roomIdField;
    private EditText roomPassField;
    private EditText notifyField;
    private MaterialButton releaseToggle;

    private TextView tab0, tab1, tab2;
    private ViewPager2 pager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (!FirebaseRepository.isReady(this)) {
            FancyText.toast(this, "Live services are unavailable. Please try again later.", Toast.LENGTH_LONG).show();
            finish();
            return;
        }
        if (android.os.Build.VERSION.SDK_INT >= 33) {
            tournament = getIntent().getSerializableExtra(EXTRA_TOURNAMENT, Tournament.class);
            match = getIntent().getSerializableExtra(EXTRA_MATCH, Match.class);
        } else {
            tournament = (Tournament) getIntent().getSerializableExtra(EXTRA_TOURNAMENT);
            match = (Match) getIntent().getSerializableExtra(EXTRA_MATCH);
        }
        matchMode = match != null;
        if (tournament == null && match == null) {
            finish();
            return;
        }
        recordId = matchMode ? match.getId() : tournament.getId();
        recordTitle = matchMode ? match.getName() : tournament.getTitle();
        buildUi();
    }

    // ------------------------------------------------------------------ theme helpers
    private int dp(float v) { return (int) (v * getResources().getDisplayMetrics().density + 0.5f); }

    private TextView navyText(String text, float sizeSp, boolean bold, String hex) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextSize(sizeSp);
        tv.setTypeface(null, bold ? Typeface.BOLD : Typeface.NORMAL);
        tv.setTextColor(Color.parseColor(hex));
        return tv;
    }

    private EditText navyField(String hint) {
        EditText input = new EditText(this);
        input.setHint(hint);
        input.setTextColor(Color.parseColor("#1C1C1E"));
        input.setHintTextColor(Color.parseColor("#68686D"));
        input.setBackgroundResource(R.drawable.bg_input_navy);
        int hPad = dp(14), vPad = dp(11);
        input.setPadding(hPad, vPad, hPad, vPad);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.topMargin = dp(4);
        input.setLayoutParams(p);
        input.setTextSize(13f);
        return input;
    }

    private MaterialButton gradientButton(String label) {
        MaterialButton b = new MaterialButton(this);
        b.setText(label);
        b.setTextColor(Color.WHITE);
        b.setAllCaps(false);
        b.setTextSize(12.5f);
        b.setTypeface(null, Typeface.BOLD);
        b.setBackgroundResource(R.drawable.bg_button_gradient);
        b.setElevation(0f);
        b.setInsetTop(0);
        b.setInsetBottom(0);
        b.setCornerRadius(dp(12));
        return b;
    }

    private MaterialButton outlineButton(String label, String strokeHex) {
        MaterialButton b = new MaterialButton(this);
        b.setText(label);
        b.setTextColor(Color.parseColor(strokeHex));
        b.setAllCaps(false);
        b.setTextSize(12.5f);
        b.setTypeface(null, Typeface.BOLD);
        b.setBackgroundResource(R.drawable.bg_dialog_button_outline);
        b.setStrokeColor(ColorStateList.valueOf(Color.parseColor(strokeHex)));
        b.setStrokeWidth(dp(1));
        b.setElevation(0f);
        b.setInsetTop(0);
        b.setInsetBottom(0);
        b.setCornerRadius(dp(12));
        return b;
    }

    // ------------------------------------------------------------------ root: top bar + pager
    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundResource(R.drawable.bg_page_navy);

        // Top bar: back + title only — nothing decorative.
        LinearLayout topBar = new LinearLayout(this);
        topBar.setOrientation(LinearLayout.HORIZONTAL);
        topBar.setGravity(Gravity.CENTER_VERTICAL);
        topBar.setPadding(dp(12), dp(10), dp(12), dp(10));
        topBar.setBackgroundResource(R.drawable.bg_card_navy);

        TextView back = new TextView(this);
        back.setBackgroundResource(R.drawable.bg_section_pill_navy);
        back.setCompoundDrawablesWithIntrinsicBounds(R.drawable.ic_arrow_back, 0, 0, 0);
        back.setPadding(dp(8), dp(6), dp(10), dp(6));
        back.setOnClickListener(v -> finish());
        topBar.addView(back, new LinearLayout.LayoutParams(-2, -2));

        TextView title = navyText(recordTitle == null ? "Match" : recordTitle, 14.5f, true, "#1C1C1E");
        title.setSingleLine(true);
        title.setEllipsize(android.text.TextUtils.TruncateAt.END);
        LinearLayout.LayoutParams titleParams = new LinearLayout.LayoutParams(0, -2, 1f);
        titleParams.leftMargin = dp(10);
        topBar.addView(title, titleParams);
        root.addView(topBar);

        // Tab strip — tap a label or swipe to move between the three pages.
        LinearLayout tabs = new LinearLayout(this);
        tabs.setOrientation(LinearLayout.HORIZONTAL);
        tabs.setBackgroundResource(R.drawable.bg_card_navy);
        tabs.setPadding(dp(12), 0, dp(12), dp(8));
        tab0 = tabLabel("OVERVIEW");
        tab1 = tabLabel("PARTICIPANTS");
        tab2 = tabLabel("RANK MANAGE");
        tabs.addView(tab0, new LinearLayout.LayoutParams(0, -2, 1f));
        tabs.addView(tab1, new LinearLayout.LayoutParams(0, -2, 1f));
        tabs.addView(tab2, new LinearLayout.LayoutParams(0, -2, 1f));
        root.addView(tabs);

        pager = new ViewPager2(this);
        pager.setAdapter(new PageAdapter());
        pager.setLayoutParams(new LinearLayout.LayoutParams(-1, 0, 1f));
        pager.registerOnPageChangeCallback(new ViewPager2.OnPageChangeCallback() {
            @Override public void onPageSelected(int position) { highlightTab(position); }
        });
        tab0.setOnClickListener(v -> pager.setCurrentItem(0, true));
        tab1.setOnClickListener(v -> pager.setCurrentItem(1, true));
        tab2.setOnClickListener(v -> pager.setCurrentItem(2, true));
        root.addView(pager);
        highlightTab(0);

        setContentView(root);
    }

    private TextView tabLabel(String text) {
        TextView t = navyText(text, 11f, true, "#68686D");
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(4), dp(8), dp(4), dp(8));
        t.setLetterSpacing(0.02f);
        return t;
    }

    private void highlightTab(int index) {
        TextView[] tabs = {tab0, tab1, tab2};
        for (int i = 0; i < tabs.length; i++) {
            tabs[i].setTextColor(Color.parseColor(i == index ? "#ED2F3E" : "#68686D"));
        }
    }

    private boolean releasedFlag() {
        return matchMode ? match.isRoomReleased() : tournament.isRoomReleased();
    }

    private String currentRoomId() {
        return matchMode ? match.getRoomId() : tournament.getRoomId();
    }

    private String currentRoomPassword() {
        return matchMode ? match.getRoomPassword() : tournament.getRoomPassword();
    }

    // ------------------------------------------------------------------ ViewPager2 adapter
    private static final int PAGE_OVERVIEW = 0;
    private static final int PAGE_PARTICIPANTS = 1;
    private static final int PAGE_RANK = 2;

    private class PageAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
        @Override public int getItemViewType(int position) { return position; }
        @Override public int getItemCount() { return 3; }

        @NonNull @Override public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View page;
            if (viewType == PAGE_OVERVIEW) page = buildOverviewPage(parent);
            else if (viewType == PAGE_PARTICIPANTS) page = buildParticipantsPage(parent);
            else page = buildRankManagePage(parent);
            page.setLayoutParams(new ViewGroup.LayoutParams(-1, -1));
            return new RecyclerView.ViewHolder(page) {};
        }

        @Override public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) { }
    }

    // ==================================================================
    // PAGE 1 — OVERVIEW (condensed room access + schedule + notification)
    // ==================================================================
    private View buildOverviewPage(ViewGroup parent) {
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(14), dp(12), dp(14), dp(12));

        if (!matchMode) {
            // DAILY MODE — works for every match in every category, new or old.
            final android.widget.Switch daily = new android.widget.Switch(this);
            daily.setText("DAILY MODE (roz isi time par repeat)");
            daily.setTextSize(12f);
            daily.setTypeface(null, Typeface.BOLD);
            daily.setTextColor(Color.parseColor("#1C1C1E"));
            daily.setChecked(tournament.isDailyMode());
            daily.setPadding(dp(2), dp(4), dp(2), dp(8));
            final boolean[] reverting = {false};
            daily.setOnCheckedChangeListener((button, checked) -> {
                if (reverting[0] || checked == tournament.isDailyMode()) return;
                button.setEnabled(false);
                FirebaseRepository.setDailyMode(tournament, checked)
                        .addOnSuccessListener(unused -> {
                            button.setEnabled(true);
                            FancyText.toast(this, checked
                                    ? "Daily mode ON — ye match roz isi time par aayega."
                                    : "Daily mode OFF.", Toast.LENGTH_SHORT).show();
                        })
                        .addOnFailureListener(error -> {
                            button.setEnabled(true);
                            reverting[0] = true;
                            button.setChecked(!checked);
                            reverting[0] = false;
                            FancyText.toast(this, "Daily mode failed: " + error.getMessage(), Toast.LENGTH_LONG).show();
                        });
            });
            page.addView(daily);
        }

        page.addView(navyText("ROOM ACCESS", 11f, true, "#68686D"));
        roomIdField = navyField("Room ID");
        roomIdField.setText(currentRoomId());
        page.addView(roomIdField);
        roomPassField = navyField("Password");
        roomPassField.setText(currentRoomPassword());
        page.addView(roomPassField);

        LinearLayout quick = new LinearLayout(this);
        quick.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams quickParams = new LinearLayout.LayoutParams(-1, -2);
        quickParams.topMargin = dp(10);
        quick.setLayoutParams(quickParams);
        MaterialButton releaseNow = gradientButton(releasedFlag() ? "HIDE ROOM" : "RELEASE NOW");
        releaseNow.setOnClickListener(v -> saveOverview(true));
        LinearLayout.LayoutParams half = new LinearLayout.LayoutParams(0, dp(42), 1f);
        half.rightMargin = dp(6);
        quick.addView(releaseNow, half);
        MaterialButton saveOnly = outlineButton("SAVE", "#68686D");
        saveOnly.setOnClickListener(v -> saveOverview(false));
        quick.addView(saveOnly, new LinearLayout.LayoutParams(0, dp(42), 1f));
        page.addView(quick);
        releaseToggle = releaseNow;

        TextView notifyLabel = navyText("RELEASE NOTIFICATION", 11f, true, "#68686D");
        LinearLayout.LayoutParams notifyLabelParams = new LinearLayout.LayoutParams(-1, -2);
        notifyLabelParams.topMargin = dp(16);
        notifyLabel.setLayoutParams(notifyLabelParams);
        page.addView(notifyLabel);

        notifyField = navyField("Message to joined players…");
        LinearLayout.LayoutParams notifyParams = new LinearLayout.LayoutParams(-1, 0, 1f);
        notifyField.setLayoutParams(notifyParams);
        notifyField.setGravity(Gravity.TOP | Gravity.START);
        notifyField.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        page.addView(notifyField);

        MaterialButton send = gradientButton("SEND NOTIFICATION");
        LinearLayout.LayoutParams sendParams = new LinearLayout.LayoutParams(-1, dp(44));
        sendParams.topMargin = dp(10);
        send.setLayoutParams(sendParams);
        send.setOnClickListener(v -> sendNotification());
        page.addView(send);

        return page;
    }

    private void saveOverview(boolean toggleRelease) {
        final String roomId = roomIdField.getText().toString().trim();
        final String roomPass = roomPassField.getText().toString().trim();

        if (matchMode) {
            if (toggleRelease) {
                RoomReleaseScheduler.cancel(this, match.getId());
                if (match.isRoomReleased()) {
                    FirebaseRepository.hideMatchRoom(match.getId());
                    FancyText.toast(this, "Room hidden from players.", Toast.LENGTH_SHORT).show();
                } else {
                    FirebaseRepository.releaseMatchRoom(match.getId(), roomId, roomPass);
                    FirebaseRepository.publishNotification("Room Released",
                            match.getName() + " room ID & password are now live.");
                    sendRoomReleasePush(FirebaseRepository.matchParticipants(match.getId()),
                            match.getName() + " — Room Released!",
                            "Room ID: " + roomId + " | Password: " + roomPass);
                    FancyText.toast(this, "Room released live to players.", Toast.LENGTH_SHORT).show();
                }
            } else {
                FancyText.toast(this, "Room details saved.", Toast.LENGTH_SHORT).show();
            }
            return;
        }

        RoomReleaseScheduler.cancel(this, tournament.getId());
        boolean released = toggleRelease ? !tournament.isRoomReleased() : tournament.isRoomReleased();
        Tournament updated = new Tournament(
                tournament.getId(), tournament.getTitle(), tournament.getMode(), tournament.getCategoryId(),
                tournament.getBannerUrl(), tournament.getDescription(), tournament.getDate(), tournament.getTime(),
                tournament.getStartAt(), tournament.getRegistrationCloseAt(), tournament.getRoomReleaseAt(),
                tournament.getPrizeInfo(), tournament.getTotalSlots(), tournament.getJoinedSlots(),
                tournament.getTeamSize(), tournament.getMap(), tournament.getMatchType(), tournament.getRules(),
                tournament.getPrizeDistribution(), roomId, roomPass, released, tournament.getDelayReason(),
                tournament.getStatus(), tournament.getRegistrationStatus(), tournament.isActive(),
                tournament.getAccentColor());
        updated.setCoinDetails(tournament.getEntryFeeCoins(), tournament.getPrizePoolCoins(), tournament.getPerKillCoins(), tournament.getGameType());
        updated.setResultSystem(tournament.getResultSystem());
        updated.setDailyMode(tournament.isDailyMode());
        updated.setDailySeriesId(tournament.getDailySeriesId());
        updated.setDailyNextId(tournament.getDailyNextId());
        FirebaseRepository.saveTournament(updated)
                .addOnSuccessListener(unused -> {
                    tournament = updated;
                    FancyText.toast(this, released ? "Room released live to players." : "Room hidden from players.",
                            Toast.LENGTH_SHORT).show();
                    FirebaseRepository.publishNotification(
                            released ? "Room Released" : "Room Update",
                            released ? tournament.getTitle() + " room ID & password are now live."
                                    : tournament.getTitle() + " room hidden.");
                    if (released) {
                        sendRoomReleasePush(FirebaseRepository.tournamentParticipants(tournament.getId()),
                                tournament.getTitle() + " — Room Released!",
                                "Room ID: " + roomId + " | Password: " + roomPass);
                    }
                })
                .addOnFailureListener(error -> FancyText.toast(this, error.getMessage(), Toast.LENGTH_LONG).show());
    }

    private void sendNotification() {
        String msg = notifyField.getText().toString().trim();
        if (msg.isEmpty()) {
            FancyText.toast(this, "Type a message first.", Toast.LENGTH_SHORT).show();
            return;
        }
        DatabaseReference participants = matchMode
                ? FirebaseRepository.matchParticipants(match.getId())
                : FirebaseRepository.tournamentParticipants(tournament.getId());
        sendRoomReleasePush(participants, recordTitle, msg);
        notifyField.setText("");
        FancyText.toast(this, "Notification sent.", Toast.LENGTH_SHORT).show();
    }

    private void sendRoomReleasePush(DatabaseReference participantsRef, String title, String body) {
        FirebaseRepository.collectParticipantFcmTokens(participantsRef, tokens -> {
            if (tokens.isEmpty()) return;
            new Thread(() -> {
                try {
                    FcmSender.sendToAllTokens(null, tokens, title, body, "",
                            (successCount, total, errorLog) -> runOnUiThread(() ->
                                    FancyText.toast(this, "Notified " + successCount + "/" + total
                                            + " joined player(s).", Toast.LENGTH_SHORT).show()));
                } catch (Exception e) {
                    runOnUiThread(() -> FancyText.toast(this, "Push failed: " + e.getMessage(), Toast.LENGTH_SHORT).show());
                }
            }).start();
        });
    }

    // ==================================================================
    // PAGE 2 — PARTICIPANTS (name / game name / game UID / pencil → coins)
    // ==================================================================
    private static class ParticipantRow {
        String uid;
        String accountName = "";
        String gameName = "";
        String gameUid = "";
        int coins = 0;
    }

    private View buildParticipantsPage(ViewGroup parent) {
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(14), dp(10), dp(14), dp(10));

        LinearLayout head = new LinearLayout(this);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setPadding(dp(10), dp(8), dp(10), dp(8));
        head.setBackgroundColor(Color.parseColor("#5A606E"));
        head.addView(headCell("Name", 1.4f));
        head.addView(headCell("Game Name / UID", 1.8f));
        head.addView(headCell("Coins", 0.8f));
        head.addView(headCell("", 0.5f));
        page.addView(head);

        RecyclerView list = new RecyclerView(this);
        list.setLayoutManager(new LinearLayoutManager(this));
        LinearLayout.LayoutParams listParams = new LinearLayout.LayoutParams(-1, 0, 1f);
        list.setLayoutParams(listParams);
        page.addView(list);

        ParticipantsAdapter adapter = new ParticipantsAdapter();
        list.setAdapter(adapter);
        loadParticipants(adapter);
        return page;
    }

    private TextView headCell(String text, float weight) {
        TextView t = navyText(text, 10.5f, true, "#FFFFFF");
        t.setLayoutParams(new LinearLayout.LayoutParams(0, -2, weight));
        return t;
    }

    private void loadParticipants(ParticipantsAdapter adapter) {
        FirebaseRepository.joinedUsers(recordId).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override public void onDataChange(@NonNull DataSnapshot snapshot) {
                List<ParticipantRow> rows = new ArrayList<>();
                for (DataSnapshot child : snapshot.getChildren()) {
                    String uid = child.getKey();
                    if (uid == null) continue;
                    ParticipantRow row = new ParticipantRow();
                    row.uid = uid;
                    Object gameName = child.child("gameName").getValue();
                    row.gameName = gameName == null ? "" : String.valueOf(gameName);
                    Object gameUid = child.child("gameUid").getValue();
                    row.gameUid = gameUid == null ? "" : String.valueOf(gameUid);
                    Object coins = child.child("adminCoins").getValue();
                    row.coins = coins instanceof Number ? ((Number) coins).intValue() : 0;
                    rows.add(row);
                    // Account display name lives on /users/{uid}/name — fetch once per row.
                    FirebaseRepository.users().child(uid).child("name").addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override public void onDataChange(@NonNull DataSnapshot nameSnap) {
                            Object n = nameSnap.getValue();
                            row.accountName = n == null || String.valueOf(n).trim().isEmpty()
                                    ? (row.gameName.isEmpty() ? "Player" : row.gameName) : String.valueOf(n);
                            adapter.notifyDataSetChanged();
                        }
                        @Override public void onCancelled(@NonNull DatabaseError error) { }
                    });
                }
                adapter.setRows(rows);
                if (rows.isEmpty()) FancyText.toast(MatchAdminCenterActivity.this,
                        "No users have joined this match yet.", Toast.LENGTH_SHORT).show();
            }
            @Override public void onCancelled(@NonNull DatabaseError error) {
                FancyText.toast(MatchAdminCenterActivity.this, "Could not load participants: " + error.getMessage(),
                        Toast.LENGTH_LONG).show();
            }
        });
    }

    private class ParticipantsAdapter extends RecyclerView.Adapter<ParticipantsAdapter.VH> {
        private final List<ParticipantRow> rows = new ArrayList<>();

        void setRows(List<ParticipantRow> newRows) {
            rows.clear();
            rows.addAll(newRows);
            notifyDataSetChanged();
        }

        class VH extends RecyclerView.ViewHolder {
            TextView name, gameInfo, coins;
            TextView edit;
            VH(LinearLayout row) {
                super(row);
                name = (TextView) row.getChildAt(0);
                gameInfo = (TextView) row.getChildAt(1);
                coins = (TextView) row.getChildAt(2);
                edit = (TextView) row.getChildAt(3);
            }
        }

        @NonNull @Override public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            LinearLayout row = new LinearLayout(MatchAdminCenterActivity.this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(dp(10), dp(9), dp(10), dp(9));
            row.setBackgroundResource(R.drawable.bg_card_navy);

            TextView name = new TextView(MatchAdminCenterActivity.this);
            name.setTextSize(12.5f);
            name.setTextColor(Color.parseColor("#1C1C1E"));
            name.setTypeface(null, Typeface.BOLD);
            row.addView(name, new LinearLayout.LayoutParams(0, -2, 1.4f));

            TextView gameInfo = new TextView(MatchAdminCenterActivity.this);
            gameInfo.setTextSize(11f);
            gameInfo.setTextColor(Color.parseColor("#68686D"));
            row.addView(gameInfo, new LinearLayout.LayoutParams(0, -2, 1.8f));

            TextView coins = new TextView(MatchAdminCenterActivity.this);
            coins.setTextSize(12.5f);
            coins.setTypeface(null, Typeface.BOLD);
            coins.setTextColor(Color.parseColor("#B8860B"));
            row.addView(coins, new LinearLayout.LayoutParams(0, -2, 0.8f));

            TextView edit = new TextView(MatchAdminCenterActivity.this);
            edit.setBackgroundResource(R.drawable.bg_section_pill_navy);
            edit.setCompoundDrawablesWithIntrinsicBounds(R.drawable.ic_edit_pencil, 0, 0, 0);
            edit.setPadding(dp(8), dp(6), dp(8), dp(6));
            LinearLayout.LayoutParams editParams = new LinearLayout.LayoutParams(0, -2, 0.5f);
            editParams.gravity = Gravity.END;
            row.addView(edit, editParams);

            LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(-1, -2);
            rp.bottomMargin = dp(4);
            row.setLayoutParams(rp);
            return new VH(row);
        }

        @Override public void onBindViewHolder(@NonNull VH holder, int position) {
            ParticipantRow row = rows.get(position);
            holder.name.setText(row.accountName.isEmpty() ? "Player" : row.accountName);
            holder.gameInfo.setText((row.gameName.isEmpty() ? "—" : row.gameName)
                    + "  •  " + (row.gameUid.isEmpty() ? "—" : row.gameUid));
            holder.coins.setText(row.coins + " coins");
            holder.edit.setOnClickListener(v -> showCoinDialog(row));
        }

        @Override public int getItemCount() { return rows.size(); }
    }

    private void showCoinDialog(ParticipantRow row) {
        EditText coinInput = navyField("Coins");
        coinInput.setInputType(InputType.TYPE_CLASS_NUMBER);
        coinInput.setText(String.valueOf(row.coins));
        LinearLayout form = new LinearLayout(this);
        form.setOrientation(LinearLayout.VERTICAL);
        form.setPadding(dp(20), dp(8), dp(20), dp(0));
        form.addView(coinInput);
        new FullScreenDialog.Builder(this)
                .setTitle((row.accountName.isEmpty() ? "Player" : row.accountName) + " — set coins")
                .setMessage("This amount is credited to the player's wallet and becomes this match's leaderboard score.")
                .setView(form)
                .setNegativeButton("CANCEL", null)
                .setPositiveButton("SAVE", (dialog, which) -> {
                    int parsedCoins;
                    try {
                        parsedCoins = Integer.parseInt(coinInput.getText().toString().trim());
                    } catch (NumberFormatException e) {
                        parsedCoins = 0;
                    }
                    final int coins = parsedCoins;
                    FirebaseRepository.setMatchPlayerCoins(recordId, recordTitle, row.uid,
                                    row.accountName.isEmpty() ? "Player" : row.accountName,
                                    row.gameName, row.gameUid, coins)
                            .addOnSuccessListener(done -> {
                                row.coins = Math.max(0, coins);
                                FancyText.toast(this, "Coins saved & wallet updated.", Toast.LENGTH_SHORT).show();
                                pager.getAdapter().notifyDataSetChanged();
                            })
                            .addOnFailureListener(error -> FancyText.toast(this, error.getMessage(), Toast.LENGTH_LONG).show());
                }).show();
    }

    // ==================================================================
    // PAGE 3 — RANK MANAGE (live leaderboard built from the coins above)
    // ==================================================================
    private static class RankRow {
        String username = "Player";
        String gameName = "";
        long coins = 0;
    }

    private View buildRankManagePage(ViewGroup parent) {
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(14), dp(10), dp(14), dp(10));

        LinearLayout head = new LinearLayout(this);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setPadding(dp(10), dp(8), dp(10), dp(8));
        head.setBackgroundColor(Color.parseColor("#5A606E"));
        head.addView(headCell("#", 0.4f));
        head.addView(headCell("Player", 1.6f));
        head.addView(headCell("Coins", 0.8f));
        page.addView(head);

        RecyclerView list = new RecyclerView(this);
        list.setLayoutManager(new LinearLayoutManager(this));
        list.setLayoutParams(new LinearLayout.LayoutParams(-1, 0, 1f));
        page.addView(list);

        RankAdapter adapter = new RankAdapter();
        list.setAdapter(adapter);
        if (leaderboardRef != null && leaderboardListener != null) leaderboardRef.removeEventListener(leaderboardListener);
        leaderboardRef = FirebaseRepository.matchLeaderboard(recordId);
        leaderboardListener = new ValueEventListener() {
            @Override public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (isFinishing() || isDestroyed()) return;
                List<RankRow> rows = new ArrayList<>();
                for (DataSnapshot child : snapshot.getChildren()) {
                    RankRow r = new RankRow();
                    Object u = child.child("username").getValue();
                    r.username = u == null ? "Player" : String.valueOf(u);
                    Object g = child.child("gameName").getValue();
                    r.gameName = g == null ? "" : String.valueOf(g);
                    Object c = child.child("coins").getValue();
                    r.coins = c instanceof Number ? ((Number) c).longValue() : 0;
                    rows.add(r);
                }
                Collections.sort(rows, (a, b) -> Long.compare(b.coins, a.coins));
                adapter.setRows(rows);
            }
            @Override public void onCancelled(@NonNull DatabaseError error) { }
        };
        leaderboardRef.addValueEventListener(leaderboardListener);
        return page;
    }

    private DatabaseReference leaderboardRef;
    private ValueEventListener leaderboardListener;

    @Override
    protected void onDestroy() {
        if (leaderboardRef != null && leaderboardListener != null) leaderboardRef.removeEventListener(leaderboardListener);
        leaderboardRef = null;
        leaderboardListener = null;
        super.onDestroy();
    }

    private class RankAdapter extends RecyclerView.Adapter<RankAdapter.VH> {
        private final List<RankRow> rows = new ArrayList<>();

        void setRows(List<RankRow> newRows) {
            rows.clear();
            rows.addAll(newRows);
            notifyDataSetChanged();
        }

        class VH extends RecyclerView.ViewHolder {
            TextView rank, player, coins;
            VH(LinearLayout row) {
                super(row);
                rank = (TextView) row.getChildAt(0);
                player = (TextView) row.getChildAt(1);
                coins = (TextView) row.getChildAt(2);
            }
        }

        @NonNull @Override public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            LinearLayout row = new LinearLayout(MatchAdminCenterActivity.this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(dp(10), dp(9), dp(10), dp(9));
            row.setBackgroundResource(R.drawable.bg_card_navy);

            TextView rank = new TextView(MatchAdminCenterActivity.this);
            rank.setTextSize(12.5f);
            rank.setTypeface(null, Typeface.BOLD);
            rank.setTextColor(Color.parseColor("#ED2F3E"));
            row.addView(rank, new LinearLayout.LayoutParams(0, -2, 0.4f));

            TextView player = new TextView(MatchAdminCenterActivity.this);
            player.setTextSize(12.5f);
            player.setTextColor(Color.parseColor("#1C1C1E"));
            row.addView(player, new LinearLayout.LayoutParams(0, -2, 1.6f));

            TextView coins = new TextView(MatchAdminCenterActivity.this);
            coins.setTextSize(12.5f);
            coins.setTypeface(null, Typeface.BOLD);
            coins.setTextColor(Color.parseColor("#B8860B"));
            row.addView(coins, new LinearLayout.LayoutParams(0, -2, 0.8f));

            LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(-1, -2);
            rp.bottomMargin = dp(4);
            row.setLayoutParams(rp);
            return new VH(row);
        }

        @Override public void onBindViewHolder(@NonNull VH holder, int position) {
            RankRow row = rows.get(position);
            holder.rank.setText("#" + (position + 1));
            holder.player.setText(row.username + (row.gameName.isEmpty() ? "" : "  (" + row.gameName + ")"));
            holder.coins.setText(row.coins + " coins");
        }

        @Override public int getItemCount() { return rows.size(); }
    }
}
