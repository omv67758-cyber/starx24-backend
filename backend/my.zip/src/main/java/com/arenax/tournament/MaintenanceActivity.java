package com.arenax.tournament;

import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.arenax.tournament.util.AppStatus;
import com.arenax.tournament.util.FancyText;
import com.arenax.tournament.util.StatusUi;
import com.google.firebase.database.ValueEventListener;

/**
 * Full-screen "under maintenance" page. The user app cannot get past it; the admin app gets an
 * extra "Continue to admin panel" button (EXTRA_CAN_BYPASS). It listens live, so it closes by
 * itself as soon as the admin switches maintenance off.
 */
public class MaintenanceActivity extends BaseActivity {
    public static final String EXTRA_CAN_BYPASS = "canBypass";

    private boolean canBypass;
    private ValueEventListener listener;
    private LinearLayout content;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        canBypass = getIntent().getBooleanExtra(EXTRA_CAN_BYPASS, false);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(StatusUi.CANVAS);
        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setGravity(Gravity.CENTER_HORIZONTAL);
        int pad = StatusUi.dp(this, 22);
        content.setPadding(pad, StatusUi.dp(this, 36), pad, pad);
        scroll.addView(content, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        setContentView(scroll);

        render(AppStatus.last());
        listener = AppStatus.listen(state -> {
            if (state == null) return;
            if (!state.mEnabled) { finish(); return; }
            render(state);
        });
    }

    private void render(AppStatus.State s) {
        content.removeAllViews();
        String title = s == null || s.mTitle.isEmpty() ? "We'll be right back" : s.mTitle;
        String msg = s == null || s.mMessage.isEmpty()
                ? "The app is under maintenance to make things faster and better. Please check back soon." : s.mMessage;
        String eta = s == null ? "" : s.mEta;
        final String contact = s == null ? "" : s.mContact;

        View spacerTop = new View(this);
        content.addView(spacerTop, new LinearLayout.LayoutParams(1, 0, 1f));

        View badge = StatusUi.badge(this, R.drawable.ic_status_maintenance, StatusUi.AMBER, StatusUi.AMBER_TINT, 112);
        content.addView(badge);

        LinearLayout status = new LinearLayout(this);
        status.setOrientation(LinearLayout.HORIZONTAL);
        status.setGravity(Gravity.CENTER_VERTICAL);
        status.setPadding(StatusUi.dp(this, 12), StatusUi.dp(this, 6), StatusUi.dp(this, 12), StatusUi.dp(this, 6));
        status.setBackground(StatusUi.box(StatusUi.AMBER_TINT, 20, 0, this));
        View dot = new View(this);
        GradientDrawable dg = new GradientDrawable();
        dg.setShape(GradientDrawable.OVAL);
        dg.setColor(StatusUi.AMBER);
        dot.setBackground(dg);
        status.addView(dot, new LinearLayout.LayoutParams(StatusUi.dp(this, 8), StatusUi.dp(this, 8)));
        ObjectAnimator pulse = ObjectAnimator.ofFloat(dot, View.ALPHA, 1f, 0.2f);
        pulse.setDuration(800);
        pulse.setRepeatMode(ValueAnimator.REVERSE);
        pulse.setRepeatCount(ValueAnimator.INFINITE);
        pulse.start();
        TextView st = StatusUi.text(this, "UNDER MAINTENANCE", 11, StatusUi.AMBER, true);
        st.setPadding(StatusUi.dp(this, 8), 0, 0, 0);
        status.addView(st);
        LinearLayout.LayoutParams stLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        stLp.topMargin = StatusUi.dp(this, 22);
        content.addView(status, stLp);

        TextView t = StatusUi.text(this, title, 26, StatusUi.INK, true);
        t.setGravity(Gravity.CENTER);
        t.setPadding(0, StatusUi.dp(this, 16), 0, StatusUi.dp(this, 10));
        content.addView(t);

        TextView m = StatusUi.text(this, msg, 15, StatusUi.MUTED, false);
        m.setGravity(Gravity.CENTER);
        m.setLineSpacing(0, 1.3f);
        content.addView(m);

        if (!eta.isEmpty()) {
            LinearLayout info = new LinearLayout(this);
            info.setOrientation(LinearLayout.VERTICAL);
            info.setGravity(Gravity.CENTER_HORIZONTAL);
            info.setPadding(StatusUi.dp(this, 16), StatusUi.dp(this, 14), StatusUi.dp(this, 16), StatusUi.dp(this, 14));
            info.setBackground(StatusUi.box(Color.WHITE, 12, StatusUi.LINE, this));
            info.addView(StatusUi.text(this, "EXPECTED BACK", 11, StatusUi.MUTED, true));
            TextView e = StatusUi.text(this, eta, 17, StatusUi.INK, true);
            e.setPadding(0, StatusUi.dp(this, 4), 0, 0);
            e.setGravity(Gravity.CENTER);
            info.addView(e);
            LinearLayout.LayoutParams il = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            il.topMargin = StatusUi.dp(this, 22);
            content.addView(info, il);
        }

        View spacerMid = new View(this);
        content.addView(spacerMid, new LinearLayout.LayoutParams(1, 0, 1f));

        TextView retry = StatusUi.button(this, "Check again", StatusUi.INK, Color.WHITE, 0);
        retry.setOnClickListener(v -> AppStatus.fetch(this, state -> {
            if (state == null) {
                FancyText.toast(this, "Could not check right now. Try again.", Toast.LENGTH_SHORT).show();
            } else if (!state.mEnabled) {
                finish();
            } else {
                FancyText.toast(this, "Still under maintenance.", Toast.LENGTH_SHORT).show();
            }
        }));
        ((LinearLayout.LayoutParams) retry.getLayoutParams()).topMargin = StatusUi.dp(this, 24);
        content.addView(retry);

        if (!contact.isEmpty()) {
            TextView support = StatusUi.button(this, "Contact support", Color.WHITE, StatusUi.INK, StatusUi.LINE);
            ((LinearLayout.LayoutParams) support.getLayoutParams()).topMargin = StatusUi.dp(this, 10);
            support.setOnClickListener(v -> AppStatus.openLink(this, contact));
            content.addView(support);
        }

        if (canBypass) {
            TextView go = StatusUi.button(this, "Continue to admin panel", StatusUi.BLUE_TINT, StatusUi.BLUE, 0);
            ((LinearLayout.LayoutParams) go.getLayoutParams()).topMargin = StatusUi.dp(this, 10);
            go.setOnClickListener(v -> finish());
            content.addView(go);
        }

        TextView brand = StatusUi.text(this, "STARX24", 12, 0xFF9CA3AF, true);
        brand.setGravity(Gravity.CENTER);
        brand.setLetterSpacing(0.2f);
        brand.setPadding(0, StatusUi.dp(this, 22), 0, 0);
        content.addView(brand);
    }

    @Override
    public void onBackPressed() {
        if (canBypass) super.onBackPressed();
        else finishAffinity();
    }

    @Override
    protected void onDestroy() {
        AppStatus.unlisten(listener);
        super.onDestroy();
    }
}
