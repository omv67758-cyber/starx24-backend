package com.arenax.tournament.util;

import android.content.Context;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.widget.OverScroller;

import androidx.appcompat.widget.AppCompatTextView;

/**
 * A TextView that scrolls its own text (use with android:maxHeight) with real momentum:
 * a quick flick keeps the text gliding and slows down smoothly, like YouTube / Instagram.
 * (The built-in ScrollingMovementMethod only follows the finger and stops dead on release.)
 *
 * It lives inside the page ScrollView: while the text can still move in the drag direction the
 * box keeps the gesture; at the top/bottom edge the page scroll takes over again.
 */
public class SmoothScrollTextView extends AppCompatTextView {
    private final OverScroller scroller;
    private final int touchSlop;
    private final int minFlingVelocity;
    private final int maxFlingVelocity;
    private VelocityTracker velocity;
    private float downY;
    private float lastY;
    private boolean dragging;

    public SmoothScrollTextView(Context context) { this(context, null); }

    public SmoothScrollTextView(Context context, AttributeSet attrs) {
        this(context, attrs, android.R.attr.textViewStyle);
    }

    public SmoothScrollTextView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        scroller = new OverScroller(context);
        ViewConfiguration vc = ViewConfiguration.get(context);
        touchSlop = vc.getScaledTouchSlop();
        minFlingVelocity = vc.getScaledMinimumFlingVelocity();
        maxFlingVelocity = vc.getScaledMaximumFlingVelocity();
        setVerticalScrollBarEnabled(true);
        setOverScrollMode(OVER_SCROLL_NEVER);
    }

    private int maxScroll() {
        return Math.max(0, computeVerticalScrollRange() - computeVerticalScrollExtent());
    }

    private void disallowParent(boolean disallow) {
        if (getParent() != null) getParent().requestDisallowInterceptTouchEvent(disallow);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        final int max = maxScroll();
        if (max <= 0) return super.onTouchEvent(event); // short text: nothing to scroll

        if (velocity == null) velocity = VelocityTracker.obtain();
        velocity.addMovement(event);

        switch (event.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                if (!scroller.isFinished()) scroller.abortAnimation(); // tap stops a running fling
                downY = lastY = event.getY();
                dragging = false;
                disallowParent(true);
                return true;

            case MotionEvent.ACTION_MOVE: {
                float y = event.getY();
                if (!dragging && Math.abs(y - downY) > touchSlop) dragging = true;
                if (!dragging) return true;
                float dy = lastY - y; // finger up => text moves down
                lastY = y;
                int cur = getScrollY();
                boolean canMove = dy > 0 ? cur < max : cur > 0;
                disallowParent(canMove); // at the edge, hand the gesture back to the page
                int target = Math.max(0, Math.min(max, Math.round(cur + dy)));
                if (target != cur) {
                    scrollTo(0, target);
                    awakenScrollBars();
                }
                return true;
            }

            case MotionEvent.ACTION_UP: {
                velocity.computeCurrentVelocity(1000, maxFlingVelocity);
                float vy = velocity.getYVelocity();
                recycleVelocity();
                disallowParent(false);
                if (dragging && Math.abs(vy) > minFlingVelocity) {
                    scroller.fling(0, getScrollY(), 0, Math.round(-vy), 0, 0, 0, max);
                    postInvalidateOnAnimation();
                }
                dragging = false;
                return true;
            }

            case MotionEvent.ACTION_CANCEL:
                recycleVelocity();
                disallowParent(false);
                dragging = false;
                return true;

            default:
                return true;
        }
    }

    @Override
    public void computeScroll() {
        if (scroller.computeScrollOffset()) {
            scrollTo(0, scroller.getCurrY());
            awakenScrollBars();
            postInvalidateOnAnimation();
        }
    }

    private void recycleVelocity() {
        if (velocity != null) { velocity.recycle(); velocity = null; }
    }

    @Override
    protected void onDetachedFromWindow() {
        scroller.abortAnimation();
        recycleVelocity();
        super.onDetachedFromWindow();
    }

    @Override
    public boolean performClick() { return super.performClick(); }
}
