package com.arenax.tournament;


import com.arenax.tournament.util.FancyText;
import com.arenax.tournament.util.ImageLoader;
import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.os.Looper;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.annotation.NonNull;
import androidx.lifecycle.Lifecycle;

import com.arenax.tournament.model.Tournament;
import com.arenax.tournament.data.FirebaseRepository;
import com.arenax.tournament.util.InputValidation;
import com.arenax.tournament.util.MatchNumber;
import com.arenax.tournament.util.MatchReports;
import com.bumptech.glide.Glide;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.ValueEventListener;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

public class TournamentDetailActivity extends BaseActivity {
    private Tournament tournament;
    private CountDownTimer countdownTimer;
    private TextView countdown;
    private View countdownCard;
    private TextView roomState;
    private MaterialButton join;
    private ValueEventListener participantsListener;
    private com.arenax.tournament.util.JoinedPlayersList joinedPlayers;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tournament_detail);
        getWindow().setStatusBarColor(getColor(R.color.cd_bg));
        getWindow().setNavigationBarColor(getColor(R.color.cd_bg));
        if (!FirebaseRepository.isReady(this)) {
            FancyText.toast(this, "Live services are unavailable. Please try again later.", Toast.LENGTH_LONG).show();
            finish(); return;
        }
        tournament = getIntentTournament();
        if (tournament == null) { finish(); return; }
        hideUntilJoinStateKnown();

        ((TextView) findViewById(R.id.detail_contest_id))
                .setText(MatchNumber.label(tournament.getId()) + "  •  STARX24 Tournament");
        bindStatusPill(tournament.getEffectiveStatus());
        ((TextView) findViewById(R.id.detail_title)).setText(tournament.getTitle());
        ((TextView) findViewById(R.id.detail_team)).setText(tournament.getMatchType());
        ((TextView) findViewById(R.id.detail_game_mode)).setText(tournament.getGameType());
        ((TextView) findViewById(R.id.detail_map)).setText(tournament.getMap());
        ((TextView) findViewById(R.id.detail_match_type))
                .setText(tournament.getEntryFeeCoins() > 0 ? "Paid" : "Free");
        ((TextView) findViewById(R.id.detail_format)).setText(String.valueOf(tournament.getEntryFeeCoins()));
        ((TextView) findViewById(R.id.detail_schedule)).setText(tournament.getDate() + " at " + tournament.getTime());
        ((TextView) findViewById(R.id.detail_prize_info)).setText(String.valueOf(tournament.getPerKillCoins()));
        ((TextView) findViewById(R.id.detail_prize)).setText(String.valueOf(tournament.getPrizePoolCoins()));
        ((TextView) findViewById(R.id.detail_description)).setText(tournament.getDescription());
        TextView rulesView = findViewById(R.id.detail_rules);
        rulesView.setText(
                tournament.getRules().isEmpty() ? "Play fair. Follow the room rules shared by the admin." : tournament.getRules());
        // Rules box scrolls itself with momentum (fling) via SmoothScrollTextView; it also
        // hands the gesture back to the page ScrollView at its top/bottom edge.
        rulesView.scrollTo(0, 0);
        updateSlotsUi(tournament.getJoinedSlots(), tournament.getTotalSlots());
        countdown = findViewById(R.id.detail_countdown);
        countdownCard = findViewById(R.id.detail_countdown_card);
        roomState = findViewById(R.id.detail_room_state);
        roomState.setOnClickListener(v -> {
            if (tournament.isRoomReleased() && !tournament.getRoomId().isEmpty()) {
                android.content.ClipboardManager cm =
                        (android.content.ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
                cm.setPrimaryClip(android.content.ClipData.newPlainText("Room",
                        "Room ID: " + tournament.getRoomId() + " | Password: " + tournament.getRoomPassword()));
                FancyText.toast(this, "Copied", Toast.LENGTH_SHORT).show();
            }
        });
        ImageLoader.loadFit((android.widget.ImageView) findViewById(R.id.detail_banner), tournament.getBannerUrl());
        startCountdown();
        updateRoomState(false);
        watchParticipants();
        watchLiveRoomUpdates();
        joinedPlayers = new com.arenax.tournament.util.JoinedPlayersList(
                (android.widget.LinearLayout) findViewById(R.id.detail_joined_list),
                (TextView) findViewById(R.id.detail_joined_count), tournament.getId());
        joinedPlayers.attach();
        // Joined players are shown only after THIS player has joined (see watchParticipants);
        // never because the match started / ended.

        findViewById(R.id.button_back).setOnClickListener(v -> finish());
        findViewById(R.id.button_report).setOnClickListener(v -> showReportOrDisputeChoice());
        findViewById(R.id.button_matches).setOnClickListener(v ->
                startActivity(new android.content.Intent(this, MyMatchesActivity.class)
                        .putExtra(MyMatchesActivity.EXTRA_TOURNAMENT_ID, tournament.getId())));
        findViewById(R.id.detail_copy).setOnClickListener(v -> {
            CharSequence text = ((TextView) findViewById(R.id.detail_description)).getText();
            if (text == null || text.length() == 0) return;
            android.content.ClipboardManager cm =
                    (android.content.ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
            cm.setPrimaryClip(android.content.ClipData.newPlainText("Match", text));
            FancyText.toast(this, "Copied", Toast.LENGTH_SHORT).show();
        });
        join = findViewById(R.id.button_join);
        join.setText(joinLabel());
        join.setOnClickListener(v -> {
            if (FirebaseAuth.getInstance().getCurrentUser() == null) {
                FancyText.toast(this, "Please sign in before joining.", Toast.LENGTH_SHORT).show();
                return;
            }
            if (tournament.hasStarted()) {
                applyStartedState();
                FancyText.toast(this, "Match has started. Joining is closed.", Toast.LENGTH_SHORT).show();
                return;
            }
            if (!tournament.isJoiningOpen()) {
                FancyText.toast(this, "Registration is closed for this match.", Toast.LENGTH_SHORT).show();
                return;
            }
            String uid = FirebaseRepository.currentUser() == null ? null : FirebaseRepository.currentUser().getUid();
            FirebaseRepository.tournamentParticipants(tournament.getId()).child(uid).get()
                    .addOnSuccessListener(snapshot -> {
                        // A bare "RESERVING" placeholder means a previous join attempt started
                        // but never actually completed (payment/slot never went through) — it's
                        // not a real registration, just leftover state from an interrupted
                        // request. Only "REGISTERED" means the player is actually in the match.
                        String status = snapshot.child("status").getValue(String.class);
                        if (snapshot.exists() && "REGISTERED".equals(status)) {
                            join.setText("ALREADY REGISTERED");
                            join.setEnabled(false);
                            FancyText.toast(this, "You are already registered.", Toast.LENGTH_SHORT).show();
                            return;
                        }
                        // A8 / B32 — once every slot is filled, route the player onto the free
                        // waitlist instead of blocking them outright.
                        if (tournament.getRemainingSlots() <= 0) {
                            joinWaitlistFlow(uid);
                            return;
                        }
                        showJoinDialog(uid);
                    })
                    .addOnFailureListener(error ->
                            FancyText.toast(this, "Could not verify your registration.", Toast.LENGTH_LONG).show());
        });
    }

    /** Player picks their slot AND enters game details before joining. The slot they tap is
     *  only a *request* — joinMatch() below still claims it with a Firebase transaction, so if
     *  someone else grabs the same slot in the split second before this request lands, the
     *  server rejects it with "That slot is already taken" and the dialog stays open so the
     *  player can pick another one, instead of silently double-booking a slot. */
    private void showJoinDialog(String uid) {
        android.content.Intent intent = new android.content.Intent(this, JoinMatchActivity.class)
                .putExtra(JoinMatchActivity.EXTRA_TOURNAMENT, tournament)
                .putExtra(JoinMatchActivity.EXTRA_UID, uid);
        startActivityForResult(intent, REQUEST_JOIN_MATCH);
    }

    private static final int REQUEST_JOIN_MATCH = 9071;

    /** JoinMatchActivity reported a successful registration — refresh the CTA and the
     *  room/participant state so the player immediately sees "REGISTERED" and any
     *  follow-up info (room release, countdown, players strip). */
    @Override
    protected void onActivityResult(int requestCode, int resultCode, android.content.Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_JOIN_MATCH && resultCode == RESULT_OK) {
            // The player is now registered and JoinMatchActivity already opened the
            // Match Details (joined) page on top of us - this pre-join page is no longer needed,
            // so going back from Match Details returns to the match list.
            finish();
            overridePendingTransition(0, 0);
        }
    }

    /** Ordered so the first tapped slot stays first (shown as the "primary" slot). Up to
     *  MAX_SLOTS_PER_JOIN may be selected — that's how many entry fees get charged. */
    private static final int MAX_SLOTS_PER_JOIN = 4;
    private final java.util.List<Integer> selectedSlots = new java.util.ArrayList<>();

    /** White/red/black themed join sheet: wallet + entry-fee summary, a tappable slot grid
     *  (grey = taken, white = open, red = your pick(s) — tap more than one to join with
     *  multiple slots at once), then Game UID / Game Name. */
    private void buildJoinDialog(String uid, java.util.Set<Integer> takenSlots) {
        selectedSlots.clear();
        android.app.Dialog dialog = new android.app.Dialog(this);
        dialog.requestWindowFeature(android.view.Window.FEATURE_NO_TITLE);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundResource(R.drawable.bg_card_white);

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.VERTICAL);
        header.setPadding(dp(22), dp(20), dp(22), dp(12));
        TextView titleView = whiteText("Join Match", 19f, true, "#111111");
        header.addView(titleView);
        int perSlotFee = tournament.getEntryFeeCoins();
        int teamSize = Math.max(1, tournament.getTeamSize());
        boolean isTeamMode = teamSize > 1;
        String subtitleText;
        if (isTeamMode) {
            subtitleText = "This is a " + teamSize + "-player team match — select exactly " + teamSize
                    + " slots for your team and enter each teammate's Game UID & Name."
                    + (perSlotFee > 0 ? " (" + perSlotFee + " coins per slot.)" : "");
        } else {
            subtitleText = perSlotFee > 0
                    ? perSlotFee + " coins per slot — tap up to " + MAX_SLOTS_PER_JOIN + " slots to join with more than one entry."
                    : "Free entry match — tap up to " + MAX_SLOTS_PER_JOIN + " slots to hold more than one.";
        }
        TextView subtitleView = whiteText(subtitleText, 12.5f, false, "#6B6066");
        LinearLayout.LayoutParams stp = new LinearLayout.LayoutParams(-1, -2);
        stp.topMargin = dp(4);
        subtitleView.setLayoutParams(stp);
        header.addView(subtitleView);
        TextView feePreview = whiteText(
                perSlotFee > 0 ? "Total: 0 coins (select a slot)" : "Free — no coins will be deducted",
                13f, true, "#B0142E");
        LinearLayout.LayoutParams fpp = new LinearLayout.LayoutParams(-1, -2);
        fpp.topMargin = dp(6);
        feePreview.setLayoutParams(fpp);
        header.addView(feePreview);
        root.addView(header);
        root.addView(whiteDivider());

        LinearLayout form = new LinearLayout(this);
        form.setOrientation(LinearLayout.VERTICAL);
        form.setPadding(dp(22), dp(12), dp(22), dp(8));

        TextView balanceRow = whiteText("Wallet balance: …", 13.5f, false, "#111111");
        form.addView(balanceRow);
        FirebaseRepository.users().child(uid).child("wallet").child("balance").get()
                .addOnSuccessListener(snap -> {
                    long bal = snap.getValue(Long.class) == null ? 0L : snap.getValue(Long.class);
                    balanceRow.setText("Wallet balance: Coins  " + bal);
                })
                .addOnFailureListener(e -> balanceRow.setText("Wallet balance: unavailable"));

        String lastGameName = getSharedPreferences("arenax_profile", MODE_PRIVATE)
                .getString("last_game_name", "");

        // Dynamic per-slot player details: rebuilt every time the slot selection
        // changes, so a Duo/Squad team (or any multi-slot join) gets one Game
        // UID + Game Name pair per slot, not one shared pair for the whole join.
        java.util.Map<Integer, String> savedUid = new java.util.LinkedHashMap<>();
        java.util.Map<Integer, String> savedName = new java.util.LinkedHashMap<>();
        java.util.Map<Integer, EditText[]> playerFields = new java.util.LinkedHashMap<>();
        LinearLayout playerDetailsContainer = new LinearLayout(this);
        playerDetailsContainer.setOrientation(LinearLayout.VERTICAL);
        TextView playerHint = whiteText("Select a slot above to enter Game UID & Name.", 11.5f, false, "#8A8085");
        Runnable refreshPlayerFields = () -> {
            playerDetailsContainer.removeAllViews();
            playerFields.clear();
            if (selectedSlots.isEmpty()) {
                playerHint.setVisibility(View.VISIBLE);
                return;
            }
            playerHint.setVisibility(View.GONE);
            java.util.List<Integer> sorted = new java.util.ArrayList<>(selectedSlots);
            java.util.Collections.sort(sorted);
            int index = 0;
            for (int slot : sorted) {
                index++;
                playerDetailsContainer.addView(whiteSectionLabel(
                        sorted.size() > 1 ? "PLAYER " + index + " — SLOT " + slot : "GAME DETAILS"));
                EditText uidField = fieldLight("Game UID");
                uidField.setText(savedUid.getOrDefault(slot, ""));
                final int slotForUid = slot;
                uidField.addTextChangedListener(new android.text.TextWatcher() {
                    @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) { }
                    @Override public void onTextChanged(CharSequence s, int a, int b, int c) { }
                    @Override public void afterTextChanged(android.text.Editable s) { savedUid.put(slotForUid, s.toString()); }
                });
                EditText nameField = fieldLight("Game Name");
                // Only the first slot's name field is prefilled with the player's
                // own last-used name — a teammate in slot 2+ is a different person.
                String defaultName = savedName.containsKey(slot) ? savedName.get(slot) : (index == 1 ? lastGameName : "");
                nameField.setText(defaultName);
                if (!defaultName.isEmpty()) savedName.put(slot, defaultName);
                final int slotForName = slot;
                nameField.addTextChangedListener(new android.text.TextWatcher() {
                    @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) { }
                    @Override public void onTextChanged(CharSequence s, int a, int b, int c) { }
                    @Override public void afterTextChanged(android.text.Editable s) { savedName.put(slotForName, s.toString()); }
                });
                playerDetailsContainer.addView(uidField);
                playerDetailsContainer.addView(nameField);
                playerFields.put(slot, new EditText[]{uidField, nameField});
            }
        };

        form.addView(whiteSectionLabel("SELECT SLOT"));
        android.widget.GridLayout grid = new android.widget.GridLayout(this);
        grid.setColumnCount(6);
        LinearLayout.LayoutParams gridParams = new LinearLayout.LayoutParams(-1, -2);
        gridParams.topMargin = dp(6);
        grid.setLayoutParams(gridParams);
        int totalSlots = Math.max(1, tournament.getTotalSlots());
        java.util.List<TextView> chips = new java.util.ArrayList<>();
        int selectionCap = isTeamMode ? teamSize : MAX_SLOTS_PER_JOIN;
        for (int slot = 1; slot <= totalSlots; slot++) {
            boolean taken = takenSlots.contains(slot);
            TextView chip = new TextView(this);
            chip.setText(String.valueOf(slot));
            chip.setGravity(Gravity.CENTER);
            chip.setTextSize(12.5f);
            chip.setTypeface(null, Typeface.BOLD);
            chip.setTextColor(android.graphics.Color.parseColor(taken ? "#B4A9AC" : "#111111"));
            chip.setBackgroundResource(taken ? R.drawable.bg_slot_taken : R.drawable.bg_slot_available);
            android.widget.GridLayout.LayoutParams lp = new android.widget.GridLayout.LayoutParams();
            lp.width = dp(42);
            lp.height = dp(42);
            lp.setMargins(dp(4), dp(4), dp(4), dp(4));
            chip.setLayoutParams(lp);
            if (!taken) {
                final int slotNumber = slot;
                chip.setOnClickListener(v -> {
                    if (selectedSlots.contains(slotNumber)) {
                        selectedSlots.remove((Integer) slotNumber);
                        savedUid.remove(slotNumber);
                        savedName.remove(slotNumber);
                    } else {
                        if (selectedSlots.size() >= selectionCap) {
                            FancyText.toast(this, isTeamMode
                                    ? "This team match takes exactly " + teamSize + " slots."
                                    : "You can select up to " + MAX_SLOTS_PER_JOIN + " slots.", Toast.LENGTH_SHORT).show();
                            return;
                        }
                        selectedSlots.add(slotNumber);
                    }
                    // Repaint every open chip: every selected one turns red, the rest reset to white.
                    for (int i = 0; i < chips.size(); i++) {
                        TextView c = chips.get(i);
                        int number = i + 1;
                        if (takenSlots.contains(number)) continue;
                        boolean picked = selectedSlots.contains(number);
                        c.setBackgroundResource(picked ? R.drawable.bg_slot_selected : R.drawable.bg_slot_available);
                        c.setTextColor(android.graphics.Color.parseColor(picked ? "#FFFFFF" : "#111111"));
                    }
                    int count = selectedSlots.size();
                    feePreview.setText(perSlotFee > 0
                            ? "Total: " + (perSlotFee * count) + " coins" + (count > 1 ? " (" + count + " slots × " + perSlotFee + ")" : count == 0 ? " (select a slot)" : "")
                            : "Free — no coins will be deducted");
                    refreshPlayerFields.run();
                });
            }
            chips.add(chip);
            grid.addView(chip);
        }
        form.addView(grid);

        form.addView(whiteSectionLabel(isTeamMode ? "TEAM DETAILS" : "PLAYER DETAILS"));
        form.addView(playerHint);
        form.addView(playerDetailsContainer);
        refreshPlayerFields.run();

        ScrollView scroll = new ScrollView(this);
        scroll.setOverScrollMode(View.OVER_SCROLL_IF_CONTENT_SCROLLS);
        scroll.addView(form);
        int maxFormHeight = (int) (getResources().getDisplayMetrics().heightPixels * 0.48);
        LinearLayout.LayoutParams formParams = new LinearLayout.LayoutParams(-1, maxFormHeight);
        scroll.setLayoutParams(formParams);
        root.addView(scroll);
        root.addView(whiteDivider());

        LinearLayout footer = new LinearLayout(this);
        footer.setOrientation(LinearLayout.HORIZONTAL);
        footer.setGravity(Gravity.END | Gravity.CENTER_VERTICAL);
        footer.setPadding(dp(16), dp(12), dp(16), dp(14));

        MaterialButton cancelButton = new MaterialButton(this);
        cancelButton.setText("CANCEL");
        cancelButton.setTextColor(android.graphics.Color.parseColor("#111111"));
        cancelButton.setAllCaps(false);
        cancelButton.setBackgroundResource(R.drawable.bg_slot_available);
        cancelButton.setElevation(0f);
        cancelButton.setInsetTop(0);
        cancelButton.setInsetBottom(0);
        LinearLayout.LayoutParams cancelParams = new LinearLayout.LayoutParams(-2, dp(46));
        cancelParams.rightMargin = dp(10);
        cancelButton.setLayoutParams(cancelParams);
        cancelButton.setOnClickListener(v -> dialog.dismiss());
        footer.addView(cancelButton);

        MaterialButton joinButton = new MaterialButton(this);
        joinButton.setText("JOIN MATCH");
        joinButton.setTextColor(android.graphics.Color.WHITE);
        joinButton.setAllCaps(false);
        joinButton.setTypeface(null, Typeface.BOLD);
        joinButton.setBackgroundResource(R.drawable.bg_button_gradient);
        joinButton.setElevation(0f);
        joinButton.setInsetTop(0);
        joinButton.setInsetBottom(0);
        joinButton.setLayoutParams(new LinearLayout.LayoutParams(-2, dp(46)));
        joinButton.setOnClickListener(v -> {
            if (selectedSlots.isEmpty()) {
                FancyText.toast(this, "Please select at least one slot.", Toast.LENGTH_SHORT).show();
                return;
            }
            if (isTeamMode && selectedSlots.size() != teamSize) {
                FancyText.toast(this, "Select exactly " + teamSize + " slots for this team match.", Toast.LENGTH_SHORT).show();
                return;
            }
            java.util.List<Integer> sortedSlots = new java.util.ArrayList<>(selectedSlots);
            java.util.Collections.sort(sortedSlots);
            String[] uidsToJoin = new String[sortedSlots.size()];
            String[] namesToJoin = new String[sortedSlots.size()];
            boolean missing = false;
            for (int i = 0; i < sortedSlots.size(); i++) {
                int slot = sortedSlots.get(i);
                EditText[] fields = playerFields.get(slot);
                String uidValue = fields == null ? "" : InputValidation.value(fields[0]);
                String nameValue = fields == null ? "" : InputValidation.value(fields[1]);
                if (uidValue.isEmpty()) { if (fields != null) fields[0].setError("Required"); missing = true; }
                if (nameValue.isEmpty()) { if (fields != null) fields[1].setError("Required"); missing = true; }
                uidsToJoin[i] = uidValue;
                namesToJoin[i] = nameValue;
            }
            if (missing) return;
            join.setEnabled(false);
            int[] slotsToJoin = new int[sortedSlots.size()];
            for (int i = 0; i < slotsToJoin.length; i++) slotsToJoin[i] = sortedSlots.get(i);
            String primaryName = namesToJoin[0];
            // FIX (2026-09-14): this used to call ZapUpiClient.joinMatch() -> backend
            // POST /joinMatch on the Render Node server. JoinMatchActivity's combined join
            // screen already writes the SAME paths (tournaments/{id}/participants,
            // tournaments/{id}/slotIndex, users/{uid}/wallet/balance+pendingDebit) through
            // FirebaseDirectJoinClient directly. Two independent join implementations
            // writing the same data was the root architectural risk behind the
            // "Could not join (Permission denied)" bug report: if the backend call was
            // ever interrupted (Render free-tier cold start / timeout) it could leave a
            // half-written participants/{uid} record that then conflicted with a later
            // attempt through the other path. There is now only ONE join code path in the
            // app (FirebaseDirectJoinClient); the backend's /joinMatch route in
            // backend/index.js is unused by the app after this change and should be
            // deleted server-side once you've confirmed no other client calls it.
            FirebaseDirectJoinClient.joinMatch(tournament, slotsToJoin, uidsToJoin, namesToJoin,
                    new FirebaseDirectJoinClient.JoinCallback() {
                        @Override public void onSuccess(int[] slotNumbers, int entryFeeCoins) {
                            getSharedPreferences("arenax_profile", MODE_PRIVATE)
                                    .edit().putString("last_game_name", primaryName).apply();
                            dialog.dismiss();
                            join.setText("REGISTERED");
                            updateRoomState(true);
                            showSlotAssignedDialog(slotNumbers, entryFeeCoins);
                        }
                        @Override public void onAlreadyRegistered() {
                            dialog.dismiss();
                            join.setText("REGISTERED");
                            updateRoomState(true);
                            FancyText.toast(TournamentDetailActivity.this,
                                    "You're already registered for this match.", Toast.LENGTH_LONG).show();
                        }
                        @Override public void onError(String message) {
                            join.setEnabled(true);
                            // A Toast alone isn't reliable here: several OEM skins
                            // (Realme/Oppo ColorOS, MIUI, etc.) silently swallow app
                            // toasts unless "Display pop-up window while running in
                            // background" is explicitly granted, and the join dialog
                            // stays open on top of it either way — the join looked
                            // like it silently did nothing. A dialog can't be blocked
                            // that way and sits above the join form, so the reason is
                            // always visible.
                            String reason = message == null ? "Could not register right now." : message;
                            MaterialAlertDialogBuilder builder =
                                    new FancyText.MaterialBuilder(TournamentDetailActivity.this)
                                            .setTitle("Could not join match")
                                            .setMessage(reason)
                                            .setPositiveButton("OK", null);
                            // Entry coins come straight out of the real wallet, so a "not enough
                            // coins" refusal should lead the player to the wallet top-up screen.
                            // NOTE: must match FirebaseDirectJoinClient's exact wording
                            // ("... coins but need ...") — "you need" (the old ZapUpiClient
                            // wording) never matched here, which silently hid the ADD COINS
                            // button on this screen for low-balance failures.
                            if (reason.toLowerCase(java.util.Locale.ROOT).contains("but need")) {
                                builder.setNegativeButton("ADD COINS", (d, which) ->
                                        startActivity(new Intent(TournamentDetailActivity.this, WalletActivity.class)));
                            }
                            builder.show();
                        }
                    });
        });
        footer.addView(joinButton);
        root.addView(footer);

        dialog.setContentView(root);
        android.view.Window window = dialog.getWindow();
        if (window != null) {
            window.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
            android.util.DisplayMetrics metrics = getResources().getDisplayMetrics();
            window.setLayout((int) (metrics.widthPixels * 0.92), ViewGroup.LayoutParams.WRAP_CONTENT);
        }
        dialog.setCancelable(true);
        dialog.show();
    }

    private TextView whiteText(String text, float sizeSp, boolean bold, String hexColor) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextSize(sizeSp);
        tv.setTypeface(null, bold ? Typeface.BOLD : Typeface.NORMAL);
        tv.setTextColor(android.graphics.Color.parseColor(hexColor));
        return tv;
    }

    private TextView whiteSectionLabel(String text) {
        TextView label = new TextView(this);
        label.setText(text);
        label.setTextColor(android.graphics.Color.parseColor("#8A8085"));
        label.setTextSize(11f);
        label.setTypeface(null, Typeface.BOLD);
        label.setLetterSpacing(0.02f);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, -2);
        params.topMargin = dp(14);
        params.bottomMargin = dp(4);
        label.setLayoutParams(params);
        return label;
    }

    private View whiteDivider() {
        View divider = new View(this);
        divider.setBackgroundColor(android.graphics.Color.parseColor("#EDE7E8"));
        divider.setLayoutParams(new LinearLayout.LayoutParams(-1, dp(1)));
        return divider;
    }

    private EditText fieldLight(String hint) {
        EditText input = new EditText(this);
        input.setHint(hint);
        input.setTextColor(android.graphics.Color.parseColor("#111111"));
        input.setHintTextColor(android.graphics.Color.parseColor("#9A9094"));
        input.setBackgroundResource(R.drawable.bg_input_light);
        int hPad = dp(16), vPad = dp(14);
        input.setPadding(hPad, vPad, hPad, vPad);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, -2);
        params.topMargin = dp(6);
        params.bottomMargin = dp(6);
        input.setLayoutParams(params);
        return input;
    }

    /** A26 — the slot is now revealed here, after a successful join, instead of being picked
     *  from a dropdown before joining (that dropdown could go stale and collide with another
     *  player's pick in between opening it and tapping JOIN). */
    private void showSlotAssignedDialog(int[] slotNumbers, int entryFeeCoins) {
        String slotText;
        if (slotNumbers == null || slotNumbers.length == 0) {
            slotText = "You're registered.";
        } else if (slotNumbers.length == 1) {
            slotText = "You've been assigned Slot " + slotNumbers[0] + ".";
        } else {
            StringBuilder joined = new StringBuilder();
            for (int i = 0; i < slotNumbers.length; i++) {
                if (i > 0) joined.append(i == slotNumbers.length - 1 ? " & " : ", ");
                joined.append(slotNumbers[i]);
            }
            slotText = "You've been assigned Slots " + joined + " (" + slotNumbers.length + " entries).";
        }
        String message = slotText
                + (entryFeeCoins > 0 ? "\n\n" + entryFeeCoins + " coins deducted from your wallet." : "\n\nFree match registration confirmed.");
        new FancyText.MaterialBuilder(this)
                .setTitle("You're in!")
                .setMessage(message)
                .setPositiveButton("OK", null)
                .show();
    }

    /** A8 / B32 — Free waitlist join for a full match. Checks for a duplicate entry first so
     *  tapping "JOIN WAITLIST" twice never creates two waitlist records. */
    private void joinWaitlistFlow(String uid) {
        FirebaseRepository.tournamentWaitlist(tournament.getId()).child(uid).get()
                .addOnSuccessListener(waitSnapshot -> {
                    if (waitSnapshot.exists()) {
                        join.setText("WAITLISTED");
                        join.setEnabled(false);
                        FancyText.toast(this, "You're already on the waitlist. We'll notify you if a slot opens.",
                                Toast.LENGTH_LONG).show();
                        return;
                    }
                    join.setEnabled(false);
                    FirebaseRepository.joinWaitlist(tournament.getId())
                            .addOnSuccessListener(ignored -> {
                                join.setText("WAITLISTED");
                                FancyText.toast(this,
                                        "Match is full — you're on the free waitlist and will be notified if a slot opens.",
                                        Toast.LENGTH_LONG).show();
                            })
                            .addOnFailureListener(error -> {
                                join.setEnabled(true);
                                FancyText.toast(this, "Could not join the waitlist right now.", Toast.LENGTH_LONG).show();
                            });
                })
                .addOnFailureListener(error ->
                        FancyText.toast(this, "Could not check the waitlist.", Toast.LENGTH_LONG).show());
    }

    @SuppressWarnings("deprecation")
    private Tournament getIntentTournament() {
        if (android.os.Build.VERSION.SDK_INT >= 33) {
            return getIntent().getSerializableExtra("tournament", Tournament.class);
        }
        return (Tournament) getIntent().getSerializableExtra("tournament");
    }

    private void startCountdown() {
        if (countdownTimer != null) countdownTimer.cancel();
        if (tournament.isDelayed()) {
            countdownCard.setVisibility(View.GONE);
            return;
        }
        long releaseTarget = tournament.getRoomReleaseAt();
        boolean countingToRoom = !tournament.isRoomReleased()
                && releaseTarget > System.currentTimeMillis();
        long target = countingToRoom ? releaseTarget : tournament.getEffectiveStartAt();
        if (target <= System.currentTimeMillis()) {
            countdownCard.setVisibility(View.GONE);
            return;
        }
        countdownCard.setVisibility(View.VISIBLE);
        countdownTimer = new CountDownTimer(target - System.currentTimeMillis(), 1000L) {
            @Override
            public void onTick(long millisUntilFinished) {
                long seconds = millisUntilFinished / 1000L;
                long days = seconds / 86400L;
                long hours = (seconds % 86400L) / 3600L;
                long minutes = (seconds % 3600L) / 60L;
                long remaining = seconds % 60L;
                // Escalating urgency: bright red under 15 min, neon pulse under 5 min.
                if (millisUntilFinished < 5 * 60 * 1000L) {
                    countdown.setTextColor(0xFFFF3B3B);
                } else if (millisUntilFinished < 15 * 60 * 1000L) {
                    countdown.setTextColor(0xFFE01414);
                }
                countdown.setText(String.format(java.util.Locale.ROOT,
                        countingToRoom ? "Room Details In: %dd %dh %02dm %02ds"
                                : "Time Left: %dd %dh %02dm %02ds",
                        days, hours, minutes, remaining));
            }

            @Override
            public void onFinish() {
                countdownCard.setVisibility(View.GONE);
                // Start time reached while the screen is open: flip to Ongoing + lock joining live.
                bindStatusPill(tournament.getEffectiveStatus());
                applyStartedState();
            }
        }.start();
    }

    /** Colors and labels the top-bar status pill (Ongoing / Upcoming / Completed / Cancelled / ...). */
    private void bindStatusPill(String status) {
        TextView statusText = findViewById(R.id.detail_status_text);
        View statusDot = findViewById(R.id.detail_status_dot);
        View statusPill = findViewById(R.id.detail_status_pill);
        String label;
        int color;
        int bg;
        switch (status == null ? "" : status) {
            case Tournament.ONGOING:
                label = "Ongoing"; color = getColor(R.color.cd_green); bg = getColor(R.color.cd_green_tint);
                break;
            case Tournament.COMPLETED:
                label = "Completed"; color = getColor(R.color.cd_body); bg = getColor(R.color.cd_divider);
                break;
            case Tournament.CANCELLED:
                label = "Cancelled"; color = getColor(R.color.admin_red); bg = getColor(R.color.admin_red_tint);
                break;
            case Tournament.RESULT_PROCESSING:
                label = "Processing"; color = getColor(R.color.admin_orange); bg = getColor(R.color.admin_orange_tint);
                break;
            case Tournament.DRAFT:
                label = "Draft"; color = getColor(R.color.cd_body); bg = getColor(R.color.cd_divider);
                break;
            default:
                label = "Upcoming"; color = getColor(R.color.cd_blue); bg = getColor(R.color.cd_blue_tint);
        }
        statusText.setText(label);
        statusText.setTextColor(color);
        statusDot.setBackgroundTintList(android.content.res.ColorStateList.valueOf(color));
        statusPill.setBackgroundTintList(android.content.res.ColorStateList.valueOf(bg));
    }

    /** Kept as a compatibility wrapper for older call sites. */
    private String shortContestId(String id) {
        return MatchNumber.fromId(id);
    }

    private void updateRoomState(boolean joined) {
        if (tournament.isDelayed()) {
            roomState.setText("MATCH DELAYED — " + tournament.getDelayReason() + "\nWAIT FOR ROOM ID & PASSWORD");
            return;
        }
        // Room only shows once the admin explicitly releases it — timestamp alone no longer reveals it.
        boolean released = tournament.isRoomReleased();
        if (!joined || !released) {
            roomState.setText(!joined
                    ? "ROOM DETAILS LOCKED  •  REGISTER TO VIEW"
                    : "WAIT FOR ROOM ID & PASSWORD");
            return;
        }
        String room = tournament.getRoomId().isEmpty() ? "Room ID will be posted by admin shortly." :
                "ROOM ID  " + tournament.getRoomId() + "\nPASSWORD  " + tournament.getRoomPassword()
                        + "\n\nTap to copy either value.";
        roomState.setText(room);
    }

    private boolean redirectedToJoinedPage;
    private boolean contentRevealed;

    /** The join page stays invisible until the first participants snapshot says whether this
     *  player already joined (then we jump straight to Match Details instead of flashing
     *  this page). Falls back to showing the page after 2.5s if the read never answers. */
    private void hideUntilJoinStateKnown() {
        findViewById(android.R.id.content).setVisibility(View.INVISIBLE);
        new Handler(Looper.getMainLooper()).postDelayed(this::revealContent, 2500L);
    }

    private void revealContent() {
        if (contentRevealed) return;
        contentRevealed = true;
        View content = findViewById(android.R.id.content);
        if (content != null) content.setVisibility(View.VISIBLE);
    }

    private void watchParticipants() {
        String uid = FirebaseRepository.currentUser() == null ? null : FirebaseRepository.currentUser().getUid();
        if (uid == null || tournament.getId() == null) { revealContent(); return; }
        participantsListener = new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                int registered = 0;
                boolean joined = false;
                for (DataSnapshot child : snapshot.getChildren()) {
                    // A RESERVING-only record is a reservation that never finished (the
                    // payment/slot claim behind it failed or the request was interrupted) —
                    // it doesn't count as a filled slot or as this player being registered.
                    String childStatus = child.child("status").getValue(String.class);
                    if ("RESERVING".equals(childStatus)) continue;
                    // count SLOTS (a duo/squad entry can hold several) so this matches the list's joinedSlots
                    long slotCount = child.child("slotNumbers").getChildrenCount();
                    registered += (int) Math.max(1, slotCount);
                    if (uid.equals(child.child("userId").getValue(String.class))) joined = true;
                }
                if (joined && !redirectedToJoinedPage && !isFinishing()
                        && getLifecycle().getCurrentState().isAtLeast(Lifecycle.State.STARTED)) {
                    // Already registered -> show the Match Details page instead of the join page.
                    redirectedToJoinedPage = true;
                    startActivity(new Intent(TournamentDetailActivity.this, MatchJoinedActivity.class)
                            .putExtra(MatchJoinedActivity.EXTRA_TOURNAMENT, tournament));
                    overridePendingTransition(0, 0);
                    finish();
                    return;
                }
                revealContent();
                View joinedCard = findViewById(R.id.detail_joined_card);
                // Joined player names (no UID) are shown to everyone, right below the rules.
                if (joinedCard != null) joinedCard.setVisibility(View.VISIBLE);
                if (joinedPlayers != null) joinedPlayers.attach();
                TextView slots = findViewById(R.id.detail_slots);
                int total = tournament.getTotalSlots();
                updateSlotsUi(registered, total);
                if (joined) {
                    join.setText("ALREADY REGISTERED");
                    join.setEnabled(false);
                } else if (registered >= total && total > 0) {
                    // A8 / B32 — full match still accepts free waitlist joins.
                    watchWaitlistState(uid);
                }
                lastJoined = joined;
                updateRoomState(joined);
                if (!joined) applyStartedState();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) { revealContent(); }
        };
        FirebaseRepository.tournamentParticipants(tournament.getId())
                .addValueEventListener(participantsListener);
    }

    /** Reflects whether the signed-in user is already waitlisted for a full match. */
    private void watchWaitlistState(String uid) {
        if (uid == null || tournament.getId() == null) return;
        if (tournament.hasStarted()) { applyStartedState(); return; }
        FirebaseRepository.tournamentWaitlist(tournament.getId()).child(uid).get()
                .addOnSuccessListener(snapshot -> {
                    if (snapshot.exists()) {
                        join.setText("WAITLISTED");
                        join.setEnabled(false);
                    } else {
                        join.setText("JOINING FULL \u2022 JOIN WAITLIST");
                        join.setEnabled(true);
                    }
                })
                .addOnFailureListener(error -> {
                    join.setText("JOINING FULL");
                    join.setEnabled(false);
                });
    }

    private ValueEventListener tournamentListener;
    private boolean lastJoined;

    /** Once the start time passes: join button locks to "MATCH STARTED" (no join, no waitlist). */
    private void applyStartedState() {
        if (join == null || tournament == null || !tournament.hasStarted()) return;
        if (lastJoined) return;
        join.setText("MATCH STARTED");
        join.setEnabled(false);
        updateSlotsUiStarted();
    }

    private void updateSlotsUiStarted() {
        TextView spotsLeft = findViewById(R.id.detail_spots_left);
        if (spotsLeft != null) spotsLeft.setText("Joining Closed");
    }

    /** Keeps room-release / delay state live so a Room Release from the admin appears instantly, no refresh needed. */
    private void watchLiveRoomUpdates() {
        if (tournament.getId() == null) return;
        tournamentListener = new ValueEventListener() {
            @Override public void onDataChange(@NonNull DataSnapshot snapshot) {
                @SuppressWarnings("unchecked")
                Tournament fresh = Tournament.fromMap(tournament.getId(),
                        (java.util.Map<String, Object>) snapshot.getValue());
                if (fresh == null) return;
                tournament = fresh;
                startCountdown();
                updateRoomState(lastJoined);
                bindStatusPill(tournament.getEffectiveStatus());
                if (!lastJoined) applyStartedState();
            }
            @Override public void onCancelled(@NonNull DatabaseError error) {}
        };
        FirebaseRepository.tournaments().child(tournament.getId()).addValueEventListener(tournamentListener);
    }

    /** A13/A14 & B43 — entry point for both Result Dispute and Report/Moderation flows. */
    private void showReportOrDisputeChoice() {
        MatchReports.showChoice(this, tournament.getId(), tournament.getTitle());
    }

    private int dp(int value) { return Math.round(value * getResources().getDisplayMetrics().density); }

    /** "JOIN MATCH • 46 coins" with the price in warm yellow so it stays readable on the green button. Uses the real entry fee
     *  (the XML used to hard-code "46 coins" for every match). */
    private CharSequence joinLabel() {
        int fee = tournament.getEntryFeeCoins();
        String head = "JOIN MATCH  \u2022  ";
        String tail = fee > 0 ? fee + " coins" : "FREE";
        android.text.SpannableString label = new android.text.SpannableString(head + tail);
        label.setSpan(new android.text.style.ForegroundColorSpan(0xFFFFE27A),
                head.length(), label.length(), android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        return label;
    }

    /** Updates the boxed slots-progress card: fill bar, "X/Y filled" text and "spots left". */
    private void updateSlotsUi(int joined, int total) {
        TextView slotsText = findViewById(R.id.detail_slots);
        TextView spotsLeft = findViewById(R.id.detail_spots_left);
        android.widget.ProgressBar bar = findViewById(R.id.detail_slots_progress);
        int remaining = Math.max(0, total - joined);
        slotsText.setText(joined + " / " + total);
        if (remaining <= 0) {
            spotsLeft.setText("Joining Full");
            spotsLeft.setTextColor(getColor(R.color.cd_green));
            spotsLeft.setBackgroundResource(R.drawable.bg_cd_pill_green);
        } else {
            spotsLeft.setText(remaining + " left");
            spotsLeft.setTextColor(getColor(R.color.cd_blue));
            spotsLeft.setBackgroundResource(R.drawable.bg_cd_pill_blue);
        }
        int percent = total > 0 ? Math.min(100, Math.round(100f * joined / total)) : 0;
        bar.setProgress(percent);
    }

    @Override
    protected void onDestroy() {
        if (joinedPlayers != null) joinedPlayers.detach();
        if (countdownTimer != null) countdownTimer.cancel();
        if (participantsListener != null && tournament != null && tournament.getId() != null) {
            FirebaseRepository.tournamentParticipants(tournament.getId())
                    .removeEventListener(participantsListener);
        }
        if (tournamentListener != null && tournament != null && tournament.getId() != null) {
            FirebaseRepository.tournaments().child(tournament.getId()).removeEventListener(tournamentListener);
        }
        super.onDestroy();
    }
}
