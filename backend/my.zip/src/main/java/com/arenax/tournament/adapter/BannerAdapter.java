package com.arenax.tournament.adapter;


import com.arenax.tournament.util.FancyText;
import com.arenax.tournament.util.ImageLoader;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.arenax.tournament.R;
import com.arenax.tournament.model.Banner;
import com.bumptech.glide.Glide;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.card.MaterialCardView;

import java.util.List;

/** Banner cards: the image fills the whole rounded card edge-to-edge (no padding gap, no
 *  white showing past the image), rendered at a taller 16:9 ratio (see Ratio16x9ImageView).
 *  In manage mode a small round "x" overlays the image corner instead of a bar below it. */
public final class BannerAdapter extends RecyclerView.Adapter<BannerAdapter.Holder> {
    public interface DeleteAction { void delete(Banner banner); }
    private final List<Banner> items;
    private final boolean manage;
    private final DeleteAction deleteAction;
    private boolean loading = false;

    /** Home: show one grey pulsing banner-shaped block until the first Firebase snapshot. */
    public void setLoading(boolean loading) {
        if (this.loading == loading) return;
        this.loading = loading;
        notifyDataSetChanged();
    }
    private boolean showSkeleton() { return loading && items.isEmpty(); }

    public BannerAdapter(List<Banner> items, boolean manage, DeleteAction deleteAction) {
        this.items = items; this.manage = manage; this.deleteAction = deleteAction;
    }

    /** Forces its own measured height to width * 9/16, regardless of the height passed
     *  in via LayoutParams, keeping the home banner compact and consistent on every phone. */
    static final class Ratio16x9ImageView extends ImageView {
        Ratio16x9ImageView(android.content.Context c) { super(c); }
        @Override protected void onMeasure(int widthSpec, int heightSpec) {
            super.onMeasure(widthSpec, heightSpec);
            int width = getMeasuredWidth();
            int height = Math.round(width * 9f / 16f);
            setMeasuredDimension(width, height);
        }
    }

    @NonNull @Override public Holder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        MaterialCardView card = new MaterialCardView(parent.getContext());
        card.setRadius(dp(parent, 16));
        card.setCardElevation(0);
        card.setStrokeWidth(dp(parent, 1));
        card.setStrokeColor(androidx.core.content.ContextCompat.getColor(parent.getContext(), R.color.banner_border));
        card.setContentPadding(0, 0, 0, 0);
        // Full recycler width (not a fixed dp) so each banner fills and centers itself
        // in the visible frame instead of hugging the left edge on wider screens.
        LinearLayoutParamsHolder.apply(card, ViewGroup.LayoutParams.MATCH_PARENT, dp(parent, 10));

        FrameLayout frame = new FrameLayout(parent.getContext());
        ImageView image = new Ratio16x9ImageView(parent.getContext());
        image.setScaleType(ImageView.ScaleType.CENTER_CROP);
        image.setBackgroundResource(R.drawable.bg_banner);
        frame.addView(image, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        MaterialButton delete = new MaterialButton(parent.getContext());
        delete.setText("×");
        delete.setTextSize(16);
        delete.setInsetTop(0); delete.setInsetBottom(0); delete.setMinWidth(0); delete.setPadding(0, 0, 0, 0);
        delete.setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xCCD9241C));
        delete.setCornerRadius(dp(parent, 14));
        FrameLayout.LayoutParams dp2 = new FrameLayout.LayoutParams(dp(parent, 28), dp(parent, 28));
        dp2.gravity = Gravity.TOP | Gravity.END;
        dp2.setMargins(0, dp(parent, 8), dp(parent, 8), 0);
        frame.addView(delete, dp2);

        card.addView(frame, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        return new Holder(card, image, delete);
    }
    @Override public void onBindViewHolder(@NonNull Holder h, int position) {
        if (showSkeleton()) {
            ImageLoader.clear(h.image);
            h.image.setImageDrawable(new android.graphics.drawable.ColorDrawable(0xFFDDE3EC));
            h.delete.setVisibility(View.GONE);
            h.itemView.setOnClickListener(null);
            h.itemView.setClickable(false);
            h.startPulse();
            return;
        }
        h.stopPulse();
        Banner b = items.get(position); h.delete.setVisibility(manage ? View.VISIBLE : View.GONE);
        ImageLoader.load(h.image, b.getImageUrl());
        String link = manage ? "" : Banner.normalizeLink(b.getLinkUrl());
        if (link != null && !link.isEmpty()) {
            final String target = link;
            h.itemView.setOnClickListener(v -> openLink(v.getContext(), target));
        } else {
            h.itemView.setOnClickListener(null);
            h.itemView.setClickable(false);
        }
        h.delete.setOnClickListener(v -> { if (deleteAction != null) deleteAction.delete(b); });
    }
    /** Opens the admin-set support link (browser / Telegram / WhatsApp / mail / dialer). */
    private static void openLink(android.content.Context context, String link) {
        try {
            android.content.Intent intent = new android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse(link));
            intent.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(intent);
        } catch (Exception e) {
            FancyText.toast(context, "Unable to open this link", android.widget.Toast.LENGTH_SHORT).show();
        }
    }
    @Override public void onViewRecycled(@NonNull Holder h) { h.stopPulse(); super.onViewRecycled(h); }
    @Override public int getItemCount() { return showSkeleton() ? 1 : items.size(); }
    static final class Holder extends RecyclerView.ViewHolder {
        final ImageView image; final MaterialButton delete;
        private android.animation.ObjectAnimator pulse;
        Holder(View v, ImageView image, MaterialButton delete) { super(v); this.image=image; this.delete=delete; }
        void startPulse() {
            if (pulse != null) return;
            pulse = android.animation.ObjectAnimator.ofFloat(itemView, View.ALPHA, 1f, 0.45f);
            pulse.setDuration(700);
            pulse.setRepeatMode(android.animation.ValueAnimator.REVERSE);
            pulse.setRepeatCount(android.animation.ValueAnimator.INFINITE);
            pulse.start();
        }
        void stopPulse() {
            if (pulse != null) { pulse.cancel(); pulse = null; }
            itemView.setAlpha(1f);
        }
    }
    private static int dp(View v, int n) { return Math.round(n * v.getResources().getDisplayMetrics().density); }

    /** Small helper so the card gets a plain RecyclerView.LayoutParams (match_parent or a
     *  fixed width) regardless of which layer builds it. */
    private static final class LinearLayoutParamsHolder {
        static void apply(MaterialCardView card, int width, int rightMarginPx) {
            RecyclerView.LayoutParams lp = new RecyclerView.LayoutParams(width, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.rightMargin = rightMarginPx;
            card.setLayoutParams(lp);
        }
    }
}
