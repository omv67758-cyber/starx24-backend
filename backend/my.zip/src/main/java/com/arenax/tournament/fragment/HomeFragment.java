package com.arenax.tournament.fragment;


import com.arenax.tournament.util.FancyText;
import com.arenax.tournament.util.ImageLoader;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.PagerSnapHelper;
import androidx.recyclerview.widget.RecyclerView;

import com.arenax.tournament.R;
import com.arenax.tournament.adapter.BannerAdapter;
import com.arenax.tournament.adapter.GameModeAdapter;
import com.arenax.tournament.data.FirebaseRepository;
import com.arenax.tournament.model.Banner;
import com.arenax.tournament.model.GameMode;
import com.bumptech.glide.Glide;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class HomeFragment extends Fragment {
    // Banner carousel auto-advances every 2.5s, matching the reference design.
    private static final long BANNER_AUTO_SLIDE_MS = 2500L;
    private final List<GameMode> gameModes = new ArrayList<>();
    private final List<Banner> banners = new ArrayList<>();
    private ValueEventListener gameModeListener;
    private ValueEventListener bannerListener;
    private ValueEventListener brandingListener;
    private ValueEventListener noticeListener;
    private ValueEventListener pointsListener;
    private ValueEventListener walletBalanceListener;
    private LinearLayout dotsContainer;
    private RecyclerView bannerListView;
    private final android.os.Handler bannerAutoSlideHandler = new android.os.Handler(android.os.Looper.getMainLooper());
    private final Runnable bannerAutoSlideRunnable = new Runnable() {
        @Override
        public void run() {
            if (bannerListView == null || banners.size() <= 1) return;
            RecyclerView.LayoutManager lm = bannerListView.getLayoutManager();
            if (!(lm instanceof LinearLayoutManager)) return;
            int current = ((LinearLayoutManager) lm).findFirstVisibleItemPosition();
            int next = (current + 1) % banners.size();
            bannerListView.smoothScrollToPosition(next);
            setActiveDot(next);
            bannerAutoSlideHandler.postDelayed(this, BANNER_AUTO_SLIDE_MS);
        }
    };

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_home, container, false);
        // Logo: show the last known custom logo instantly from local cache, so the default app
        // logo never flashes while Firebase answers. Nothing cached yet -> black until it arrives.
        final String[] shownLogoUrl = { ImageLoader.getCachedLogoUrl(requireContext()) };
        final android.widget.ImageView homeLogo = view.findViewById(R.id.home_logo_image);
        if (homeLogo != null) {
            if (!shownLogoUrl[0].isEmpty()) ImageLoader.load(homeLogo, shownLogoUrl[0]);
            else if (!FirebaseRepository.isReady(requireContext())) homeLogo.setImageResource(R.drawable.ic_arenax);
        }
        if (!FirebaseRepository.isReady(requireContext())) {
            FancyText.toast(requireContext(),
                    "Live arena data is temporarily unavailable. Please try again.",
                    android.widget.Toast.LENGTH_LONG).show();
            return view;
        }
        brandingListener = new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                String logoUrl = snapshot.child("branding").child("logoUrl").getValue(String.class);
                android.widget.ImageView logo = view.findViewById(R.id.home_logo_image);
                if (logoUrl == null || logoUrl.trim().isEmpty()) {
                    // No custom logo configured: the app logo is the intended image here.
                    ImageLoader.setCachedLogoUrl(view.getContext(), "");
                    if (logo != null) {
                        ImageLoader.clear(logo);
                        logo.setImageResource(R.drawable.ic_arenax);
                    }
                    shownLogoUrl[0] = "";
                    return;
                }
                String cleanLogo = logoUrl.trim();
                ImageLoader.setCachedLogoUrl(view.getContext(), cleanLogo);
                if (logo != null && !cleanLogo.equals(shownLogoUrl[0])) {
                    shownLogoUrl[0] = cleanLogo;
                    ImageLoader.load(logo, cleanLogo);
                }
            }

            @Override
            public void onCancelled(DatabaseError error) {}
        };
        FirebaseRepository.appConfig().addValueEventListener(brandingListener);

        // Account icon replaces the old "LIVE ARENA" label: taps into the existing Profile
        // tab, which already carries login/account info plus support, team, FAQ and logout —
        // i.e. everything that normally lives under "settings" — rather than a new screen.
        View accountButton = view.findViewById(R.id.home_account_button);
        if (accountButton != null) {
            accountButton.setOnClickListener(v -> {
                com.google.android.material.bottomnavigation.BottomNavigationView nav =
                        requireActivity().findViewById(R.id.bottom_nav);
                if (nav != null) nav.setSelectedItemId(R.id.nav_profile);
            });
        }

        // Coin badge (top-right, next to the profile icon) now opens the Wallet page —
        // same destination as the bottom-nav Wallet tab — instead of doing nothing.
        View searchButton = view.findViewById(R.id.home_search_button);
        if (searchButton != null) {
            searchButton.setOnClickListener(v -> startActivity(
                    new Intent(requireContext(), com.arenax.tournament.GlobalSearchActivity.class)
                            .putExtra(com.arenax.tournament.GlobalSearchActivity.EXTRA_MODE,
                                    com.arenax.tournament.GlobalSearchActivity.MODE_USER)));
        }
        View pointsBadge = view.findViewById(R.id.home_points_badge);
        if (pointsBadge != null) {
            pointsBadge.setOnClickListener(v -> startActivity(
                    new Intent(requireContext(), com.arenax.tournament.WalletActivity.class)));
        }

        // Upcoming / Ongoing / Completed tiles now open a page listing the player's own
        // joined matches for that status, instead of doing nothing.
        View cardUpcoming = view.findViewById(R.id.home_card_upcoming);
        if (cardUpcoming != null) {
            cardUpcoming.setOnClickListener(v -> {
                Intent i = new Intent(requireContext(), com.arenax.tournament.MyMatchesStatusActivity.class);
                i.putExtra(com.arenax.tournament.MyMatchesStatusActivity.EXTRA_STATUS,
                        com.arenax.tournament.MyMatchesStatusActivity.STATUS_UPCOMING);
                startActivity(i);
            });
        }
        View cardOngoing = view.findViewById(R.id.home_card_ongoing);
        if (cardOngoing != null) {
            cardOngoing.setOnClickListener(v -> {
                Intent i = new Intent(requireContext(), com.arenax.tournament.MyMatchesStatusActivity.class);
                i.putExtra(com.arenax.tournament.MyMatchesStatusActivity.EXTRA_STATUS,
                        com.arenax.tournament.MyMatchesStatusActivity.STATUS_ONGOING);
                startActivity(i);
            });
        }
        View cardCompleted = view.findViewById(R.id.home_card_completed);
        if (cardCompleted != null) {
            cardCompleted.setOnClickListener(v -> {
                Intent i = new Intent(requireContext(), com.arenax.tournament.MyMatchesStatusActivity.class);
                i.putExtra(com.arenax.tournament.MyMatchesStatusActivity.EXTRA_STATUS,
                        com.arenax.tournament.MyMatchesStatusActivity.STATUS_COMPLETED);
                startActivity(i);
            });
        }

        View seeAll = view.findViewById(R.id.home_see_all);
        if (seeAll != null) {
            seeAll.setOnClickListener(v -> startActivity(new Intent(requireContext(),
                    com.arenax.tournament.EsportsGalleryActivity.class)));
        }

        // Header coin badge shows the same wallet balance used by WalletActivity.
        // The old implementation read leaderboard score, so paid/top-up coins did
        // not appear beside the profile icon.
        android.widget.TextView pointsValue = view.findViewById(R.id.home_points_value);
        String uid = com.google.firebase.auth.FirebaseAuth.getInstance().getUid();
        if (uid != null && pointsValue != null) {
            walletBalanceListener = new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot snapshot) {
                    Object rawBalance = snapshot.getValue();
                    long walletBalance = rawBalance instanceof Number
                            ? ((Number) rawBalance).longValue() : 0L;
                    pointsValue.setText(String.valueOf(walletBalance));
                }

                @Override
                public void onCancelled(DatabaseError error) {}
            };
            FirebaseRepository.users().child(uid).child("wallet").child("balance")
                    .addValueEventListener(walletBalanceListener);
        }

        RecyclerView gameModeList = view.findViewById(R.id.home_game_mode_list);
        gameModeList.setLayoutManager(new GridLayoutManager(requireContext(), 2));
        gameModeList.setNestedScrollingEnabled(false);
        gameModeList.setHasFixedSize(false);
        final GameModeAdapter gameModeAdapter = new GameModeAdapter(gameModes, false, null, mode -> {
            Intent intent = new Intent(requireContext(), com.arenax.tournament.CategoryMatchesActivity.class);
            intent.putExtra("categoryId", mode.getId());
            intent.putExtra("categoryTitle", mode.getTitle());
            startActivity(intent);
        });
        // Grey skeleton cards until the first Firebase snapshot arrives (no empty gap).
        gameModeAdapter.setLoading(true);
        gameModeList.setAdapter(gameModeAdapter);
        fitGameModeList(gameModeList);
        RecyclerView bannerList = view.findViewById(R.id.home_banner_list);
        bannerListView = bannerList;
        dotsContainer = view.findViewById(R.id.home_banner_dots);
        bannerList.setLayoutManager(new LinearLayoutManager(requireContext(), LinearLayoutManager.HORIZONTAL, false));
        final BannerAdapter bannerAdapter = new BannerAdapter(banners, false, null);
        bannerAdapter.setLoading(true);
        bannerList.setAdapter(bannerAdapter);
        // PagerSnapHelper so each banner snaps fully into view at full width instead of a
        // half-cropped strip. Auto-slide is layered on top via bannerAutoSlideRunnable below,
        // and is paused while the user is actively touching/dragging the carousel.
        PagerSnapHelper snapHelper = new PagerSnapHelper();
        snapHelper.attachToRecyclerView(bannerList);
        bannerList.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(@NonNull RecyclerView recyclerView, int newState) {
                if (newState != RecyclerView.SCROLL_STATE_IDLE) return;
                RecyclerView.LayoutManager lm = recyclerView.getLayoutManager();
                if (!(lm instanceof LinearLayoutManager)) return;
                int position = ((LinearLayoutManager) lm).findFirstVisibleItemPosition();
                setActiveDot(position);
            }
        });
        bannerList.addOnItemTouchListener(new RecyclerView.SimpleOnItemTouchListener() {
            @Override
            public boolean onInterceptTouchEvent(@NonNull RecyclerView rv, @NonNull android.view.MotionEvent e) {
                if (e.getAction() == android.view.MotionEvent.ACTION_DOWN) {
                    bannerAutoSlideHandler.removeCallbacks(bannerAutoSlideRunnable);
                } else if (e.getAction() == android.view.MotionEvent.ACTION_UP || e.getAction() == android.view.MotionEvent.ACTION_CANCEL) {
                    restartBannerAutoSlide();
                }
                return false;
            }
        });
        bannerListener = new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                hideStartupLoading();
                banners.clear();
                for (DataSnapshot child : snapshot.getChildren()) {
                    Object raw = child.getValue();
                    if (!(raw instanceof java.util.Map)) continue;
                    Banner banner = Banner.fromMap(child.getKey(), (java.util.Map<String, Object>) raw);
                    if (banner != null && banner.isActive()) banners.add(banner);
                }
                Collections.sort(banners, Comparator.comparingInt(Banner::getDisplayOrder));
                bannerAdapter.setLoading(false);
                bannerAdapter.notifyDataSetChanged();
                // Background: warm the disk cache for every banner so swiping is instant.
                List<String> bannerUrls = new ArrayList<>();
                for (Banner b : banners) bannerUrls.add(b.getImageUrl());
                ImageLoader.preload(bannerList.getContext(), bannerUrls);
                rebuildDots();
                restartBannerAutoSlide();
            }

            @Override
            public void onCancelled(DatabaseError error) {
                hideStartupLoading();
                bannerAdapter.setLoading(false);
            }
        };
        FirebaseRepository.banners().addValueEventListener(bannerListener);

        // Admin-controlled notice strip shown above the banner carousel (appConfig/homeNotice).
        View noticeContainer = view.findViewById(R.id.home_notice_container);
        android.widget.TextView noticeText = view.findViewById(R.id.home_notice_text);
        noticeListener = new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                DataSnapshot notice = snapshot.child("homeNotice");
                String text = notice.child("text").getValue(String.class);
                String title = notice.child("title").getValue(String.class);
                Boolean enabled = notice.child("enabled").getValue(Boolean.class);
                boolean show = Boolean.TRUE.equals(enabled) && text != null && !text.trim().isEmpty();
                if (noticeContainer != null) noticeContainer.setVisibility(show ? View.VISIBLE : View.GONE);
                if (show) {
                    noticeText.setText(text);
                    noticeText.setSelected(true); // marquee only scrolls while selected
                    final String finalTitle = title;
                    final String finalText = text;
                    if (noticeContainer != null) {
                        noticeContainer.setOnClickListener(v -> {
                            Intent intent = new Intent(requireContext(), com.arenax.tournament.NoticeDetailActivity.class);
                            intent.putExtra(com.arenax.tournament.NoticeDetailActivity.EXTRA_TITLE, finalTitle);
                            intent.putExtra(com.arenax.tournament.NoticeDetailActivity.EXTRA_TEXT, finalText);
                            startActivity(intent);
                        });
                    }
                }
            }

            @Override
            public void onCancelled(DatabaseError error) {}
        };
        FirebaseRepository.appConfig().addValueEventListener(noticeListener);
        gameModeListener = new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                hideStartupLoading();
                gameModes.clear();
                for (DataSnapshot child : snapshot.getChildren()) {
                    Object raw = child.getValue();
                    if (!(raw instanceof java.util.Map)) continue;
                    GameMode mode = GameMode.fromMap(child.getKey(),
                            (java.util.Map<String, Object>) raw);
                    if (mode != null && mode.isActive()) gameModes.add(mode);
                }
                Collections.sort(gameModes, Comparator.comparingInt(GameMode::getDisplayOrder));
                gameModeAdapter.setLoading(false);
                gameModeAdapter.notifyDataSetChanged();
                List<String> modeUrls = new ArrayList<>();
                for (GameMode m : gameModes) modeUrls.add(m.getImageUrl());
                ImageLoader.preload(gameModeList.getContext(), modeUrls);
                // A RecyclerView with wrap_content height inside a plain ScrollView does not
                // reliably re-measure itself when the item count changes (a well-known
                // RecyclerView/ScrollView interaction issue) — it was getting stuck at the
                // height captured on first layout (2 rows / 4 cards) no matter how many
                // categories actually existed, with nothing below rendered or reachable by
                // scrolling. Forcing an explicit measure pass and pinning the RecyclerView's
                // LayoutParams height to the real measured content height fixes that for good:
                // the grid now always sizes to fit every category, and the outer ScrollView
                // scrolls the rest of the page (including any rows below the fold) normally.
                fitGameModeList(gameModeList);
            }

            @Override
            public void onCancelled(DatabaseError error) {
                hideStartupLoading();
                gameModeAdapter.setLoading(false);
                gameModeAdapter.notifyDataSetChanged();
                fitGameModeList(gameModeList);
                if (isAdded()) FancyText.toast(requireContext(),
                        "Game categories unavailable: " + error.getMessage(), android.widget.Toast.LENGTH_LONG).show();
            }
        };
        FirebaseRepository.gameModes().addValueEventListener(gameModeListener);
        homeRoot = view;
        loadMyMatchCounts();
        return view;
    }

    /** Pins the grid's height to its real content height (skeleton or real cards) so the outer
     *  ScrollView always shows every row. */
    private void fitGameModeList(final RecyclerView gameModeList) {
        gameModeList.post(() -> {
            if (!isAdded()) return;
            int width = gameModeList.getWidth();
            if (width <= 0) return;
            gameModeList.measure(
                    View.MeasureSpec.makeMeasureSpec(width, View.MeasureSpec.EXACTLY),
                    View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED));
            ViewGroup.LayoutParams params = gameModeList.getLayoutParams();
            if (params != null) {
                params.height = gameModeList.getMeasuredHeight();
                gameModeList.setLayoutParams(params);
            }
        });
    }

    private void hideStartupLoading() {
        if (!isAdded()) return;
        android.app.Activity activity = getActivity();
        if (activity instanceof com.arenax.tournament.MainActivity) {
            ((com.arenax.tournament.MainActivity) activity).hideStartupLoading();
        }
    }

    // ---- Upcoming / Ongoing / Completed tile counters -------------------------------------
    // These three TextViews used to keep their static "0 Tournaments" text forever because
    // nothing ever wrote to them. They now show the player's own joined tournaments per status,
    // i.e. exactly what the tile opens (MyMatchesStatusActivity).
    private View homeRoot;
    private int countGeneration;

    private void setTileCounts(int upcoming, int ongoing, int completed) {
        if (homeRoot == null || !isAdded()) return;
        android.widget.TextView up = homeRoot.findViewById(R.id.home_count_upcoming);
        android.widget.TextView on = homeRoot.findViewById(R.id.home_count_ongoing);
        android.widget.TextView done = homeRoot.findViewById(R.id.home_count_completed);
        if (up != null) up.setText(upcoming + (upcoming == 1 ? " Tournament" : " Tournaments"));
        if (on != null) on.setText(ongoing + " Live " + (ongoing == 1 ? "Tournament" : "Tournaments"));
        if (done != null) done.setText(completed + (completed == 1 ? " Tournament" : " Tournaments"));
    }

    private void loadMyMatchCounts() {
        final String uid = com.google.firebase.auth.FirebaseAuth.getInstance().getUid();
        if (uid == null || homeRoot == null || !FirebaseRepository.isReady(requireContext())) return;
        final int generation = ++countGeneration;
        FirebaseRepository.tournaments().addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                final List<com.arenax.tournament.model.Tournament> all = new ArrayList<>();
                for (DataSnapshot child : snapshot.getChildren()) {
                    Object raw = child.getValue();
                    if (!(raw instanceof java.util.Map)) continue;
                    try {
                        com.arenax.tournament.model.Tournament t = com.arenax.tournament.model.Tournament
                                .fromMap(child.getKey(), (java.util.Map<String, Object>) raw);
                        if (t != null) all.add(t);
                    } catch (RuntimeException ignored) { }
                }
                if (all.isEmpty()) { setTileCounts(0, 0, 0); return; }
                final int[] counts = new int[3]; // upcoming, ongoing, completed
                final java.util.concurrent.atomic.AtomicInteger pending =
                        new java.util.concurrent.atomic.AtomicInteger(all.size());
                for (com.arenax.tournament.model.Tournament t : all) {
                    FirebaseRepository.tournamentParticipants(t.getId()).child(uid).get()
                            .addOnCompleteListener(task -> {
                                if (task.isSuccessful() && task.getResult() != null && task.getResult().exists()) {
                                    String st = t.getEffectiveStatus();
                                    synchronized (counts) {
                                        if (com.arenax.tournament.model.Tournament.COMPLETED.equals(st)) counts[2]++;
                                        else if (com.arenax.tournament.model.Tournament.UPCOMING.equals(st)) counts[0]++;
                                        else if (!com.arenax.tournament.model.Tournament.CANCELLED.equals(st)
                                                && !com.arenax.tournament.model.Tournament.DRAFT.equals(st)) counts[1]++;
                                    }
                                }
                                if (pending.decrementAndGet() == 0 && generation == countGeneration) {
                                    setTileCounts(counts[0], counts[1], counts[2]);
                                }
                            });
                }
            }

            @Override
            public void onCancelled(DatabaseError error) { }
        });
    }

    private void rebuildDots() {
        if (dotsContainer == null) return;
        dotsContainer.removeAllViews();
        if (banners.size() <= 1) return; // no dots needed for 0 or 1 banner
        int size = dpToPx(8);
        int margin = dpToPx(3);
        for (int i = 0; i < banners.size(); i++) {
            android.widget.ImageView dot = new android.widget.ImageView(requireContext());
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(size, size);
            params.setMargins(margin, 0, margin, 0);
            dot.setLayoutParams(params);
            dot.setImageDrawable(null);
            dot.setBackgroundResource(i == 0 ? R.drawable.dot_active : R.drawable.dot_inactive);
            dotsContainer.addView(dot);
        }
    }

    private void setActiveDot(int position) {
        if (dotsContainer == null) return;
        for (int i = 0; i < dotsContainer.getChildCount(); i++) {
            View dot = dotsContainer.getChildAt(i);
            dot.setBackgroundResource(i == position ? R.drawable.dot_active : R.drawable.dot_inactive);
        }
    }

    private int dpToPx(int dp) {
        return Math.round(dp * getResources().getDisplayMetrics().density);
    }

    private void restartBannerAutoSlide() {
        bannerAutoSlideHandler.removeCallbacks(bannerAutoSlideRunnable);
        if (banners.size() > 1) {
            bannerAutoSlideHandler.postDelayed(bannerAutoSlideRunnable, BANNER_AUTO_SLIDE_MS);
        }
    }

    @Override
    public void onPause() {
        super.onPause();
        bannerAutoSlideHandler.removeCallbacks(bannerAutoSlideRunnable);
    }

    @Override
    public void onResume() {
        super.onResume();
        restartBannerAutoSlide();
        loadMyMatchCounts();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        bannerAutoSlideHandler.removeCallbacks(bannerAutoSlideRunnable);
        bannerListView = null;
        homeRoot = null;
        countGeneration++;
        if (gameModeListener != null) FirebaseRepository.gameModes().removeEventListener(gameModeListener);
        if (bannerListener != null) FirebaseRepository.banners().removeEventListener(bannerListener);
        if (brandingListener != null) FirebaseRepository.appConfig().removeEventListener(brandingListener);
        if (noticeListener != null) FirebaseRepository.appConfig().removeEventListener(noticeListener);
        if (pointsListener != null) {
            String uid = com.google.firebase.auth.FirebaseAuth.getInstance().getUid();
            if (uid != null) FirebaseRepository.leaderboard().child("allTime").child(uid).removeEventListener(pointsListener);
        }
        if (walletBalanceListener != null) {
            String uid = com.google.firebase.auth.FirebaseAuth.getInstance().getUid();
            if (uid != null) FirebaseRepository.users().child(uid).child("wallet").child("balance")
                    .removeEventListener(walletBalanceListener);
        }
        dotsContainer = null;
    }
}
