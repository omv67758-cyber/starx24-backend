package com.arenax.tournament.util;

import android.app.Activity;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.Toast;

import com.arenax.tournament.R;
import com.arenax.tournament.data.FirebaseRepository;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.firebase.auth.FirebaseAuth;

/**
 * Result-dispute + report-a-problem dialogs for a tournament. Shared by the pre-join
 * Contest Details page and the post-join Match Details page so both behave identically.
 * (A13/A14 & B43 — moved out of TournamentDetailActivity unchanged.)
 */
public final class MatchReports {
    private MatchReports() {}

    /** Entry point for both Result Dispute and Report/Moderation flows. */
    public static void showChoice(Activity activity, String tournamentId, String tournamentTitle) {
        if (FirebaseAuth.getInstance().getCurrentUser() == null) {
            FancyText.toast(activity, "Please sign in first.", Toast.LENGTH_SHORT).show();
            return;
        }
        new FancyText.MaterialBuilder(activity)
                .setTitle("What would you like to do?")
                .setMessage("Raise a dispute if you disagree with the published result, or report a rule violation / problem.")
                .setNegativeButton("CANCEL", null)
                .setNeutralButton("REPORT A PROBLEM", (d, w) -> showReportForm(activity, tournamentId, tournamentTitle))
                .setPositiveButton("RAISE RESULT DISPUTE", (d, w) -> showDisputeForm(activity, tournamentId, tournamentTitle))
                .show();
    }

    /** Leaderboard player report: reason + description, submit -> admin Reports me UID ke saath. */
    public static void showPlayerReport(Activity activity, String reportedUid, String reportedName) {
        if (FirebaseAuth.getInstance().getCurrentUser() == null) {
            FancyText.toast(activity, "Please sign in first.", Toast.LENGTH_SHORT).show();
            return;
        }
        LinearLayout form = form(activity);
        Spinner reason = new Spinner(activity);
        reason.setAdapter(new ArrayAdapter<>(activity, android.R.layout.simple_spinner_dropdown_item,
                new String[]{"Cheating / Hacking", "Fake Result / Wrong Coins", "Abusive Behavior", "Fake Account", "Other"}));
        EditText description = field(activity, "Kya hua? Detail me likho");
        form.addView(reason);
        form.addView(description);
        new FancyText.MaterialBuilder(activity)
                .setTitle("Report • " + reportedName)
                .setView(form)
                .setNegativeButton("CANCEL", null)
                .setPositiveButton("SUBMIT REPORT", (d, w) -> {
                    if (!InputValidation.length(description, 10, 4000,
                            "Please describe the problem in 10–4000 characters")) {
                        FancyText.toast(activity, "Please correct the highlighted field.", Toast.LENGTH_LONG).show();
                        return;
                    }
                    FirebaseRepository.submitPlayerReport(reportedUid, reportedName,
                                    String.valueOf(reason.getSelectedItem()), InputValidation.value(description))
                            .addOnSuccessListener(u -> FancyText.toast(activity,
                                    "Report submitted. Admin review karega.", Toast.LENGTH_LONG).show())
                            .addOnFailureListener(e -> FancyText.toast(activity, e.getMessage(), Toast.LENGTH_LONG).show());
                })
                .show();
    }

    private static void showDisputeForm(Activity activity, String tournamentId, String tournamentTitle) {
        LinearLayout form = form(activity);
        Spinner reason = new Spinner(activity);
        reason.setAdapter(new ArrayAdapter<>(activity, android.R.layout.simple_spinner_dropdown_item,
                new String[]{"Wrong Result", "Missing Kills", "Wrong Placement", "Cheating Suspected", "Other"}));
        EditText description = field(activity, "Describe what happened (attach a screenshot in your ticket if needed)");
        form.addView(reason);
        form.addView(description);
        new FancyText.MaterialBuilder(activity)
                .setTitle("Raise a dispute • " + tournamentTitle)
                .setView(form)
                .setNegativeButton("CANCEL", null)
                .setPositiveButton("SUBMIT DISPUTE", (d, w) -> {
                    if (!InputValidation.length(description, 10, 4000,
                            "Please describe the dispute in 10–4000 characters")) {
                        FancyText.toast(activity, "Please correct the highlighted field.", Toast.LENGTH_LONG).show();
                        return;
                    }
                    FirebaseRepository.submitDispute(tournamentId, tournamentTitle,
                                    String.valueOf(reason.getSelectedItem()), InputValidation.value(description))
                            .addOnSuccessListener(u -> FancyText.toast(activity,
                                    "Dispute submitted. Admin will review it.", Toast.LENGTH_LONG).show())
                            .addOnFailureListener(e -> FancyText.toast(activity, e.getMessage(), Toast.LENGTH_LONG).show());
                })
                .show();
    }

    private static void showReportForm(Activity activity, String tournamentId, String tournamentTitle) {
        LinearLayout form = form(activity);
        Spinner reason = new Spinner(activity);
        reason.setAdapter(new ArrayAdapter<>(activity, android.R.layout.simple_spinner_dropdown_item,
                new String[]{"Rule Violation", "Abusive Behavior", "Wrong Result", "Cheating", "Other"}));
        EditText description = field(activity, "Describe the problem");
        form.addView(reason);
        form.addView(description);
        new FancyText.MaterialBuilder(activity)
                .setTitle("Report a problem • " + tournamentTitle)
                .setView(form)
                .setNegativeButton("CANCEL", null)
                .setPositiveButton("SUBMIT REPORT", (d, w) -> {
                    if (!InputValidation.length(description, 10, 4000,
                            "Please describe the problem in 10–4000 characters")) {
                        FancyText.toast(activity, "Please correct the highlighted field.", Toast.LENGTH_LONG).show();
                        return;
                    }
                    FirebaseRepository.submitReport("TOURNAMENT", tournamentId, tournamentTitle,
                                    String.valueOf(reason.getSelectedItem()), InputValidation.value(description))
                            .addOnSuccessListener(u -> FancyText.toast(activity,
                                    "Report submitted. Moderators will review it.", Toast.LENGTH_LONG).show())
                            .addOnFailureListener(e -> FancyText.toast(activity, e.getMessage(), Toast.LENGTH_LONG).show());
                })
                .show();
    }

    private static LinearLayout form(Activity activity) {
        LinearLayout form = new LinearLayout(activity);
        form.setOrientation(LinearLayout.VERTICAL);
        int pad = dp(activity, 24);
        form.setPadding(pad, dp(activity, 8), pad, dp(activity, 8));
        return form;
    }

    private static EditText field(Activity activity, String hint) {
        EditText input = new EditText(activity);
        input.setHint(hint);
        input.setBackgroundResource(R.drawable.bg_input);
        int hPad = dp(activity, 16), vPad = dp(activity, 14);
        input.setPadding(hPad, vPad, hPad, vPad);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, -2);
        params.topMargin = dp(activity, 6);
        params.bottomMargin = dp(activity, 6);
        input.setLayoutParams(params);
        return input;
    }

    private static int dp(Activity activity, int value) {
        return Math.round(value * activity.getResources().getDisplayMetrics().density);
    }
}
