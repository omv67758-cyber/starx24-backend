package com.arenax.tournament.util;

import android.content.Context;
import android.content.res.Configuration;

/**
 * Keeps every screen (user app + admin app) looking full-width / full-height on ALL devices.
 *
 * Problem: phones running a high DPI or a large "Display size" / "Font size" setting report a
 * very small width in dp (e.g. 300-330dp instead of ~392dp). Every fixed-dp header, card and
 * bottom-nav then eats far more of the screen, so pages look zoomed-in / cropped ("half screen").
 *
 * Fix: if the shortest side is narrower than {@link #MIN_WIDTH_DP}, the density is lowered so the
 * layout always gets at least that many dp of width. The layout is then identical to what it looks
 * like on a normal phone and fills the whole screen. Devices that are already wide enough are
 * left completely untouched. Font scale is capped so text can never blow the layout up either.
 */
public final class ScreenFit {
    /** Design width. Any phone narrower than this (in dp) gets scaled down to fit it. */
    public static final int MIN_WIDTH_DP = 360;
    /** Max system font scale we honour (accessibility still works, but layouts can't explode). */
    public static final float MAX_FONT_SCALE = 1.15f;

    private ScreenFit() { }

    /** Wrap in Activity.attachBaseContext(). */
    public static Context wrap(Context base) {
        try {
            Configuration current = base.getResources().getConfiguration();
            Configuration override = new Configuration(current);
            if (!adjust(override)) return base;
            return base.createConfigurationContext(override);
        } catch (Throwable ignored) {
            return base; // never let a display quirk crash the app
        }
    }

    /**
     * Adjusts density / font scale in-place. Returns true if anything changed.
     * Safe to call on a partial override configuration (fields that are unset are skipped).
     */
    public static boolean adjust(Configuration cfg) {
        if (cfg == null) return false;
        boolean changed = false;

        if (cfg.fontScale > MAX_FONT_SCALE) {
            cfg.fontScale = MAX_FONT_SCALE;
            changed = true;
        }

        int dpi = cfg.densityDpi;
        int wDp = cfg.screenWidthDp;
        int hDp = cfg.screenHeightDp;
        if (dpi <= 0 || wDp <= 0 || hDp <= 0) return changed;

        int shortDp = Math.min(wDp, hDp);
        if (shortDp >= MIN_WIDTH_DP) return changed;

        float scale = (float) shortDp / MIN_WIDTH_DP;            // < 1
        int newDpi = Math.max(120, Math.round(dpi * scale));      // lower density => more dp
        if (newDpi >= dpi) return changed;

        cfg.densityDpi = newDpi;
        cfg.screenWidthDp = Math.round(wDp * (float) dpi / newDpi);
        cfg.screenHeightDp = Math.round(hDp * (float) dpi / newDpi);
        if (cfg.smallestScreenWidthDp > 0) {
            cfg.smallestScreenWidthDp = Math.round(cfg.smallestScreenWidthDp * (float) dpi / newDpi);
        }
        return true;
    }
}
