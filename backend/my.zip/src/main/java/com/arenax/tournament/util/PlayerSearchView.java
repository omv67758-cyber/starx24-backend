package com.arenax.tournament.util;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.arenax.tournament.R;
import com.arenax.tournament.data.FirebaseRepository;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.resource.bitmap.CircleCrop;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.ValueEventListener;

import java.util.Locale;

/**
 * Player search for the top of the Profile tab.
 * Reads ONLY publicProfiles (name, bio, photo) - email, phone and wallet are never touched,
 * so they can never show up here. Prefix search on the lower-cased name, 350 ms debounce.
 * Tap a result to expand / collapse a long bio.
 */
public class PlayerSearchView extends LinearLayout {
    private static final int INK = 0xFF101936, MUTED = 0xFF5B6784;
    private static final int BLUE = 0xFF2F6FED, VIOLET = 0xFF7C5CE8, PINK = 0xFFEC4899;
    private static final long DEBOUNCE_MS = 350L;
    private static final int MAX_RESULTS = 25;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final String selfUid;
    private final EditText input;
    private final ImageView clear;
    private final LinearLayout results;
    private int generation = 0;
    private Runnable pending;

    public PlayerSearchView(Context context, String selfUid) {
        super(context);
        this.selfUid = selfUid == null ? "" : selfUid;
        setOrientation(VERTICAL);

        // gradient border (blue -> violet) around a white pill
        LinearLayout frame = new LinearLayout(context);
        frame.setPadding(dp(2), dp(2), dp(2), dp(2));
        GradientDrawable border = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                new int[]{BLUE, VIOLET, PINK});
        border.setCornerRadius(dp(20));
        frame.setBackground(border);
        frame.setElevation(dp(3));

        LinearLayout bar = new LinearLayout(context);
        bar.setOrientation(HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(16), 0, dp(8), 0);
        GradientDrawable white = new GradientDrawable();
        white.setColor(Color.WHITE);
        white.setCornerRadius(dp(18));
        bar.setBackground(white);

        ImageView icon = new ImageView(context);
        icon.setImageResource(R.drawable.ic_pf_search);
        bar.addView(icon, new LayoutParams(dp(22), dp(22)));

        input = new EditText(context);
        input.setHint("Search anything in the app");
        input.setHintTextColor(0xFF9AA5BD);
        input.setTextColor(INK);
        input.setTextSize(14.5f);
        input.setSingleLine(true);
        input.setBackground(null);
        input.setPadding(dp(10), dp(14), dp(6), dp(14));
        input.setImeOptions(EditorInfo.IME_ACTION_SEARCH);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        LayoutParams ip = new LayoutParams(0, -2, 1f);
        bar.addView(input, ip);

        clear = new ImageView(context);
        clear.setImageResource(R.drawable.ic_pf_clear);
        clear.setPadding(dp(8), dp(8), dp(8), dp(8));
        clear.setVisibility(GONE);
        clear.setContentDescription("Clear");
        clear.setOnClickListener(v -> input.setText(""));
        bar.addView(clear, new LayoutParams(dp(38), dp(38)));

        frame.addView(bar, new LayoutParams(-1, dp(48)));
        addView(frame, new LayoutParams(-1, -2));

        results = new LinearLayout(context);
        results.setOrientation(VERTICAL);
        results.setVisibility(GONE);
        LayoutParams rp = new LayoutParams(-1, -2);
        rp.topMargin = dp(12);
        addView(results, rp);

        input.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void afterTextChanged(Editable s) {
                clear.setVisibility(s.length() == 0 ? GONE : VISIBLE);
                if (pending != null) handler.removeCallbacks(pending);
                final String typed = s.toString();
                pending = () -> search(typed);
                handler.postDelayed(pending, DEBOUNCE_MS);
            }
        });
        input.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                if (pending != null) handler.removeCallbacks(pending);
                search(input.getText().toString());
                InputMethodManager imm = (InputMethodManager) getContext().getSystemService(Context.INPUT_METHOD_SERVICE);
                if (imm != null) imm.hideSoftInputFromWindow(input.getWindowToken(), 0);
                return true;
            }
            return false;
        });
    }

    /** Makes the whole bar a button: tapping it opens the full app-wide search screen. */
    public void openGlobalSearchOnTap() {
        input.setFocusable(false);
        input.setFocusableInTouchMode(false);
        input.setCursorVisible(false);
        View.OnClickListener open = v -> getContext().startActivity(
                new android.content.Intent(getContext(), com.arenax.tournament.GlobalSearchActivity.class)
                        .putExtra(com.arenax.tournament.GlobalSearchActivity.EXTRA_MODE,
                                com.arenax.tournament.GlobalSearchActivity.MODE_USER));
        input.setOnClickListener(open);
        setOnClickListener(open);
    }

    private void search(String raw) {
        final String q = raw == null ? "" : raw.trim().toLowerCase(Locale.ROOT).replaceAll("\\s+", " ");
        final int gen = ++generation;
        if (q.isEmpty()) {
            results.removeAllViews();
            results.setVisibility(GONE);
            return;
        }
        results.setVisibility(VISIBLE);
        showStatus("Searching\u2026");
        if (!FirebaseRepository.isReady(getContext())) {
            showStatus("Search is unavailable right now.");
            return;
        }
        FirebaseRepository.publicProfiles().orderByChild("nameLower")
                .startAt(q).endAt(q + "\uf8ff").limitToFirst(MAX_RESULTS)
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override public void onDataChange(@NonNull DataSnapshot snapshot) {
                        if (gen != generation) return;   // an older query finished late
                        results.removeAllViews();
                        int shown = 0;
                        for (DataSnapshot child : snapshot.getChildren()) {
                            if (child.getKey() == null) continue;
                            String name = str(child.child("name").getValue());
                            if (name.isEmpty()) continue;
                            results.addView(buildCard(child.getKey(), name,
                                    str(child.child("bio").getValue()),
                                    str(child.child("photoUrl").getValue())));
                            shown++;
                        }
                        if (shown == 0) showStatus("No player found for \u201c" + raw.trim() + "\u201d");
                    }
                    @Override public void onCancelled(@NonNull DatabaseError error) {
                        if (gen == generation) showStatus("Could not search. Try again.");
                    }
                });
    }

    private void showStatus(String message) {
        results.removeAllViews();
        TextView t = new TextView(getContext());
        t.setText(message);
        t.setTextColor(MUTED);
        t.setTextSize(13);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(8), dp(14), dp(8), dp(14));
        results.addView(t, new LayoutParams(-1, -2));
    }

    private View buildCard(String uid, String name, String bio, String photoUrl) {
        Context c = getContext();
        LinearLayout row = new LinearLayout(c);
        row.setOrientation(HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(12), dp(12), dp(14), dp(12));
        GradientDrawable bg = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{0xFFFFFFFF, 0xFFFFFFFF, 0xFFEEF3FF});
        bg.setCornerRadius(dp(20));
        bg.setStroke(dp(1.5f), 0xFFC9D8FB);
        row.setBackground(bg);
        row.setElevation(dp(2));
        LayoutParams lp = new LayoutParams(-1, -2);
        lp.bottomMargin = dp(10);
        row.setLayoutParams(lp);

        // avatar: gradient ring + white outline + photo
        LinearLayout ring = new LinearLayout(c);
        ring.setGravity(Gravity.CENTER);
        ring.setPadding(dp(2.5f), dp(2.5f), dp(2.5f), dp(2.5f));
        GradientDrawable ringBg = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{0xFF38BDF8, 0xFF6366F1, PINK});
        ringBg.setShape(GradientDrawable.OVAL);
        ring.setBackground(ringBg);
        ImageView avatar = new ImageView(c);
        GradientDrawable whiteDot = new GradientDrawable();
        whiteDot.setShape(GradientDrawable.OVAL);
        whiteDot.setColor(Color.WHITE);
        avatar.setBackground(whiteDot);
        avatar.setScaleType(ImageView.ScaleType.CENTER_CROP);
        if (photoUrl.isEmpty()) {
            avatar.setPadding(dp(12), dp(12), dp(12), dp(12));
            avatar.setImageResource(R.drawable.ic_profile);
        } else {
            avatar.setPadding(dp(2), dp(2), dp(2), dp(2));
            try {
                Glide.with(avatar).load(photoUrl).transform(new CircleCrop()).into(avatar);
            } catch (RuntimeException e) {
                avatar.setPadding(dp(12), dp(12), dp(12), dp(12));
                avatar.setImageResource(R.drawable.ic_profile);
            }
        }
        ring.addView(avatar, new LayoutParams(dp(54), dp(54)));
        row.addView(ring, new LayoutParams(dp(59), dp(59)));

        LinearLayout col = new LinearLayout(c);
        col.setOrientation(VERTICAL);
        LayoutParams cp = new LayoutParams(0, -2, 1f);
        cp.leftMargin = dp(12);
        row.addView(col, cp);

        LinearLayout nameRow = new LinearLayout(c);
        nameRow.setOrientation(HORIZONTAL);
        nameRow.setGravity(Gravity.CENTER_VERTICAL);
        TextView n = new TextView(c);
        n.setText(name);
        n.setTextColor(INK);
        n.setTextSize(15);
        n.setTypeface(null, Typeface.BOLD);
        n.setSingleLine(true);
        n.setEllipsize(TextUtils.TruncateAt.END);
        nameRow.addView(n, new LayoutParams(-2, -2));
        if (uid.equals(selfUid)) {
            TextView you = new TextView(c);
            you.setText("YOU");
            you.setTextColor(Color.WHITE);
            you.setTextSize(9);
            you.setTypeface(null, Typeface.BOLD);
            you.setPadding(dp(7), dp(1), dp(7), dp(1));
            GradientDrawable pill = new GradientDrawable();
            pill.setColor(BLUE);
            pill.setCornerRadius(dp(10));
            you.setBackground(pill);
            LayoutParams yp = new LayoutParams(-2, -2);
            yp.leftMargin = dp(8);
            nameRow.addView(you, yp);
        }
        col.addView(nameRow, new LayoutParams(-1, -2));

        final TextView b = new TextView(c);
        boolean hasBio = !bio.trim().isEmpty();
        b.setText(hasBio ? FancyText.plain(bio.trim()) : "No bio yet");
        b.setTextColor(hasBio ? MUTED : 0xFF9AA5BD);
        b.setTextSize(12.5f);
        if (!hasBio) b.setTypeface(null, Typeface.ITALIC);
        b.setMaxLines(2);
        b.setEllipsize(TextUtils.TruncateAt.END);
        b.setLineSpacing(dp(2), 1f);
        LayoutParams bp = new LayoutParams(-1, -2);
        bp.topMargin = dp(3);
        col.addView(b, bp);

        row.setOnClickListener(v -> c.startActivity(
                new android.content.Intent(c, com.arenax.tournament.PlayerProfileActivity.class)
                        .putExtra(com.arenax.tournament.PlayerProfileActivity.EXTRA_UID, uid)
                        .putExtra(com.arenax.tournament.PlayerProfileActivity.EXTRA_NAME, name)
                        .putExtra(com.arenax.tournament.PlayerProfileActivity.EXTRA_BIO, bio)
                        .putExtra(com.arenax.tournament.PlayerProfileActivity.EXTRA_PHOTO, photoUrl)));
        return row;
    }

    @Override protected void onDetachedFromWindow() {
        handler.removeCallbacksAndMessages(null);
        generation++;
        super.onDetachedFromWindow();
    }

    private static String str(Object value) { return value == null ? "" : String.valueOf(value); }

    private int dp(float v) { return Math.round(v * getResources().getDisplayMetrics().density); }
}
