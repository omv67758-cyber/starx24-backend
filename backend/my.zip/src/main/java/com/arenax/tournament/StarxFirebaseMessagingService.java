package com.arenax.tournament;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.os.Build;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;

public class StarxFirebaseMessagingService extends FirebaseMessagingService {
    private static final String CHANNEL_ID = "starx24_announcements";

    @Override public void onNewToken(String token) {
        super.onNewToken(token);
        if (FirebaseAuth.getInstance().getCurrentUser() != null) {
            String uid = FirebaseAuth.getInstance().getCurrentUser().getUid();
            FirebaseDatabase.getInstance().getReference("users").child(uid).child("fcmToken").setValue(token);
        }
    }

    @Override public void onMessageReceived(RemoteMessage message) {
        super.onMessageReceived(message);
        String title = message.getNotification() == null ? message.getData().get("title") : message.getNotification().getTitle();
        String body = message.getNotification() == null ? message.getData().get("message") : message.getNotification().getBody();
        showNotification(title == null ? "STARX24" : title, body == null ? "New announcement" : body,
                message.getData().get(com.arenax.tournament.util.NotificationRedirect.EXTRA_TYPE),
                message.getData().get(com.arenax.tournament.util.NotificationRedirect.EXTRA_ID),
                message.getData().get(com.arenax.tournament.util.NotificationRedirect.EXTRA_TITLE));
    }

    private void showNotification(String title, String body, String redirectType, String redirectId, String redirectTitle) {
        NotificationManager manager = getSystemService(NotificationManager.class);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            manager.createNotificationChannel(new NotificationChannel(CHANNEL_ID, "STARX24 announcements", NotificationManager.IMPORTANCE_HIGH));
        }
        Intent intent = new Intent(this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        // Tap -> open the exact content the admin picked (match, wallet, category ...).
        if (redirectType != null && !redirectType.trim().isEmpty()) {
            intent.putExtra(com.arenax.tournament.util.NotificationRedirect.EXTRA_TYPE, redirectType);
            intent.putExtra(com.arenax.tournament.util.NotificationRedirect.EXTRA_ID, redirectId == null ? "" : redirectId);
            intent.putExtra(com.arenax.tournament.util.NotificationRedirect.EXTRA_TITLE, redirectTitle == null ? "" : redirectTitle);
        }
        // Unique request code per notification: with a shared code (0) and FLAG_UPDATE_CURRENT a
        // second notification would overwrite the first one's redirect extras.
        int requestCode = (int) (System.currentTimeMillis() & 0x7fffffff);
        PendingIntent pending = PendingIntent.getActivity(this, requestCode, intent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, CHANNEL_ID)
                // Status-bar icons must be a plain white silhouette (Android strips color and
                // shows only the alpha shape) — the full-colour brand mark was rendering as a
                // solid blob. ic_notification is a dedicated white-on-transparent mark for this.
                .setSmallIcon(R.drawable.ic_notification).setContentTitle(title).setContentText(body)
                .setStyle(new NotificationCompat.BigTextStyle().bigText(body)).setPriority(NotificationCompat.PRIORITY_HIGH)
                .setAutoCancel(true).setContentIntent(pending);
        if (Build.VERSION.SDK_INT < 33 || checkSelfPermission("android.permission.POST_NOTIFICATIONS") == android.content.pm.PackageManager.PERMISSION_GRANTED) {
            NotificationManagerCompat.from(this).notify((int) System.currentTimeMillis(), builder.build());
        }
    }
}
