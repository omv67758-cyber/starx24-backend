package com.arenax.tournament;


import com.arenax.tournament.util.FancyText;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.widget.Toast;

import com.arenax.tournament.data.FirebaseRepository;

/** Central place for every "open an outside link" action tied to the admin's Platform
 *  controls (Customer Support, Telegram, YouTube, Instagram). Every Customer Support entry point
 *  in the app (FAQ, About Us, etc.) should call {@link #openTelegramSupport} so support
 *  always opens Telegram, using whatever link the admin has configured. */
public final class SupportLinks {

    private SupportLinks() { }

    /** Kept only so old call sites keep compiling. Support is Telegram-only now. */
    public static void openWhatsAppSupport(Context context) {
        openTelegramSupport(context);
    }

    /** Opens the Customer Support Telegram link the admin set in Platform Links
     *  (appConfig/profile/supportUrl). If that is empty it falls back to the general
     *  Telegram link (telegramUrl). Every "Contact Support" button routes through here. */
    public static void openTelegramSupport(Context context) {
        if (!FirebaseRepository.isReady(context)) {
            FancyText.toast(context, "Telegram support is not available right now.", Toast.LENGTH_SHORT).show();
            return;
        }
        FirebaseRepository.appConfig().child("profile").get()
                .addOnSuccessListener(snapshot -> {
                    String link = clean(snapshot.child("supportUrl").getValue(String.class));
                    if (link.isEmpty()) link = clean(snapshot.child("telegramUrl").getValue(String.class));
                    if (link.isEmpty()) {
                        FancyText.toast(context, "Telegram support link is not configured yet.", Toast.LENGTH_LONG).show();
                        return;
                    }
                    // Accept "@username" too.
                    if (link.startsWith("@")) link = "https://t.me/" + link.substring(1);
                    openUrl(context, link);
                })
                .addOnFailureListener(error -> FancyText.toast(context, "Could not open Telegram support.", Toast.LENGTH_SHORT).show());
    }

    private static String clean(String raw) {
        return raw == null ? "" : raw.trim();
    }

    /** Opens an admin-configured link (Telegram/YouTube/Instagram/Terms/Privacy) by its
     *  key under appConfig/profile. Shows a friendly message if it isn't set up yet. */
    public static void openConfiguredLink(Context context, String key, String label) {
        if (!FirebaseRepository.isReady(context)) {
            FancyText.toast(context, label + " link is not available right now.", Toast.LENGTH_SHORT).show();
            return;
        }
        FirebaseRepository.appConfig().child("profile").child(key).get()
                .addOnSuccessListener(snapshot -> {
                    String url = snapshot.getValue(String.class);
                    if (url == null || url.trim().isEmpty()) {
                        FancyText.toast(context, label + " link is not configured yet.", Toast.LENGTH_LONG).show();
                        return;
                    }
                    openUrl(context, url.trim());
                })
                .addOnFailureListener(error -> FancyText.toast(context, "Could not open " + label + ".", Toast.LENGTH_SHORT).show());
    }

    private static void openUrl(Context context, String rawUrl) {
        try {
            String url = rawUrl.startsWith("http://") || rawUrl.startsWith("https://") ? rawUrl : "https://" + rawUrl;
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            if (!(context instanceof android.app.Activity)) intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(intent);
        } catch (RuntimeException error) {
            FancyText.toast(context, "Link is not available right now.", Toast.LENGTH_SHORT).show();
        }
    }
}
