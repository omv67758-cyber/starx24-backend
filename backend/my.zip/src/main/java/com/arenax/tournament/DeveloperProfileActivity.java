package com.arenax.tournament;

import android.content.Intent;
import android.animation.ValueAnimator;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Matrix;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.arenax.tournament.util.FancyText;

/**
 * Developer Profile — opened from the user app's Profile tab. Shows the developer's logo,
 * contact number, a short bio, skills, services and a Telegram button.
 *
 * To change anything, edit the constants below. To use your own logo, put an image named
 * developer_logo.png in res/drawable/ (it is picked up automatically, no code change).
 */
public class DeveloperProfileActivity extends BaseActivity {

    // ----- EDIT THESE -----------------------------------------------------------------
    private static final String DEV_NAME = "STARX24 Developer";
    private static final String DEV_TAGLINE = "Full-Stack • App • Web • 3D";
    /** TODO: put your real contact number here (with country code). */
    private static final String DEV_PHONE = "+91 74707 64560";
    /** WhatsApp chat link (opens WhatsApp, not the dialer). */
    private static final String DEV_WHATSAPP = "https://wa.me/917470764560";
    private static final String DEV_TELEGRAM = "https://t.me/+x8bmWRPgSNg2MGY1";
    // ----------------------------------------------------------------------------------

    private static final int INK = 0xFF101936, MUTED = 0xFF5B6784;
    private static final int BLUE = 0xFF2F6FED, VIOLET = 0xFF7C5CE8, CYAN = 0xFF22C3E6;

    private static final String[] SKILLS = {
            "Java", "XML", "TypeScript", "HTML", "CSS", "Frontend", "Backend", "Android",
            "Websites", "Blender 3D",
            "Python", "Node.js", "Firebase", "Telegram Bot", "WhatsApp Bot", "Unity Mods",
            "UI / UX", "Payment API"};

    private static final String[][] SERVICES = {
            {"Android Apps", "Java + XML me poori app: UI, Firebase, payment, admin panel."},
            {"Websites", "HTML, CSS, TypeScript me fast, clean aur responsive websites."},
            {"Backend & APIs", "Secure backend, database, login, wallet aur notifications."},
            {"Blender 3D Models", "Game, logo aur product ke liye 3D models aur renders."}};
    private static final int[] SERVICE_ICONS = {
            R.drawable.ic_dev_phone_app, R.drawable.ic_dev_globe,
            R.drawable.ic_dev_server, R.drawable.ic_dev_cube};
    private static final int[][] SERVICE_COLORS = {
            {0xFF4ADE80, 0xFF16A34A},   // apps: green
            {0xFF38BDF8, 0xFF2563EB},   // websites: blue
            {0xFFA78BFA, 0xFF7C3AED},   // backend: violet
            {0xFFFBBF24, 0xFFEA580C}};  // 3D: orange

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.WHITE);
        getWindow().setNavigationBarColor(Color.WHITE);

        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setBackgroundColor(0xFFEEF1FF);

        // ---------- hero ----------
        LinearLayout hero = new LinearLayout(this);
        hero.setOrientation(LinearLayout.VERTICAL);
        hero.setGravity(Gravity.CENTER_HORIZONTAL);
        hero.setPadding(dp(16), dp(12), dp(16), dp(26));
        GradientDrawable heroBg = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{0xFF1E3A8A, 0xFF4338CA, 0xFF7C3AED});
        heroBg.setCornerRadii(new float[]{0, 0, 0, 0, dp(32), dp(32), dp(32), dp(32)});
        hero.setBackground(heroBg);

        TextView back = text("‹", 28, Color.WHITE, true);
        back.setGravity(Gravity.CENTER);
        back.setContentDescription("Back");
        GradientDrawable backBg = new GradientDrawable();
        backBg.setShape(GradientDrawable.OVAL);
        backBg.setColor(0x33FFFFFF);
        back.setBackground(backBg);
        back.setOnClickListener(v -> finish());
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(dp(38), dp(38));
        bp.gravity = Gravity.START;
        hero.addView(back, bp);

        // logo with golden-pink outline
        int logoRes = getResources().getIdentifier("developer_logo", "drawable", getPackageName());
        View logo;
        if (logoRes != 0) {
            ImageView iv = new ImageView(this);
            iv.setImageResource(logoRes);
            iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
            iv.setClipToOutline(true);
            GradientDrawable clip = new GradientDrawable();
            clip.setShape(GradientDrawable.OVAL);
            iv.setBackground(clip);
            iv.setPadding(0, 0, 0, 0);
            logo = iv;
        } else {
            TextView mono = text("</>", 30, Color.WHITE, true);
            mono.setGravity(Gravity.CENTER);
            mono.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
            GradientDrawable m = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{BLUE, CYAN});
            m.setShape(GradientDrawable.OVAL);
            mono.setBackground(m);
            logo = mono;
        }
        // single golden-pink gradient outline (gradient ring = gradient oval + padding around the logo)
        FrameHolder ring = new FrameHolder(this);
        GradientDrawable outer = new GradientDrawable();
        outer.setShape(GradientDrawable.OVAL);
        outer.setGradientType(GradientDrawable.SWEEP_GRADIENT);
        outer.setGradientCenter(0.5f, 0.5f);
        outer.setColors(new int[]{0xFFFFC94D, 0xFFFF6FAE, 0xFFFFD98A, 0xFFFF4F9A, 0xFFFFC94D});
        ring.setBackground(outer);
        ring.setElevation(dp(6));
        ring.setPadding(dp(4), dp(4), dp(4), dp(4));
        ring.addView(logo, new LinearLayout.LayoutParams(dp(108), dp(108)));
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(dp(116), dp(116));
        rp.topMargin = dp(2);
        hero.addView(ring, rp);

        TextView name = text(DEV_NAME, 21, Color.WHITE, true);
        name.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams np = new LinearLayout.LayoutParams(-2, -2);
        np.topMargin = dp(12);
        hero.addView(name, np);
        TextView tag = text(DEV_TAGLINE, 12.5f, 0xFFD6DEFF, false);
        tag.setGravity(Gravity.CENTER);
        hero.addView(tag, new LinearLayout.LayoutParams(-2, -2));
        lightSweep(tag, 0xFFD6DEFF, 0xFFFFFFFF, 4200, 0);

        // cheap price pill: vector tag icon + single-line text (no emoji, never wraps)
        LinearLayout price = new LinearLayout(this);
        price.setOrientation(LinearLayout.HORIZONTAL);
        price.setGravity(Gravity.CENTER);
        price.setPadding(dp(16), dp(8), dp(18), dp(8));
        GradientDrawable pill = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                new int[]{0xFFFFE27A, 0xFFFFB347, 0xFFFF8FA3});
        pill.setCornerRadius(dp(30));
        pill.setStroke(dp(1.5f), 0xCCFFFFFF);
        price.setBackground(pill);
        price.setElevation(dp(4));
        ImageView priceIcon = new ImageView(this);
        priceIcon.setImageResource(R.drawable.ic_dev_tag);
        price.addView(priceIcon, new LinearLayout.LayoutParams(dp(16), dp(16)));
        TextView priceText = text("CHEAP PRICE  •  BEST QUALITY", 11, INK, true);
        priceText.setSingleLine(true);
        priceText.setLetterSpacing(0.04f);
        LinearLayout.LayoutParams ptp = new LinearLayout.LayoutParams(-2, -2);
        ptp.leftMargin = dp(8);
        price.addView(priceText, ptp);
        lightSweep(priceText, INK, 0xFFFFFFFF, 3800, 600);
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(-2, -2);
        pp.topMargin = dp(14);
        hero.addView(price, pp);

        // ---------- body ----------
        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(dp(16), dp(16), dp(16), dp(28));

        // contact card
        LinearLayout contact = card(BLUE);
        contact.addView(sectionTitle("CONTACT", BLUE));
        LinearLayout phoneRow = infoRow(R.drawable.ic_dev_call, 0xFF34D399, 0xFF059669, "Contact number", DEV_PHONE);
        contact.addView(phoneRow);
        final boolean hasPhone = DEV_PHONE.replaceAll("[^0-9]", "").length() >= 7;
        phoneRow.setOnClickListener(v -> {
            if (!hasPhone) { toast("Number abhi add nahi hua."); return; }
            try {
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(DEV_WHATSAPP)));
            } catch (RuntimeException e) { toast("WhatsApp link nahi khul paya."); }
        });
        LinearLayout tgRow = infoRow(R.drawable.ic_dev_telegram, 0xFF38BDF8, 0xFF229ED9, "Telegram", "Join / message on Telegram");
        tgRow.setOnClickListener(v -> openTelegram());
        contact.addView(tgRow);
        body.addView(contact);

        // about card
        LinearLayout about = card(VIOLET);
        about.addView(sectionTitle("ABOUT ME", VIOLET));
        TextView bio = text("I build apps and websites \u2014 everything from frontend to backend: "
                + "Java, XML, TypeScript, HTML, CSS and Blender 3D models. "
                + "All work is done on a small budget, with clean design and fast delivery. "
                + "If you need an app, website or 3D model, message me directly on Telegram or WhatsApp.",
                13.5f, MUTED, false);
        bio.setLineSpacing(dp(3), 1f);
        about.addView(bio);
        body.addView(about);

        // skills
        LinearLayout skills = card(0xFF0EA5A4);
        skills.addView(sectionTitle("SKILLS", 0xFF0EA5A4));
        LinearLayout rowL = null;
        int inRow = 0;
        for (int i = 0; i < SKILLS.length; i++) {
            if (rowL == null || inRow == 3) {
                rowL = new LinearLayout(this);
                rowL.setOrientation(LinearLayout.HORIZONTAL);
                skills.addView(rowL, new LinearLayout.LayoutParams(-1, -2));
                inRow = 0;
            }
            rowL.addView(chip(SKILLS[i], i));
            inRow++;
        }
        // last row: invisible fillers so a lone chip keeps the same width as the others
        while (rowL != null && inRow < 3) {
            View filler = new View(this);
            LinearLayout.LayoutParams fp = new LinearLayout.LayoutParams(0, 1, 1f);
            fp.setMargins(dp(3), dp(3), dp(3), dp(3));
            rowL.addView(filler, fp);
            inRow++;
        }
        body.addView(skills);

        // services
        LinearLayout services = card(0xFFEA580C);
        services.addView(sectionTitle("WHAT I BUILD", 0xFFEA580C));
        for (int i = 0; i < SERVICES.length; i++) {
            services.addView(serviceRow(SERVICE_ICONS[i], SERVICE_COLORS[i][0], SERVICE_COLORS[i][1],
                    SERVICES[i][0], SERVICES[i][1]));
        }
        body.addView(services);

        // CTA
        LinearLayout cta = new LinearLayout(this);
        cta.setOrientation(LinearLayout.HORIZONTAL);
        cta.setGravity(Gravity.CENTER);
        ImageView ctaIcon = new ImageView(this);
        ctaIcon.setImageResource(R.drawable.ic_dev_telegram);
        cta.addView(ctaIcon, new LinearLayout.LayoutParams(dp(22), dp(22)));
        TextView ctaText = text("MESSAGE ON TELEGRAM", 14, Color.WHITE, true);
        ctaText.setLetterSpacing(0.04f);
        LinearLayout.LayoutParams ctp = new LinearLayout.LayoutParams(-2, -2);
        ctp.leftMargin = dp(10);
        cta.addView(ctaText, ctp);
        GradientDrawable ctaBg = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                new int[]{0xFF229ED9, BLUE, VIOLET});
        ctaBg.setCornerRadius(dp(16));
        cta.setBackground(ctaBg);
        cta.setElevation(dp(4));
        cta.setOnClickListener(v -> openTelegram());
        AlphaAnimation pulse = new AlphaAnimation(1f, 0.82f);
        pulse.setDuration(900);
        pulse.setRepeatMode(Animation.REVERSE);
        pulse.setRepeatCount(Animation.INFINITE);
        cta.startAnimation(pulse);
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1, dp(54));
        cp.topMargin = dp(6);
        body.addView(cta, cp);

        page.addView(hero, new LinearLayout.LayoutParams(-1, -2));
        page.addView(body, new LinearLayout.LayoutParams(-1, -2));
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setOverScrollMode(View.OVER_SCROLL_NEVER);
        scroll.addView(page);
        setContentView(scroll);
    }

    // ---------------- helpers ----------------

    private void openTelegram() {
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(DEV_TELEGRAM)));
        } catch (RuntimeException e) {
            toast("Telegram link nahi khul paya.");
        }
    }

    /** Card with a soft accent tint (white -> accent 12%) and an accent-coloured border. */
    private LinearLayout card(int accent) {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(16), dp(14), dp(16), dp(14));
        int rgb = accent & 0x00FFFFFF;
        GradientDrawable bg = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{0xFFFFFFFF, 0xFFFFFFFF, rgb | 0x1F000000});
        bg.setCornerRadius(dp(20));
        bg.setStroke(dp(1.5f), rgb | 0x59000000);
        c.setBackground(bg);
        c.setElevation(dp(3));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.bottomMargin = dp(14);
        c.setLayoutParams(p);
        return c;
    }

    private TextView sectionTitle(String s, int color) {
        TextView t = text(s, 11, color, true);
        t.setLetterSpacing(0.14f);
        t.setPadding(0, 0, 0, dp(8));
        return t;
    }

    private LinearLayout infoRow(int iconRes, int gradStart, int gradEnd, String label, String value) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(0, dp(8), 0, dp(8));
        ImageView icon = new ImageView(this);
        icon.setImageResource(iconRes);
        icon.setPadding(dp(11), dp(11), dp(11), dp(11));
        GradientDrawable ib = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{gradStart, gradEnd});
        ib.setShape(GradientDrawable.OVAL);
        icon.setBackground(ib);
        icon.setElevation(dp(2));
        row.addView(icon, new LinearLayout.LayoutParams(dp(44), dp(44)));
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.addView(text(label, 11, MUTED, false));
        col.addView(text(value, 14.5f, INK, true));
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(0, -2, 1f);
        cp.leftMargin = dp(12);
        row.addView(col, cp);
        row.addView(text("›", 22, MUTED, false));
        return row;
    }

    private TextView chip(String label, int index) {
        int[] colors = {BLUE, VIOLET, 0xFF0EA5A4, 0xFFE11D48, 0xFFD97706};
        int c = colors[index % colors.length];
        TextView t = text(label, 12, c, true);
        t.setGravity(Gravity.CENTER);
        t.setSingleLine(true);
        t.setPadding(dp(6), dp(8), dp(6), dp(8));
        // long names (e.g. "WhatsApp Bot") shrink instead of getting cut
        androidx.core.widget.TextViewCompat.setAutoSizeTextTypeUniformWithConfiguration(
                t, 9, 12, 1, android.util.TypedValue.COMPLEX_UNIT_SP);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor((c & 0x00FFFFFF) | 0x14000000);
        bg.setStroke(dp(1), (c & 0x00FFFFFF) | 0x66000000);
        bg.setCornerRadius(dp(20));
        t.setBackground(bg);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, -2, 1f);
        p.setMargins(dp(3), dp(3), dp(3), dp(3));
        t.setLayoutParams(p);
        return t;
    }

    private LinearLayout serviceRow(int iconRes, int gradStart, int gradEnd, String title, String desc) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(0, dp(7), 0, dp(7));
        ImageView icon = new ImageView(this);
        icon.setImageResource(iconRes);
        icon.setPadding(dp(11), dp(11), dp(11), dp(11));
        GradientDrawable ib = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{gradStart, gradEnd});
        ib.setCornerRadius(dp(14));
        icon.setBackground(ib);
        icon.setElevation(dp(2));
        row.addView(icon, new LinearLayout.LayoutParams(dp(46), dp(46)));
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.addView(text(title, 14, INK, true));
        TextView d = text(desc, 12, MUTED, false);
        col.addView(d);
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(0, -2, 1f);
        cp.leftMargin = dp(12);
        row.addView(col, cp);
        return row;
    }

    private TextView text(String s, float size, int color, boolean bold) {
        TextView v = new TextView(this);
        v.setText(s);
        v.setTextSize(size);
        v.setTextColor(color);
        v.setTypeface(null, bold ? Typeface.BOLD : Typeface.NORMAL);
        return v;
    }

    // ---------- light sweep effect on text ----------
    private final java.util.List<ValueAnimator> sweepAnims = new java.util.ArrayList<>();

    /** Shiny light band repeatedly glides across the text (left to right). */
    private void lightSweep(final TextView tv, final int base, final int highlight, long durationMs, long startDelayMs) {
        tv.post(() -> {
            final float w = Math.max(1f, tv.getPaint().measureText(tv.getText().toString()));
            final float band = w * 0.55f;
            final LinearGradient lg = new LinearGradient(0, 0, band, 0,
                    new int[]{base, highlight, base}, new float[]{0f, 0.5f, 1f}, Shader.TileMode.CLAMP);
            final Matrix m = new Matrix();
            tv.getPaint().setShader(lg);
            ValueAnimator va = ValueAnimator.ofFloat(0f, 1f);
            va.setDuration(durationMs);
            va.setStartDelay(startDelayMs);
            va.setRepeatCount(ValueAnimator.INFINITE);
            va.setInterpolator(new android.view.animation.LinearInterpolator());
            va.addUpdateListener(a -> {
                float t = (float) a.getAnimatedValue();
                // travel from off-left to off-right; last part is a short rest before next sweep
                float p = Math.min(1f, t / 0.7f);
                float x = -band + p * (w + band);
                m.setTranslate(x, 0);
                lg.setLocalMatrix(m);
                tv.invalidate();
            });
            va.start();
            sweepAnims.add(va);
        });
    }

    @Override
    protected void onDestroy() {
        for (ValueAnimator a : sweepAnims) a.cancel();
        sweepAnims.clear();
        super.onDestroy();
    }

    private int dp(float value) { return Math.round(value * getResources().getDisplayMetrics().density); }

    private void toast(String message) { FancyText.toast(this, message, Toast.LENGTH_SHORT).show(); }

    /** Tiny vertical holder so the logo sits centred inside its ring. */
    private static final class FrameHolder extends LinearLayout {
        FrameHolder(android.content.Context c) {
            super(c);
            setOrientation(VERTICAL);
            setGravity(Gravity.CENTER);
        }
    }
}
