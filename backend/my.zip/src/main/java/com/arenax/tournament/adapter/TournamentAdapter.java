package com.arenax.tournament.adapter;

import com.arenax.tournament.util.ImageLoader;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.arenax.tournament.R;
import com.arenax.tournament.data.FirebaseRepository;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.ValueEventListener;
import com.arenax.tournament.model.Tournament;
import com.arenax.tournament.util.MatchNumber;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.google.android.material.button.MaterialButton;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Locale;

public class TournamentAdapter extends RecyclerView.Adapter<TournamentAdapter.Holder> {
    public interface OnTournamentClick { void onClick(Tournament tournament); }
    private final List<Tournament> items;
    private final OnTournamentClick listener;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private boolean deleteEnabled = false;
    private OnTournamentClick deleteListener;
    // Admin builds this adapter for match-MAKING (create/manage matches), never for a
    // player-style "join" action — so the card's primary button label is overridable.
    private String joinButtonText = null;
    // The red "LIVE NOW" strip on running matches. Screens that already group matches
    // by Ongoing/Upcoming/Resulted (category screen) switch it off.
    private boolean showLiveStrip = true;
    // Player cards: tournaments this signed-in user has already joined (live, per-card listener on
    // tournaments/{id}/participants/{uid}). Those cards say "JOINED" instead of "JOIN NOW".
    private final Set<String> joinedIds = new HashSet<>();
    private final Map<String, ValueEventListener> joinWatchers = new HashMap<>();
    private final Map<String, com.google.firebase.database.DatabaseReference> joinRefs = new HashMap<>();

    public void setShowLiveStrip(boolean show) {
        this.showLiveStrip = show;
    }

    public TournamentAdapter(List<Tournament> items, OnTournamentClick listener) {
        this.items = items;
        this.listener = listener;
    }

    /** Turns on the per-card DELETE button (used in admin match-management screens only). */
    public void setOnDeleteClick(OnTournamentClick deleteListener) {
        this.deleteEnabled = true;
        this.deleteListener = deleteListener;
    }

    /**
     * Overrides the primary card button's label. Admin screens use this to show
     * "MANAGE MATCH" instead of the player-facing "JOIN" text, since tapping the card in
     * admin opens match-making / control center, not a registration flow.
     */
    public void setJoinButtonText(String text) {
        this.joinButtonText = text;
    }

    /** Starts (once) a live watch on whether the current user is a registered participant of this match. */
    private void watchJoined(String tournamentId) {
        if (joinButtonText != null || tournamentId == null || tournamentId.isEmpty()) return;
        if (joinWatchers.containsKey(tournamentId)) return;
        if (FirebaseRepository.currentUser() == null) return;
        final String uid = FirebaseRepository.currentUser().getUid();
        if (uid == null) return;
        com.google.firebase.database.DatabaseReference ref = FirebaseRepository.tournamentParticipants(tournamentId).child(uid);
        ValueEventListener l = new ValueEventListener() {
            @Override public void onDataChange(@NonNull DataSnapshot snap) {
                // A RESERVING-only record is an unfinished join, not a real registration.
                boolean joined = snap.exists() && !"RESERVING".equals(snap.child("status").getValue(String.class));
                boolean was = joinedIds.contains(tournamentId);
                if (joined == was) return;
                if (joined) joinedIds.add(tournamentId); else joinedIds.remove(tournamentId);
                for (int i = 0; i < items.size(); i++) {
                    Tournament it = items.get(i);
                    if (it != null && tournamentId.equals(it.getId())) notifyItemChanged(i);
                }
            }
            @Override public void onCancelled(@NonNull DatabaseError error) { }
        };
        joinWatchers.put(tournamentId, l);
        joinRefs.put(tournamentId, ref);
        ref.addValueEventListener(l);
    }

    private void stopJoinWatchers() {
        for (Map.Entry<String, ValueEventListener> e : joinWatchers.entrySet()) {
            com.google.firebase.database.DatabaseReference ref = joinRefs.get(e.getKey());
            if (ref != null) ref.removeEventListener(e.getValue());
        }
        joinWatchers.clear();
        joinRefs.clear();
        joinedIds.clear();
    }

    @NonNull
    @Override
    public Holder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new Holder(LayoutInflater.from(parent.getContext()).inflate(joinButtonText != null ? R.layout.item_admin_tournament_compact : R.layout.item_tournament, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull Holder h, int position) {
        Tournament t = items.get(position);
        watchJoined(t.getId());
        boolean alreadyJoined = joinButtonText == null && t.getId() != null && joinedIds.contains(t.getId());
        // The Firebase key is stable, so this public match number remains the same
        // after refresh, sorting, and reopening the match.
        String title = t.getTitle() == null ? "Match" : t.getTitle().trim();
        // Any "#123456" typed into the stored title is dropped: the number always comes from the match key,
        // so every daily copy shows its own, new number.
        title = MatchNumber.stripCode(title) + "  " + MatchNumber.label(t.getId());
        h.title.setText(title);
        // Black placeholder while loading / on error / no banner; disk+memory cached via AppGlideConfig.
        ImageLoader.load(h.image, t.getBannerUrl());
        h.mode.setText(t.getMode());
        h.timeLine.setText("Time : " + t.getDate() + " at " + t.getTime());
        h.prize.setText("Coins  " + t.getPrizePoolCoins());
        h.perKill.setText("Coins  " + t.getPerKillCoins());
        h.entry.setText("Coins  " + t.getEntryFeeCoins());
        h.type.setText(t.getGameType());
        h.entryPerPlayer.setText(String.valueOf(t.getTeamSize()));
        h.map.setText(t.getMap());
        h.slots.setText(t.getJoinedSlots() + "/" + t.getTotalSlots());
        int total = Math.max(1, t.getTotalSlots());
        int joined = Math.max(0, Math.min(t.getJoinedSlots(), total));
        int percent = (int) ((joined * 100f) / total);
        h.progress.setMax(100);
        h.progress.setProgress(percent);
        int left = Math.max(0, t.getTotalSlots() - t.getJoinedSlots());
        boolean full = left <= 0;
        if (h.fullBadge != null) h.fullBadge.setVisibility(full ? View.VISIBLE : View.GONE);
        boolean startedNow = t.hasStarted();
        h.spotsLeft.setText(startedNow ? "Joining Closed" : (full ? "Match Full" : ("Only " + left + " Spot Left")));
        h.spotsLeft.setTextColor(ContextCompat.getColor(h.spotsLeft.getContext(),
                left > 0 ? R.color.success : R.color.gold));
        String effectiveStatus = t.getEffectiveStatus();
        h.status.setText(statusLabel(effectiveStatus));
        h.status.setTextColor(Tournament.ONGOING.equals(effectiveStatus)
                ? ContextCompat.getColor(h.status.getContext(), R.color.success)
                : t.getAccentColor());
        // LIVE strip only for an actually-running match, exactly like the reference card.
        boolean live = showLiveStrip && Tournament.ONGOING.equals(effectiveStatus);
        h.liveStrip.setVisibility(live ? View.VISIBLE : View.GONE);
        if (live) h.liveStrip.setText("● LIVE NOW");
        if (joinButtonText != null) {
            // Admin card — always "MANAGE MATCH" regardless of status.
            h.join.setText(joinButtonText);
        } else if (Tournament.COMPLETED.equals(effectiveStatus)) {
            h.join.setText("VIEW RESULT");
        } else if (alreadyJoined && !Tournament.CANCELLED.equals(effectiveStatus)) {
            // This player already has a registered entry in this match (tap opens Match Details).
            h.join.setText("JOINED");
        } else if (Tournament.ONGOING.equals(effectiveStatus) || Tournament.RESULT_PROCESSING.equals(effectiveStatus)) {
            // Start time passed: joining is closed even if slots are still empty (e.g. 40/48).
            h.join.setText("MATCH STARTED");
        } else if (full && !Tournament.CANCELLED.equals(effectiveStatus)) {
            // Every slot taken: same card, but the button reads JOINING FULL (tap still opens match info).
            h.join.setText("JOINING FULL");
        } else {
            h.join.setText("JOIN NOW");
        }
        h.join.setOnClickListener(v -> listener.onClick(t));
        h.itemView.setOnClickListener(v -> listener.onClick(t));
        if (deleteEnabled) {
            h.delete.setVisibility(View.VISIBLE);
            h.delete.setOnClickListener(v -> {
                if (deleteListener != null) deleteListener.onClick(t);
            });
        } else {
            h.delete.setVisibility(View.GONE);
        }
        bindCountdown(h, t);
    }

    /** Friendly label for the raw status enum — this is what the player actually sees on the card. */
    private String statusLabel(String effectiveStatus) {
        if (Tournament.DRAFT.equals(effectiveStatus)) return "DRAFT";
        if (Tournament.ONGOING.equals(effectiveStatus)) return "● MATCH IS RUNNING";
        if (Tournament.RESULT_PROCESSING.equals(effectiveStatus)) return "RESULT BEING VERIFIED";
        if (Tournament.COMPLETED.equals(effectiveStatus)) return "MATCH COMPLETED";
        if (Tournament.CANCELLED.equals(effectiveStatus)) return "CANCELLED";
        return "UPCOMING";
    }

    private void bindCountdown(@NonNull Holder h, Tournament t) {
        // Cancel any countdown left over from a recycled view before starting a fresh one.
        if (h.tickRunnable != null) handler.removeCallbacks(h.tickRunnable);
        long startAt = t.getEffectiveStartAt();
        // Once the match has moved past "Upcoming" (running or resulted) the countdown is stale
        // and would just contradict the status label above it — hide it instead.
        if (startAt <= 0L || !Tournament.UPCOMING.equals(t.getEffectiveStatus())) {
            h.countdown.setVisibility(View.GONE);
            return;
        }
        h.countdown.setVisibility(View.VISIBLE);
        h.tickRunnable = new Runnable() {
            @Override
            public void run() {
                long remainingMs = startAt - System.currentTimeMillis();
                if (remainingMs <= 0L) {
                    h.countdown.setText("ROOM IS READY  •  WAITING FOR ROOM ID & PASSWORD");
                    h.countdown.setBackgroundResource(R.drawable.bg_status_dark);
                    h.countdown.setTextColor(ContextCompat.getColor(h.countdown.getContext(), R.color.success));
                    return; // Reached zero: stop ticking, no more callbacks needed.
                }
                long totalSeconds = remainingMs / 1000L;
                long hours = totalSeconds / 3600L;
                long minutes = (totalSeconds % 3600L) / 60L;
                long seconds = totalSeconds % 60L;
                String formatted = hours > 0
                        ? String.format(Locale.ROOT, "STARTS IN  %02d:%02d:%02d", hours, minutes, seconds)
                        : String.format(Locale.ROOT, "STARTS IN  %02d:%02d", minutes, seconds);
                h.countdown.setText(formatted);
                h.countdown.setBackgroundResource(R.drawable.bg_status_gold);
                h.countdown.setTextColor(ContextCompat.getColor(h.countdown.getContext(), R.color.ink));
                handler.postDelayed(this, 1000L);
            }
        };
        h.tickRunnable.run();
    }

    @Override
    public void onViewRecycled(@NonNull Holder h) {
        super.onViewRecycled(h);
        if (h.tickRunnable != null) handler.removeCallbacks(h.tickRunnable);
    }

    @Override
    public void onDetachedFromRecyclerView(@NonNull RecyclerView recyclerView) {
        super.onDetachedFromRecyclerView(recyclerView);
        handler.removeCallbacksAndMessages(null);
        stopJoinWatchers();
    }

    @Override
    public int getItemCount() { return items.size(); }

    static class Holder extends RecyclerView.ViewHolder {
        TextView title, mode, timeLine, prize, perKill, entry, type, entryPerPlayer, map, slots, status, countdown, spotsLeft, liveStrip;
        android.widget.ImageView image;
        android.widget.ProgressBar progress;
        TextView fullBadge;
        MaterialButton join, delete;
        Runnable tickRunnable;
        Holder(@NonNull View v) {
            super(v);
            title = v.findViewById(R.id.tournament_title);
            image = v.findViewById(R.id.tournament_image);
            mode = v.findViewById(R.id.tournament_mode);
            timeLine = v.findViewById(R.id.tournament_time_line);
            prize = v.findViewById(R.id.tournament_prize);
            perKill = v.findViewById(R.id.tournament_perkill);
            entry = v.findViewById(R.id.tournament_entry);
            type = v.findViewById(R.id.tournament_type);
            entryPerPlayer = v.findViewById(R.id.tournament_entry_per_player);
            map = v.findViewById(R.id.tournament_map);
            slots = v.findViewById(R.id.tournament_slots);
            status = v.findViewById(R.id.tournament_status);
            countdown = v.findViewById(R.id.tournament_countdown);
            join = v.findViewById(R.id.button_card_join);
            delete = v.findViewById(R.id.button_card_delete);
            progress = v.findViewById(R.id.tournament_progress);
            fullBadge = v.findViewById(R.id.tournament_full_badge);
            spotsLeft = v.findViewById(R.id.tournament_spots_left);
            liveStrip = v.findViewById(R.id.tournament_live_strip);
        }
    }
}
