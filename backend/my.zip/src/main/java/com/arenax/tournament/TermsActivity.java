package com.arenax.tournament;

import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import com.arenax.tournament.data.FirebaseRepository;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.ValueEventListener;
import androidx.core.widget.NestedScrollView;

/** Terms & Conditions — in-app, read-only rulebook for STARX24 tournaments.
 *  White/gold theme, one colour-coded rule card per condition, matching the
 *  FAQ and About Us screens. Fully self-contained (no extra layout/drawable
 *  resources), built the same programmatic way as FaqActivity. */
public class TermsActivity extends BaseActivity {

    private static final class Rule {
        final int icon; final String title, tag, body, bg, accent;
        Rule(int icon, String title, String tag, String body, String bg, String accent) {
            this.icon = icon; this.title = title; this.tag = tag; this.body = body;
            this.bg = bg; this.accent = accent;
        }
    }

    private static final Rule[] rules = new Rule[]{
            new Rule(R.drawable.ic_profile, "Eligibility (18+ Age Requirement)", "Rule #1",
                    "By registering on and using this platform, you confirm that you are at least 18 years of age. " +
                            "Participation in any match, contest, or paid activity is strictly restricted to users who meet " +
                            "this minimum age requirement. STARX24 reserves the right to suspend or terminate accounts " +
                            "found to be in violation of this condition without prior notice.",
                    "#E8EEF7", "#3B5BA0"),
            new Rule(R.drawable.ic_block, "No Cancellation After Entry", "Rule #2",
                    "Once you join a paid match, your entry is final. Entry fees are not refundable or transferable after " +
                            "joining, regardless of whether you are able to play the match to completion.",
                    "#FBE7E7", "#C0392B"),
            new Rule(R.drawable.ic_shield_check, "Fair Play & Anti-Cheat Policy", "Rule #3",
                    "Use of hacks, mods, emulators, teaming, or any third-party tool that grants an unfair advantage is " +
                            "strictly prohibited. Violations result in an immediate match disqualification, forfeiture of " +
                            "winnings, and may lead to a permanent account ban.",
                    "#ECE8FB", "#5B3FC4"),
            new Rule(R.drawable.ic_lock, "Room ID & Password Confidentiality", "Rule #4",
                    "Room ID and Password are released shortly before the scheduled match time and are strictly for " +
                            "registered participants only. Sharing these details outside your squad or on public platforms " +
                            "may result in disqualification from the match.",
                    "#FDF3D9", "#8D6B12"),
            new Rule(R.drawable.ic_wallet_outline, "Wallet, Deposits & Withdrawals", "Rule #5",
                    "All deposits and withdrawals are processed through the in-app wallet. Withdrawal requests are " +
                            "reviewed and settled within the timeline shown on the Wallet screen. STARX24 is not responsible " +
                            "for delays caused by incorrect payment details submitted by the user.",
                    "#E8F7F0", "#1E7F5C"),
            new Rule(R.drawable.ic_trophy, "Prize Distribution & Payout Timeline", "Rule #6",
                    "Prizes are credited to the winner's in-app wallet after results are verified against the submitted " +
                            "match screenshots and the official points table. Disputed results are held until the admin " +
                            "team completes a manual review.",
                    "#FDF3D9", "#8D6B12"),
            new Rule(R.drawable.ic_warning, "Account Suspension & Termination", "Rule #7",
                    "STARX24 reserves the right to suspend or permanently ban any account found violating these terms, " +
                            "engaging in fraudulent payment activity, or abusing the platform's reward system, without prior " +
                            "notice and without obligation to refund wallet balances gained through the violation.",
                    "#F0EFEC", "#1C1C1E"),
            new Rule(R.drawable.ic_terms, "Changes to These Terms", "Rule #8",
                    "These terms may be updated from time to time to reflect changes to tournaments, features, or " +
                            "policies. Continued use of STARX24 after an update means you accept the revised terms.",
                    "#E8EEF7", "#3B5BA0"),
    };

    /** Built-in text as {title, body} pairs, used by the admin editor as the starting point. */
    public static String[][] defaultContent() {
        String[][] out = new String[rules.length][2];
        for (int i = 0; i < rules.length; i++) { out[i][0] = rules[i].title; out[i][1] = rules[i].body; }
        return out;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildScreen();
    }

    private void buildScreen() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.parseColor("#F6F5F2"));

        NestedScrollView scroll = new NestedScrollView(this);
        scroll.setFillViewport(true);
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(18), dp(18), dp(18), dp(24));

        page.addView(buildHeader());

        LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams listParams = new LinearLayout.LayoutParams(-1, -2);
        listParams.topMargin = dp(18);
        list.setLayoutParams(listParams);
        for (Rule rule : rules) list.addView(buildRuleCard(rule));
        page.addView(list);
        loadAdminRules(list);

        page.addView(buildFooterNote());
        page.addView(buildContactButton());

        scroll.addView(page);
        root.addView(scroll);
        setContentView(root);
    }

    /** If the admin saved their own terms (appContent/terms/sections), show those instead. */
    private void loadAdminRules(LinearLayout list) {
        try {
            FirebaseRepository.appContent().child("terms").child("sections")
                    .addListenerForSingleValueEvent(new ValueEventListener() {
                @Override public void onDataChange(@NonNull DataSnapshot snapshot) {
                    if (isFinishing() || isDestroyed()) return;
                    java.util.List<Rule> custom = new java.util.ArrayList<>();
                    for (DataSnapshot c : snapshot.getChildren()) {
                        String title = c.child("title").getValue(String.class);
                        String body = c.child("body").getValue(String.class);
                        if (title == null) title = "";
                        if (body == null) body = "";
                        if (title.trim().isEmpty() && body.trim().isEmpty()) continue;
                        int i = custom.size();
                        Rule base = rules[i % rules.length];
                        custom.add(new Rule(base.icon, title, "Rule #" + (i + 1), body, base.bg, base.accent));
                    }
                    if (custom.isEmpty()) return;
                    list.removeAllViews();
                    for (Rule r : custom) list.addView(buildRuleCard(r));
                }
                @Override public void onCancelled(@NonNull DatabaseError error) { /* keep defaults */ }
            });
        } catch (RuntimeException ignored) { /* keep defaults */ }
    }

    private View buildHeader() {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.TOP);

        LinearLayout left = new LinearLayout(this);
        left.setOrientation(LinearLayout.VERTICAL);
        left.setLayoutParams(new LinearLayout.LayoutParams(0, -2, 1));

        TextView back = label("\u2039", 30, Color.parseColor("#1C1C1E"), true);
        back.setGravity(Gravity.CENTER);
        GradientDrawable backBg = new GradientDrawable();
        backBg.setShape(GradientDrawable.OVAL);
        backBg.setColor(Color.WHITE);
        back.setBackground(backBg);
        back.setOnClickListener(v -> finish());
        LinearLayout.LayoutParams backParams = new LinearLayout.LayoutParams(dp(40), dp(40));
        backParams.bottomMargin = dp(14);
        back.setLayoutParams(backParams);
        left.addView(back);

        TextView title = label("Terms & Conditions", 24, Color.parseColor("#1C1C1E"), true);
        left.addView(title);

        TextView subtitle = label("Please read these terms carefully before participating.",
                13, Color.parseColor("#68686D"), false);
        LinearLayout.LayoutParams subParams = new LinearLayout.LayoutParams(-1, -2);
        subParams.topMargin = dp(8);
        subtitle.setLayoutParams(subParams);
        left.addView(subtitle);

        row.addView(left);
        row.addView(buildHeaderDeco());
        return row;
    }

    /** Document + shield decorative cluster, built from shapes/vector icons only. */
    private View buildHeaderDeco() {
        FrameLayout deco = new FrameLayout(this);
        deco.setLayoutParams(new LinearLayout.LayoutParams(dp(84), dp(84)));

        GradientDrawable haze = new GradientDrawable();
        haze.setShape(GradientDrawable.OVAL);
        haze.setColor(Color.parseColor("#222563EB"));
        View hazeView = new View(this);
        hazeView.setBackground(haze);
        FrameLayout.LayoutParams hazeParams = new FrameLayout.LayoutParams(dp(76), dp(76));
        hazeParams.gravity = Gravity.BOTTOM | Gravity.END;
        deco.addView(hazeView, hazeParams);

        GradientDrawable docBg = new GradientDrawable();
        docBg.setColor(Color.WHITE);
        docBg.setCornerRadius(dp(10));
        docBg.setStroke(dp(1), Color.parseColor("#E5E3DE"));
        android.widget.ImageView doc = new android.widget.ImageView(this);
        doc.setImageResource(R.drawable.ic_terms);
        doc.setColorFilter(Color.parseColor("#1C1C1E"));
        doc.setPadding(dp(11), dp(11), dp(11), dp(11));
        doc.setBackground(docBg);
        FrameLayout.LayoutParams docParams = new FrameLayout.LayoutParams(dp(48), dp(48));
        docParams.gravity = Gravity.TOP | Gravity.START;
        deco.addView(doc, docParams);

        GradientDrawable shieldBg = new GradientDrawable();
        shieldBg.setShape(GradientDrawable.OVAL);
        shieldBg.setColor(Color.parseColor("#3B5BA0"));
        android.widget.ImageView shield = new android.widget.ImageView(this);
        shield.setImageResource(R.drawable.am_ic_check);
        shield.setColorFilter(Color.WHITE);
        shield.setPadding(dp(7), dp(7), dp(7), dp(7));
        shield.setBackground(shieldBg);
        FrameLayout.LayoutParams shieldParams = new FrameLayout.LayoutParams(dp(30), dp(30));
        shieldParams.gravity = Gravity.BOTTOM | Gravity.END;
        deco.addView(shield, shieldParams);

        return deco;
    }

    private View buildRuleCard(Rule rule) {
        int bgColor = Color.parseColor(rule.bg);
        int accentColor = Color.parseColor(rule.accent);

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable cardBg = new GradientDrawable();
        cardBg.setColor(Color.WHITE);
        cardBg.setCornerRadius(dp(20));
        cardBg.setStroke(dp(1), Color.parseColor("#E5E3DE"));
        card.setBackground(cardBg);
        card.setPadding(dp(16), dp(16), dp(16), dp(16));
        LinearLayout.LayoutParams cardParams = new LinearLayout.LayoutParams(-1, -2);
        cardParams.bottomMargin = dp(14);
        card.setLayoutParams(cardParams);

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.TOP);

        android.widget.ImageView icon = new android.widget.ImageView(this);
        icon.setImageResource(rule.icon);
        icon.setColorFilter(accentColor);
        icon.setPadding(dp(15), dp(15), dp(15), dp(15));
        GradientDrawable iconBg = new GradientDrawable();
        iconBg.setCornerRadius(dp(16));
        iconBg.setColor(bgColor);
        icon.setBackground(iconBg);
        top.addView(icon, new LinearLayout.LayoutParams(dp(56), dp(56)));

        LinearLayout mid = new LinearLayout(this);
        mid.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams midParams = new LinearLayout.LayoutParams(0, -2, 1);
        midParams.leftMargin = dp(14);
        midParams.rightMargin = dp(10);
        mid.setLayoutParams(midParams);

        TextView title = label(rule.title, 17, Color.parseColor("#1C1C1E"), true);
        title.setLineSpacing(dp(2), 1f);
        mid.addView(title);

        TextView tag = label(rule.tag, 11.5f, accentColor, true);
        tag.setPadding(dp(11), dp(5), dp(11), dp(5));
        GradientDrawable tagBg = new GradientDrawable();
        tagBg.setColor(bgColor);
        tagBg.setCornerRadius(dp(100));
        tag.setBackground(tagBg);
        LinearLayout.LayoutParams tagParams = new LinearLayout.LayoutParams(-2, -2);
        tagParams.topMargin = dp(9);
        tag.setLayoutParams(tagParams);
        mid.addView(tag);

        top.addView(mid);

        android.widget.ImageView badge = new android.widget.ImageView(this);
        badge.setImageResource(rule.icon);
        badge.setColorFilter(accentColor);
        badge.setPadding(dp(14), dp(14), dp(14), dp(14));
        GradientDrawable badgeBg = new GradientDrawable();
        badgeBg.setShape(GradientDrawable.OVAL);
        badgeBg.setColor(bgColor);
        badge.setBackground(badgeBg);
        LinearLayout.LayoutParams badgeParams = new LinearLayout.LayoutParams(dp(54), dp(54));
        badge.setLayoutParams(badgeParams);
        top.addView(badge);

        card.addView(top);

        TextView body = label(rule.body, 13.5f, Color.parseColor("#68686D"), false);
        body.setLineSpacing(dp(4), 1f);
        body.setPadding(dp(16), dp(14), dp(16), dp(14));
        GradientDrawable bodyBg = new GradientDrawable();
        bodyBg.setColor(bgColor);
        bodyBg.setCornerRadius(dp(14));
        body.setBackground(bodyBg);
        LinearLayout.LayoutParams bodyParams = new LinearLayout.LayoutParams(-1, -2);
        bodyParams.topMargin = dp(14);
        body.setLayoutParams(bodyParams);
        card.addView(body);

        return card;
    }

    private View buildFooterNote() {
        TextView note = label("By continuing to use STARX24, you agree to all rules listed above. " +
                        "These terms may change from time to time — check back here periodically.",
                12, Color.parseColor("#9A9A9F"), false);
        note.setGravity(Gravity.CENTER);
        note.setLineSpacing(dp(3), 1f);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, -2);
        params.topMargin = dp(6);
        params.leftMargin = dp(8);
        params.rightMargin = dp(8);
        note.setLayoutParams(params);
        return note;
    }

    private View buildContactButton() {
        TextView contact = label("QUESTIONS ABOUT THESE TERMS? CONTACT SUPPORT", 12, Color.parseColor("#1D4ED8"), true);
        contact.setGravity(Gravity.CENTER);
        contact.setAllCaps(true);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.WHITE);
        bg.setCornerRadius(dp(14));
        bg.setStroke(dp(1), Color.parseColor("#2563EB"));
        contact.setBackground(bg);
        contact.setClickable(true);
        contact.setFocusable(true);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, dp(52));
        params.topMargin = dp(18);
        contact.setLayoutParams(params);
        contact.setOnClickListener(v -> SupportLinks.openTelegramSupport(this));
        return contact;
    }

    private TextView label(String text, float size, int color, boolean bold) {
        TextView v = new TextView(this);
        v.setText(text);
        v.setTextSize(size);
        v.setTextColor(color);
        v.setTypeface(null, bold ? Typeface.BOLD : Typeface.NORMAL);
        return v;
    }

    private int dp(float value) { return Math.round(value * getResources().getDisplayMetrics().density); }
}
