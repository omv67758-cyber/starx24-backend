package com.arenax.tournament.util;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;

import com.arenax.tournament.data.FirebaseRepository;
import com.google.android.material.button.MaterialButton;
import com.google.firebase.database.DataSnapshot;

import java.util.Locale;

/**
 * Per-category "saved description / rules". The admin writes a description or rules once, taps SAVE
 * under the field, and every later Add Match in that category opens with the saved text already filled
 * in. It stays fully editable - change it and tap SAVE again to replace the saved version. Saving an
 * empty field removes the saved text (rules then fall back to the app default rules).
 * Stored at categoryPresets/{categoryId}/description and /rules.
 */
public final class CategoryPresetUi {
    private CategoryPresetUi() { }

    /**
     * Adds a status line + SAVE button right under each field and pre-fills the saved text.
     *
     * @param defaultRules text the rules field starts with when nothing is saved yet (null = empty field)
     */
    public static void attach(final Context ctx, final LinearLayout form, final EditText descField,
                              final EditText rulesField, final String categoryId, final String categoryTitle,
                              @Nullable final String defaultRules) {
        if (form == null || descField == null || rulesField == null) return;
        final String cat = categoryTitle == null || categoryTitle.trim().isEmpty() ? "this category" : categoryTitle.trim();
        final boolean hasCategory = categoryId != null && !categoryId.trim().isEmpty();

        final TextView descStatus = status(ctx);
        final TextView rulesStatus = status(ctx);
        final MaterialButton descSave = saveButton(ctx, "SAVE DESCRIPTION FOR " + cat.toUpperCase(Locale.ROOT));
        final MaterialButton rulesSave = saveButton(ctx, "SAVE RULES FOR " + cat.toUpperCase(Locale.ROOT));

        int at = form.indexOfChild(rulesField);
        if (at >= 0) { form.addView(rulesStatus, at + 1); form.addView(rulesSave, at + 2); }
        at = form.indexOfChild(descField);
        if (at >= 0) { form.addView(descStatus, at + 1); form.addView(descSave, at + 2); }

        if (!hasCategory) {
            descStatus.setText("Category select nahi hai - save option category ke andar se Add Match kholne par chalega.");
            rulesStatus.setText(descStatus.getText());
            descSave.setEnabled(false);
            rulesSave.setEnabled(false);
            return;
        }
        descStatus.setText("Saved description check ho raha hai...");
        rulesStatus.setText("Saved rules check ho rahe hain...");

        descSave.setOnClickListener(v -> save(ctx, categoryId, cat, "description", descField, descStatus, "Description"));
        rulesSave.setOnClickListener(v -> save(ctx, categoryId, cat, "rules", rulesField, rulesStatus, "Rules"));

        FirebaseRepository.categoryPresets().child(FirebaseRepository.categoryPresetKey(categoryId)).get()
                .addOnSuccessListener((DataSnapshot snap) -> {
                    String savedDesc = text(snap.child("description").getValue());
                    String savedRules = text(snap.child("rules").getValue());
                    // Only fill a field the admin has not touched yet (empty / still the app default).
                    if (!savedDesc.isEmpty() && descField.getText().toString().trim().isEmpty()) descField.setText(savedDesc);
                    String currentRules = rulesField.getText().toString().trim();
                    boolean untouched = currentRules.isEmpty() || (defaultRules != null && currentRules.equals(defaultRules.trim()));
                    if (!savedRules.isEmpty() && untouched) rulesField.setText(savedRules);
                    descStatus.setText(savedDesc.isEmpty()
                            ? "Is category ke liye koi saved description nahi. Likho aur SAVE dabao."
                            : "Saved description laga di gayi hai. Badalni ho to edit karke dobara SAVE karo.");
                    rulesStatus.setText(savedRules.isEmpty()
                            ? "Is category ke liye koi saved rules nahi (default rules lage hain). Badlo aur SAVE dabao."
                            : "Saved rules laga diye gaye hain. Badalne ho to edit karke dobara SAVE karo.");
                })
                .addOnFailureListener(error -> {
                    descStatus.setText("Saved description load nahi ho paayi: " + error.getMessage());
                    rulesStatus.setText("Saved rules load nahi ho paaye: " + error.getMessage());
                });
    }

    private static void save(Context ctx, String categoryId, String cat, String field, EditText input,
                             TextView status, String label) {
        final String value = input.getText() == null ? "" : input.getText().toString().trim();
        FirebaseRepository.saveCategoryPreset(categoryId, field, value)
                .addOnSuccessListener(done -> {
                    String msg = value.isEmpty()
                            ? label + " saved list se hata di gayi (" + cat + ")."
                            : label + " " + cat + " ke liye save ho gayi. Agli baar apne aap aa jayegi.";
                    status.setText(msg);
                    FancyText.toast(ctx, msg, Toast.LENGTH_SHORT).show();
                    FirebaseRepository.logActivity("Category " + field + " saved", cat,
                            value.isEmpty() ? "removed" : value.length() + " characters");
                })
                .addOnFailureListener(error -> {
                    String msg = "Save failed: " + error.getMessage();
                    status.setText(msg);
                    FancyText.toast(ctx, msg, Toast.LENGTH_LONG).show();
                });
    }

    private static String text(Object raw) {
        return raw == null ? "" : String.valueOf(raw).trim();
    }

    private static int dp(Context ctx, float v) {
        return (int) (v * ctx.getResources().getDisplayMetrics().density + 0.5f);
    }

    private static TextView status(Context ctx) {
        TextView view = new TextView(ctx);
        view.setTextSize(11.5f);
        view.setTextColor(Color.rgb(100, 115, 135));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(ctx, 4);
        view.setLayoutParams(lp);
        return view;
    }

    private static MaterialButton saveButton(Context ctx, String text) {
        MaterialButton button = new MaterialButton(ctx);
        button.setText(text);
        button.setAllCaps(false);
        button.setTextSize(12f);
        button.setTypeface(null, Typeface.BOLD);
        button.setTextColor(Color.rgb(24, 92, 175));
        button.setCornerRadius(dp(ctx, 7));
        button.setBackgroundTintList(ColorStateList.valueOf(Color.rgb(232, 241, 255)));
        button.setStrokeColor(ColorStateList.valueOf(Color.rgb(55, 65, 81)));
        button.setStrokeWidth(dp(ctx, 1));
        button.setElevation(0f);
        button.setInsetTop(0);
        button.setInsetBottom(0);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(ctx, 42));
        lp.topMargin = dp(ctx, 4);
        lp.bottomMargin = dp(ctx, 6);
        button.setLayoutParams(lp);
        return button;
    }
}
