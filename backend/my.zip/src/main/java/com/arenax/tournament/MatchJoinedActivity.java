package com.arenax.tournament;


import com.arenax.tournament.util.FancyText;
import com.arenax.tournament.util.ImageLoader;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.WindowInsetsControllerCompat;

import com.arenax.tournament.data.FirebaseRepository;
import com.arenax.tournament.model.Tournament;
import com.arenax.tournament.util.MatchReports;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.resource.bitmap.CircleCrop;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.ValueEventListener;

import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * MATCH DETAILS — the page a player lands on after joining a match (and every time they
 * re-open a match they have already joined). White cards with black outlines, a black
 * countdown card + status bar with gold outlines.
 *
 * Everything is live: match info / joined count / room release come from
 * tournaments/{id}, the player's own slot(s) from tournaments/{id}/participants/{uid}.
 * All IDs are defined in activity_match_joined.xml.
 */
public class MatchJoinedActivity extends BaseActivity {
    public static final String EXTRA_TOURNAMENT = "tournament";

    private Tournament tournament;
    private String uid;
    private com.arenax.tournament.util.JoinedPlayersList joinedPlayers;
    private CountDownTimer countdownTimer;
    private ValueEventListener tournamentListener;
    private ValueEventListener participantListener;

    private TextView players, roomId, roomPass, cdLabel, cdH, cdM, cdS, roomInfo;
    private TextView playerName, playerSub, slotCaption, slotValue;
    private View countdownCard;
    private int[] mySlots = new int[0];

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_match_joined);
        if (!FirebaseRepository.isReady(this)) {
            FancyText.toast(this, "Live services are unavailable. Please try again later.", Toast.LENGTH_LONG).show();
            finish(); return;
        }
        tournament = readTournament();
        FirebaseUser user = FirebaseRepository.currentUser();
        if (tournament == null || tournament.getId() == null || user == null) { finish(); return; }
        uid = user.getUid();

        applySystemBars();
        bindViews();
        bindStatic();
        renderLive();
        loadAvatar();
        watchTournament();
        watchParticipant();
        joinedPlayers = new com.arenax.tournament.util.JoinedPlayersList(
                (android.widget.LinearLayout) findViewById(R.id.mj_joined_list),
                (TextView) findViewById(R.id.mj_joined_count), tournament.getId());
        joinedPlayers.attach();
        animateEntrance();
    }

    /** Soft staggered fade + rise-in for each card, matching the reference screen's feel. */
    private void animateEntrance() {
        View content = findViewById(R.id.mj_content);
        if (!(content instanceof android.view.ViewGroup)) return;
        android.view.ViewGroup group = (android.view.ViewGroup) content;
        long delay = 0;
        for (int i = 0; i < group.getChildCount(); i++) {
            View child = group.getChildAt(i);
            child.setAlpha(0f);
            child.setTranslationY(28f);
            child.animate()
                    .alpha(1f)
                    .translationY(0f)
                    .setStartDelay(delay)
                    .setDuration(360)
                    .setInterpolator(new android.view.animation.DecelerateInterpolator(1.6f))
                    .start();
            delay += 60;
        }
    }

    // ------------------------------------------------------------------ setup

    /** Edge-to-edge safe (Android 15 enforces it for targetSdk 35) + dark bar icons. */
    private void applySystemBars() {
        int canvas = getColor(R.color.ink);
        getWindow().setStatusBarColor(canvas);
        getWindow().setNavigationBarColor(canvas);
        View root = findViewById(R.id.mj_root);
        ViewCompat.setOnApplyWindowInsetsListener(root, (view, insets) -> {
            Insets bars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            view.setPadding(bars.left, bars.top, bars.right, bars.bottom);
            return insets;
        });
        WindowInsetsControllerCompat controller = WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView());
        controller.setAppearanceLightStatusBars(true);
        controller.setAppearanceLightNavigationBars(true);
    }

    private void bindViews() {
        players = findViewById(R.id.mj_players);
        roomId = findViewById(R.id.mj_room_id);
        roomPass = findViewById(R.id.mj_room_pass);
        cdLabel = findViewById(R.id.mj_cd_label);
        cdH = findViewById(R.id.mj_cd_h);
        cdM = findViewById(R.id.mj_cd_m);
        cdS = findViewById(R.id.mj_cd_s);
        roomInfo = findViewById(R.id.mj_room_info);
        countdownCard = findViewById(R.id.mj_countdown_card);
        playerName = findViewById(R.id.mj_player_name);
        playerSub = findViewById(R.id.mj_player_sub);
        slotCaption = findViewById(R.id.mj_slot_caption);
        slotValue = findViewById(R.id.mj_slot_value);

        findViewById(R.id.mj_back).setOnClickListener(v -> finish());
        findViewById(R.id.mj_my_matches).setOnClickListener(v ->
                startActivity(new Intent(this, MyMatchesActivity.class)
                        .putExtra(MyMatchesActivity.EXTRA_TOURNAMENT_ID, tournament.getId())));
        findViewById(R.id.mj_report).setOnClickListener(v ->
                MatchReports.showChoice(this, tournament.getId(), tournament.getTitle()));
        findViewById(R.id.mj_room_id_box).setOnClickListener(v -> copyRoomValue("Room ID", true));
        findViewById(R.id.mj_room_pass_box).setOnClickListener(v -> copyRoomValue("Password", false));
    }

    /** Values that never change while the page is open. */
    private void bindStatic() {
        ((TextView) findViewById(R.id.mj_match_title)).setText(tournament.getTitle());
        String mode = tournament.getMode();
        TextView subtitle = findViewById(R.id.mj_subtitle);
        if (mode == null || mode.trim().isEmpty() || "CUSTOM MODE".equalsIgnoreCase(mode.trim())) {
            subtitle.setVisibility(View.GONE);
        } else {
            subtitle.setText(titleCase(mode));
        }
        ((TextView) findViewById(R.id.mj_date)).setText(titleCase(tournament.getDate()));
        ((TextView) findViewById(R.id.mj_time)).setText(tournament.getTime());

        String type = tournament.getMatchType();
        TextView tag = findViewById(R.id.mj_tag);
        if (type != null && !type.trim().isEmpty()) {
            tag.setText((type.trim() + " TOURNAMENT").toUpperCase(Locale.ROOT));
            tag.setVisibility(View.VISIBLE);
        }
        ImageLoader.load((ImageView) findViewById(R.id.mj_banner), tournament.getBannerUrl());
        for (int coinViewId : new int[]{R.id.mj_prize, R.id.mj_entry, R.id.mj_kill}) {
            TextView coinView = findViewById(coinViewId);
            coinView.setCompoundDrawablesRelativeWithIntrinsicBounds(
                    CoinEmoji.drawable(this, 14), null, null, null);
        }
        ((TextView) findViewById(R.id.mj_prize)).setText(coins(tournament.getPrizePoolCoins()));
        TextView entry = findViewById(R.id.mj_entry);
        if (tournament.getEntryFeeCoins() > 0) {
            entry.setText(coins(tournament.getEntryFeeCoins()));
        } else {
            entry.setText("FREE");
            entry.setCompoundDrawablesRelative(null, null, null, null);
        }
        ((TextView) findViewById(R.id.mj_kill)).setText(coins(tournament.getPerKillCoins()));
        ((TextView) findViewById(R.id.mj_type)).setText(
                type == null || type.trim().isEmpty() ? "—" : titleCase(type));
        String map = tournament.getMap();
        ((TextView) findViewById(R.id.mj_map)).setText(map == null || map.trim().isEmpty() ? "—" : map);
    }

    /** Everything that can change live: joined count + room release / countdown. */
    private void renderLive() {
        boolean full = tournament.getTotalSlots() > 0 && tournament.getJoinedSlots() >= tournament.getTotalSlots();
        players.setText(tournament.getJoinedSlots() + "/" + tournament.getTotalSlots() + (tournament.hasStarted() ? "  \u2022 Match Started" : (full ? "  \u2022 Joining Full" : "")));
        renderRoom();
    }

    // ------------------------------------------------------------------ room / countdown

    private void renderRoom() {
        if (countdownTimer != null) { countdownTimer.cancel(); countdownTimer = null; }
        boolean released = tournament.isRoomReleased();
        boolean hasCredentials = released && !tournament.getRoomId().isEmpty();
        roomId.setText(hasCredentials ? tournament.getRoomId() : "Hidden");
        roomPass.setText(hasCredentials ? tournament.getRoomPassword() : "Hidden");

        if (tournament.isDelayed()) {
            countdownCard.setVisibility(View.VISIBLE);
            cdLabel.setText("Match delayed — " + tournament.getDelayReason());
            setDigits(-1);
            roomInfo.setText("Wait for the Room ID & Password to be shared.");
            return;
        }
        if (hasCredentials) {
            countdownCard.setVisibility(View.GONE);
            roomInfo.setText("Room is live. Tap Room ID or Password to copy it.");
            return;
        }
        countdownCard.setVisibility(View.VISIBLE);
        if (released) {
            // Released but the admin hasn't typed the credentials yet.
            cdLabel.setText("Room ID & Password will be posted shortly");
            setDigits(-1);
            roomInfo.setText("Room details will be available before the match.");
            return;
        }
        roomInfo.setText("Room details will be available before the match.");
        long now = System.currentTimeMillis();
        long target = tournament.getRoomReleaseAt() > now ? tournament.getRoomReleaseAt() : 0L;
        if (target == 0L && tournament.getRoomReleaseAt() <= 0L && tournament.getEffectiveStartAt() > now) {
            target = tournament.getEffectiveStartAt();
            cdLabel.setText("Match starts in");
        } else if (target > 0L) {
            cdLabel.setText("Password will be revealed in");
        }
        if (target == 0L) {
            cdLabel.setText("Waiting for the admin to release the room");
            setDigits(0);
            return;
        }
        countdownTimer = new CountDownTimer(target - now, 1000L) {
            @Override public void onTick(long millisUntilFinished) { setDigits(millisUntilFinished / 1000L); }
            @Override public void onFinish() {
                setDigits(0);
                cdLabel.setText("Waiting for the admin to release the room");
            }
        }.start();
        setDigits((target - now) / 1000L);
    }

    /** seconds &lt; 0 shows "--" placeholders. Hours are total hours (days folded in). */
    private void setDigits(long totalSeconds) {
        if (totalSeconds < 0) {
            cdH.setText("--"); cdM.setText("--"); cdS.setText("--");
            return;
        }
        cdH.setText(String.format(Locale.ROOT, "%02d", totalSeconds / 3600L));
        cdM.setText(String.format(Locale.ROOT, "%02d", (totalSeconds % 3600L) / 60L));
        cdS.setText(String.format(Locale.ROOT, "%02d", totalSeconds % 60L));
    }

    private void copyRoomValue(String label, boolean id) {
        if (!tournament.isRoomReleased() || tournament.getRoomId().isEmpty()) return;
        String value = id ? tournament.getRoomId() : tournament.getRoomPassword();
        ClipboardManager cm = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
        if (cm != null) {
            cm.setPrimaryClip(ClipData.newPlainText(label, value));
            FancyText.toast(this, label + " copied", Toast.LENGTH_SHORT).show();
        }
    }

    // ------------------------------------------------------------------ live data

    private void watchTournament() {
        tournamentListener = new ValueEventListener() {
            @Override public void onDataChange(@NonNull DataSnapshot snapshot) {
                @SuppressWarnings("unchecked")
                Tournament fresh = Tournament.fromMap(tournament.getId(), (Map<String, Object>) snapshot.getValue());
                if (fresh == null) return;
                tournament = fresh;
                renderLive();
                renderSlot();
            }
            @Override public void onCancelled(@NonNull DatabaseError error) { }
        };
        FirebaseRepository.tournaments().child(tournament.getId()).addValueEventListener(tournamentListener);
    }

    private void watchParticipant() {
        participantListener = new ValueEventListener() {
            @Override public void onDataChange(@NonNull DataSnapshot snapshot) {
                String name = text(snapshot.child("gameName").getValue());
                if (name.isEmpty()) {
                    name = getSharedPreferences("arenax_profile", MODE_PRIVATE).getString("last_game_name", "");
                }
                playerName.setText(name == null || name.isEmpty() ? "Player" : name);
                String gameUid = text(snapshot.child("gameUid").getValue());
                playerSub.setText(gameUid.isEmpty() ? "Player" : "Player • UID " + gameUid);

                List<Integer> slots = new ArrayList<>();
                for (DataSnapshot p : snapshot.child("players").getChildren()) {
                    Integer n = toInt(p.child("slotNumber").getValue());
                    if (n == null) n = toInt(p.getKey());
                    if (n != null) slots.add(n);
                }
                if (slots.isEmpty()) {
                    Integer primary = toInt(snapshot.child("slotNumber").getValue());
                    if (primary != null) slots.add(primary);
                }
                Collections.sort(slots);
                mySlots = new int[slots.size()];
                for (int i = 0; i < mySlots.length; i++) mySlots[i] = slots.get(i);
                renderSlot();
            }
            @Override public void onCancelled(@NonNull DatabaseError error) { }
        };
        FirebaseRepository.tournamentParticipants(tournament.getId()).child(uid)
                .addValueEventListener(participantListener);
    }

    private void renderSlot() {
        if (mySlots.length == 0) { slotValue.setText("—"); return; }
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < mySlots.length; i++) {
            if (i > 0) sb.append(", ");
            sb.append(mySlots[i]);
        }
        slotCaption.setText(mySlots.length > 1 ? "SLOTS" : "SLOT NO.");
        slotValue.setText(sb + " / " + tournament.getTotalSlots());
    }

    private void loadAvatar() {
        ImageView avatar = findViewById(R.id.mj_avatar);
        avatar.setImageResource(R.drawable.ic_mj_user);
        avatar.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        avatar.setColorFilter(getColor(R.color.text_muted));
        FirebaseRepository.users().child(uid).child("photoUrl").get()
                .addOnSuccessListener(snapshot -> {
                    String url = text(snapshot.getValue());
                    if (url.isEmpty() || isDestroyed()) return;
                    avatar.clearColorFilter();
                    avatar.setScaleType(ImageView.ScaleType.CENTER_CROP);
                    Glide.with(this).load(url).transform(new CircleCrop()).into(avatar);
                });
    }

    // ------------------------------------------------------------------ helpers

    private Tournament readTournament() {
        if (android.os.Build.VERSION.SDK_INT >= 33) {
            return getIntent().getSerializableExtra(EXTRA_TOURNAMENT, Tournament.class);
        }
        return (Tournament) getIntent().getSerializableExtra(EXTRA_TOURNAMENT);
    }

    private static String coins(int amount) {
        return NumberFormat.getIntegerInstance(Locale.US).format(amount);
    }

    private static String text(Object value) {
        return value == null ? "" : String.valueOf(value).trim();
    }

    private static Integer toInt(Object value) {
        if (value == null) return null;
        try { return Integer.valueOf(String.valueOf(value).trim()); }
        catch (NumberFormatException e) { return null; }
    }

    /** "19 SEP 2026" -> "19 Sep 2026", "SOLO" -> "Solo". Digit/time tokens are left alone. */
    private static String titleCase(String raw) {
        if (raw == null || raw.trim().isEmpty()) return "";
        String[] parts = raw.trim().split("\\s+");
        StringBuilder out = new StringBuilder();
        for (String part : parts) {
            if (out.length() > 0) out.append(' ');
            boolean alphaOnly = part.matches("[A-Za-z]+");
            if (alphaOnly && part.length() > 2) {
                out.append(part.substring(0, 1).toUpperCase(Locale.ROOT))
                        .append(part.substring(1).toLowerCase(Locale.ROOT));
            } else {
                out.append(part);
            }
        }
        return out.toString();
    }

    @Override
    protected void onDestroy() {
        if (joinedPlayers != null) joinedPlayers.detach();
        if (countdownTimer != null) countdownTimer.cancel();
        if (tournament != null && tournament.getId() != null) {
            if (tournamentListener != null) {
                FirebaseRepository.tournaments().child(tournament.getId()).removeEventListener(tournamentListener);
            }
            if (participantListener != null && uid != null) {
                FirebaseRepository.tournamentParticipants(tournament.getId()).child(uid)
                        .removeEventListener(participantListener);
            }
        }
        super.onDestroy();
    }
}
