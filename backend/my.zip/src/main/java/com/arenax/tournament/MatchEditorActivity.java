package com.arenax.tournament;


import com.arenax.tournament.util.FancyText;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.arenax.tournament.data.FirebaseRepository;
import com.arenax.tournament.model.Match;
import com.arenax.tournament.model.Tournament;
import com.google.android.material.button.MaterialButton;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * F1 — full-screen replacement for the old floating "create/edit match" dialog
 * (showMatchDialog in AdminActivity). When an admin adds a match, this page opens
 * full screen for match details + max slots + rules — no floating dialog.
 *
 * F2 — the Mode field auto-fills from the tournament's match type, and team-based
 * modes derive the exact slot expectation: SOLO = 1 player, DUO = 2,
 * SQUAD / CLASH SQUAD = 4 (via teamSizeFor()).
 */
public class MatchEditorActivity extends BaseActivity {

    public static final String EXTRA_TOURNAMENT = "tournament";
    public static final String EXTRA_MATCH = "match";

    private Tournament tournament;
    private Match existing;
    private boolean editMode;

    private EditText nameField;
    private EditText roundField;
    private EditText mapField;
    private EditText modeField;
    private EditText dateField;
    private EditText timeField;
    private EditText maxSlotsField;
    private EditText rulesField;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (!FirebaseRepository.isReady(this)) {
            FancyText.toast(this, "Live services are unavailable. Please try again later.", Toast.LENGTH_LONG).show();
            finish();
            return;
        }
        if (android.os.Build.VERSION.SDK_INT >= 33) {
            tournament = getIntent().getSerializableExtra(EXTRA_TOURNAMENT, Tournament.class);
            existing = getIntent().getSerializableExtra(EXTRA_MATCH, Match.class);
        } else {
            tournament = (Tournament) getIntent().getSerializableExtra(EXTRA_TOURNAMENT);
            existing = (Match) getIntent().getSerializableExtra(EXTRA_MATCH);
        }
        editMode = existing != null;
        if (tournament == null) {
            finish();
            return;
        }
        buildUi();
    }

    // ------------------------------------------------------------------
    // F2 — own match-type logic
    // ------------------------------------------------------------------

    /** Team size implied by a match type label (SOLO=1, DUO=2, SQUAD/CLASH SQUAD=4). */
    public static int teamSizeFor(String matchType) {
        if (matchType == null) return 1;
        String t = matchType.trim().toUpperCase(Locale.ROOT);
        if (t.contains("SOLO") || t.contains("1V") && t.endsWith("1")) return 1;
        if (t.contains("DUO") || t.contains("2V") && t.endsWith("2")) return 2;
        if (t.contains("CLASH")) return 4;
        if (t.contains("SQUAD") || t.contains("4V")) return 4;
        if (t.contains("TRIO") || t.contains("3V")) return 3;
        return 1;
    }

    // ------------------------------------------------------------------
    // Theme helpers
    // ------------------------------------------------------------------

    private int dp(float v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private TextView navyText(String text, float sizeSp, boolean bold, String hex) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextSize(sizeSp);
        tv.setTypeface(null, bold ? Typeface.BOLD : Typeface.NORMAL);
        tv.setTextColor(Color.parseColor(hex));
        return tv;
    }

    private TextView sectionLabel(String text) {
        TextView label = navyText(text, 11.5f, true, "#68686D");
        label.setLetterSpacing(0.04f);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.topMargin = dp(18);
        p.bottomMargin = dp(6);
        label.setLayoutParams(p);
        return label;
    }

    private EditText navyField(String hint) {
        EditText input = new EditText(this);
        input.setHint(hint);
        input.setTextColor(Color.parseColor("#1C1C1E"));
        input.setHintTextColor(Color.parseColor("#68686D"));
        input.setBackgroundResource(R.drawable.bg_input_navy);
        int hPad = dp(16), vPad = dp(14);
        input.setPadding(hPad, vPad, hPad, vPad);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.topMargin = dp(6);
        p.bottomMargin = dp(6);
        input.setLayoutParams(p);
        input.setTextSize(13.5f);
        return input;
    }

    private MaterialButton gradientButton(String label) {
        MaterialButton b = new MaterialButton(this);
        b.setText(label);
        b.setTextColor(Color.WHITE);
        b.setAllCaps(false);
        b.setTextSize(13f);
        b.setTypeface(null, Typeface.BOLD);
        b.setBackgroundResource(R.drawable.bg_button_gradient);
        b.setElevation(0f);
        b.setInsetTop(0);
        b.setInsetBottom(0);
        b.setCornerRadius(dp(14));
        return b;
    }

    private MaterialButton outlineButton(String label, String strokeHex) {
        MaterialButton b = new MaterialButton(this);
        b.setText(label);
        b.setTextColor(Color.parseColor(strokeHex));
        b.setAllCaps(false);
        b.setTextSize(13f);
        b.setTypeface(null, Typeface.BOLD);
        b.setBackgroundResource(R.drawable.bg_dialog_button_outline);
        b.setStrokeColor(android.content.res.ColorStateList.valueOf(Color.parseColor(strokeHex)));
        b.setStrokeWidth(dp(1));
        b.setElevation(0f);
        b.setInsetTop(0);
        b.setInsetBottom(0);
        b.setCornerRadius(dp(14));
        return b;
    }

    private LinearLayout infoCard() {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setBackgroundResource(R.drawable.bg_card_navy);
        card.setPadding(dp(14), dp(12), dp(14), dp(12));
        return card;
    }

    // ------------------------------------------------------------------
    // Page
    // ------------------------------------------------------------------

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundResource(R.drawable.bg_page_navy);

        // ---- Top bar ----
        LinearLayout topBar = new LinearLayout(this);
        topBar.setOrientation(LinearLayout.HORIZONTAL);
        topBar.setGravity(Gravity.CENTER_VERTICAL);
        topBar.setPadding(dp(14), dp(12), dp(14), dp(12));
        topBar.setBackgroundResource(R.drawable.bg_card_navy);

        TextView back = new TextView(this);
        back.setBackgroundResource(R.drawable.bg_section_pill_navy);
        back.setCompoundDrawablesWithIntrinsicBounds(R.drawable.ic_arrow_back, 0, 0, 0);
        back.setCompoundDrawablePadding(dp(6));
        back.setPadding(dp(12), dp(10), dp(12), dp(10));
        back.setOnClickListener(v -> finish());
        topBar.addView(back, new LinearLayout.LayoutParams(-2, -2));

        LinearLayout titleBlock = new LinearLayout(this);
        titleBlock.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams tbParams = new LinearLayout.LayoutParams(0, -2, 1f);
        tbParams.leftMargin = dp(12);
        titleBlock.setLayoutParams(tbParams);
        titleBlock.addView(navyText(editMode ? "EDIT MATCH" : "ADD MATCH", 18f, true, "#1C1C1E"));
        TextView sub = navyText(tournament.getTitle(), 12f, false, "#68686D");
        LinearLayout.LayoutParams subParams = new LinearLayout.LayoutParams(-1, -2);
        subParams.topMargin = dp(2);
        sub.setLayoutParams(subParams);
        titleBlock.addView(sub);
        topBar.addView(titleBlock);
        root.addView(topBar);

        // ---- Body ----
        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(dp(18), dp(12), dp(18), dp(18));

        // Info banner
        LinearLayout info = infoCard();
        info.addView(navyText("MATCH SCHEDULE", 10.5f, true, "#B8860B"));
        TextView infoLine = navyText("Countdown on the User App is computed from this exact date/time, "
                + "not a client timer — it stays correct after refresh.", 11.5f, false, "#68686D");
        LinearLayout.LayoutParams ilp = new LinearLayout.LayoutParams(-1, -2);
        ilp.topMargin = dp(6);
        infoLine.setLayoutParams(ilp);
        info.addView(infoLine);
        body.addView(info);

        // Basics
        body.addView(sectionLabel("MATCH BASICS"));
        nameField = navyField("Match name (e.g. Round 1 — Group A)");
        body.addView(nameField);
        roundField = navyField("Round number");
        roundField.setInputType(InputType.TYPE_CLASS_NUMBER);
        body.addView(roundField);
        mapField = navyField("Map (e.g. Bermuda, Purgatory, Kalahari)");
        body.addView(mapField);

        // Mode + match-type logic card (F2)
        modeField = navyField("Mode (e.g. Squad, Clash Squad)");
        body.addView(modeField);
        LinearLayout typeCard = infoCard();
        LinearLayout.LayoutParams tcParams = new LinearLayout.LayoutParams(-1, -2);
        tcParams.topMargin = dp(8);
        typeCard.setLayoutParams(tcParams);
        typeCard.addView(navyText("MATCH TYPE LOGIC", 10.5f, true, "#B8860B"));
        final TextView typeLine = navyText("", 11.5f, false, "#68686D");
        LinearLayout.LayoutParams tlParams = new LinearLayout.LayoutParams(-1, -2);
        tlParams.topMargin = dp(4);
        typeLine.setLayoutParams(tlParams);
        typeCard.addView(typeLine);
        body.addView(typeCard);
        final Runnable refreshTypeLine = () -> {
            String modeValue = modeField.getText().toString().trim();
            String baseType = modeValue.isEmpty() ? safeTournamentType() : modeValue;
            int players = teamSizeFor(baseType);
            typeLine.setText(baseType.toUpperCase(Locale.ROOT) + " — " + players
                    + (players == 1 ? " player per entry." : " players per entry (team join)."));
        };
        modeField.addTextChangedListener(new android.text.TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) { }

            @Override public void onTextChanged(CharSequence s, int a, int b, int c) { }

            @Override public void afterTextChanged(android.text.Editable s) {
                refreshTypeLine.run();
            }
        });

        // Schedule
        body.addView(sectionLabel("SCHEDULE"));
        dateField = navyField("Scheduled date (e.g. 20 SEP 2026)");
        body.addView(dateField);
        timeField = navyField("Scheduled time (e.g. 08:30 PM)");
        body.addView(timeField);

        // Slots
        body.addView(sectionLabel("SLOTS"));
        maxSlotsField = navyField("Max slots");
        maxSlotsField.setInputType(InputType.TYPE_CLASS_NUMBER);
        body.addView(maxSlotsField);
        TextView slotsHint = navyText("Leave the default to inherit the tournament's total slots.", 11f, false, "#68686D");
        LinearLayout.LayoutParams shp = new LinearLayout.LayoutParams(-1, -2);
        shp.topMargin = dp(4);
        slotsHint.setLayoutParams(shp);
        body.addView(slotsHint);

        // Rules
        body.addView(sectionLabel("RULES"));
        rulesField = navyField("Match rules (optional)");
        body.addView(rulesField);

        // Pre-fill (edit mode / defaults)
        if (editMode) {
            nameField.setText(existing.getName());
            roundField.setText(String.valueOf(existing.getRound()));
            mapField.setText(existing.getMap());
            modeField.setText(existing.getMode());
            if (existing.getScheduledAt() > 0) {
                Date d = new Date(existing.getScheduledAt());
                dateField.setText(new SimpleDateFormat("dd MMM yyyy", Locale.ENGLISH).format(d));
                timeField.setText(new SimpleDateFormat("hh:mm a", Locale.ENGLISH).format(d));
            }
            maxSlotsField.setText(String.valueOf(existing.getMaxSlots()));
            rulesField.setText(existing.getRules());
        } else {
            roundField.setText("1");
            rulesField.setText(com.arenax.tournament.util.DefaultMatchRules.TEXT); // auto rules (editable)
            modeField.setText(safeTournamentType());
            maxSlotsField.setText(String.valueOf(tournament.getTotalSlots()));
        }
        refreshTypeLine.run();

        ScrollView scroll = new ScrollView(this);
        scroll.addView(body);
        scroll.setLayoutParams(new LinearLayout.LayoutParams(-1, 0, 1f));
        root.addView(scroll);

        // ---- Pinned action bar ----
        LinearLayout bottomBar = new LinearLayout(this);
        bottomBar.setOrientation(LinearLayout.HORIZONTAL);
        bottomBar.setPadding(dp(16), dp(12), dp(16), dp(14));
        bottomBar.setBackgroundResource(R.drawable.bg_card_navy);

        MaterialButton cancelButton = outlineButton("CANCEL", "#68686D");
        cancelButton.setOnClickListener(v -> finish());
        LinearLayout.LayoutParams cancelParams = new LinearLayout.LayoutParams(0, dp(48), 1f);
        cancelParams.rightMargin = dp(10);
        bottomBar.addView(cancelButton, cancelParams);

        MaterialButton saveButton = gradientButton(editMode ? "SAVE MATCH" : "CREATE MATCH");
        saveButton.setOnClickListener(v -> saveMatch());
        bottomBar.addView(saveButton, new LinearLayout.LayoutParams(0, dp(48), 1f));
        root.addView(bottomBar);

        setContentView(root);
    }

    private String safeTournamentType() {
        String type = tournament.getMatchType();
        if (type == null || type.trim().isEmpty()) return "SOLO";
        return type.trim().toUpperCase(Locale.ROOT);
    }

    // ------------------------------------------------------------------
    // Save — port of showMatchDialog SAVE button
    // ------------------------------------------------------------------

    private void saveMatch() {
        String name = nameField.getText().toString().trim();
        if (name.isEmpty()) {
            nameField.setError("Enter a name");
            return;
        }
        long scheduledAt = parseDateTime(dateField.getText().toString().trim(),
                timeField.getText().toString().trim());
        String modeValue = modeField.getText().toString().trim();
        if (modeValue.isEmpty()) modeValue = safeTournamentType();
        int maxSlots = numberOrDefault(maxSlotsField.getText().toString().trim(),
                tournament.getTotalSlots());
        // F2 — slots must be a whole multiple of the team size so every team
        // gets complete rows on the join page.
        int teamSize = Math.max(1, teamSizeFor(modeValue));
        if (maxSlots % teamSize != 0) {
            maxSlots = (maxSlots / teamSize) * teamSize;
            if (maxSlots < teamSize) maxSlots = teamSize;
            maxSlotsField.setText(String.valueOf(maxSlots));
            FancyText.toast(this, "Max slots adjusted to " + maxSlots
                            + " (whole teams of " + teamSize + ").", Toast.LENGTH_LONG).show();
        }
        Match match = new Match(
                editMode ? existing.getId() : null,
                tournament.getId(),
                tournament.getTitle(),
                name,
                numberOrDefault(roundField.getText().toString().trim(), 1),
                mapField.getText().toString().trim(),
                modeValue.toUpperCase(Locale.ROOT),
                scheduledAt,
                maxSlots,
                rulesField.getText().toString().trim(),
                editMode ? existing.getStatus() : Match.UPCOMING,
                editMode ? existing.getRoomId() : "",
                editMode ? existing.getRoomPassword() : "",
                editMode && existing.isRoomReleased(),
                editMode ? existing.getRoomReleasedAt() : 0L,
                editMode ? existing.getDelayReason() : "",
                editMode ? existing.getDelayExpectedAt() : 0L);
        FirebaseRepository.saveMatch(match)
                .addOnSuccessListener(unused -> {
                    FirebaseRepository.logActivity(editMode ? "MATCH_EDITED" : "MATCH_CREATED",
                            match.getName(), tournament.getTitle());
                    if (!editMode) {
                        FirebaseRepository.publishNotification("New Match Scheduled",
                                match.getName() + " • " + tournament.getTitle());
                    }
                    FancyText.toast(this, editMode ? "Match updated." : "Match created.",
                            Toast.LENGTH_SHORT).show();
                    setResult(RESULT_OK);
                    finish();
                })
                .addOnFailureListener(error ->
                        FancyText.toast(this, error.getMessage(), Toast.LENGTH_LONG).show());
    }

    private int numberOrDefault(String value, int fallback) {
        try {
            return Integer.parseInt(value);
        } catch (NumberFormatException e) {
            return fallback;
        }
    }

    private long parseDateTime(String date, String time) {
        if (date == null || time == null || date.trim().isEmpty() || time.trim().isEmpty()
                || "TBA".equalsIgnoreCase(date) || "TBA".equalsIgnoreCase(time)) return 0L;
        String combined = date.trim() + " " + time.trim();
        String[] formats = {"dd MMM yyyy hh:mm a", "dd MMM yyyy HH:mm"};
        for (String format : formats) {
            try {
                Date parsed = new SimpleDateFormat(format, Locale.ENGLISH).parse(combined);
                if (parsed != null) return parsed.getTime();
            } catch (ParseException ignored) {
                // Keep the record publishable when an optional date is not parseable.
            }
        }
        return 0L;
    }
}
