package com.arenax.tournament.model;

import java.util.Map;

public final class Banner {
    private final String id;
    private final String title;
    private final String subtitle;
    private final String imageUrl;
    private final int displayOrder;
    private final boolean active;
    private final String linkUrl;

    public Banner(String id, String title, String subtitle, String imageUrl, int displayOrder, boolean active) {
        this(id, title, subtitle, imageUrl, displayOrder, active, "");
    }

    public Banner(String id, String title, String subtitle, String imageUrl, int displayOrder, boolean active, String linkUrl) {
        this.linkUrl = linkUrl == null ? "" : linkUrl;
        this.id = id;
        this.title = title == null ? "" : title;
        this.subtitle = subtitle == null ? "" : subtitle;
        this.imageUrl = imageUrl == null ? "" : imageUrl;
        this.displayOrder = displayOrder;
        this.active = active;
    }

    public static Banner fromMap(String id, Map<String, Object> value) {
        if (value == null) return null;
        Object order = value.get("displayOrder");
        Object enabled = value.get("active");
        return new Banner(id, text(value.get("title")), text(value.get("subtitle")),
                text(value.get("imageUrl")), order instanceof Number ? ((Number) order).intValue() : 0,
                !(enabled instanceof Boolean) || (Boolean) enabled, text(value.get("linkUrl")));
    }

    private static final java.util.Set<String> ALLOWED_LINK_SCHEMES = new java.util.HashSet<>(
            java.util.Arrays.asList("http", "https", "tg", "whatsapp", "mailto", "tel"));

    /** Cleans a support link typed by an admin. Returns "" for empty input (= remove the link),
     *  the normalized link when valid (a bare "t.me/xyz" becomes "https://t.me/xyz"), or null
     *  when the link is not usable. Only http/https/tg/whatsapp/mailto/tel are accepted. */
    public static String normalizeLink(String raw) {
        if (raw == null) return "";
        String link = raw.trim();
        if (link.isEmpty()) return "";
        if (link.length() > 2000) return null;
        for (int i = 0; i < link.length(); i++) if (Character.isWhitespace(link.charAt(i))) return null;
        java.util.regex.Matcher m = java.util.regex.Pattern.compile("^([A-Za-z][A-Za-z0-9+.-]*):").matcher(link);
        if (m.find()) {
            String scheme = m.group(1).toLowerCase(java.util.Locale.ENGLISH);
            if (!ALLOWED_LINK_SCHEMES.contains(scheme)) return null;
            if (scheme.equals("http") || scheme.equals("https")) {
                String host = android.net.Uri.parse(link).getHost();
                if (host == null || host.isEmpty()) return null;
            }
            return link;
        }
        link = "https://" + link;
        String host = android.net.Uri.parse(link).getHost();
        return host == null || host.isEmpty() || !host.contains(".") ? null : link;
    }
    private static String text(Object v) { return v == null ? "" : String.valueOf(v); }
    public String getId() { return id; }
    public String getTitle() { return title; }
    public String getSubtitle() { return subtitle; }
    public String getImageUrl() { return imageUrl; }
    public int getDisplayOrder() { return displayOrder; }
    public boolean isActive() { return active; }
    public String getLinkUrl() { return linkUrl; }
}
