package com.arenax.tournament.util;

/** Default rules text auto-filled in every new match (admin can still edit it). */
public final class DefaultMatchRules {
    private DefaultMatchRules() {}

    public static final String TEXT =
            "\ud83c\udfc6 TOURNAMENT RULES & REGULATIONS\n" +
            "\n" +
            "\u278a Character Skill \ud83c\udfae\n" +
            "Character Skills are ON.\n" +
            "\n" +
            "\u278b Gun Attributes \ud83d\udd2b\n" +
            "Gun Attributes are OFF.\n" +
            "\n" +
            "\u278c Banned Guns \ud83d\udeab\n" +
            "\u2022 Double Vector\n" +
            "\u2022 M79\n" +
            "\n" +
            "\u278d Horse \ud83d\udc0e\n" +
            "Using the Horse is strictly prohibited.\n" +
            "\n" +
            "\u278e Team-Up \ud83e\udd1d\n" +
            "Team-ups or teaming with opponents are strictly prohibited.\n" +
            "\n" +
            "\u278f Slot Rules \ud83c\udfaf\n" +
            "Players must use the same slot in the Custom Room that they selected while registering in the app.\n" +
            "\n" +
            "\u2790 Unregistered Player Rules \ud83d\udc64\n" +
            "If a registered player invites an unregistered player and the unregistered player gets a kill, no prize will be awarded for that kill.\n" +
            "\n" +
            "\u2791 Level Requirement \u2b50\n" +
            "Only players with Level 40+ IDs are eligible to participate.\n" +
            "\n" +
            "\u2792 Headshot Rate \ud83c\udfaf\n" +
            "The CS Career Headshot Rate must not exceed 70%.\n" +
            "\n" +
            "\u2793 Device Requirements \ud83d\udcf1\n" +
            "The match must be played exclusively on a smartphone or tablet. Emulators are strictly prohibited.\n" +
            "\n" +
            "\u24eb Registration Name Rules \u270d\ufe0f\n" +
            "Players must use simple text while registering.\n" +
            "Example: RONITH RON\n" +
            "Special characters, symbols, or decorative fonts are not allowed.\n" +
            "\n" +
            "\u24ec Prohibited Behavior \u26a0\ufe0f\n" +
            "Any activity that violates the tournament rules or provides an unfair advantage is strictly prohibited.\n" +
            "\n" +
            "\u24ed Unauthorized Tools \ud83d\udeab\n" +
            "Aimbots, no-recoil applications, scripts, or any game-modifying software are strictly prohibited.\n" +
            "\n" +
            "\u24ee Teaming Up with Opponents \ud83e\udd1d\n" +
            "Collaborating or teaming up with opponents to gain an unfair advantage is strictly prohibited.\n" +
            "\n" +
            "\u24ef Mandatory Gameplay Recording \ud83c\udfa5\n" +
            "Players must record their gameplay using the in-game recording feature or a screen recorder.\n" +
            "\n" +
            "\u24f0 Custom Room Screen Recording \ud83d\udcf9\n" +
            "Players must record their screen while joining the Custom Room. The joining process must be clearly visible.\n" +
            "\n" +
            "\u24f1 Multiple Accounts \ud83d\udc65\n" +
            "The use of multiple accounts by a single user is strictly prohibited.\n" +
            "\n" +
            "\u24f2 Blacklisted Game IDs \ud83d\udeab\n" +
            "Blacklisted Game IDs are not allowed to participate.\n" +
            "\n" +
            "\u24f3 Match Result \u23f1\ufe0f\n" +
            "The match result will be generated within 1 to 1.5 hours after the scheduled match time.\n" +
            "\n" +
            "\u24f4 Refund Policy \ud83d\udcb0\n" +
            "Refunds will not be provided for missed matches. STARx24-related technical issues may be considered on a case-by-case basis.\n" +
            "\n" +
            "\u3251 Match Registration Cancellation \u274c\n" +
            "Once a player joins a match, the registration cannot be cancelled.\n" +
            "\n" +
            "\u3252 Rights & Regulations \ud83d\udcdc\n" +
            "StarX24 reserves the right to modify match prizes, rules, regulations, or other tournament conditions at its discretion.\n" +
            "\n" +
            "\u26a0\ufe0f NOTE\n" +
            "\u2705 By joining a match, players confirm that they have read, understood, and agreed to all the above rules and regulations.";
}
