package com.arenax.tournament.util;

import android.app.Activity;
import android.app.Application;
import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.text.Spanned;
import android.text.SpannableStringBuilder;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Map;
import java.util.WeakHashMap;

/**
 * App-wide "fancy text" look.
 *
 * Every piece of text the user SEES (screen labels, buttons, dialogs, toasts, and anything an
 * admin types in a normal field and that is later shown to players) is drawn with the stylised
 * Unicode math alphabet, e.g.  Hello  ->  𝖧𝖾𝗅𝗅𝗈.
 *
 * - Display only: EditText fields are never touched, so typing stays normal and the value that
 *   is saved to Firebase is still plain text. Admin text is therefore converted at display time.
 * - Only A-Z / a-z are converted. Digits, Hindi/other scripts, emoji and symbols are untouched.
 * - Tokens that look like data (contain a digit, '@', '/', '_' or look like a domain/URL) are left
 *   plain so Room IDs, UPI IDs, e-mails, links and amounts stay copy-paste safe.
 * - A view can opt out by setting its tag to "nofancy".
 *
 * To change how heavy the style looks, change {@link #STYLE} (one line).
 */
public final class FancyText {

    /** Alphabet used for the look. SANS is the lightest (regular weight). */
    public enum Style {
        /** 𝖠𝖻𝖼  - sans-serif, regular weight (light). */
        SANS(0x1D5A0, 0x1D5BA),
        /** 𝐴𝑏𝑐  - serif italic (light). */
        ITALIC(0x1D434, 0x1D44E),
        /** 𝙰𝚋𝚌  - monospace (light). */
        MONO(0x1D670, 0x1D68A),
        /** 𝐀𝐛𝐜  - serif bold (the heavy original sample). */
        BOLD(0x1D400, 0x1D41A);

        final int upperBase;
        final int lowerBase;

        Style(int upperBase, int lowerBase) {
            this.upperBase = upperBase;
            this.lowerBase = lowerBase;
        }
    }

    /** One-line switch for the whole app's text design. */
    public static final Style STYLE = Style.SANS;

    /** Set a view's tag to this to keep its text plain. */
    public static final String NO_FANCY = "nofancy";

    // Every style's [upperBase, lowerBase] so plain() can undo any of them.
    private static final int[][] ALL_BASES = {
            {0x1D400, 0x1D41A}, // bold
            {0x1D434, 0x1D44E}, // italic
            {0x1D468, 0x1D482}, // bold italic
            {0x1D5A0, 0x1D5BA}, // sans
            {0x1D5D4, 0x1D5EE}, // sans bold
            {0x1D608, 0x1D622}, // sans italic
            {0x1D670, 0x1D68A}, // monospace
    };

    private static final Map<View, Boolean> ATTACHED = new WeakHashMap<>();

    private FancyText() {}

    // ------------------------------------------------------------------------------------
    // Conversion
    // ------------------------------------------------------------------------------------

    /** Returns text in the fancy alphabet. Same instance back when there is nothing to change. */
    public static CharSequence convert(CharSequence in) {
        if (in == null || in.length() == 0) return in;
        if (LanguageManager.isTranslating()) return in; // translated text stays plain
        final String s = in.toString();
        final boolean[] mask = buildMask(s);
        if (mask == null) return in; // nothing convertible

        if (in instanceof Spanned) {
            Spanned sp = (Spanned) in;
            Object[] spans = sp.getSpans(0, s.length(), Object.class);
            if (spans != null && spans.length > 0) {
                // Letters grow from 1 to 2 UTF-16 chars, so remap every span boundary.
                int[] map = new int[s.length() + 1];
                StringBuilder sb = new StringBuilder(s.length() * 2);
                for (int i = 0; i < s.length(); i++) {
                    map[i] = sb.length();
                    if (mask[i]) sb.appendCodePoint(fancyCodePoint(s.charAt(i)));
                    else sb.append(s.charAt(i));
                }
                map[s.length()] = sb.length();
                SpannableStringBuilder out = new SpannableStringBuilder(sb.toString());
                for (Object span : spans) {
                    int st = sp.getSpanStart(span);
                    int en = sp.getSpanEnd(span);
                    if (st < 0 || en < 0) continue;
                    out.setSpan(span, map[st], map[en], sp.getSpanFlags(span));
                }
                return out;
            }
        }

        StringBuilder sb = new StringBuilder(s.length() * 2);
        for (int i = 0; i < s.length(); i++) {
            if (mask[i]) sb.appendCodePoint(fancyCodePoint(s.charAt(i)));
            else sb.append(s.charAt(i));
        }
        return sb.toString();
    }

    /**
     * Premium heading look: sans-serif BOLD alphabet (𝗔𝗯𝗰). Use for page / section headings only;
     * body text stays on {@link #STYLE}. Set the view's tag to "nofancy" so it is not converted twice.
     * Build coloured spans from separately converted parts (letters grow from 1 to 2 UTF-16 chars).
     */
    public static CharSequence heading(CharSequence in) {
        if (in == null || in.length() == 0) return in;
        if (LanguageManager.isTranslating()) return in;
        final String s = in.toString();
        final boolean[] mask = buildMask(s);
        if (mask == null) return in;
        StringBuilder sb = new StringBuilder(s.length() * 2);
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (!mask[i]) sb.append(c);
            else if (c >= 'A' && c <= 'Z') sb.appendCodePoint(0x1D5D4 + (c - 'A'));
            else sb.appendCodePoint(0x1D5EE + (c - 'a'));
        }
        return sb.toString();
    }

    /** String convenience wrapper. */
    public static String convert(String in) {
        CharSequence out = convert((CharSequence) in);
        return out == null ? null : out.toString();
    }

    /**
     * Undo the fancy alphabet back to normal A-Z / a-z. Use this whenever code READS text back
     * from a label (e.g. parsing a chip's text or sending a displayed name to the server).
     */
    public static String plain(CharSequence in) {
        if (in == null) return "";
        String s = in.toString();
        StringBuilder sb = null;
        for (int i = 0; i < s.length(); ) {
            int cp = s.codePointAt(i);
            int n = Character.charCount(cp);
            int rep = plainOf(cp);
            if (rep != cp && sb == null) {
                sb = new StringBuilder(s.length());
                sb.append(s, 0, i);
            }
            if (sb != null) sb.appendCodePoint(rep);
            i += n;
        }
        return sb == null ? s : sb.toString();
    }

    private static int plainOf(int cp) {
        if (cp == 0x210E) return 'h'; // italic small h lives outside the math block
        if (cp < 0x1D400 || cp > 0x1D7FF) return cp;
        for (int[] b : ALL_BASES) {
            if (cp >= b[0] && cp < b[0] + 26) return 'A' + (cp - b[0]);
            if (cp >= b[1] && cp < b[1] + 26) return 'a' + (cp - b[1]);
        }
        return cp;
    }

    private static int fancyCodePoint(char c) {
        if (STYLE == Style.ITALIC && c == 'h') return 0x210E;
        if (c >= 'A' && c <= 'Z') return STYLE.upperBase + (c - 'A');
        return STYLE.lowerBase + (c - 'a');
    }

    /** Marks which chars to convert, or returns null if none (fast path). */
    private static boolean[] buildMask(String s) {
        final int n = s.length();
        boolean[] mask = null;
        int i = 0;
        while (i < n) {
            while (i < n && Character.isWhitespace(s.charAt(i))) i++;
            int start = i;
            while (i < n && !Character.isWhitespace(s.charAt(i))) i++;
            if (start == i) break;
            if (isDataToken(s, start, i)) continue;
            for (int k = start; k < i; k++) {
                char c = s.charAt(k);
                if ((c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z')) {
                    if (mask == null) mask = new boolean[n];
                    mask[k] = true;
                }
            }
        }
        return mask;
    }

    /** True for tokens that are data, not words: IDs, codes, e-mails, links, amounts, usernames. */
    private static boolean isDataToken(String s, int start, int end) {
        for (int k = start; k < end; k++) {
            char c = s.charAt(k);
            if (c >= '0' && c <= '9') return true;
            if (c == '@' || c == '/' || c == '\\' || c == '_' || c == '#') return true;
            if (c == ':' && k + 2 < end && s.charAt(k + 1) == '/' && s.charAt(k + 2) == '/') return true;
            if (c == '.' && k > start && k + 1 < end
                    && Character.isLetter(s.charAt(k - 1)) && Character.isLetter(s.charAt(k + 1))) {
                return true; // example.com style
            }
        }
        return false;
    }

    // ------------------------------------------------------------------------------------
    // Applying it to the UI
    // ------------------------------------------------------------------------------------

    /** Converts every non-edit TextView under root once. Safe to call repeatedly. */
    public static void apply(View root) {
        if (root == null) return;
        if (NO_FANCY.equals(root.getTag())) return;
        if (root instanceof EditText) {
            if (LanguageManager.isTranslating()) AppTranslator.translateHint((TextView) root);
            return;
        }
        if (root instanceof TextView && LanguageManager.isTranslating()) {
            TextView t = (TextView) root;
            AppTranslator.translate(t);
            // Unicode bold only exists for A-Z/a-z, so other languages get a real bold font.
            android.graphics.Typeface tf = t.getTypeface();
            if (tf == null || !tf.isBold()) t.setTypeface(tf, android.graphics.Typeface.BOLD);
        } else if (root instanceof TextView) {
            TextView tv = (TextView) root;
            CharSequence cur = tv.getText();
            if (cur != null && cur.length() > 0) {
                CharSequence out = convert(cur);
                if (out != cur && !TextUtils.equals(out, cur)) tv.setText(out);
            }
        }
        if (root instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) root;
            for (int i = 0; i < g.getChildCount(); i++) apply(g.getChildAt(i));
        }
    }

    /** Keeps a window (activity or dialog) converted for as long as it is on screen. */
    public static void attach(Window window) {
        if (window == null) return;
        final View decor = window.getDecorView();
        if (decor == null) return;
        synchronized (ATTACHED) {
            if (ATTACHED.containsKey(decor)) return;
            ATTACHED.put(decor, Boolean.TRUE);
        }
        decor.getViewTreeObserver().addOnGlobalLayoutListener(() -> apply(decor));
        decor.post(() -> apply(decor));
    }

    public static void attach(Dialog dialog) {
        if (dialog != null) attach(dialog.getWindow());
    }

    /** Hooks every Activity of the app. Call once from Application.onCreate(). */
    public static void install(Application app) {
        AppTranslator.init(app);
        app.registerActivityLifecycleCallbacks(new Application.ActivityLifecycleCallbacks() {
            @Override public void onActivityCreated(Activity a, Bundle b) {}
            @Override public void onActivityStarted(Activity a) { attach(a.getWindow()); }
            @Override public void onActivityResumed(Activity a) { attach(a.getWindow()); }
            @Override public void onActivityPaused(Activity a) {}
            @Override public void onActivityStopped(Activity a) {}
            @Override public void onActivitySaveInstanceState(Activity a, Bundle b) {}
            @Override public void onActivityDestroyed(Activity a) {}
        });
    }

    // ------------------------------------------------------------------------------------
    // Toast (drop-in for Toast.makeText)
    // ------------------------------------------------------------------------------------

    public static Toast toast(Context context, CharSequence text, int duration) {
        return Toast.makeText(context, LanguageManager.isTranslating()
                ? AppTranslator.cached(text) : convert(text), duration);
    }

    public static Toast toast(Context context, int resId, int duration) {
        CharSequence t = context.getText(resId);
        return Toast.makeText(context, LanguageManager.isTranslating()
                ? AppTranslator.cached(t) : convert(t), duration);
    }

    // ------------------------------------------------------------------------------------
    // Dialog builders (drop-in replacements that keep dialog text fancy)
    // ------------------------------------------------------------------------------------

    /** Drop-in for MaterialAlertDialogBuilder. */
    public static class MaterialBuilder extends com.google.android.material.dialog.MaterialAlertDialogBuilder {
        public MaterialBuilder(Context context) { super(context); }
        public MaterialBuilder(Context context, int overrideThemeResId) { super(context, overrideThemeResId); }

        @Override
        public androidx.appcompat.app.AlertDialog create() {
            androidx.appcompat.app.AlertDialog d = super.create();
            attach(d);
            return d;
        }
    }

    /** Drop-in for androidx.appcompat.app.AlertDialog.Builder. */
    public static class AppCompatBuilder extends androidx.appcompat.app.AlertDialog.Builder {
        public AppCompatBuilder(Context context) { super(context); }
        public AppCompatBuilder(Context context, int themeResId) { super(context, themeResId); }

        @Override
        public androidx.appcompat.app.AlertDialog create() {
            androidx.appcompat.app.AlertDialog d = super.create();
            attach(d);
            return d;
        }
    }

    /** Drop-in for android.app.AlertDialog.Builder. */
    public static class PlatformBuilder extends android.app.AlertDialog.Builder {
        public PlatformBuilder(Context context) { super(context); }
        public PlatformBuilder(Context context, int themeResId) { super(context, themeResId); }

        @Override
        public android.app.AlertDialog create() {
            android.app.AlertDialog d = super.create();
            attach(d);
            return d;
        }
    }
}
