package com.arenax.tournament;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import com.arenax.tournament.data.FirebaseRepository;
import com.arenax.tournament.fragment.HomeFragment;
import com.arenax.tournament.fragment.LeaderboardFragment;
import com.arenax.tournament.fragment.ProfileFragment;
import com.arenax.tournament.fragment.RewardsFragment;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.messaging.FirebaseMessaging;

public class MainActivity extends BaseActivity {

    private android.view.View startupLoading;
    private final android.os.Handler startupLoadingHandler =
            new android.os.Handler(android.os.Looper.getMainLooper());
    private final Runnable startupLoadingFallback = this::hideStartupLoading;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        startupLoading = findViewById(R.id.home_startup_loading);
        if (savedInstanceState == null && getIntent().getBooleanExtra("celebrate_new_user", false)) {
            getIntent().removeExtra("celebrate_new_user");
            showWelcomeCelebration(getIntent().getStringExtra("celebrate_name"));
        }
        // Never leave the bar stuck when Firebase is offline or its first callback is delayed.
        startupLoadingHandler.postDelayed(startupLoadingFallback, 5000L);
        // Wake the payment backend and prime the Firebase token before the user
        // reaches Wallet, so Add Money does not wait for a cold server start.
        ZapUpiClient.warmUp();
        if (android.os.Build.VERSION.SDK_INT >= 33 && checkSelfPermission("android.permission.POST_NOTIFICATIONS") != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 9001);
        }
        // Already-logged-in player got banned meanwhile: kick out with the ban notice.
        com.arenax.tournament.util.BanGuard.check(this, banned -> { });
        registerPushToken();
        // Login ke baad saari app images background me encrypted zip me download.
        com.arenax.tournament.data.FirebaseRepository.keepHomeDataSynced();
        com.arenax.tournament.util.AssetSync.syncAll(this);
        // Deep-linked category browsing now opens CategoryMatchesActivity directly from
        // HomeFragment's Esports Games grid, so MainActivity no longer needs to switch
        // bottom-nav tabs based on an incoming categoryId extra.
        BottomNavigationView nav = findViewById(R.id.bottom_nav);
        nav.setOnItemSelectedListener(item -> {
            Fragment fragment;
            if (item.getItemId() == R.id.nav_leaderboard) fragment = new LeaderboardFragment();
            else if (item.getItemId() == R.id.nav_wallet) {
                startActivity(new android.content.Intent(this, WalletActivity.class));
                return true;
            }
            else if (item.getItemId() == R.id.nav_profile) fragment = new ProfileFragment();
            else fragment = new HomeFragment();
            showFragment(fragment);
            return true;
        });
        if (savedInstanceState == null) {
            int requestedTab = getIntent().getIntExtra("open_tab", R.id.nav_home);
            nav.setSelectedItemId(requestedTab);
            handleNotificationRedirect(getIntent());
        }
    }

    /** Push / inbox tap -> open the exact content the admin chose for that notification. */
    private void handleNotificationRedirect(android.content.Intent intent) {
        if (!com.arenax.tournament.util.NotificationRedirect.hasRedirect(intent)) return;
        final com.arenax.tournament.util.NotificationRedirect.Target target =
                com.arenax.tournament.util.NotificationRedirect.fromIntent(intent);
        // Consume first so rotating the phone / coming back never re-opens it.
        com.arenax.tournament.util.NotificationRedirect.consume(intent);
        com.arenax.tournament.util.NotificationRedirect.consume(getIntent());
        // Post so the bottom-nav fragment is in place before the target screen opens on top.
        findViewById(android.R.id.content).post(() ->
                com.arenax.tournament.util.NotificationRedirect.open(this, target));
    }

    private void registerPushToken() {
        if (!FirebaseRepository.isFirebaseAvailable(this)) return;
        if (FirebaseRepository.currentUser() == null) return;
        FirebaseMessaging.getInstance().getToken().addOnSuccessListener(token ->
                FirebaseRepository.users().child(FirebaseRepository.currentUser().getUid()).child("fcmToken").setValue(token));
    }

    @Override
    protected void onNewIntent(android.content.Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        int requestedTab = intent.getIntExtra("open_tab", -1);
        if (requestedTab != -1) {
            BottomNavigationView nav = findViewById(R.id.bottom_nav);
            if (nav != null) nav.setSelectedItemId(requestedTab);
        }
        handleNotificationRedirect(intent);
    }

    private void showFragment(Fragment fragment) {
        getSupportFragmentManager().beginTransaction()
                .setCustomAnimations(android.R.anim.fade_in, android.R.anim.fade_out)
                .replace(R.id.fragment_container, fragment)
                .commit();
    }

    /** Called by HomeFragment after the first live home-data callback arrives. */
    public void hideStartupLoading() {
        if (startupLoading == null || startupLoading.getVisibility() != android.view.View.VISIBLE) return;
        startupLoadingHandler.removeCallbacks(startupLoadingFallback);
        startupLoading.animate().alpha(0f).setDuration(180L).withEndAction(() -> {
            startupLoading.setVisibility(android.view.View.GONE);
            startupLoading.setAlpha(1f);
        }).start();
    }

    @Override
    protected void onDestroy() {
        startupLoadingHandler.removeCallbacks(startupLoadingFallback);
        super.onDestroy();
    }

    /** Confetti + welcome card shown once right after a brand-new account is created. */
    private void showWelcomeCelebration(String name) {
        final android.view.ViewGroup root = findViewById(android.R.id.content);
        final float d = getResources().getDisplayMetrics().density;

        final android.widget.TextView card = new android.widget.TextView(this);
        String first = name == null ? "" : name.trim().split("\\s+")[0];
        card.setText("\uD83C\uDF89 Welcome" + (first.isEmpty() ? "" : ", " + first) + "!\nYour STARX24 journey starts now");
        card.setTextColor(0xFFFFD700);
        card.setTextSize(17);
        card.setTypeface(null, android.graphics.Typeface.BOLD);
        card.setGravity(android.view.Gravity.CENTER);
        card.setPadding((int) (24 * d), (int) (18 * d), (int) (24 * d), (int) (18 * d));
        android.graphics.drawable.GradientDrawable bg = new android.graphics.drawable.GradientDrawable();
        bg.setColor(0xEE101010);
        bg.setCornerRadius(24 * d);
        bg.setStroke((int) (2 * d), 0xFFFFD700);
        card.setBackground(bg);
        card.setElevation(12 * d);
        android.widget.FrameLayout.LayoutParams lp = new android.widget.FrameLayout.LayoutParams(-2, -2, android.view.Gravity.CENTER);
        lp.leftMargin = lp.rightMargin = (int) (24 * d);
        card.setAlpha(0f);
        card.setScaleX(0.6f);
        card.setScaleY(0.6f);
        root.addView(card, lp);
        card.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(450)
                .setInterpolator(new android.view.animation.OvershootInterpolator(1.4f)).start();
        card.postDelayed(() -> card.animate().alpha(0f).setDuration(500)
                .withEndAction(() -> root.removeView(card)).start(), 3200);

        final ConfettiView confetti = new ConfettiView(this);
        confetti.setClickable(false);
        confetti.setElevation(20 * d);
        root.addView(confetti, new android.widget.FrameLayout.LayoutParams(-1, -1));
        confetti.start(() -> root.post(() -> root.removeView(confetti)));
        try { card.performHapticFeedback(android.view.HapticFeedbackConstants.CONFIRM); } catch (Throwable ignored) { }
    }
}
