package com.arenax.tournament;

import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/**
 * Customer Support page (white theme). Lists the common problems with a short fix for each and
 * a "Contact Support on Telegram" button. The Telegram link is whatever the admin saved under
 * Platform Links -> Customer Support Link (see {@link SupportLinks#openTelegramSupport}).
 */
public class CustomerSupportActivity extends BaseActivity {

    private static final String[][] PROBLEMS = {
            {"Account Problem", "Login, password, profile or email issue. Log out and log in again; if it still fails, message us with your registered email."},
            {"Add Money / Payment", "Money deducted but not added? Wait a few minutes, then send us the payment screenshot and UTR / transaction ID."},
            {"Withdrawal Problem", "Check your payout details in Wallet. Pending withdrawals are processed by the team; contact us if it takes too long."},
            {"Registration Problem", "Unable to join a tournament? Make sure your wallet balance, game ID and slot availability are correct."},
            {"Room ID / Password", "Room details are shown inside the joined match shortly before start time. Contact us if they have not appeared."},
            {"Result / Reward Problem", "Result or prize missing? Send the match name and your game ID so we can verify it."},
            {"Team Problem", "Issue with team members or squad slots. Tell us the match name and team details."},
            {"Report a Player", "Found cheating or abuse? Send the player's game ID and proof (screenshot / video)."},
            {"Technical Problem", "App crash or bug. Update to the latest version and send us a screenshot of the issue."},
            {"Other", "Anything else \u2014 just message us on Telegram and we will help."}
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(buildScreen());
    }

    private View buildScreen() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.parseColor("#F5F7FB"));

        // ---- top bar
        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setBackgroundColor(Color.WHITE);
        top.setPadding(dp(8), dp(8), dp(16), dp(8));
        top.setElevation(dp(2));
        TextView back = label("\u2039", 34, Color.parseColor("#17233F"), true);
        back.setGravity(Gravity.CENTER);
        back.setOnClickListener(v -> finish());
        top.addView(back, new LinearLayout.LayoutParams(dp(46), dp(46)));
        LinearLayout heading = new LinearLayout(this);
        heading.setOrientation(LinearLayout.VERTICAL);
        heading.addView(label("Customer Support", 19, Color.parseColor("#17233F"), true));
        heading.addView(label("We are here to help you", 12, Color.parseColor("#6B7690"), false));
        top.addView(heading, new LinearLayout.LayoutParams(0, -2, 1));
        root.addView(top, new LinearLayout.LayoutParams(-1, -2));

        // ---- scrolling body
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(dp(16), dp(16), dp(16), dp(24));

        body.addView(telegramCard());

        TextView title = label("Common problems", 15, Color.parseColor("#17233F"), true);
        LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(-2, -2);
        tlp.topMargin = dp(20);
        tlp.bottomMargin = dp(8);
        body.addView(title, tlp);

        for (String[] item : PROBLEMS) body.addView(problemCard(item[0], item[1]));

        scroll.addView(body, new ScrollView.LayoutParams(-1, -2));
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        return root;
    }

    /** Big blue card with the Telegram button. */
    private View telegramCard() {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(18), dp(18), dp(18), dp(18));
        card.setBackground(round(Color.parseColor("#EAF2FF"), Color.parseColor("#9CC4FF"), 18));

        card.addView(label("Need help? Talk to us", 17, Color.parseColor("#17233F"), true));
        TextView sub = label("Tap the button below to open our Customer Support on Telegram.",
                13, Color.parseColor("#4A5878"), false);
        sub.setPadding(0, dp(4), 0, dp(14));
        card.addView(sub);

        TextView button = label("Contact Support on Telegram  \u2192", 15, Color.WHITE, true);
        button.setGravity(Gravity.CENTER);
        button.setBackground(round(Color.parseColor("#229ED9"), 0, 14));
        button.setClickable(true);
        button.setOnClickListener(v -> SupportLinks.openTelegramSupport(this));
        card.addView(button, new LinearLayout.LayoutParams(-1, dp(50)));
        return card;
    }

    private View problemCard(String name, String help) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(16), dp(14), dp(16), dp(14));
        card.setBackground(round(Color.WHITE, Color.parseColor("#E3E8F2"), 14));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.bottomMargin = dp(10);
        card.setLayoutParams(lp);

        card.addView(label(name, 14.5f, Color.parseColor("#17233F"), true));
        TextView text = label(help, 13, Color.parseColor("#5A6784"), false);
        text.setLineSpacing(0, 1.1f);
        text.setPadding(0, dp(4), 0, 0);
        card.addView(text);
        return card;
    }

    private GradientDrawable round(int fill, int stroke, int radiusDp) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(fill);
        d.setCornerRadius(dp(radiusDp));
        if (stroke != 0) d.setStroke(dp(1), stroke);
        return d;
    }

    private TextView label(String text, float size, int color, boolean bold) {
        TextView v = new TextView(this);
        v.setText(text);
        v.setTextSize(size);
        v.setTextColor(color);
        v.setTypeface(null, bold ? Typeface.BOLD : Typeface.NORMAL);
        return v;
    }

    private int dp(float value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}
