package com.arenax.tournament.util;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.net.Uri;
import android.os.Build;

import com.arenax.tournament.AdminAppControlActivity;
import com.arenax.tournament.BannedActivity;
import com.arenax.tournament.BuildConfig;
import com.arenax.tournament.CrashActivity;
import com.arenax.tournament.MaintenanceActivity;
import com.arenax.tournament.data.FirebaseRepository;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;

/**
 * Maintenance mode + update notice, controlled by the admin from Platform controls.
 *
 * Firebase node: appConfig/status
 *   maintenance { enabled, title, message, eta, contactUrl }
 *   update      { enabled, force, versionName, versionCode, title, description, link, adminLink }
 *
 * Every screen (user + admin) calls {@link #gate(Activity)} from BaseActivity.onResume.
 * It is fail-open: if Firebase is unreachable the app keeps working normally.
 */
public final class AppStatus {

    private AppStatus() { }

    public static final class State {
        public boolean mEnabled;
        public String mTitle = "", mMessage = "", mEta = "", mContact = "";
        public boolean uEnabled, uForce;
        public long uCode;
        public long uStamp;
        public String uName = "", uTitle = "", uDesc = "", uLink = "", uAdminLink = "";
    }

    public interface Callback { void onState(State state); }

    private static final long REFRESH_MS = 15_000L;
    private static State cached;
    private static long cachedAt;
    private static boolean adminNoticeShown;
    private static String updateShownKey = "";
    private static java.lang.ref.WeakReference<Activity> resumed;
    private static boolean liveAttached;
    private static android.app.Dialog updateDialog;

    public static boolean isUserApp() {
        return "user".equals(BuildConfig.FLAVOR);
    }

    public static DatabaseReference ref() {
        return FirebaseRepository.appConfig().child("status");
    }

    public static State last() { return cached; }

    public static State parse(DataSnapshot s) {
        State st = new State();
        DataSnapshot m = s.child("maintenance");
        st.mEnabled = Boolean.TRUE.equals(m.child("enabled").getValue(Boolean.class));
        st.mTitle = str(m.child("title"));
        st.mMessage = str(m.child("message"));
        st.mEta = str(m.child("eta"));
        st.mContact = str(m.child("contactUrl"));
        DataSnapshot u = s.child("update");
        st.uEnabled = Boolean.TRUE.equals(u.child("enabled").getValue(Boolean.class));
        st.uForce = Boolean.TRUE.equals(u.child("force").getValue(Boolean.class));
        Long code = u.child("versionCode").getValue(Long.class);
        st.uCode = code == null ? 0L : code;
        Long stamp = u.child("updatedAt").getValue(Long.class);
        st.uStamp = stamp == null ? 0L : stamp;
        st.uName = str(u.child("versionName"));
        st.uTitle = str(u.child("title"));
        st.uDesc = str(u.child("description"));
        st.uLink = str(u.child("link"));
        st.uAdminLink = str(u.child("adminLink"));
        return st;
    }

    private static String str(DataSnapshot s) {
        String v = s.getValue(String.class);
        return v == null ? "" : v.trim();
    }

    /** One-shot read (used by the Retry button and by the gate). */
    public static void fetch(Context ctx, Callback cb) {
        try {
            if (!FirebaseRepository.isReady(ctx)) { cb.onState(null); return; }
            ref().get().addOnCompleteListener(task -> {
                if (task.isSuccessful() && task.getResult() != null) {
                    cached = parse(task.getResult());
                    cachedAt = System.currentTimeMillis();
                    cb.onState(cached);
                } else {
                    cb.onState(null);
                }
            });
        } catch (RuntimeException e) {
            cb.onState(null);
        }
    }

    /** Live listener for MaintenanceActivity so it closes the moment the admin turns maintenance off. */
    public static ValueEventListener listen(Callback cb) {
        ValueEventListener l = new ValueEventListener() {
            @Override public void onDataChange(DataSnapshot snapshot) {
                cached = parse(snapshot);
                cachedAt = System.currentTimeMillis();
                cb.onState(cached);
            }
            @Override public void onCancelled(DatabaseError error) { }
        };
        try { ref().addValueEventListener(l); } catch (RuntimeException ignored) { }
        return l;
    }

    public static void unlisten(ValueEventListener l) {
        try { if (l != null) ref().removeEventListener(l); } catch (RuntimeException ignored) { }
    }

    /** Installed app's versionCode. */
    public static long installedCode(Context ctx) {
        try {
            PackageInfo pi = ctx.getPackageManager().getPackageInfo(ctx.getPackageName(), 0);
            return Build.VERSION.SDK_INT >= 28 ? pi.getLongVersionCode() : pi.versionCode;
        } catch (Exception e) {
            return Long.MAX_VALUE; // unknown: never nag
        }
    }

    public static String installedName(Context ctx) {
        try {
            String n = ctx.getPackageManager().getPackageInfo(ctx.getPackageName(), 0).versionName;
            return n == null ? "" : n;
        } catch (Exception e) {
            return "";
        }
    }

    // ------------------------------------------------------------------------------------------

    /**
     * Launch-time check, run by the launcher (LoginActivity) BEFORE any login / auto-login routing.
     * If a newer build is published the update dialog is shown first; "Later" (optional update)
     * continues to {@code proceed}, a forced update never continues. Fail-open: offline, slow
     * (> 3.5 s) or no update -> {@code proceed} runs straight away.
     */
    public static void launchGate(Activity a, Runnable proceed) {
        final boolean[] done = {false};
        final android.os.Handler h = new android.os.Handler(android.os.Looper.getMainLooper());
        launchHold = true;
        final Runnable go = () -> {
            if (done[0]) return;
            done[0] = true;
            h.removeCallbacksAndMessages(null);
            launchHold = false;
            if (a.isFinishing() || a.isDestroyed()) return;
            proceed.run();
        };
        h.postDelayed(go, 3500L);
        try {
            fetch(a, state -> {
                if (done[0] || a.isFinishing() || a.isDestroyed()) return;
                if (state == null || !state.uEnabled || !needsUpdate(a, state)) { go.run(); return; }
                h.removeCallbacksAndMessages(null); // dialog is up: wait for the player, no timeout
                done[0] = true;
                updateShownKey = updateKey(state);
                updateDialog = StatusUi.showUpdateDialog(a, state, linkFor(state));
                if (state.uForce) return; // blocked until they update
                updateDialog.setOnDismissListener(d -> {
                    launchHold = false;
                    if (!a.isFinishing() && !a.isDestroyed()) proceed.run();
                });
            });
        } catch (RuntimeException e) {
            go.run();
        }
    }

    private static boolean launchHold;

    /** Same code re-published (new text / time) counts as a new notice, so it pops up again. */
    private static String updateKey(State s) { return s.uCode + ":" + s.uStamp; }

    /** Called from BaseActivity.onPause so a live notice never targets a screen that is not visible. */
    public static void paused(Activity a) {
        if (resumed != null && resumed.get() == a) resumed = null;
    }

    /** Listens once for the whole process: the moment the admin publishes (or changes) an update
     *  notice, the floating dialog pops up on whatever screen the player is looking at. */
    private static void attachLive() {
        if (liveAttached) return;
        liveAttached = true;
        try {
            ref().addValueEventListener(new ValueEventListener() {
                @Override public void onDataChange(DataSnapshot snapshot) {
                    State st = parse(snapshot);
                    cached = st;
                    cachedAt = System.currentTimeMillis();
                    Activity a = resumed == null ? null : resumed.get();
                    if (a == null || a.isFinishing() || a.isDestroyed() || launchHold) return;
                    if (a instanceof MaintenanceActivity || a instanceof CrashActivity
                            || a instanceof BannedActivity || a instanceof AdminAppControlActivity) return;
                    apply(a, st);
                }
                @Override public void onCancelled(DatabaseError error) { liveAttached = false; }
            });
        } catch (RuntimeException e) { liveAttached = false; }
    }

    private static String linkFor(State s) { return isUserApp() ? s.uLink : s.uAdminLink; }

    private static boolean needsUpdate(Context c, State s) {
        if (!isUserApp() && linkFor(s).isEmpty()) return false;
        return s.uCode > 0 && installedCode(c) < s.uCode;
    }

    public static void gate(Activity a) {
        if (a == null || a.isFinishing()) return;
        resumed = new java.lang.ref.WeakReference<>(a);
        if (launchHold) return; // launcher is still running its own pre-login check
        if (a instanceof MaintenanceActivity || a instanceof CrashActivity
                || a instanceof BannedActivity || a instanceof AdminAppControlActivity) return;
        attachLive();
        long now = System.currentTimeMillis();
        if (cached != null && now - cachedAt < REFRESH_MS) {
            apply(a, cached);
            return;
        }
        fetch(a, state -> {
            if (state == null || a.isFinishing() || a.isDestroyed()) return;
            apply(a, state);
        });
    }

    private static void apply(Activity a, State s) {
        if (s.mEnabled) {
            if (isUserApp()) {
                a.startActivity(new Intent(a, MaintenanceActivity.class));
                return;
            }
            // Admin / messenger apps: show the same screen once per launch, with a way through,
            // so an admin can never lock themselves out of the switch that turns it off.
            if (!adminNoticeShown) {
                adminNoticeShown = true;
                Intent i = new Intent(a, MaintenanceActivity.class);
                i.putExtra(MaintenanceActivity.EXTRA_CAN_BYPASS, true);
                a.startActivity(i);
                return;
            }
        }
        if (s.uEnabled) maybeShowUpdate(a, s);
    }

    private static void maybeShowUpdate(Activity a, State s) {
        String link = linkFor(s);
        if (!needsUpdate(a, s)) return;
        if (updateDialog != null && updateDialog.isShowing()) return;
        if (!s.uForce && updateShownKey.equals(updateKey(s))) return; // optional: once per publish
        updateShownKey = updateKey(s);
        updateDialog = StatusUi.showUpdateDialog(a, s, link);
    }

    public static void openLink(Context ctx, String raw) {
        try {
            String url = raw == null ? "" : raw.trim();
            if (url.isEmpty()) {
                FancyText.toast(ctx, "Link is not available right now.", android.widget.Toast.LENGTH_SHORT).show();
                return;
            }
            if (url.startsWith("@")) url = "https://t.me/" + url.substring(1);
            if (!url.startsWith("http://") && !url.startsWith("https://")) url = "https://" + url;
            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            if (!(ctx instanceof Activity)) i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            ctx.startActivity(i);
        } catch (RuntimeException e) {
            FancyText.toast(ctx, "Link is not available right now.", android.widget.Toast.LENGTH_SHORT).show();
        }
    }
}
