package com.arenax.tournament.adapter;

import com.arenax.tournament.util.ImageLoader;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.arenax.tournament.R;
import com.arenax.tournament.model.GameMode;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.google.android.material.button.MaterialButton;

import java.util.List;

public class GameModeAdapter extends RecyclerView.Adapter<GameModeAdapter.Holder> {
    public interface OnDeleteClick { void onDelete(GameMode mode); }
    public interface OnModeClick { void onClick(GameMode mode); }

    private final List<GameMode> items;
    private final boolean adminMode;
    private final OnDeleteClick deleteListener;
    private final OnModeClick clickListener;
    private OnModeClick editListener;
    // While the first Firebase snapshot has not arrived, show grey pulsing placeholder cards
    // instead of an empty gap.
    private static final int SKELETON_COUNT = 6;
    private boolean loading = false;

    public void setLoading(boolean loading) {
        if (this.loading == loading) return;
        this.loading = loading;
        notifyDataSetChanged();
    }

    private boolean showSkeleton() { return loading && items.isEmpty(); }

    public GameModeAdapter(List<GameMode> items, boolean adminMode, OnDeleteClick deleteListener) {
        this(items, adminMode, deleteListener, null);
    }

    public GameModeAdapter(List<GameMode> items, boolean adminMode, OnDeleteClick deleteListener,
                           OnModeClick clickListener) {
        this.items = items;
        this.adminMode = adminMode;
        this.deleteListener = deleteListener;
        this.clickListener = clickListener;
    }

    /** Admin-only: long-press a category card to edit its title/image/slot position. */
    public void setOnEditClick(OnModeClick editListener) {
        this.editListener = editListener;
    }

    @NonNull
    @Override
    public Holder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new Holder(LayoutInflater.from(parent.getContext()).inflate(R.layout.item_game_mode, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull Holder holder, int position) {
        if (showSkeleton()) {
            bindSkeleton(holder);
            return;
        }
        holder.stopPulse();
        holder.statusDot.setVisibility(View.VISIBLE);
        GameMode mode = items.get(position);
        holder.title.setText(mode.getTitle());
        holder.users.setText(String.valueOf(mode.getTotalUsers()));
        holder.statusDot.setBackgroundResource(mode.isOnline() ? R.drawable.dot_status_online : R.drawable.dot_status_offline);
        ImageLoader.load(holder.image, mode.getImageUrl());
        holder.delete.setVisibility(adminMode ? View.VISIBLE : View.GONE);
        holder.delete.setOnClickListener(v -> {
            if (deleteListener != null) deleteListener.onDelete(mode);
        });
        // Visible pencil button is the primary way into edit (title/image/online-offline
        // toggle) — long-press on the card still works too, but shouldn't be the only way in.
        holder.edit.setVisibility(adminMode ? View.VISIBLE : View.GONE);
        holder.edit.setOnClickListener(v -> {
            if (editListener != null) editListener.onClick(mode);
        });
        if (holder.position != null) {
            if (adminMode) {
                holder.position.setVisibility(View.VISIBLE);
                holder.position.setText("#" + mode.getDisplayOrder());
            } else {
                holder.position.setVisibility(View.GONE);
            }
        }
        holder.itemView.setOnClickListener(v -> {
            if (clickListener != null) clickListener.onClick(mode);
        });
        holder.itemView.setOnLongClickListener(v -> {
            if (adminMode && editListener != null) {
                editListener.onClick(mode);
                return true;
            }
            return false;
        });
    }

    private void bindSkeleton(Holder holder) {
        ImageLoader.clear(holder.image);
        holder.image.setImageDrawable(new android.graphics.drawable.ColorDrawable(0xFFDDE3EC));
        holder.title.setText("");
        holder.users.setText("");
        holder.statusDot.setVisibility(View.INVISIBLE);
        holder.delete.setVisibility(View.GONE);
        holder.edit.setVisibility(View.GONE);
        if (holder.position != null) holder.position.setVisibility(View.GONE);
        holder.itemView.setOnClickListener(null);
        holder.itemView.setOnLongClickListener(null);
        holder.itemView.setClickable(false);
        holder.startPulse();
    }

    @Override
    public void onViewRecycled(@NonNull Holder holder) {
        holder.stopPulse();
        super.onViewRecycled(holder);
    }

    @Override
    public int getItemCount() { return showSkeleton() ? SKELETON_COUNT : items.size(); }

    static class Holder extends RecyclerView.ViewHolder {
        ImageView image;
        TextView title;
        MaterialButton delete;
        MaterialButton edit;
        TextView position;
        TextView users;
        View statusDot;
        private android.animation.ObjectAnimator pulse;

        void startPulse() {
            if (pulse != null) return;
            pulse = android.animation.ObjectAnimator.ofFloat(itemView, View.ALPHA, 1f, 0.45f);
            pulse.setDuration(700);
            pulse.setRepeatMode(android.animation.ValueAnimator.REVERSE);
            pulse.setRepeatCount(android.animation.ValueAnimator.INFINITE);
            pulse.start();
        }

        void stopPulse() {
            if (pulse != null) { pulse.cancel(); pulse = null; }
            itemView.setAlpha(1f);
        }

        Holder(@NonNull View view) {
            super(view);
            image = view.findViewById(R.id.game_mode_image);
            title = view.findViewById(R.id.game_mode_title);
            delete = view.findViewById(R.id.game_mode_delete);
            edit = view.findViewById(R.id.game_mode_edit);
            position = view.findViewById(R.id.game_mode_position);
            users = view.findViewById(R.id.game_mode_users);
            statusDot = view.findViewById(R.id.game_mode_status_dot);
        }
    }
}
