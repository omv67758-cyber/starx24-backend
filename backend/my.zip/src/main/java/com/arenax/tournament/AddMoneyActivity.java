package com.arenax.tournament;


import com.arenax.tournament.util.FancyText;
import android.content.ComponentName;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.browser.customtabs.CustomTabColorSchemeParams;
import androidx.browser.customtabs.CustomTabsClient;
import androidx.browser.customtabs.CustomTabsIntent;
import androidx.browser.customtabs.CustomTabsServiceConnection;
import androidx.browser.customtabs.CustomTabsSession;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;

import com.arenax.tournament.data.FirebaseRepository;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Add Money page. Opened by tapping the Coin Balance card on the Wallet screen.
 * Pick a quick amount or type your own (min ₹10, max ₹10000), tap "Proceed to pay"
 * and the ZapUPI order is created through the backend and opened in a Custom Tab.
 * Payment is UPI only.
 */
public class AddMoneyActivity extends BaseActivity {

    public static final int MIN_AMOUNT = 10;
    public static final int MAX_AMOUNT = 10000;

    private static final int[] AMOUNTS = {10, 20, 50, 100, 200, 500};

    // Same keys WalletActivity uses so a payment started here is still verified
    // by the wallet screen if the app gets killed while the Custom Tab is open.
    private static final String WALLET_PREFS = "wallet";
    private static final String PREF_PENDING_ORDER_ID = "pending_order_id";

    private long balance;
    private int selectedAmount = AMOUNTS[0];

    private final List<View> amountChips = new ArrayList<>();

    private TextView balancePill, balanceHero, balanceWithdraw, amountError, proceedText;
    private EditText customAmount;
    private View inputBox;
    private View proceedButton;

    private ValueEventListener balanceListener;
    private CustomTabsSession customTabsSession;
    private CustomTabsServiceConnection customTabsConnection;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        WindowCompat.setDecorFitsSystemWindows(getWindow(), false);
        setContentView(R.layout.activity_add_money);

        // Edge-to-edge: keep the header/footer clear of the status + navigation bars.
        View root = findViewById(R.id.am_root);
        ViewCompat.setOnApplyWindowInsetsListener(root, (v, insets) -> {
            Insets bars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            Insets ime = insets.getInsets(WindowInsetsCompat.Type.ime());
            v.setPadding(0, bars.top, 0, Math.max(bars.bottom, ime.bottom));
            return insets;
        });

        // Wake the backend + Firebase token now so "Proceed to pay" is quick.
        ZapUpiClient.warmUp();
        warmUpCustomTabs();

        balancePill = findViewById(R.id.am_balance_pill);
        balanceHero = findViewById(R.id.am_balance_hero);
        balanceWithdraw = findViewById(R.id.am_balance_withdraw);
        amountError = findViewById(R.id.am_amount_error);
        proceedText = findViewById(R.id.am_proceed_text);
        customAmount = findViewById(R.id.am_custom_amount);
        inputBox = findViewById(R.id.am_input_box);
        proceedButton = findViewById(R.id.am_proceed);

        findViewById(R.id.am_back).setOnClickListener(v -> finish());

        buildAmountChips();
        setupCustomAmount();
        renderBalance();
        loadWalletBalance();

        proceedButton.setOnClickListener(v -> onProceed());
        findViewById(R.id.am_withdraw).setOnClickListener(v -> WithdrawDialog.show(this, balance));
    }

    // ---------------------------------------------------------------- amounts

    private void buildAmountChips() {
        LinearLayout row1 = findViewById(R.id.am_amount_row_1);
        LinearLayout row2 = findViewById(R.id.am_amount_row_2);
        LayoutInflater inflater = LayoutInflater.from(this);
        int margin = dp(3);

        for (int i = 0; i < AMOUNTS.length; i++) {
            LinearLayout row = i < (AMOUNTS.length + 1) / 2 ? row1 : row2;
            View chip = inflater.inflate(R.layout.item_add_money_amount, row, false);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(40), 1f);
            lp.setMargins(margin, margin, margin, margin);
            chip.setLayoutParams(lp);

            final int amount = AMOUNTS[i];
            ((TextView) chip.findViewById(R.id.am_chip_text)).setText(CoinEmoji.EMOJI + " " + amount);
            chip.setOnClickListener(v -> {
                // Picking a chip replaces whatever was typed in the custom field.
                customAmount.setText("");
                customAmount.clearFocus();
                hideKeyboard();
                selectAmount(amount);
            });
            row.addView(chip);
            amountChips.add(chip);
        }
        selectAmount(AMOUNTS[0]); // ₹10 is pre-selected
    }

    /** amount <= 0 clears the chip selection (used while a custom amount is typed). */
    private void selectAmount(int amount) {
        selectedAmount = amount;
        for (int i = 0; i < amountChips.size(); i++) {
            View chip = amountChips.get(i);
            boolean on = AMOUNTS[i] == amount;
            chip.setSelected(on);
            chip.findViewById(R.id.am_check).setVisibility(on ? View.VISIBLE : View.GONE);
        }
        hideAmountError();
        updateProceedLabel();
    }

    private void setupCustomAmount() {
        customAmount.setOnFocusChangeListener((v, hasFocus) -> inputBox.setSelected(hasFocus));
        customAmount.setOnEditorActionListener((v, actionId, event) -> {
            hideKeyboard();
            customAmount.clearFocus();
            return true;
        });
        customAmount.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (s.length() > 0) selectAmount(0); // typing overrides the chips
                else if (selectedAmount <= 0) selectAmount(AMOUNTS[0]);
                hideAmountError();
                updateProceedLabel();
            }
            @Override public void afterTextChanged(Editable s) { }
        });
    }

    /** Amount currently chosen (custom field wins over chips), or -1 if the custom field isn't a number. */
    private int currentAmount() {
        String raw = customAmount.getText().toString().trim();
        if (raw.isEmpty()) return selectedAmount;
        try {
            return Integer.parseInt(raw);
        } catch (NumberFormatException e) {
            return -1;
        }
    }

    private boolean isValidAmount(int amount) {
        return amount >= MIN_AMOUNT && amount <= MAX_AMOUNT;
    }

    private void updateProceedLabel() {
        int amount = currentAmount();
        proceedText.setText(isValidAmount(amount) ? "PROCEED TO PAY  ₹" + amount : "PROCEED TO PAY");
    }

    private void showAmountError(String message) {
        amountError.setText(message);
        amountError.setVisibility(View.VISIBLE);
    }

    private void hideAmountError() {
        amountError.setVisibility(View.GONE);
    }

    private void hideKeyboard() {
        InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
        if (imm != null) imm.hideSoftInputFromWindow(customAmount.getWindowToken(), 0);
    }

    private void onProceed() {
        int amount = currentAmount();
        if (amount < MIN_AMOUNT) {
            showAmountError("Minimum amount is ₹" + MIN_AMOUNT);
            return;
        }
        if (amount > MAX_AMOUNT) {
            showAmountError("Maximum amount is ₹" + MAX_AMOUNT);
            return;
        }
        hideKeyboard();
        startPayment(amount);
    }

    // ---------------------------------------------------------------- payment

    private void startPayment(int amount) {
        if (!isValidAmount(amount)) {
            showAmountError("Enter an amount between ₹" + MIN_AMOUNT + " and ₹" + MAX_AMOUNT);
            return;
        }
        // Block duplicate taps while the backend/provider wakes up.
        setProceedEnabled(false);
        toast(getString(R.string.wallet_creating_order));
        String mobile = getSharedPreferences("profile", MODE_PRIVATE).getString("phone", "");
        ZapUpiClient.createOrder(amount, mobile, new ZapUpiClient.Callback() {
            @Override public void onSuccess(String paymentUrl, String orderId) {
                // Survives the app being killed while the Custom Tab is in front,
                // so it can be verified + credited the moment the user is back.
                getSharedPreferences(WALLET_PREFS, MODE_PRIVATE).edit()
                        .putString(PREF_PENDING_ORDER_ID, orderId).apply();
                openInCustomTab(paymentUrl);
            }
            @Override public void onError(String message) {
                setProceedEnabled(true);
                // A dialog (not a Toast) so the real server error stays readable.
                new FancyText.AppCompatBuilder(AddMoneyActivity.this)
                        .setTitle("Could not open payment page")
                        .setMessage(message == null ? "Something went wrong. Please try again." : message)
                        .setPositiveButton("OK", null)
                        .show();
            }
        });
    }

    private void setProceedEnabled(boolean enabled) {
        proceedButton.setEnabled(enabled);
        proceedButton.setAlpha(enabled ? 1f : 0.6f);
    }

    @Override protected void onResume() {
        super.onResume();
        // Back from the payment page (paid or not): unlock the button and re-check the order.
        setProceedEnabled(true);
        verifyPendingOrderIfAny();
    }

    private void verifyPendingOrderIfAny() {
        SharedPreferences prefs = getSharedPreferences(WALLET_PREFS, MODE_PRIVATE);
        String orderId = prefs.getString(PREF_PENDING_ORDER_ID, null);
        if (orderId == null) return;

        ZapUpiClient.verifyOrder(orderId, new ZapUpiClient.VerifyCallback() {
            @Override public void onResult(String status) {
                if ("credited".equals(status) || "failed".equals(status)) {
                    prefs.edit().remove(PREF_PENDING_ORDER_ID).apply();
                    if ("credited".equals(status)) toast(getString(R.string.wallet_add_success));
                }
                // "pending" stays in prefs; the next onResume retries it.
            }
            @Override public void onError(String message) {
                // Silent: the webhook may still credit it, and onResume retries.
            }
        });
    }

    private void warmUpCustomTabs() {
        try {
            String packageName = CustomTabsClient.getPackageName(this, null);
            if (packageName == null) return;
            customTabsConnection = new CustomTabsServiceConnection() {
                @Override public void onCustomTabsServiceConnected(ComponentName name, CustomTabsClient client) {
                    client.warmup(0L);
                    customTabsSession = client.newSession(null);
                }
                @Override public void onServiceDisconnected(ComponentName name) {
                    customTabsSession = null;
                }
            };
            CustomTabsClient.bindCustomTabsService(this, packageName, customTabsConnection);
        } catch (Exception ignored) {
            // Best effort only; openInCustomTab() falls back to a plain launch.
        }
    }

    private void openInCustomTab(String url) {
        try {
            if (customTabsSession != null) {
                customTabsSession.mayLaunchUrl(Uri.parse(url), null, null);
            }
            CustomTabColorSchemeParams colorParams = new CustomTabColorSchemeParams.Builder()
                    .setToolbarColor(0xFF5B3DF5)
                    .build();
            CustomTabsIntent.Builder builder = customTabsSession != null
                    ? new CustomTabsIntent.Builder(customTabsSession)
                    : new CustomTabsIntent.Builder();
            CustomTabsIntent intent = builder
                    .setDefaultColorSchemeParams(colorParams)
                    .setShowTitle(true)
                    .build();
            intent.launchUrl(this, Uri.parse(url));
        } catch (Exception e) {
            try {
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
            } catch (Exception e2) {
                setProceedEnabled(true);
                toast("Could not open payment page");
            }
        }
    }

    // ---------------------------------------------------------------- balance

    private void loadWalletBalance() {
        FirebaseUser user = FirebaseRepository.currentUser();
        if (user == null) return;
        balanceListener = new ValueEventListener() {
            @Override public void onDataChange(DataSnapshot snapshot) {
                Long value = snapshot.getValue(Long.class);
                balance = value == null ? 0L : value;
                renderBalance();
            }
            @Override public void onCancelled(DatabaseError error) {
                toast("Could not load wallet balance.");
            }
        };
        FirebaseRepository.users().child(user.getUid()).child("wallet").child("balance")
                .addValueEventListener(balanceListener);
    }

    private void renderBalance() {
        String text = String.format(Locale.US, "%,d", balance);
        balancePill.setText(text);
        balanceHero.setText(text);
        balanceWithdraw.setText(text);
    }

    @Override protected void onDestroy() {
        FirebaseUser user = FirebaseRepository.currentUser();
        if (user != null && balanceListener != null) {
            FirebaseRepository.users().child(user.getUid()).child("wallet").child("balance")
                    .removeEventListener(balanceListener);
        }
        if (customTabsConnection != null) {
            try { unbindService(customTabsConnection); } catch (Exception ignored) { }
            customTabsConnection = null;
            customTabsSession = null;
        }
        super.onDestroy();
    }

    // ---------------------------------------------------------------- helpers

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density);
    }

    private void toast(String message) {
        FancyText.toast(this, message, Toast.LENGTH_LONG).show();
    }
}
