package com.arenax.tournament.util;

import com.arenax.tournament.BuildConfig;
import com.google.android.gms.tasks.Tasks;
import com.google.firebase.auth.FirebaseAuth;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;
import java.util.List;

import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

/**
 * Sends push notifications.
 *
 * STRATEGY (v2 — private key removed from the APK):
 * The app never ships a private service-account key. Instead, all pushes
 * are relayed through the StarX24 backend which holds the Firebase service
 * account (already configured on Render):
 *
 *     POST {STARX_API_BASE_URL}/admin/sendPush
 *     Authorization: Bearer <Firebase ID token of the admin>
 *     { "tokens": [...], "title": "...", "body": "...", "type": "..." }
 *
 * The backend verifies the caller is an admin and sends via FCM v1
 * (sendEachForMulticast) — see backend/index.js "admin/sendPush".
 *
 * The legacy accessToken parameter is kept in the public signatures so that
 * existing call-sites (AdminActivity, RoomControlActivity,
 * RoomReleaseAlarmReceiver) continue to compile unchanged; it is simply
 * ignored by the relay path.
 *
 * NOTE: this class must be called from a background thread, never the main thread.
 */
public class FcmSender {

    private static final OkHttpClient client = new OkHttpClient();

    private static String currentFirebaseIdToken() throws IOException {
        try {
            com.google.firebase.auth.FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
            if (user == null) throw new IOException("Admin session expired. Please sign in again.");
            com.google.firebase.auth.GetTokenResult token = Tasks.await(user.getIdToken(false));
            String value = token == null ? null : token.getToken();
            if (value == null || value.trim().isEmpty()) {
                throw new IOException("Could not refresh the admin session token.");
            }
            return value;
        } catch (IOException error) {
            throw error;
        } catch (Exception error) {
            throw new IOException("Could not refresh the admin session token.", error);
        }
    }

    private static String baseUrl() {
        String url = BuildConfig.STARX_API_BASE_URL;
        if (url == null) return "";
        String u = url.trim();
        if (u.endsWith("/")) u = u.substring(0, u.length() - 1);
        return u;
    }

    /** @return true if the backend relay is configured. */
    public static boolean hasRelay() {
        String u = baseUrl();
        return !u.isEmpty() && !u.contains("YOUR-SERVICE");
    }

    /**
     * Relay a push through the backend. Uses the admin's Firebase ID token
     * (obtained via FirebaseAuth.getInstance().getCurrentUser().getIdToken(true)).
     */
    public static void relayToBackend(String idToken, List<String> tokens,
                                      String title, String body, String type)
            throws IOException, org.json.JSONException {
        JSONObject payload = new JSONObject();
        payload.put("tokens", new JSONArray(tokens));
        payload.put("title", title);
        payload.put("body", body);
        if (type != null) payload.put("type", type);

        Request request = new Request.Builder()
                .url(baseUrl() + "/admin/sendPush")
                .post(RequestBody.create(payload.toString(),
                        MediaType.parse("application/json")))
                .addHeader("Authorization", "Bearer " + (idToken == null ? "" : idToken))
                .addHeader("Content-Type", "application/json")
                .build();

        try (Response response = client.newCall(request).execute()) {
            String respBody = response.body() != null ? response.body().string() : "";
            if (!response.isSuccessful()) {
                throw new IOException("Push relay error (" + response.code() + "): " + respBody);
            }
        }
    }

    // ---------------------------------------------------------------------
    // Legacy-compatible API — signatures kept so existing call-sites compile.
    // ---------------------------------------------------------------------

    /** Legacy single-token direct FCM call (kept for compatibility; unused now). */
    public static String sendToToken(String accessToken, String targetToken,
                                      String title, String body, String imageUrl) throws IOException, org.json.JSONException {
        if (hasRelay()) {
            // Relay path — accessToken is ignored.
            relayToBackend(currentFirebaseIdToken(), java.util.Collections.singletonList(targetToken),
                    title, body, null);
            return "relayed";
        }
        throw new IOException("Push relay not configured (STARX_API_BASE_URL missing)");
    }

    /**
     * Legacy multi-token API. Sends the same notification to a list of tokens
     * through the backend relay and reports a summary via the callback.
     */
    public static void sendToAllTokens(String accessToken, List<String> tokens,
                                        String title, String body, String imageUrl,
                                        SendResultCallback callback) {
        StringBuilder errorLog = new StringBuilder();
        int successCount = 0;

        if (tokens == null || tokens.isEmpty()) {
            callback.onDone(0, 0, "• No tokens to notify\n");
            return;
        }

        if (hasRelay()) {
            // Send in batches of up to 500 tokens (backend limit).
            int total = tokens.size();
            String firebaseIdToken;
            try {
                firebaseIdToken = currentFirebaseIdToken();
            } catch (Exception e) {
                callback.onDone(0, total, "• " + e.getMessage() + "\n");
                return;
            }
            for (int i = 0; i < total; i += 500) {
                List<String> batch = tokens.subList(i, Math.min(i + 500, total));
                try {
                    relayToBackend(firebaseIdToken, batch, title, body, null);
                    successCount += batch.size();
                } catch (Exception e) {
                    errorLog.append("• Relay batch failed: ").append(e.getMessage()).append("\n");
                }
            }
            callback.onDone(successCount, total, errorLog.toString());
            return;
        }

        callback.onDone(0, tokens.size(),
                "• Push relay not configured (STARX_API_BASE_URL missing)\n");
    }

    public interface SendResultCallback {
        void onDone(int successCount, int total, String errorLog);
    }
}
