package com.arenax.tournament.util;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.Nullable;

import com.arenax.tournament.AddMoneyActivity;
import com.arenax.tournament.AboutUsActivity;
import com.arenax.tournament.CategoryMatchesActivity;
import com.arenax.tournament.CustomerSupportActivity;
import com.arenax.tournament.EsportsGalleryActivity;
import com.arenax.tournament.FaqActivity;
import com.arenax.tournament.MainActivity;
import com.arenax.tournament.MatchHistoryActivity;
import com.arenax.tournament.MatchResultActivity;
import com.arenax.tournament.MyMatchesStatusActivity;
import com.arenax.tournament.NotificationsActivity;
import com.arenax.tournament.R;
import com.arenax.tournament.SupportChatActivity;
import com.arenax.tournament.TournamentDetailActivity;
import com.arenax.tournament.WalletActivity;
import com.arenax.tournament.data.FirebaseRepository;
import com.arenax.tournament.model.Tournament;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;
import java.util.Map;

/**
 * One place that knows how a notification "redirect" (chosen by the admin when sending a
 * notification) maps to a real user-panel screen.
 *
 * A redirect is three plain strings so it can travel through Firebase records, the backend
 * FCM push {@code data} payload and Intent extras without any conversion:
 *   redirectType  - one of the TYPE_* constants below (empty / NONE = just open the app)
 *   redirectId    - categoryId for CATEGORY, tournament/match id for MATCH and RESULT
 *   redirectTitle - human label (category title, match title) used in the admin preview
 */
public final class NotificationRedirect {

    public static final String EXTRA_TYPE = "redirectType";
    public static final String EXTRA_ID = "redirectId";
    public static final String EXTRA_TITLE = "redirectTitle";

    public static final String TYPE_NONE = "NONE";
    public static final String TYPE_HOME = "HOME";
    public static final String TYPE_LEADERBOARD = "LEADERBOARD";
    public static final String TYPE_PROFILE = "PROFILE";
    public static final String TYPE_WALLET = "WALLET";
    public static final String TYPE_ADD_MONEY = "ADD_MONEY";
    public static final String TYPE_NOTIFICATIONS = "NOTIFICATIONS";
    public static final String TYPE_MY_UPCOMING = "MY_UPCOMING";
    public static final String TYPE_MY_ONGOING = "MY_ONGOING";
    public static final String TYPE_MY_COMPLETED = "MY_COMPLETED";
    public static final String TYPE_MATCH_HISTORY = "MATCH_HISTORY";
    public static final String TYPE_GALLERY = "GALLERY";
    public static final String TYPE_SUPPORT = "SUPPORT";
    public static final String TYPE_SUPPORT_CHAT = "SUPPORT_CHAT";
    public static final String TYPE_FAQ = "FAQ";
    public static final String TYPE_ABOUT = "ABOUT";
    public static final String TYPE_CATEGORY = "CATEGORY";
    public static final String TYPE_MATCH = "MATCH";
    public static final String TYPE_RESULT = "RESULT";

    private NotificationRedirect() { }

    /** A selected redirect target. */
    public static final class Target {
        public final String type;
        public final String id;
        public final String title;

        public Target(String type, @Nullable String id, @Nullable String title) {
            this.type = type == null || type.trim().isEmpty() ? TYPE_NONE : type.trim();
            this.id = id == null ? "" : id.trim();
            this.title = title == null ? "" : title.trim();
        }

        public boolean isNone() { return TYPE_NONE.equals(type); }

        /** Fields to merge into a Firebase notification / announcement record. */
        public Map<String, Object> toFields() {
            Map<String, Object> map = new HashMap<>();
            if (isNone()) return map;
            map.put(EXTRA_TYPE, type);
            map.put(EXTRA_ID, id);
            map.put(EXTRA_TITLE, title);
            return map;
        }
    }

    public static Target none() { return new Target(TYPE_NONE, "", ""); }

    /** Short admin-facing label, e.g. "Wallet", "Match: Solo Rush". */
    public static String label(Target t) {
        if (t == null || t.isNone()) return "No redirect (just open app)";
        switch (t.type) {
            case TYPE_HOME: return "Home";
            case TYPE_LEADERBOARD: return "Leaderboard";
            case TYPE_PROFILE: return "Profile";
            case TYPE_WALLET: return "Wallet";
            case TYPE_ADD_MONEY: return "Add Money";
            case TYPE_NOTIFICATIONS: return "Notifications inbox";
            case TYPE_MY_UPCOMING: return "My Matches - Upcoming";
            case TYPE_MY_ONGOING: return "My Matches - Ongoing";
            case TYPE_MY_COMPLETED: return "My Matches - Completed";
            case TYPE_MATCH_HISTORY: return "Match History";
            case TYPE_GALLERY: return "Esports Games";
            case TYPE_SUPPORT: return "Customer Support";
            case TYPE_SUPPORT_CHAT: return "Support Chat";
            case TYPE_FAQ: return "FAQ";
            case TYPE_ABOUT: return "About Us";
            case TYPE_CATEGORY: return "Category: " + (t.title.isEmpty() ? t.id : t.title);
            case TYPE_MATCH: return "Match: " + (t.title.isEmpty() ? t.id : t.title);
            case TYPE_RESULT: return "Result: " + (t.title.isEmpty() ? t.id : t.title);
            default: return t.type;
        }
    }

    // ---------------------------------------------------------------------------------
    // Carrying a redirect through Intents (push tap -> LoginActivity -> MainActivity)
    // ---------------------------------------------------------------------------------

    /** True when the intent carries a redirect worth acting on. */
    public static boolean hasRedirect(@Nullable Intent intent) {
        if (intent == null) return false;
        String type = intent.getStringExtra(EXTRA_TYPE);
        return type != null && !type.trim().isEmpty() && !TYPE_NONE.equals(type.trim());
    }

    /** Reads a redirect out of Intent extras. FCM puts the data payload straight into extras. */
    public static Target fromIntent(@Nullable Intent intent) {
        if (intent == null) return none();
        return new Target(intent.getStringExtra(EXTRA_TYPE), intent.getStringExtra(EXTRA_ID),
                intent.getStringExtra(EXTRA_TITLE));
    }

    /** Copies redirect extras from {@code from} into {@code to} (used when screens hand over). */
    public static void copyExtras(@Nullable Intent from, Intent to) {
        if (from == null || to == null) return;
        Bundle extras = from.getExtras();
        if (extras == null) return;
        for (String key : new String[]{EXTRA_TYPE, EXTRA_ID, EXTRA_TITLE}) {
            if (extras.containsKey(key)) to.putExtra(key, extras.getString(key));
        }
    }

    /** Redirect read from a Firebase notification / announcement snapshot. */
    public static Target fromSnapshot(@Nullable DataSnapshot item) {
        if (item == null) return none();
        return new Target(item.child(EXTRA_TYPE).getValue(String.class),
                item.child(EXTRA_ID).getValue(String.class),
                item.child(EXTRA_TITLE).getValue(String.class));
    }

    /** Removes the redirect extras so a rotated / re-created screen does not re-open the target. */
    public static void consume(@Nullable Intent intent) {
        if (intent == null) return;
        intent.removeExtra(EXTRA_TYPE);
        intent.removeExtra(EXTRA_ID);
        intent.removeExtra(EXTRA_TITLE);
    }

    // ---------------------------------------------------------------------------------
    // Opening the target
    // ---------------------------------------------------------------------------------

    /**
     * Opens the screen for {@code target} on top of whatever is showing. Safe to call from any
     * user screen: every branch just starts an Activity (or loads one match first).
     */
    public static void open(Context context, Target target) {
        if (context == null || target == null || target.isNone()) return;
        switch (target.type) {
            case TYPE_HOME:
                openTab(context, R.id.nav_home);
                return;
            case TYPE_LEADERBOARD:
                openTab(context, R.id.nav_leaderboard);
                return;
            case TYPE_PROFILE:
                openTab(context, R.id.nav_profile);
                return;
            case TYPE_WALLET:
                context.startActivity(new Intent(context, WalletActivity.class));
                return;
            case TYPE_ADD_MONEY:
                context.startActivity(new Intent(context, AddMoneyActivity.class));
                return;
            case TYPE_NOTIFICATIONS:
                NotificationsActivity.openAll(context);
                return;
            case TYPE_MY_UPCOMING:
                openMyMatches(context, MyMatchesStatusActivity.STATUS_UPCOMING);
                return;
            case TYPE_MY_ONGOING:
                openMyMatches(context, MyMatchesStatusActivity.STATUS_ONGOING);
                return;
            case TYPE_MY_COMPLETED:
                openMyMatches(context, MyMatchesStatusActivity.STATUS_COMPLETED);
                return;
            case TYPE_MATCH_HISTORY:
                context.startActivity(new Intent(context, MatchHistoryActivity.class));
                return;
            case TYPE_GALLERY:
                context.startActivity(new Intent(context, EsportsGalleryActivity.class));
                return;
            case TYPE_SUPPORT:
                context.startActivity(new Intent(context, CustomerSupportActivity.class));
                return;
            case TYPE_SUPPORT_CHAT:
                context.startActivity(new Intent(context, SupportChatActivity.class));
                return;
            case TYPE_FAQ:
                context.startActivity(new Intent(context, FaqActivity.class));
                return;
            case TYPE_ABOUT:
                context.startActivity(new Intent(context, AboutUsActivity.class));
                return;
            case TYPE_CATEGORY: {
                if (target.id.isEmpty()) return;
                Intent intent = new Intent(context, CategoryMatchesActivity.class);
                intent.putExtra("categoryId", target.id);
                intent.putExtra("categoryTitle", target.title);
                context.startActivity(intent);
                return;
            }
            case TYPE_RESULT: {
                if (target.id.isEmpty()) return;
                context.startActivity(new Intent(context, MatchResultActivity.class)
                        .putExtra("tournamentId", target.id));
                return;
            }
            case TYPE_MATCH:
                openMatch(context, target.id);
                return;
            default:
                // Unknown / future type: do nothing rather than crash an old app version.
        }
    }

    private static void openTab(Context context, int navId) {
        Intent intent = new Intent(context, MainActivity.class)
                .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP)
                .putExtra("open_tab", navId);
        context.startActivity(intent);
    }

    private static void openMyMatches(Context context, String status) {
        context.startActivity(new Intent(context, MyMatchesStatusActivity.class)
                .putExtra(MyMatchesStatusActivity.EXTRA_STATUS, status));
    }

    /**
     * A match opens the same screen the Matches list opens: the join/detail page, or the
     * published result page once the match is completed. The match is loaded fresh from
     * Firebase so the user always lands on live data (slots, room, status).
     */
    private static void openMatch(Context context, String matchId) {
        if (matchId == null || matchId.isEmpty()) return;
        final Context app = context;
        FirebaseRepository.tournaments().child(matchId)
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @SuppressWarnings("unchecked")
                    @Override public void onDataChange(DataSnapshot snapshot) {
                        Object raw = snapshot.getValue();
                        if (!(raw instanceof Map)) return; // match was deleted since the notice was sent
                        Tournament tournament = Tournament.fromMap(snapshot.getKey(), (Map<String, Object>) raw);
                        if (tournament == null) return;
                        Intent intent;
                        if (Tournament.COMPLETED.equals(tournament.getEffectiveStatus())) {
                            intent = new Intent(app, MatchResultActivity.class)
                                    .putExtra("tournamentId", tournament.getId());
                        } else {
                            intent = new Intent(app, TournamentDetailActivity.class)
                                    .putExtra("tournament", tournament);
                        }
                        try { app.startActivity(intent); } catch (Exception ignored) { }
                    }
                    @Override public void onCancelled(DatabaseError error) { }
                });
    }
}
