package com.arenax.tournament;

import android.graphics.Color;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import com.arenax.tournament.data.FirebaseRepository;
import com.arenax.tournament.util.AppStatus;
import com.arenax.tournament.util.FancyText;
import com.arenax.tournament.util.StatusUi;
import com.google.firebase.database.ServerValue;

import java.util.HashMap;
import java.util.Map;

/**
 * Admin screen: Maintenance mode + Update notice. Writes appConfig/status (see AppStatus).
 * Opened from Platform controls on the admin dashboard.
 */
public class AdminAppControlActivity extends BaseActivity {

    private Switch mSwitch, uSwitch, uForce;
    private EditText mTitle, mMessage, mEta, mContact;
    private EditText uName, uCode, uTitle, uDesc, uLink, uAdminLink;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(StatusUi.CANVAS);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int p = StatusUi.dp(this, 16);
        root.setPadding(p, p, p, StatusUi.dp(this, 32));
        scroll.addView(root);
        setContentView(scroll);

        TextView back = StatusUi.text(this, "Back", 14, StatusUi.BLUE, true);
        back.setPadding(0, 0, 0, StatusUi.dp(this, 8));
        back.setOnClickListener(v -> finish());
        root.addView(back);
        root.addView(StatusUi.text(this, "Maintenance and update", 24, StatusUi.INK, true));
        TextView sub = StatusUi.text(this, "Control what players and admins see. Changes go live within seconds.", 13, StatusUi.MUTED, false);
        sub.setPadding(0, StatusUi.dp(this, 4), 0, StatusUi.dp(this, 14));
        root.addView(sub);

        // ---- Maintenance card ----
        LinearLayout m = card(root, R.drawable.ic_status_maintenance, StatusUi.AMBER, StatusUi.AMBER_TINT,
                "Maintenance mode", "Players see a full-screen notice and cannot use the app. Admin app can continue.");
        mSwitch = toggle(m, "Maintenance is ON");
        mTitle = field(m, "Title (e.g. We'll be right back)", false);
        mMessage = field(m, "Message shown to players", true);
        mEta = field(m, "Expected back (e.g. Today 6:00 PM)", false);
        mContact = field(m, "Support link (optional, Telegram / URL)", false);
        mContact.setInputType(InputType.TYPE_TEXT_VARIATION_URI);
        TextView mSave = StatusUi.button(this, "Save maintenance", StatusUi.AMBER, Color.WHITE, 0);
        ((LinearLayout.LayoutParams) mSave.getLayoutParams()).topMargin = StatusUi.dp(this, 14);
        mSave.setOnClickListener(v -> saveMaintenance());
        m.addView(mSave);
        TextView mPrev = StatusUi.button(this, "Preview screen", Color.WHITE, StatusUi.INK, StatusUi.LINE);
        ((LinearLayout.LayoutParams) mPrev.getLayoutParams()).topMargin = StatusUi.dp(this, 8);
        mPrev.setOnClickListener(v -> {
            android.content.Intent i = new android.content.Intent(this, MaintenanceActivity.class);
            i.putExtra(MaintenanceActivity.EXTRA_CAN_BYPASS, true);
            startActivity(i);
        });
        m.addView(mPrev);

        // ---- Update card ----
        LinearLayout u = card(root, R.drawable.ic_status_update, StatusUi.BLUE, StatusUi.BLUE_TINT,
                "Update notice", "Shown inside older installed versions. Apps with a version code lower than the one below get the notice.");
        uSwitch = toggle(u, "Update notice is ON");
        uForce = toggle(u, "Force update (cannot be skipped)");
        uName = field(u, "New version name (e.g. 2026.10.09-1830)", false);
        uCode = field(u, "New version code (number)", false);
        uCode.setInputType(InputType.TYPE_CLASS_NUMBER);
        TextView codeHelp = StatusUi.text(this, "This admin build: code " + AppStatus.installedCode(this)
                + "  (" + AppStatus.installedName(this) + "). If you build user and admin together in one Gradle command they share the same code.",
                12, StatusUi.MUTED, false);
        codeHelp.setPadding(0, StatusUi.dp(this, 4), 0, 0);
        u.addView(codeHelp);
        TextView use = StatusUi.text(this, "Use this build's code", 13, StatusUi.BLUE, true);
        use.setPadding(0, StatusUi.dp(this, 6), 0, 0);
        use.setOnClickListener(v -> {
            uCode.setText(String.valueOf(AppStatus.installedCode(this)));
            if (uName.getText().toString().trim().isEmpty()) uName.setText(AppStatus.installedName(this).replace("-admin", ""));
        });
        u.addView(use);
        uTitle = field(u, "Title (e.g. New update available)", false);
        uDesc = field(u, "Description / what's new (one point per line)", true);
        uLink = field(u, "Player app download link (APK / Play Store)", false);
        uLink.setInputType(InputType.TYPE_TEXT_VARIATION_URI);
        uAdminLink = field(u, "Admin app download link (optional)", false);
        uAdminLink.setInputType(InputType.TYPE_TEXT_VARIATION_URI);
        TextView uSave = StatusUi.button(this, "Publish update notice", StatusUi.BLUE, Color.WHITE, 0);
        ((LinearLayout.LayoutParams) uSave.getLayoutParams()).topMargin = StatusUi.dp(this, 14);
        uSave.setOnClickListener(v -> saveUpdate());
        u.addView(uSave);
        TextView uPrev = StatusUi.button(this, "Preview dialog", Color.WHITE, StatusUi.INK, StatusUi.LINE);
        ((LinearLayout.LayoutParams) uPrev.getLayoutParams()).topMargin = StatusUi.dp(this, 8);
        uPrev.setOnClickListener(v -> previewUpdate());
        u.addView(uPrev);

        load();
    }

    private LinearLayout card(LinearLayout parent, int icon, int accent, int tint, String title, String hint) {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        int pad = StatusUi.dp(this, 16);
        c.setPadding(pad, pad, pad, pad);
        c.setBackground(StatusUi.box(Color.WHITE, 12, StatusUi.LINE, this));
        LinearLayout head = new LinearLayout(this);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(Gravity.CENTER_VERTICAL);
        head.addView(StatusUi.badge(this, icon, accent, tint, 44));
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(StatusUi.dp(this, 12), 0, 0, 0);
        col.addView(StatusUi.text(this, title, 17, StatusUi.INK, true));
        col.addView(StatusUi.text(this, hint, 12, StatusUi.MUTED, false));
        head.addView(col, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        c.addView(head);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.bottomMargin = StatusUi.dp(this, 14);
        parent.addView(c, lp);
        return c;
    }

    private Switch toggle(LinearLayout parent, String label) {
        Switch s = new Switch(this);
        s.setText(label);
        s.setTextSize(15);
        s.setTextColor(StatusUi.INK);
        s.setPadding(0, StatusUi.dp(this, 12), 0, StatusUi.dp(this, 4));
        parent.addView(s);
        return s;
    }

    private EditText field(LinearLayout parent, String hint, boolean multiline) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setTextSize(14);
        e.setTextColor(StatusUi.INK);
        e.setHintTextColor(0xFF9CA3AF);
        e.setBackground(StatusUi.box(0xFFF9FAFB, 8, StatusUi.LINE, this));
        int pad = StatusUi.dp(this, 12);
        e.setPadding(pad, pad, pad, pad);
        if (multiline) {
            e.setMinLines(3);
            e.setGravity(Gravity.TOP);
            e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        } else {
            e.setSingleLine(true);
        }
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = StatusUi.dp(this, 10);
        parent.addView(e, lp);
        return e;
    }

    private void load() {
        if (!FirebaseRepository.isReady(this)) return;
        AppStatus.fetch(this, s -> {
            if (s == null) {
                FancyText.toast(this, "Could not load current settings.", Toast.LENGTH_SHORT).show();
                return;
            }
            mSwitch.setChecked(s.mEnabled);
            mTitle.setText(s.mTitle);
            mMessage.setText(s.mMessage);
            mEta.setText(s.mEta);
            mContact.setText(s.mContact);
            uSwitch.setChecked(s.uEnabled);
            uForce.setChecked(s.uForce);
            uName.setText(s.uName);
            uCode.setText(s.uCode > 0 ? String.valueOf(s.uCode) : "");
            uTitle.setText(s.uTitle);
            uDesc.setText(s.uDesc);
            uLink.setText(s.uLink);
            uAdminLink.setText(s.uAdminLink);
        });
    }

    private static String t(EditText e) { return e.getText().toString().trim(); }

    private void saveMaintenance() {
        Map<String, Object> m = new HashMap<>();
        m.put("enabled", mSwitch.isChecked());
        m.put("title", t(mTitle));
        m.put("message", t(mMessage));
        m.put("eta", t(mEta));
        m.put("contactUrl", t(mContact));
        m.put("updatedAt", ServerValue.TIMESTAMP);
        AppStatus.ref().child("maintenance").setValue(m)
                .addOnSuccessListener(x -> {
                    FancyText.toast(this, mSwitch.isChecked() ? "Maintenance mode is ON." : "Maintenance mode is OFF.", Toast.LENGTH_SHORT).show();
                    FirebaseRepository.logActivity("Maintenance mode " + (mSwitch.isChecked() ? "ON" : "OFF"), "platform", t(mTitle));
                })
                .addOnFailureListener(e -> FancyText.toast(this, e.getMessage(), Toast.LENGTH_LONG).show());
    }

    private void saveUpdate() {
        long code;
        try { code = Long.parseLong(t(uCode)); } catch (NumberFormatException e) { code = 0; }
        if (uSwitch.isChecked() && code <= 0) {
            FancyText.toast(this, "Enter the new version code first.", Toast.LENGTH_LONG).show();
            return;
        }
        if (uSwitch.isChecked() && t(uLink).isEmpty()) {
            FancyText.toast(this, "Enter the player app download link.", Toast.LENGTH_LONG).show();
            return;
        }
        Map<String, Object> u = new HashMap<>();
        u.put("enabled", uSwitch.isChecked());
        u.put("force", uForce.isChecked());
        u.put("versionName", t(uName));
        u.put("versionCode", code);
        u.put("title", t(uTitle));
        u.put("description", t(uDesc));
        u.put("link", t(uLink));
        u.put("adminLink", t(uAdminLink));
        u.put("updatedAt", ServerValue.TIMESTAMP);
        final long savedCode = code;
        AppStatus.ref().child("update").setValue(u)
                .addOnSuccessListener(x -> {
                    FancyText.toast(this, uSwitch.isChecked() ? "Update notice published." : "Update notice turned off.", Toast.LENGTH_SHORT).show();
                    FirebaseRepository.logActivity("Update notice " + (uSwitch.isChecked() ? "published" : "off"), "platform", t(uName) + " / " + savedCode);
                })
                .addOnFailureListener(e -> FancyText.toast(this, e.getMessage(), Toast.LENGTH_LONG).show());
    }

    private void previewUpdate() {
        AppStatus.State s = new AppStatus.State();
        s.uForce = uForce.isChecked();
        s.uName = t(uName);
        s.uTitle = t(uTitle);
        s.uDesc = t(uDesc);
        StatusUi.showUpdateDialog(this, s, t(uLink));
    }
}
