package com.arenax.tournament;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputType;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.WindowInsetsControllerCompat;

import com.arenax.tournament.data.FirebaseRepository;
import com.arenax.tournament.model.GameMode;
import com.arenax.tournament.model.Tournament;
import com.arenax.tournament.util.MatchNumber;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/**
 * One search screen for the whole app.
 *
 *  - MODE_ADMIN: every admin function / page this key may open, plus all matches and categories.
 *    Picking a function returns its key through setResult(EXTRA_ACTION) so AdminActivity opens it.
 *  - MODE_USER: every player-side function (wallet, withdraw, FAQ, support...), live matches,
 *    categories and other players (public name/bio only).
 *
 * Type anything (Hindi/English keywords work: "paisa", "withdraw", "coin", "room", "result"...).
 */
public class GlobalSearchActivity extends BaseActivity {
    public static final String EXTRA_MODE = "mode";
    public static final String EXTRA_ALLOWED = "allowed";
    public static final String EXTRA_ACTION = "action";
    public static final String MODE_ADMIN = "admin";
    public static final String MODE_USER = "user";

    private static final int INK = 0xFF101936, MUTED = 0xFF5B6784, BLUE = 0xFF2F6FED;

    private static final class Entry {
        final String key, title, sub, words;
        Entry(String key, String title, String sub, String words) {
            this.key = key; this.title = title; this.sub = sub;
            this.words = (title + " " + sub + " " + words).toLowerCase(Locale.ROOT);
        }
    }

    private boolean admin;
    private final Set<String> allowed = new HashSet<>();
    private final List<Entry> functions = new ArrayList<>();
    private final List<Tournament> matches = new ArrayList<>();
    private final List<GameMode> categories = new ArrayList<>();
    private EditText input;
    private LinearLayout results;
    private ValueEventListener matchListener, categoryListener;
    private int playerGeneration = 0;
    private final android.os.Handler handler = new android.os.Handler(android.os.Looper.getMainLooper());
    private Runnable pendingPlayers;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        admin = MODE_ADMIN.equals(getIntent().getStringExtra(EXTRA_MODE));
        String[] a = getIntent().getStringArrayExtra(EXTRA_ALLOWED);
        if (a != null) allowed.addAll(Arrays.asList(a));
        buildRegistry();
        buildScreen();
        listen();
        render();
    }

    // ------------------------------------------------------------------ registry

    private void add(String key, String title, String sub, String words) {
        functions.add(new Entry(key, title, sub, words));
    }

    private boolean ok(String key) { return !admin || allowed.contains(key); }

    private void buildRegistry() {
        if (admin) {
            add("dashboard", "Dashboard", "Admin home", "home main overview");
            if (ok("users")) add("users", "Users", "View / ban players, edit coins", "user player ban unban coin edit balance wallet add remove");
            if (ok("payments")) add("payments", "Payments", "Deposits & withdrawal requests", "payment withdraw withdrawal deposit upi paid reject paisa");
            if (ok("matches")) add("matches", "Matches", "Match management", "match room key release edit schedule");
            if (ok("tournaments")) add("tournaments", "Tournaments", "Tournament list", "tournament battle");
            if (ok("battles")) add("battles", "Battles", "Battle management", "battle");
            if (ok("category")) add("category", "Categories", "Game categories", "category categories esports game mode");
            if (ok("esports")) add("esports", "Esports Categories", "Esports games", "esports category game");
            if (ok("teams")) add("teams", "Teams", "Team list", "team squad");
            if (ok("results")) add("results", "Results & Leaderboard", "Post results", "result leaderboard rank kills prize winner");
            if (ok("disputes")) add("disputes", "Disputes", "Player disputes", "dispute complaint");
            if (ok("reports")) add("reports", "Reports", "Moderation reports", "report moderation cheat hacker");
            if (ok("faq")) add("faq", "FAQ", "Edit FAQ text", "faq question answer help");
            if (ok("notice")) add("notice", "Notice", "Notices & notifications", "notice notification announcement message push");
            if (ok("analytics")) add("analytics", "Analytics", "App statistics", "analytics stats report graph");
            if (ok("activity")) add("activity", "Activity Log", "What admins did, with time", "activity log history audit");
            if (ok("settings")) add("settings", "Settings", "App settings", "setting config");
            if (ok("roles")) add("roles", "Roles & Permissions", "Admin keys and work roles", "role permission admin key generate work");
            if (ok("bannerlinks")) add("bannerlinks", "Banner Customer Support Link", "Support link on banners", "banner support link telegram whatsapp");
            if (ok("terms")) add("terms", "Terms", "Terms text", "terms conditions");
            if (ok("privacy")) add("privacy", "Privacy Policy", "Privacy text", "privacy policy");
            if (ok("about")) add("about", "About Us", "About text", "about us");
            if (ok("banners")) {
                add("act_banners", "Featured Banners", "Home banners list", "banner carousel home image");
                add("act_add_banner", "Add Banner", "Add a new home banner", "banner add new upload");
            }
            if (ok("categories")) add("act_add_category", "Add Category", "Create a new game category", "category add new create");
            if (ok("matches") || ok("tournaments")) add("act_search_match", "Search Match", "Find match by #code or name", "match search hash code find");
            add("act_more", "More", "Extra admin sections", "more menu");
        } else {
            add("tab_home", "Home", "Banners, categories, match status", "home main banner");
            add("tab_leaderboard", "Leaderboard", "Rankings and scores", "leaderboard rank top score");
            add("tab_profile", "Profile", "Your name, bio, badges", "profile account bio badge photo name");
            add("wallet", "Wallet", "Balance, add coins, withdraw, history", "wallet balance coin paisa money rupee");
            add("wallet", "Add Coins", "Top up your wallet with UPI", "add coin top up recharge deposit pay upi payment");
            add("wallet", "Withdraw Earnings", "Send winnings to your bank account", "withdraw cash out bank winning earning paisa nikalna");
            add("wallet", "Transaction History", "Entry fees, prizes, withdrawals", "history transaction entry fee prize");
            add("my_matches", "Upcoming Matches", "Matches you joined that are not started", "upcoming joined my match");
            add("my_ongoing", "Ongoing Matches", "Your live matches", "ongoing live running my match");
            add("my_completed", "Completed Matches", "Your finished matches", "completed finished result my match");
            add("notifications", "Notifications", "All your notifications", "notification inbox alert");
            add("support_chat", "AI Support Chat", "Ask the support assistant", "support chat help ai agent problem issue");
            add("customer_support", "Customer Support", "Contact support on Telegram", "customer support telegram contact payment problem coins nahi mile");
            add("faq", "FAQ", "Frequently asked questions", "faq question help how");
            add("terms", "Terms & Conditions", "App terms", "terms conditions rules");
            add("privacy", "Privacy Policy", "How your data is used", "privacy policy data");
            add("about", "About Us", "About STARX24", "about us app");
            add("developer", "Developer", "Developer profile", "developer creator");
            add("language", "Language", "Change app language", "language bhasha hindi english");
            add("esports", "Esports Games", "All game categories gallery", "esports games gallery category");
        }
    }

    // ------------------------------------------------------------------ screen

    private void buildScreen() {
        final int canvas = getColor(R.color.home_bg);
        getWindow().setStatusBarColor(canvas);
        getWindow().setNavigationBarColor(canvas);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(canvas);
        ViewCompat.setOnApplyWindowInsetsListener(root, (view, insets) -> {
            Insets bars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            Insets ime = insets.getInsets(WindowInsetsCompat.Type.ime());
            view.setPadding(bars.left, bars.top, bars.right, Math.max(bars.bottom, ime.bottom));
            return insets;
        });

        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(12), dp(12), dp(12), dp(8));
        TextView back = text("‹", 28, INK, true);
        back.setGravity(Gravity.CENTER);
        back.setContentDescription("Back");
        back.setBackgroundResource(R.drawable.bg_category_back);
        back.setOnClickListener(v -> finish());
        bar.addView(back, new LinearLayout.LayoutParams(dp(36), dp(36)));
        TextView title = text("Search", 18, INK, true);
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(0, -2, 1f);
        tp.leftMargin = dp(12);
        bar.addView(title, tp);
        root.addView(bar, new LinearLayout.LayoutParams(-1, -2));

        input = new EditText(this);
        input.setHint(admin ? "Search any admin function, match or category"
                : "Search any function, match, category or player");
        input.setHintTextColor(0xFF9AA5BD);
        input.setTextColor(INK);
        input.setTextSize(14.5f);
        input.setSingleLine(true);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        input.setImeOptions(EditorInfo.IME_ACTION_SEARCH);
        input.setPadding(dp(14), dp(12), dp(14), dp(12));
        GradientDrawable field = new GradientDrawable();
        field.setColor(Color.WHITE);
        field.setCornerRadius(dp(12));
        field.setStroke(dp(1), 0xFF9CC5F5);
        input.setBackground(field);
        input.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void afterTextChanged(Editable s) {
                render();
                schedulePlayerSearch(s.toString());
            }
        });
        LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(-1, -2);
        ip.setMargins(dp(12), dp(4), dp(12), dp(8));
        root.addView(input, ip);

        results = new LinearLayout(this);
        results.setOrientation(LinearLayout.VERTICAL);
        results.setPadding(dp(12), 0, dp(12), dp(16));
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.addView(results, new android.widget.FrameLayout.LayoutParams(-1, -2));
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1f));
        setContentView(root);

        WindowInsetsControllerCompat c = WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView());
        c.setAppearanceLightStatusBars(true);
        c.setAppearanceLightNavigationBars(true);
        input.requestFocus();
    }

    // ------------------------------------------------------------------ live data

    @SuppressWarnings("unchecked")
    private void listen() {
        if (!FirebaseRepository.isReady(this)) return;
        matchListener = new ValueEventListener() {
            @Override public void onDataChange(DataSnapshot snapshot) {
                matches.clear();
                for (DataSnapshot child : snapshot.getChildren()) {
                    try {
                        Tournament t = Tournament.fromMap(child.getKey(), (Map<String, Object>) child.getValue());
                        if (t != null) matches.add(t);
                    } catch (RuntimeException ignored) { }
                }
                java.util.Collections.sort(matches, (x, y) -> Long.compare(y.getEffectiveStartAt(), x.getEffectiveStartAt()));
                render();
            }
            @Override public void onCancelled(DatabaseError error) { }
        };
        FirebaseRepository.tournaments().addValueEventListener(matchListener);
        categoryListener = new ValueEventListener() {
            @Override public void onDataChange(DataSnapshot snapshot) {
                categories.clear();
                for (DataSnapshot child : snapshot.getChildren()) {
                    Object raw = child.getValue();
                    if (!(raw instanceof Map)) continue;
                    try {
                        GameMode m = GameMode.fromMap(child.getKey(), (Map<String, Object>) raw);
                        if (m != null && (admin || m.isActive())) categories.add(m);
                    } catch (RuntimeException ignored) { }
                }
                render();
            }
            @Override public void onCancelled(DatabaseError error) { }
        };
        FirebaseRepository.gameModes().addValueEventListener(categoryListener);
    }

    // ------------------------------------------------------------------ rendering

    private final List<View> playerViews = new ArrayList<>();
    private String playerStatus = "";

    private void render() {
        results.removeAllViews();
        String raw = input == null ? "" : input.getText().toString().trim();
        String q = raw.toLowerCase(Locale.ROOT).replaceAll("\\s+", " ");
        String digits = raw.replaceAll("[^0-9]", "");
        boolean codeSearch = !digits.isEmpty() && raw.replaceAll("[#0-9\\s]", "").isEmpty();
        String[] tokens = q.isEmpty() ? new String[0] : q.split(" ");

        int total = 0;
        // 1) functions
        List<Entry> fHits = new ArrayList<>();
        Set<String> seen = new HashSet<>();
        for (Entry e : functions) {
            boolean hit = true;
            for (String tk : tokens) if (!e.words.contains(tk)) { hit = false; break; }
            if (hit && seen.add(e.key + "|" + e.title)) fHits.add(e);
        }
        if (!fHits.isEmpty()) {
            section(q.isEmpty() ? "All functions" : "Functions");
            for (Entry e : fHits) { row(e.title, e.sub, "›", () -> openFunction(e.key)); total++; }
        }
        // 2) categories
        List<GameMode> cHits = new ArrayList<>();
        if (!q.isEmpty() && !codeSearch) {
            for (GameMode m : categories) {
                String t = m.getTitle() == null ? "" : m.getTitle().toLowerCase(Locale.ROOT);
                boolean hit = true;
                for (String tk : tokens) if (!t.contains(tk)) { hit = false; break; }
                if (hit) cHits.add(m);
            }
        }
        if (!cHits.isEmpty()) {
            section("Categories");
            for (GameMode m : cHits) { row(m.getTitle(), "Game category", "›", () -> openCategory(m)); total++; }
        }
        // 3) matches (only when something is typed; there can be hundreds)
        if (!q.isEmpty()) {
            List<Tournament> tHits = new ArrayList<>();
            for (Tournament t : matches) {
                boolean hit;
                if (codeSearch) {
                    hit = MatchNumber.fromId(t.getId()).contains(digits);
                } else {
                    String hay = ((t.getTitle() == null ? "" : t.getTitle()) + " "
                            + (t.getMode() == null ? "" : t.getMode())).toLowerCase(Locale.ROOT);
                    hit = true;
                    for (String tk : tokens) if (!hay.contains(tk)) { hit = false; break; }
                }
                if (hit) tHits.add(t);
                if (tHits.size() >= 30) break;
            }
            if (!tHits.isEmpty()) {
                section("Matches");
                for (Tournament t : tHits) {
                    String sub = (t.getMode() == null ? "" : t.getMode()) + "  •  " + t.getEffectiveStatus();
                    row(t.getTitle(), sub, "›", () -> openMatch(t));
                    total++;
                }
            }
        }
        // 4) players (user mode)
        if (!admin && !q.isEmpty()) {
            if (!playerViews.isEmpty()) {
                section("Players");
                for (View v : playerViews) {
                    if (v.getParent() != null) ((android.view.ViewGroup) v.getParent()).removeView(v);
                    results.addView(v);
                    total++;
                }
            } else if (!playerStatus.isEmpty()) {
                section("Players");
                TextView t = text(playerStatus, 12.5f, MUTED, false);
                t.setPadding(dp(4), dp(2), dp(4), dp(8));
                results.addView(t);
            }
        }
        if (total == 0) {
            TextView empty = text(q.isEmpty() ? "Kuchh bhi type karo." : "Kuchh nahi mila: \u201c" + raw + "\u201d", 14, MUTED, false);
            empty.setGravity(Gravity.CENTER);
            empty.setPadding(dp(24), dp(48), dp(24), 0);
            results.addView(empty);
        }
    }

    private void section(String name) {
        TextView t = text(name.toUpperCase(Locale.ROOT), 11.5f, BLUE, true);
        t.setLetterSpacing(0.06f);
        t.setPadding(dp(4), dp(12), dp(4), dp(6));
        results.addView(t);
    }

    private void row(String title, String sub, String chevron, Runnable onTap) {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setPadding(dp(14), dp(12), dp(14), dp(12));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.WHITE);
        bg.setCornerRadius(dp(14));
        bg.setStroke(dp(1), 0xFFC9D8FB);
        r.setBackground(bg);
        r.setClickable(true);
        r.setFocusable(true);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.bottomMargin = dp(8);
        r.setLayoutParams(lp);

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        TextView tt = text(title == null ? "" : title, 14.5f, INK, true);
        tt.setSingleLine(true);
        tt.setEllipsize(TextUtils.TruncateAt.END);
        col.addView(tt);
        if (sub != null && !sub.trim().isEmpty()) {
            TextView ss = text(sub, 12, MUTED, false);
            ss.setSingleLine(true);
            ss.setEllipsize(TextUtils.TruncateAt.END);
            col.addView(ss);
        }
        r.addView(col, new LinearLayout.LayoutParams(0, -2, 1f));
        r.addView(text(chevron, 20, MUTED, false));
        r.setOnClickListener(v -> onTap.run());
        results.addView(r);
    }

    // ------------------------------------------------------------------ players (user mode)

    private void schedulePlayerSearch(String raw) {
        if (admin) return;
        if (pendingPlayers != null) handler.removeCallbacks(pendingPlayers);
        final String q = raw.trim().toLowerCase(Locale.ROOT).replaceAll("\\s+", " ");
        final int gen = ++playerGeneration;
        if (q.isEmpty()) { playerViews.clear(); playerStatus = ""; return; }
        pendingPlayers = () -> {
            if (!FirebaseRepository.isReady(this)) return;
            FirebaseRepository.publicProfiles().orderByChild("nameLower")
                    .startAt(q).endAt(q + "\uf8ff").limitToFirst(15)
                    .addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override public void onDataChange(DataSnapshot snapshot) {
                            if (gen != playerGeneration) return;
                            playerViews.clear();
                            for (DataSnapshot child : snapshot.getChildren()) {
                                Object n = child.child("name").getValue();
                                if (n == null || String.valueOf(n).isEmpty()) continue;
                                Object b = child.child("bio").getValue();
                                Object ph = child.child("photoUrl").getValue();
                                playerViews.add(playerRow(child.getKey(), String.valueOf(n),
                                        b == null ? "" : String.valueOf(b), ph == null ? "" : String.valueOf(ph)));
                            }
                            playerStatus = playerViews.isEmpty() ? "Is naam ka koi player nahi mila." : "";
                            render();
                        }
                        @Override public void onCancelled(DatabaseError error) { }
                    });
        };
        handler.postDelayed(pendingPlayers, 350L);
    }

    private View playerRow(String uid, String name, String bio, String photo) {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.VERTICAL);
        r.setPadding(dp(14), dp(12), dp(14), dp(12));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.WHITE);
        bg.setCornerRadius(dp(14));
        bg.setStroke(dp(1), 0xFFC9D8FB);
        r.setBackground(bg);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.bottomMargin = dp(8);
        r.setLayoutParams(lp);
        r.setClickable(true);
        r.setFocusable(true);
        r.setOnClickListener(v -> startActivity(new Intent(this, PlayerProfileActivity.class)
                .putExtra(PlayerProfileActivity.EXTRA_UID, uid)
                .putExtra(PlayerProfileActivity.EXTRA_NAME, name)
                .putExtra(PlayerProfileActivity.EXTRA_BIO, bio)
                .putExtra(PlayerProfileActivity.EXTRA_PHOTO, photo)));
        r.addView(text(name, 14.5f, INK, true));
        if (!bio.trim().isEmpty()) {
            TextView b = text(bio.trim(), 12, MUTED, false);
            b.setMaxLines(2);
            b.setEllipsize(TextUtils.TruncateAt.END);
            r.addView(b);
        }
        return r;
    }

    // ------------------------------------------------------------------ actions

    private void openFunction(String key) {
        if (admin) {
            setResult(RESULT_OK, new Intent().putExtra(EXTRA_ACTION, key));
            finish();
            return;
        }
        Intent i = null;
        switch (key) {
            case "tab_home": i = tab(R.id.nav_home); break;
            case "tab_leaderboard": i = tab(R.id.nav_leaderboard); break;
            case "tab_profile": i = tab(R.id.nav_profile); break;
            case "wallet": i = new Intent(this, WalletActivity.class); break;
            case "my_matches": i = new Intent(this, MyMatchesStatusActivity.class).putExtra(MyMatchesStatusActivity.EXTRA_STATUS, MyMatchesStatusActivity.STATUS_UPCOMING); break;
            case "my_ongoing": i = new Intent(this, MyMatchesStatusActivity.class).putExtra(MyMatchesStatusActivity.EXTRA_STATUS, MyMatchesStatusActivity.STATUS_ONGOING); break;
            case "my_completed": i = new Intent(this, MyMatchesStatusActivity.class).putExtra(MyMatchesStatusActivity.EXTRA_STATUS, MyMatchesStatusActivity.STATUS_COMPLETED); break;
            case "notifications": NotificationsActivity.openAll(this); return;
            case "support_chat": i = new Intent(this, SupportChatActivity.class); break;
            case "customer_support": i = new Intent(this, CustomerSupportActivity.class); break;
            case "faq": i = new Intent(this, FaqActivity.class); break;
            case "terms": i = new Intent(this, TermsActivity.class); break;
            case "privacy": i = new Intent(this, PrivacyPolicyActivity.class); break;
            case "about": i = new Intent(this, AboutUsActivity.class); break;
            case "developer": i = new Intent(this, DeveloperProfileActivity.class); break;
            case "esports": i = new Intent(this, EsportsGalleryActivity.class); break;
            case "language": com.arenax.tournament.util.LanguageManager.showPicker(this); return;
            default: break;
        }
        if (i != null) startActivity(i);
    }

    private Intent tab(int navId) {
        return new Intent(this, MainActivity.class).putExtra("open_tab", navId)
                .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
    }

    private void openCategory(GameMode m) {
        if (admin) {
            setResult(RESULT_OK, new Intent().putExtra(EXTRA_ACTION, "category"));
            finish();
            return;
        }
        startActivity(new Intent(this, CategoryMatchesActivity.class)
                .putExtra("categoryId", m.getId()).putExtra("categoryTitle", m.getTitle()));
    }

    private void openMatch(Tournament t) {
        if (admin) {
            startActivity(new Intent(this, TournamentControlCenterActivity.class)
                    .putExtra("tournamentId", t.getId()).putExtra("title", t.getTitle()));
        } else if (Tournament.COMPLETED.equals(t.getEffectiveStatus())) {
            startActivity(new Intent(this, MatchResultActivity.class).putExtra("tournamentId", t.getId()));
        } else {
            startActivity(new Intent(this, TournamentDetailActivity.class).putExtra("tournament", t));
        }
    }

    @Override protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        playerGeneration++;
        if (matchListener != null) FirebaseRepository.tournaments().removeEventListener(matchListener);
        if (categoryListener != null) FirebaseRepository.gameModes().removeEventListener(categoryListener);
        super.onDestroy();
    }

    private TextView text(String s, float size, int color, boolean bold) {
        TextView v = new TextView(this);
        v.setText(s);
        v.setTextSize(size);
        v.setTextColor(color);
        v.setTypeface(null, bold ? Typeface.BOLD : Typeface.NORMAL);
        return v;
    }

    private int dp(int value) { return Math.round(value * getResources().getDisplayMetrics().density); }
}
