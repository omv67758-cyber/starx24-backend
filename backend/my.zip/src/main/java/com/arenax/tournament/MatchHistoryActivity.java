package com.arenax.tournament;

import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.arenax.tournament.data.FirebaseRepository;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.ValueEventListener;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/** Own match history + stats: matches played, wins, kills, coins won, and a list of every result. */
public class MatchHistoryActivity extends AppCompatActivity {
    private LinearLayout list;
    private TextView sMatches, sWins, sKills, sCoins;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xFFF6F8FC);

        LinearLayout bar = new LinearLayout(this);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setBackgroundColor(Color.WHITE);
        bar.setPadding(dp(16), dp(14), dp(16), dp(14));
        TextView back = text("\u2039", 28, 0xFF12172B, true);
        back.setPadding(0, 0, dp(16), 0);
        back.setOnClickListener(v -> finish());
        bar.addView(back);
        bar.addView(text("Match History & Stats", 18, 0xFF12172B, true));
        root.addView(bar);

        ScrollView scroll = new ScrollView(this);
        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(dp(16), dp(16), dp(16), dp(24));
        scroll.addView(body);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1f));

        LinearLayout stats = new LinearLayout(this);
        stats.setOrientation(LinearLayout.HORIZONTAL);
        sMatches = statBox(stats, "Matches");
        sWins = statBox(stats, "Wins");
        sKills = statBox(stats, "Kills");
        sCoins = statBox(stats, "Coins won");
        body.addView(stats);

        TextView head = text("RECENT MATCHES", 11.5f, 0xFF2F7BF0, true);
        head.setPadding(0, dp(20), 0, dp(6));
        body.addView(head);
        list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        body.addView(list);
        setContentView(root);
        load();
    }

    private void load() {
        String uid = FirebaseAuth.getInstance().getUid();
        if (uid == null || !FirebaseRepository.isReady(this)) {
            list.addView(text("Please sign in to see your history.", 14, 0xFF7A8091, false));
            return;
        }
        FirebaseRepository.tournaments().addListenerForSingleValueEvent(new ValueEventListener() {
            @Override public void onDataChange(@NonNull DataSnapshot snapshot) {
                long matches = 0, wins = 0, kills = 0, coins = 0;
                List<Object[]> rows = new ArrayList<>();   // {when, title, outcome, kills, coins}
                for (DataSnapshot t : snapshot.getChildren()) {
                    DataSnapshot r = t.child("results").child(uid);
                    if (!r.exists()) continue;
                    String outcome = String.valueOf(r.child("result").getValue()).toUpperCase(Locale.ROOT);
                    long k = num(r.child("kills").getValue());
                    long c = num(r.child("coins").getValue());
                    matches++;
                    if ("WIN".equals(outcome)) wins++;
                    kills += k;
                    coins += c;
                    long when = num(t.child("startAt").getValue());
                    if (when <= 0) when = num(t.child("resultPublishedAt").getValue());
                    rows.add(new Object[]{when, String.valueOf(t.child("title").getValue()), outcome, k, c});
                }
                sMatches.setText(String.valueOf(matches));
                sWins.setText(String.valueOf(wins));
                sKills.setText(String.valueOf(kills));
                sCoins.setText(String.valueOf(coins));
                java.util.Collections.sort(rows, (x, y) -> Long.compare((Long) y[0], (Long) x[0]));
                list.removeAllViews();
                if (rows.isEmpty()) {
                    list.addView(text("No finished matches yet. Join a match to build your history!", 14, 0xFF7A8091, false));
                    return;
                }
                SimpleDateFormat fmt = new SimpleDateFormat("dd MMM, hh:mm a", Locale.ENGLISH);
                for (Object[] row : rows) {
                    long when = (Long) row[0];
                    String outcome = (String) row[2];
                    int color = "WIN".equals(outcome) ? 0xFF18A957 : "REFUND".equals(outcome) ? 0xFFE08A00 : 0xFF7A8091;
                    LinearLayout card = new LinearLayout(MatchHistoryActivity.this);
                    card.setOrientation(LinearLayout.VERTICAL);
                    card.setPadding(dp(14), dp(12), dp(14), dp(12));
                    GradientDrawable bg = new GradientDrawable();
                    bg.setColor(Color.WHITE);
                    bg.setCornerRadius(dp(12));
                    card.setBackground(bg);
                    LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
                    lp.bottomMargin = dp(8);
                    card.addView(text(String.valueOf(row[1]), 14.5f, 0xFF12172B, true));
                    card.addView(text((when > 0 ? fmt.format(new Date(when)) : "—") + "  •  " + outcome
                            + "  •  " + row[3] + " kills  •  " + row[4] + " coins", 12, color, false));
                    list.addView(card, lp);
                }
            }
            @Override public void onCancelled(@NonNull DatabaseError error) {
                list.addView(text("Could not load history: " + error.getMessage(), 13, 0xFFD64545, false));
            }
        });
    }

    private TextView statBox(LinearLayout parent, String label) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER);
        box.setPadding(dp(4), dp(14), dp(4), dp(14));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.WHITE);
        bg.setCornerRadius(dp(12));
        box.setBackground(bg);
        TextView value = text("0", 20, 0xFF12172B, true);
        value.setGravity(Gravity.CENTER);
        TextView name = text(label, 11, 0xFF7A8091, false);
        name.setGravity(Gravity.CENTER);
        box.addView(value);
        box.addView(name);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        lp.rightMargin = dp(6);
        parent.addView(box, lp);
        return value;
    }

    private static long num(Object o) { return o instanceof Number ? ((Number) o).longValue() : 0L; }

    private TextView text(String s, float size, int color, boolean bold) {
        TextView v = new TextView(this);
        v.setText(s);
        v.setTextSize(size);
        v.setTextColor(color);
        if (bold) v.setTypeface(null, Typeface.BOLD);
        return v;
    }

    private int dp(int value) { return Math.round(value * getResources().getDisplayMetrics().density); }
}
