# AI Support Agent (Profile -> Support Agent (AI))

**Backend:** `POST /support/chat` in `backend/index.js` (Firebase login required, 12 msgs/min per user).
Uses OpenRouter (free models). Set env on Railway: `OPENROUTER_API_KEY` (required), `SUPPORT_AI_MODEL` (optional, default `openrouter/free`). Then redeploy.

**App:** `SupportChatActivity` + `WithdrawalApiClient.supportChat()` + new row in `fragment_profile.xml` / `ProfileFragment`.

Bot answers from built-in knowledge + the admin `faq` node in Firebase. It cannot see wallet/accounts and never promises refunds;
for such cases it shows a "Create support ticket" button (opens SupportActivity).

## Weird replies like "User Safety: safe / Response Safety: safe"
`openrouter/free` auto-picks ANY free model, sometimes a safety-classifier model (Llama Guard / Nemotron Safety).
Backend now discards such outputs and retries (up to 3 times). For best results pin a real chat model on Railway:
`SUPPORT_AI_MODEL=<chat-model-id>:free` (comma-separated list = fallback order).
