# STARX24 Admin Redesign — Deep Implementation Flow Prompt

You are working on the STARX24 / STARX24 Android tournament application. Redesign the complete admin panel to match the supplied mobile reference: clean white UI, compact top bar, blue/green/orange/purple metric cards, rounded cards, clear status pills, strong spacing, and a five-item bottom navigation. The old dark/red or legacy dashboard must not remain visible anywhere in the admin experience.

## Non-negotiable goals

1. Preserve existing Firebase and backend behavior unless a security or correctness bug is found.
2. Keep admin RBAC strict. Never expose controls that the current role cannot use.
3. Every major admin page must have its own XML layout or reusable XML component:
   - Dashboard
   - Banner management
   - Categories
   - Match management
   - Add/edit match
   - Room control
   - User management
   - User details
   - Payment management
   - Withdrawal requests
   - Transaction history
   - Notifications and activity logs
   - Settings
   - Quick actions/profile
4. Prefer XML + small adapters/fragments over a giant Java activity with all rendering logic inline.
5. All user-facing strings must be readable, consistent, and localizable.
6. Use loading, empty, error, and retry states for every Firebase/backend collection.
7. Use confirmation dialogs for destructive operations and show success/error feedback after every write.

## Visual system

- Background: warm white / very light grey.
- Cards: white, 1dp light grey stroke, 12–16dp radius, no heavy shadow.
- Primary action: blue or near-black depending on action importance.
- Positive: green; pending: amber; rejected/destructive: red; analytics/secondary: purple.
- Typography: 20–22sp page title, 16–18sp section title, 11–13sp metadata, bold numbers.
- Touch targets: minimum 44dp.
- Spacing: 8dp grid, 14–16dp screen padding.
- Bottom navigation: Dashboard, Banners, Categories, Matches, More.
- Add a compact page header with back button, page title and contextual action.

## Data and connection rules

### Firebase

- Use existing `FirebaseRepository` and existing database paths.
- Never allow a normal authenticated user to write admin-only data.
- Keep user-visible data reads minimal; do not expose private user fields to unrelated users.
- For user lists, use paging/limited queries where possible.
- For matches, show live status from Firebase and refresh after create/edit/delete.

### Backend/payment

- All money actions must stay server-authoritative:
  - Create deposit order
  - Verify payment
  - Request withdrawal
  - Approve/reject withdrawal
  - Leave paid match and refund
- Android app must send Firebase ID token only; never embed payment provider secrets or service-account keys.
- Prevent duplicate actions with disabled buttons, request IDs/idempotency, backend transaction guards, and clear retry behavior.
- Never mark a deposit successful only because the payment page opened.
- Withdrawal states must be explicit: PENDING, PAID, REJECTED, REFUNDED/FAILED where applicable.
- Show amount, user, UPI ID masking, timestamps, request ID, and current status.
- Payment admin role must see only payment pages; match roles must not see money controls.

## Page implementation checklist

### Dashboard
- Header with admin identity, search, notifications, settings.
- Metric cards: total users, total matches, upcoming matches, completed matches, deposits, withdrawals, pending payments, revenue.
- Featured banner preview.
- Quick actions: Add Match, Add Banner, Manage Users, Payment Settings, View Transactions.
- Recent matches list with image, title, category, time, entry fee, prize pool, player count and status.

### Banner management
- Banner preview at top.
- Add/edit/delete banner.
- Enable/disable toggle.
- Upload URL/file state.
- Display order.
- Firebase update with success/error result.

### Categories
- 2-column responsive cards.
- Icon/image, title, match count, active status.
- Edit and delete actions with RBAC checks.

### Matches
- Filter tabs: All, Live, Upcoming, Completed.
- Match cards with banner, title, mode, entry fee, prize pool, players, status.
- Add Match screen with dedicated XML and validation.
- Edit Match screen with preserved existing data.
- Room control screen with masked/revealable room ID/password and reveal schedule.

### Users
- Search field.
- User card with avatar, name, ID, online state, match count, wallet summary.
- User details screen with deposits, withdrawals, winnings, recent transactions.
- Block/unblock must require confirmation and write an activity log.

### Payments
- Tabs: Add Money, Withdrawals, Transactions.
- Pending cards with approve/reject buttons.
- Disable buttons while request is running.
- Show backend error message and retry option.
- Never silently modify wallet balance from Android.

### Notifications/activity
- Notification composer with audience, match selection, title, body, optional room details and schedule.
- Activity log should show actor, action, target, timestamp, result.

### Settings
- App settings, payment settings, notification settings, security/RBAC, backup/restore guidance, about.
- Sensitive configuration must never be editable into the APK or stored as plain text locally.

## Verification plan

1. Run XML/resource validation.
2. Run all Gradle flavors: user, admin, messenger.
3. Test each role: SUPER_ADMIN, PAYMENT_ADMIN, MATCH_ADMIN, TOURNAMENT_MANAGER, SUPPORT_AGENT, MODERATOR.
4. Test offline, timeout, cold backend, duplicate tap, duplicate webhook, and stale Firebase data.
5. Test a normal player after every admin write: match appears, slots update, room release appears, notification arrives, wallet/transaction history remains consistent.
6. Compare every screen against the supplied reference image and remove any old legacy styling.
7. Before release, verify Firebase rules with emulator tests and verify production payment webhooks with signed test events.

## Delivery

- Source code with separate XML layouts/components.
- Updated Java/Kotlin navigation and adapters.
- Updated colors, styles, drawables and dimensions.
- A short changelog listing each redesigned page.
- Build output or a clear build-blocker message if Android SDK/configuration is unavailable.
