# Admin Panel Redesign Changelog

## Implemented in this pass

The admin home/dashboard XML was replaced with a clean reference-aligned mobile-first layout: compact STARX24 header, search/notification/settings actions, greeting hero, live overview area, reusable metric-card styling, featured banners, categories, recent matches, broadcast notice, role-aware platform controls, and a five-item bottom navigation.

The Firebase and backend Java behavior was intentionally preserved. Existing view IDs used by `AdminActivity` remain available, including role-gated navigation IDs, data list IDs, dashboard actions, payment-related workspace access, and the existing live listeners.

Reusable XML components were added for metric cards, section headers, page shells, match rows, and admin surface cards. A dedicated implementation flow prompt documents the remaining page-by-page XML migration and payment/withdrawal verification strategy.

## Verification

- Java-to-XML admin view-ID compatibility: passed; no required `admin_*` IDs are missing.
- XML parser validation: passed for the new admin XML resources.
- Gradle build: blocked in the current sandbox because no Android SDK is installed/configured (`ANDROID_HOME` is empty and `sdk.dir` is unavailable). This is an environment blocker, not a reported Java/resource compile error.

## Dense workspace pass

The shared Java-rendered workspace theme was tightened for desktop-like density: human-readable page titles, smaller metadata, compact 44dp actions, blue primary actions, lighter spacing, and reference-aligned payment tabs (`Transactions`, `Add Money`, `Withdrawals`). Existing live payment, withdrawal, user, match, room-control, moderation, notifications and role flows remain connected to their existing Firebase/backend methods.

## Pixel-focused density pass

The reference measurements were tightened for the target compact layout: 56dp top bar, 56dp bottom navigation, 100dp banner rail, 78dp overview cards, 64dp quick-action tiles, 10dp compact action radius, 44dp workspace actions, and smaller page typography. The goal is a dense desktop-like control surface on phone and tablet widths while retaining the supplied navigation structure.

## Category-only full-screen match flow

- Removed global/dashboard Add Match entry points.
- Categories workspace now renders clickable category cards.
- Category tap opens a full-screen white `BR Match Management` style page.
- The category page shows dense match cards with image, title, date/time, entry, prize pool, players, status, Edit, Delete and View Details actions.
- `+ Add Match` exists only in the selected category page and opens the full-screen `MatchScheduleActivity`.
- Match scheduling form was moved to a simple white full-screen theme; no floating add-match dialog is used for this flow.

## Build error fix

Fixed AAPT resource-linking failure in `item_admin_category_match.xml`: malformed `@color:text_secondary`-style references were corrected to Android's valid `@color/text_secondary` syntax (and all color references in that layout were scanned).

## Room-only match details and targeted scheduled notification

Removed the notification composer/center from Match View Details. The detail page now contains only room credential entry and schedule controls. Saving a fixed schedule writes the room release schedule and registers the exact alarm. At the fixed time the receiver releases the room, sends FCM only to users under the match participants node, and writes one durable `/notifications` inbox record per joined user so it remains visible after the match ends. Home notification controls remain separate.

## Compact banner rendering

Featured banners now use a dedicated compact adapter with a fixed 270dp x 92dp thumbnail, `CENTER_CROP`, rounded light background, placeholder/error fallback, and a correctly sized horizontal list. This keeps banner presentation visually consistent with the small match thumbnails instead of stretching the banner across the page.

## Dashboard cleanup and workspace cards

Removed Recent Matches from the admin home dashboard. Replaced plain workspace access buttons with clickable light-color cards that show a related icon above each workspace label. Added a black outlined user-home notice card background while preserving the existing Firebase homeNotice behavior.

## Analytics crash fix

Replaced unsupported Firebase `getValue(Number.class)` calls with safe raw-value numeric parsing. This prevents the Analytics screen from crashing when Firebase returns primitive Long/Double values.

## Reference-aligned admin screens

- Feature banner cards retain a visible light outline and reduced radius.
- Category match management now uses a full-screen white page with one `+ Add Match` action; Ongoing/Upcoming/Resulted tabs were removed.
- Added a dedicated full-screen `BannerEditorActivity` instead of the floating banner dialog.
- Added a compact admin tournament card layout with smaller height, visible text, light outlined action buttons and reduced radii.
- Converted the match scheduler form from dark styling to compact white styling with readable dark text and light outlined buttons.
- Tuned the category editor and admin login copy/layout toward the supplied white reference screens.

## Build error fix

- Fixed `AdminActivity.java:1802` `illegal start of expression` caused by an unclosed block comment left behind when replacing the floating banner dialog with `BannerEditorActivity`.
- The deprecated dialog code is now correctly closed/commented and the new full-screen banner activity remains the active flow.
