#!/data/data/com.termux/files/usr/bin/bash
# deploy_rules.sh — database.rules.json ko Firebase Realtime Database par publish karta hai.
#
# Usage:
#   bash /storage/emulated/0/tournament_app_msking/deploy_rules.sh
#
# Ye script project root me hi rakho (jaha database.rules.json hai).
# Pehli baar Google login maangega (link open karo, code yahan paste karo).

set -e

PROJECT_ID="tournament-app-82b33"
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
RULES_FILE="$SCRIPT_DIR/database.rules.json"

if [ ! -f "$RULES_FILE" ]; then
  echo "❌ database.rules.json nahi mila: $RULES_FILE"
  exit 1
fi

# ---- 1. JSON valid hai ya nahi ----
if command -v python3 >/dev/null 2>&1; then
  python3 -c "import json,sys; json.load(open(sys.argv[1]))" "$RULES_FILE" \
    || { echo "❌ database.rules.json me JSON error hai."; exit 1; }
  echo "✅ Rules JSON valid hai"
fi

# ---- 2. nodejs + firebase-tools install (agar nahi hai) ----
if ! command -v node >/dev/null 2>&1; then
  echo "📦 nodejs install ho raha hai..."
  pkg update -y && pkg install -y nodejs
fi
if ! command -v firebase >/dev/null 2>&1; then
  echo "📦 firebase-tools install ho raha hai (thoda time lagega)..."
  npm install -g firebase-tools
fi

# ---- 3. Home folder me temporary deploy folder (storage me permission issues aate hain) ----
WORK="$HOME/.starx_rules_deploy"
rm -rf "$WORK"
mkdir -p "$WORK"
cp "$RULES_FILE" "$WORK/database.rules.json"
cat > "$WORK/firebase.json" <<'EOF'
{
  "database": {
    "rules": "database.rules.json"
  }
}
EOF
cd "$WORK"

# ---- 4. Login check ----
if ! firebase projects:list >/dev/null 2>&1; then
  echo "🔑 Firebase login chahiye. Jo link aaye use browser me kholo, Google account se allow karo,"
  echo "   aur jo code mile wo yahan paste karo."
  firebase login --no-localhost
fi

# ---- 5. Deploy ----
echo "🚀 Rules publish ho rahe hain: $PROJECT_ID"
firebase deploy --only database --project "$PROJECT_ID"

echo
echo "✅ Done! Ab admin panel me Privacy Policy / Terms / About Us card dobara kholo."
