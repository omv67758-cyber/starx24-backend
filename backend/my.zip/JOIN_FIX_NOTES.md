# Join / slot fixes

## backend/index.js  (redeploy backend)
1. 0-coin join: debit transaction returned `null` when wallet node was missing -> Firebase COMMITTED it with no
   debit, so players with 0 coins joined paid matches. Now: wallet pre-read, early reject BEFORE any slot is
   claimed ("You have X coins but need Y"), null wallet aborts, commit without a real wallet is rolled back.
2. Failed join (no coins) never keeps a slot: slots / participant / joinedSlots are only written after the debit succeeds.
3. Slot reconciler now rebuilds slotIndex + joinedSlots from REGISTERED participants (single source of truth),
   releases ghost TAKEN slots, so list "2/40", detail "0/40" and slot picker all agree. Runs every 60s.

## Android
- JoinMatchActivity: CANCEL (black) button removed, JOIN NOW full width; client pre-check for coins
  (dialog with ADD COINS) before any request.
- TournamentDetailActivity: detail counter counts slots (same as list).

## Update
- Reconciler also deletes abandoned RESERVING participant records (>2 min), so unpaid joins never count anywhere.
- FirebaseRepository.promoteNextFromWaitlist: refused on paid matches (it created a free REGISTERED participant, no debit).
- Match detail page: "Joined Players" card is now visible to everyone, right below RULES, as a numbered list of in-game names only (no UID, no slot box). Files: activity_tournament_detail.xml, TournamentDetailActivity.java, util/JoinedPlayersList.java.
- AI support chat (backend /support/chat): prompt limited replies to English/Hindi/Hinglish; now replies in whatever language the user writes.
